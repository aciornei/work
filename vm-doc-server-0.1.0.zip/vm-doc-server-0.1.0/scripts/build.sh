#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
go mod download
gofmt -w cmd internal migrations openapi web tools
go test ./...
make build

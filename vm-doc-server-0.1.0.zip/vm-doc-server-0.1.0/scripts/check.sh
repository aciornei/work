#!/usr/bin/env bash
set -euo pipefail
BASE_URL="${1:-http://127.0.0.1:9080}"
curl --fail --silent --show-error "$BASE_URL/healthz"; echo
curl --fail --silent --show-error "$BASE_URL/readyz"; echo
curl --fail --silent --show-error "$BASE_URL/version"; echo

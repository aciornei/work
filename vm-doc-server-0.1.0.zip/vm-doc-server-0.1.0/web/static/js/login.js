const form = document.getElementById('loginForm');
const username = document.getElementById('username');
const password = document.getElementById('password');
const errorBox = document.getElementById('loginError');
const oidcLogin = document.getElementById('oidcLogin');

(async () => {
  try {
    const response = await fetch('/api/v1/auth/providers');
    if (!response.ok) return;
    const providers = await response.json();
    form.hidden = !providers.ldap;
    oidcLogin.hidden = !providers.oidc;
  } catch (_) {}
})();

(async () => {
  try {
    const response = await fetch('/api/v1/auth/me');
    if (response.ok) location.href = '/';
  } catch (_) {}
})();

form.addEventListener('submit', async event => {
  event.preventDefault();
  errorBox.textContent = '';
  try {
    const response = await fetch('/api/v1/auth/ldap/login', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({username: username.value, password: password.value})
    });
    if (response.ok) {
      location.href = '/';
      return;
    }
    const body = await response.json().catch(() => ({}));
    errorBox.textContent = body.message || 'Autentificare eșuată.';
  } catch (_) {
    errorBox.textContent = 'Serverul nu este disponibil.';
  }
});

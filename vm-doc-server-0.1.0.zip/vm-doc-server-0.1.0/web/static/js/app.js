const state={user:null,csrf:'',agents:[]};
const content=document.getElementById('content');
const title=document.getElementById('pageTitle');
const subtitle=document.getElementById('pageSubtitle');
const dialog=document.getElementById('agentDialog');
const form=document.getElementById('agentForm');
const agentId=document.getElementById('agentId');
const agentName=document.getElementById('agentName');
const agentURL=document.getElementById('agentURL');
const agentToken=document.getElementById('agentToken');
const agentInterval=document.getElementById('agentInterval');
const agentTimeout=document.getElementById('agentTimeout');
const agentOffline=document.getElementById('agentOffline');
const agentEnabled=document.getElementById('agentEnabled');
const agentVerifyTLS=document.getElementById('agentVerifyTLS');

const rolePermissions={
  admin:new Set(['*']),
  operator:new Set(['dashboard.read','agents.read','agents.manage','collections.read','collections.run','inventories.read','inventories.raw.read']),
  viewer:new Set(['dashboard.read','agents.read','collections.read','inventories.read']),
  auditor:new Set(['dashboard.read','agents.read','collections.read','inventories.read','inventories.raw.read','audit.read'])
};
function can(permission){return (state.user?.roles||[]).some(role=>rolePermissions[role]?.has('*')||rolePermissions[role]?.has(permission))}

async function api(path,options={}){
  const headers={Accept:'application/json',...(options.headers||{})};
  if(options.body&&!headers['Content-Type'])headers['Content-Type']='application/json';
  if(!['GET','HEAD'].includes((options.method||'GET').toUpperCase())&&state.csrf)headers['X-CSRF-Token']=state.csrf;
  const response=await fetch(path,{...options,headers});
  if(response.status===401){location.href='/login';throw new Error('Sesiunea a expirat.');}
  const type=response.headers.get('content-type')||'';
  const body=response.status===204?null:type.includes('json')?await response.json():await response.text();
  if(!response.ok)throw new Error(body?.message||body?.error||`HTTP ${response.status}`);
  return body;
}
const e=v=>String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const dt=v=>v?new Date(v).toLocaleString('ro-RO'):'—';
const badge=v=>`<span class="badge ${e(v)}">${e(v)}</span>`;
function toast(message,error=false){const box=document.getElementById('toast');box.textContent=message;box.className=`toast show${error?' error':''}`;setTimeout(()=>box.className='toast',2800)}
function pageMeta(name,sub){title.textContent=name;subtitle.textContent=sub||''}
function panel(head,body,tools=''){return `<section class="panel"><div class="panel-header"><h2>${head}</h2><div class="toolbar">${tools}</div></div>${body}</section>`}
function empty(text){return `<div class="empty">${e(text)}</div>`}

async function init(){
  try{state.user=await api('/api/v1/auth/me');state.csrf=state.user.csrf_token;document.getElementById('currentUser').textContent=state.user.display_name||state.user.username;document.querySelector('[data-page="audit"]').hidden=!can('audit.read');document.querySelector('[data-page="access"]').hidden=!can('rbac.manage');document.body.classList.remove('booting');route();}
  catch{location.href='/login'}
}

async function route(){
  const raw=(location.hash||'#dashboard').slice(1);const [page,id]=raw.split('/');
  document.querySelectorAll('#nav a[data-page]').forEach(a=>a.classList.toggle('active',a.dataset.page===page));
  content.innerHTML='<div class="loading">Se încarcă…</div>';
  try{
    if(page==='dashboard')await dashboard();
    else if(page==='agents')await agentsPage();
    else if(page==='vms'&&id)await vmDetail(id);
    else if(page==='vms')await vmsPage();
    else if(page==='audit')await auditPage();
    else if(page==='access')await accessPage();
    else location.hash='#dashboard';
  }catch(err){content.innerHTML=empty(err.message);toast(err.message,true)}
}

async function dashboard(){
  pageMeta('Dashboard','Starea centralizată a platformei');
  const d=await api('/api/v1/dashboard');
  content.innerHTML=`<div class="cards">
    <div class="card"><div class="label">Agenți configurați</div><div class="value">${d.agents_total}</div></div>
    <div class="card"><div class="label">Agenți online</div><div class="value">${d.agents_online}</div></div>
    <div class="card"><div class="label">VM-uri inventariate</div><div class="value">${d.vms}</div></div>
    <div class="card"><div class="label">Joburi în așteptare</div><div class="value">${d.jobs_pending}</div></div>
  </div>${panel('Flux operațional',`<div class="detail-grid"><div class="detail-item"><span>1. Agent</span>Expune inventarul pe portul 9078</div><div class="detail-item"><span>2. Collector</span>Interoghează și validează inventarul</div><div class="detail-item"><span>3. MariaDB</span>Păstrează snapshoturi și audit</div><div class="detail-item"><span>4. Server</span>Expune API-ul și interfața</div></div>`)}`;
}

async function agentsPage(){
  pageMeta('Agenți','Administrare, conectivitate și colectare');state.agents=await api('/api/v1/agents');
  const rows=state.agents.map(a=>{const actions=[can('collections.run')?`<button class="small secondary" data-action="test" data-id="${a.id}">Test</button><button class="small" data-action="collect" data-id="${a.id}">Colectează</button>`:'',can('agents.manage')?`<button class="small secondary" data-action="edit" data-id="${a.id}">Editează</button><button class="small danger" data-action="delete" data-id="${a.id}">Șterge</button>`:''].join('');return `<tr><td><strong>${e(a.name)}</strong><div class="muted mono">${e(a.base_url)}</div></td><td>${badge(a.status)}</td><td>${e(a.agent_uuid||'—')}</td><td>${dt(a.last_contact_at)}</td><td class="muted">${e(a.last_error||'—')}</td><td><div class="actions">${actions||'—'}</div></td></tr>`}).join('');
  content.innerHTML=panel('Lista agenților',state.agents.length?`<table><thead><tr><th>Agent</th><th>Status</th><th>UUID</th><th>Ultimul contact</th><th>Ultima eroare</th><th>Acțiuni</th></tr></thead><tbody>${rows}</tbody></table>`:empty('Nu există agenți configurați.'),can('agents.manage')?'<button id="newAgent">Adaugă agent</button>':'');
  const newAgentButton=document.getElementById('newAgent');if(newAgentButton)newAgentButton.onclick=()=>openAgent();
  content.querySelectorAll('[data-action]').forEach(b=>b.onclick=()=>agentAction(b.dataset.action,Number(b.dataset.id)));
}

function openAgent(agent=null){
  document.getElementById('agentDialogTitle').textContent=agent?'Editare agent':'Agent nou';
  agentId.value=agent?.id||'';agentName.value=agent?.name||'';agentURL.value=agent?.base_url||'';agentToken.value='';agentToken.required=!agent;
  agentInterval.value=agent?.collection_interval_seconds||900;agentTimeout.value=agent?.request_timeout_seconds||45;agentOffline.value=agent?.offline_after_seconds||2700;agentEnabled.checked=agent?.enabled??true;agentVerifyTLS.checked=agent?.verify_tls??true;dialog.showModal();
}
async function agentAction(action,id){
  const agent=state.agents.find(a=>a.id===id);
  if(action==='edit'){openAgent(agent);return}
  if(action==='delete'){if(!confirm(`Ștergi agentul ${agent.name}? Istoricul lui va fi șters.`))return;await api(`/api/v1/agents/${id}`,{method:'DELETE'});toast('Agent șters.');agentsPage();return}
  const job=await api(`/api/v1/agents/${id}/${action==='test'?'test':'collect'}`,{method:'POST'});toast(`Job ${job.id} introdus în coadă.`);setTimeout(agentsPage,1200);
}
form.addEventListener('submit',async event=>{
  event.preventDefault();
  const id=Number(agentId.value||0);const body={name:agentName.value.trim(),base_url:agentURL.value.trim(),token:agentToken.value,enabled:agentEnabled.checked,verify_tls:agentVerifyTLS.checked,collection_interval_seconds:Number(agentInterval.value),request_timeout_seconds:Number(agentTimeout.value),offline_after_seconds:Number(agentOffline.value)};
  if(id&&!body.token)delete body.token;
  try{await api(id?`/api/v1/agents/${id}`:'/api/v1/agents',{method:id?'PATCH':'POST',body:JSON.stringify(body)});dialog.close();toast(id?'Agent actualizat.':'Agent creat.');agentsPage()}catch(err){toast(err.message,true)}
});

async function vmsPage(){
  pageMeta('VM-uri','Inventarul curent al sistemelor');const vms=await api('/api/v1/vms');
  const rows=vms.map(v=>`<tr><td><a href="#vms/${v.agent_id}"><strong>${e(v.hostname||`Agent ${v.agent_id}`)}</strong></a></td><td>${e(v.os_name)} ${e(v.os_version)}</td><td class="mono">${e(v.primary_ip||'—')}</td><td>${e(v.schema_version||'—')}</td><td>${dt(v.received_at)}</td><td>${v.changed_from_previous?badge('changed'):badge('same')}</td></tr>`).join('');
  content.innerHTML=panel('Inventare curente',vms.length?`<table><thead><tr><th>Hostname</th><th>Sistem de operare</th><th>IP principal</th><th>Schemă</th><th>Colectat</th><th>Schimbare</th></tr></thead><tbody>${rows}</tbody></table>`:empty('Nu există încă inventare colectate.'));
}

async function vmDetail(id){
  const data=await api(`/api/v1/vms/${id}`);const a=data.agent,v=data.inventory||{};pageMeta(v.hostname||a.name,'Detalii inventar și istoric');
  content.innerHTML=`<div class="cards"><div class="card"><div class="label">Status agent</div><div class="value" style="font-size:20px">${badge(a.status)}</div></div><div class="card"><div class="label">Sistem de operare</div><div class="value" style="font-size:18px">${e(v.os_name||'—')}</div><div class="muted">${e(v.os_version||'')}</div></div><div class="card"><div class="label">IP principal</div><div class="value mono" style="font-size:20px">${e(v.primary_ip||'—')}</div></div><div class="card"><div class="label">Ultimul inventar</div><div class="value" style="font-size:16px">${dt(v.received_at)}</div></div></div>
  ${panel('Prezentare',`<div class="detail-grid"><div class="detail-item"><span>Hostname</span>${e(v.hostname||'—')}</div><div class="detail-item"><span>UUID agent</span><span class="mono">${e(v.agent_uuid||a.agent_uuid||'—')}</span></div><div class="detail-item"><span>Schemă JSON</span>${e(v.schema_version||'—')}</div><div class="detail-item"><span>Boot time</span>${dt(v.boot_time)}</div><div class="detail-item"><span>Colectoare OK</span>${v.collector_ok??0} / ${v.collector_total??0}</div><div class="detail-item"><span>Erori colectoare</span>${v.collector_error??0}</div><div class="detail-item"><span>Timeout colectoare</span>${v.collector_timeout??0}</div><div class="detail-item"><span>Dimensiune JSON</span>${v.payload_size??0} bytes</div></div>`,`${can('collections.run')?'<button id="collectVM">Colectează acum</button>':''}<button id="historyVM" class="secondary">Istoric</button>${can('inventories.raw.read')?'<button id="rawVM" class="secondary">JSON brut</button>':''}`)}`;
  const collectButton=document.getElementById('collectVM');if(collectButton)collectButton.onclick=async()=>{const j=await api(`/api/v1/agents/${id}/collect`,{method:'POST'});toast(`Job ${j.id} introdus în coadă.`)};
  document.getElementById('historyVM').onclick=()=>showHistory(id);
  const rawButton=document.getElementById('rawVM');if(rawButton)rawButton.onclick=()=>showRaw(v.id);
}
async function showHistory(agentId){const list=await api(`/api/v1/vms/${agentId}/inventories`);content.insertAdjacentHTML('beforeend',panel('Istoric inventare',list.length?`<table><thead><tr><th>ID</th><th>Colectat</th><th>Hash</th><th>Schimbat</th><th></th></tr></thead><tbody>${list.map(v=>`<tr><td>${v.id}</td><td>${dt(v.received_at)}</td><td class="mono">${e(v.payload_sha256.slice(0,16))}…</td><td>${v.changed_from_previous?'Da':'Nu'}</td><td>${can('inventories.raw.read')?`<button class="small secondary raw-history" data-id="${v.id}">JSON</button>`:'—'}</td></tr>`).join('')}</tbody></table>`:empty('Istoricul este gol.')));content.querySelectorAll('.raw-history').forEach(b=>b.onclick=()=>showRaw(b.dataset.id))}
async function showRaw(id){if(!id){toast('Inventarul nu există.',true);return}const r=await fetch(`/api/v1/inventories/${id}/raw`);if(!r.ok){toast('Nu se poate încărca JSON-ul.',true);return}const text=await r.text();let pretty=text;try{pretty=JSON.stringify(JSON.parse(text),null,2)}catch{}content.insertAdjacentHTML('beforeend',panel(`JSON brut · inventar ${id}`,`<pre class="json">${e(pretty)}</pre>`));window.scrollTo({top:document.body.scrollHeight,behavior:'smooth'})}

async function auditPage(){pageMeta('Audit','Acțiuni administrative și colectări');const rows=await api('/api/v1/audit/events');content.innerHTML=panel('Evenimente recente',rows.length?`<table><thead><tr><th>Data</th><th>Sursă</th><th>Actor</th><th>Acțiune</th><th>Resursă</th><th>Rezultat</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${dt(r.occurred_at)}</td><td>${e(r.source)}</td><td>${e(r.actor_username||'sistem')}</td><td class="mono">${e(r.action)}</td><td>${e(r.resource_type)} ${e(r.resource_id)}</td><td>${badge(r.outcome)}</td></tr>`).join('')}</tbody></table>`:empty('Nu există evenimente de audit.'))}

async function accessPage(){pageMeta('Acces','Mapări grupuri LDAP/OIDC către roluri');const [roles,maps]=await Promise.all([api('/api/v1/rbac/roles'),api('/api/v1/rbac/group-mappings')]);content.innerHTML=`${panel('Adaugă mapare',`<form id="mappingForm" class="detail-grid"><label>Provider<select id="mapProvider"><option value="ldap">LDAP</option><option value="oidc">OIDC</option><option value="any">Oricare</option></select></label><label>Grup<input id="mapGroup" required placeholder="VM-DOC-Operators"></label><label>Rol<select id="mapRole">${roles.map(r=>`<option value="${e(r.name)}">${e(r.name)}</option>`).join('')}</select></label><label style="align-self:end"><button type="submit">Adaugă</button></label></form>`)}${panel('Mapări existente',maps.length?`<table><thead><tr><th>Provider</th><th>Grup</th><th>Rol</th><th></th></tr></thead><tbody>${maps.map(m=>`<tr><td>${e(m.provider)}</td><td class="mono">${e(m.group_name)}</td><td>${badge(m.role)}</td><td><button class="small danger del-map" data-id="${m.id}">Șterge</button></td></tr>`).join('')}</tbody></table>`:empty('Nu există mapări.'))}`;
  const mapProvider=document.getElementById('mapProvider'),mapGroup=document.getElementById('mapGroup'),mapRole=document.getElementById('mapRole');document.getElementById('mappingForm').onsubmit=async ev=>{ev.preventDefault();await api('/api/v1/rbac/group-mappings',{method:'POST',body:JSON.stringify({provider:mapProvider.value,group_name:mapGroup.value.trim(),role:mapRole.value})});toast('Mapare creată. Va fi aplicată la următoarea autentificare.');accessPage()};content.querySelectorAll('.del-map').forEach(b=>b.onclick=async()=>{await api(`/api/v1/rbac/group-mappings/${b.dataset.id}`,{method:'DELETE'});toast('Mapare ștearsă.');accessPage()})
}

document.getElementById('logoutButton').onclick=async()=>{await api('/api/v1/auth/logout',{method:'POST'});location.href='/login'};
document.getElementById('themeButton').onclick=()=>{const next=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=next;localStorage.setItem('vm-doc-theme',next)};
const savedTheme=localStorage.getItem('vm-doc-theme');if(savedTheme)document.documentElement.dataset.theme=savedTheme;
window.addEventListener('hashchange',route);init();

document.querySelectorAll('[data-close-dialog]').forEach(button=>button.addEventListener('click',()=>dialog.close()));

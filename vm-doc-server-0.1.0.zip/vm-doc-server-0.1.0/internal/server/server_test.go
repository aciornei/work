package server

import (
	"net/http/httptest"
	"testing"
)

func TestResolvedClientIPUsesRightmostUntrustedHop(t *testing.T) {
	r := httptest.NewRequest("GET", "https://vm-doc.example.ro/", nil)
	r.RemoteAddr = "127.0.0.1:43210"
	r.Header.Set("X-Forwarded-For", "203.0.113.200, 198.51.100.10")
	got := resolvedClientIP(r, []string{"127.0.0.1/32"})
	if got != "198.51.100.10" {
		t.Fatalf("resolved client IP %q, want 198.51.100.10", got)
	}
}

func TestResolvedClientIPIgnoresForwardedHeaderFromUntrustedPeer(t *testing.T) {
	r := httptest.NewRequest("GET", "https://vm-doc.example.ro/", nil)
	r.RemoteAddr = "192.0.2.44:43210"
	r.Header.Set("X-Forwarded-For", "203.0.113.200")
	got := resolvedClientIP(r, []string{"127.0.0.1/32"})
	if got != "192.0.2.44" {
		t.Fatalf("resolved client IP %q, want direct peer", got)
	}
}

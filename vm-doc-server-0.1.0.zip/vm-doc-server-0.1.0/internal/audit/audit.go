package audit

import (
	"context"
	"database/sql"
	"encoding/json"
	"time"
)

type Event struct {
	Source        string
	ActorUserID   *int64
	ActorUsername string
	Action        string
	ResourceType  string
	ResourceID    string
	Outcome       string
	RequestID     string
	IPAddress     string
	UserAgent     string
	Details       any
}

type Service struct{ DB *sql.DB }

func (s Service) Log(ctx context.Context, e Event) error {
	if e.Source == "" {
		e.Source = "server"
	}
	if e.Outcome == "" {
		e.Outcome = "success"
	}
	b, err := json.Marshal(e.Details)
	if err != nil {
		return err
	}
	if string(b) == "null" {
		b = []byte("{}")
	}
	_, err = s.DB.ExecContext(ctx, `INSERT INTO audit_events(occurred_at,source,actor_user_id,actor_username,action,resource_type,resource_id,outcome,request_id,ip_address,user_agent,details_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`, time.Now().UTC(), e.Source, e.ActorUserID, e.ActorUsername, e.Action, e.ResourceType, e.ResourceID, e.Outcome, e.RequestID, e.IPAddress, e.UserAgent, b)
	return err
}

type Record struct {
	ID            int64           `json:"id"`
	OccurredAt    time.Time       `json:"occurred_at"`
	Source        string          `json:"source"`
	ActorUsername string          `json:"actor_username"`
	Action        string          `json:"action"`
	ResourceType  string          `json:"resource_type"`
	ResourceID    string          `json:"resource_id"`
	Outcome       string          `json:"outcome"`
	IPAddress     string          `json:"ip_address"`
	Details       json.RawMessage `json:"details"`
}

func (s Service) List(ctx context.Context, limit int) ([]Record, error) {
	if limit <= 0 || limit > 1000 {
		limit = 200
	}
	rows, err := s.DB.QueryContext(ctx, `SELECT id,occurred_at,source,actor_username,action,resource_type,resource_id,outcome,ip_address,details_json FROM audit_events ORDER BY id DESC LIMIT ?`, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []Record
	for rows.Next() {
		var r Record
		if err := rows.Scan(&r.ID, &r.OccurredAt, &r.Source, &r.ActorUsername, &r.Action, &r.ResourceType, &r.ResourceID, &r.Outcome, &r.IPAddress, &r.Details); err != nil {
			return nil, err
		}
		out = append(out, r)
	}
	return out, rows.Err()
}

package rbac

import "testing"

func TestAllowed(t *testing.T) {
	if !Allowed([]string{"operator"}, "collections.run") {
		t.Fatal("operator should be allowed to run collections")
	}
	if Allowed([]string{"viewer"}, "agents.manage") {
		t.Fatal("viewer should not be allowed to manage agents")
	}
	if !Allowed([]string{"admin"}, "anything") {
		t.Fatal("admin wildcard permission is not effective")
	}
}

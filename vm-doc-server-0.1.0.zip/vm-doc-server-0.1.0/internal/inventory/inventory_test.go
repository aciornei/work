package inventory

import "testing"

func TestSummarizeSchemaTwoInventory(t *testing.T) {
	raw := []byte(`{
	  "schema": {"name": "vm-doc-agent-inventory", "version": "2.0"},
	  "generated_at": "2026-08-25T08:30:00Z",
	  "identity": {"hostname": "vm-app-01", "uuid": "host-uuid-123"},
	  "os": {"name": "Ubuntu", "version": "20.04"},
	  "system": {"boot_time": "2026-08-20T06:00:00Z"},
	  "network": {
	    "interfaces": [
	      {"name": "lo", "addresses": ["127.0.0.1/8"]},
	      {"name": "eth0", "addresses": ["10.20.30.40/24"]}
	    ]
	  },
	  "storage": {"partitions": [{"name": "/", "uuid": "partition-uuid-wrong"}]},
	  "collectors": {
	    "system": {"status": "ok"},
	    "network": {"status": "ok"},
	    "filebeat": {"status": "error"},
	    "ntp": {"status": "timeout"}
	  }
	}`)

	s, err := Summarize(raw)
	if err != nil {
		t.Fatal(err)
	}
	if s.SchemaVersion != "2.0" || s.AgentUUID != "host-uuid-123" || s.Hostname != "vm-app-01" {
		t.Fatalf("unexpected identity summary: %+v", s)
	}
	if s.OSName != "Ubuntu" || s.OSVersion != "20.04" {
		t.Fatalf("unexpected OS summary: %+v", s)
	}
	if s.PrimaryIP != "10.20.30.40" {
		t.Fatalf("primary IP %q, want 10.20.30.40", s.PrimaryIP)
	}
	if s.CollectorTotal != 4 || s.CollectorOK != 2 || s.CollectorError != 1 || s.CollectorTimeout != 1 {
		t.Fatalf("unexpected collector counts: %+v", s)
	}
	if s.BootTime == nil || s.CollectedAt == nil {
		t.Fatalf("times were not parsed: %+v", s)
	}
}

func TestSummarizeDoesNotUseUnrelatedUUID(t *testing.T) {
	raw := []byte(`{"schema_version":"2.0","hostname":"vm1","storage":{"partitions":[{"uuid":"partition-only"}]}}`)
	s, err := Summarize(raw)
	if err != nil {
		t.Fatal(err)
	}
	if s.AgentUUID != "" {
		t.Fatalf("agent UUID %q was taken from an unrelated object", s.AgentUUID)
	}
}

func TestSummarizeRejectsTrailingJSON(t *testing.T) {
	if _, err := Summarize([]byte(`{"schema_version":"2.0"} {}`)); err == nil {
		t.Fatal("trailing JSON unexpectedly accepted")
	}
}

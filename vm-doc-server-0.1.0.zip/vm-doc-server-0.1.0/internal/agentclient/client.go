package agentclient

import (
	"context"
	"crypto/tls"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"strings"
	"time"

	"vm-doc-server/internal/domain"
)

type Client struct {
	AllowedNetworks []*net.IPNet
	MaxBody         int64
}

type Result struct {
	StatusCode int
	Body       []byte
	Duration   time.Duration
}

func New(allowed []string, maxBody int64) (*Client, error) {
	c := &Client{MaxBody: maxBody}
	if c.MaxBody <= 0 {
		c.MaxBody = 10 << 20
	}
	for _, raw := range allowed {
		_, network, err := net.ParseCIDR(raw)
		if err != nil {
			return nil, fmt.Errorf("invalid allowed network %q: %w", raw, err)
		}
		c.AllowedNetworks = append(c.AllowedNetworks, network)
	}
	return c, nil
}

func (c *Client) Test(ctx context.Context, agent domain.Agent, token string) (Result, error) {
	return c.request(ctx, agent, token, http.MethodGet, "/v1/status")
}

func (c *Client) Collect(ctx context.Context, agent domain.Agent, token string, refresh bool) (Result, error) {
	if refresh {
		if _, err := c.request(ctx, agent, token, http.MethodPost, "/v1/inventory/refresh"); err != nil {
			return Result{}, fmt.Errorf("refresh inventory: %w", err)
		}
	}
	return c.request(ctx, agent, token, http.MethodGet, "/v1/inventory")
}

func (c *Client) request(ctx context.Context, agent domain.Agent, token, method, path string) (Result, error) {
	if err := c.validateTarget(ctx, agent.BaseURL); err != nil {
		return Result{}, err
	}
	transport := &http.Transport{
		Proxy:           nil,
		TLSClientConfig: &tls.Config{MinVersion: tls.VersionTLS12, ServerName: agent.TLSServerName, InsecureSkipVerify: !agent.VerifyTLS}, //nolint:gosec
		DialContext:     c.dialContext,
		IdleConnTimeout: 90 * time.Second,
	}
	client := &http.Client{
		Transport: transport,
		Timeout:   time.Duration(agent.RequestTimeoutSeconds) * time.Second,
		CheckRedirect: func(_ *http.Request, _ []*http.Request) error {
			return http.ErrUseLastResponse
		},
	}
	req, err := http.NewRequestWithContext(ctx, method, strings.TrimRight(agent.BaseURL, "/")+path, nil)
	if err != nil {
		return Result{}, err
	}
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Accept", "application/json")
	start := time.Now()
	resp, err := client.Do(req)
	if err != nil {
		return Result{Duration: time.Since(start)}, err
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(io.LimitReader(resp.Body, c.MaxBody+1))
	result := Result{StatusCode: resp.StatusCode, Body: body, Duration: time.Since(start)}
	if err != nil {
		return result, err
	}
	if int64(len(body)) > c.MaxBody {
		return result, errors.New("agent response exceeds configured limit")
	}
	if resp.StatusCode < 200 || resp.StatusCode > 299 {
		return result, fmt.Errorf("agent returned HTTP %d: %s", resp.StatusCode, truncate(string(body), 300))
	}
	return result, nil
}

func (c *Client) validateTarget(_ context.Context, raw string) error {
	u, err := url.Parse(raw)
	if err != nil || u.Hostname() == "" {
		return errors.New("invalid agent URL")
	}
	if u.Scheme != "https" && u.Scheme != "http" {
		return errors.New("agent URL must use HTTP or HTTPS")
	}
	if u.User != nil || u.RawQuery != "" || u.Fragment != "" || (u.Path != "" && u.Path != "/") {
		return errors.New("agent URL must contain only scheme, host and optional port")
	}
	return nil
}

func (c *Client) dialContext(ctx context.Context, network, address string) (net.Conn, error) {
	host, port, err := net.SplitHostPort(address)
	if err != nil {
		return nil, fmt.Errorf("invalid dial address: %w", err)
	}
	ips, err := net.DefaultResolver.LookupIP(ctx, "ip", host)
	if err != nil {
		return nil, fmt.Errorf("resolve agent host: %w", err)
	}
	dialer := &net.Dialer{Timeout: 10 * time.Second, KeepAlive: 30 * time.Second}
	var lastErr error
	for _, ip := range ips {
		if !c.ipAllowed(ip) {
			continue
		}
		conn, err := dialer.DialContext(ctx, network, net.JoinHostPort(ip.String(), port))
		if err == nil {
			return conn, nil
		}
		lastErr = err
	}
	if lastErr != nil {
		return nil, lastErr
	}
	return nil, fmt.Errorf("agent host %s has no address in collector.allowed_networks", host)
}

func (c *Client) ipAllowed(ip net.IP) bool {
	if len(c.AllowedNetworks) == 0 {
		return true
	}
	for _, network := range c.AllowedNetworks {
		if network.Contains(ip) {
			return true
		}
	}
	return false
}

func truncate(v string, n int) string {
	if len(v) > n {
		return v[:n]
	}
	return v
}

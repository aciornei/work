package agentclient

import (
	"context"
	"testing"
)

func TestValidateTargetRejectsCredentialsAndPath(t *testing.T) {
	client, err := New([]string{"10.0.0.0/8"}, 1024)
	if err != nil {
		t.Fatal(err)
	}
	for _, raw := range []string{
		"https://user:password@vm1:9078",
		"https://vm1:9078/api",
		"file:///tmp/inventory.json",
	} {
		if err := client.validateTarget(context.Background(), raw); err == nil {
			t.Fatalf("target %q unexpectedly accepted", raw)
		}
	}
}

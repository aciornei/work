package domain

import "time"

type User struct {
	ID          int64    `json:"id"`
	Username    string   `json:"username"`
	DisplayName string   `json:"display_name"`
	Email       string   `json:"email"`
	Source      string   `json:"source"`
	Groups      []string `json:"groups"`
	Roles       []string `json:"roles"`
	CSRFToken   string   `json:"csrf_token,omitempty"`
}

type Agent struct {
	ID                        int64      `json:"id"`
	SecretRef                 string     `json:"-"`
	Name                      string     `json:"name"`
	BaseURL                   string     `json:"base_url"`
	Enabled                   bool       `json:"enabled"`
	VerifyTLS                 bool       `json:"verify_tls"`
	TLSServerName             string     `json:"tls_server_name,omitempty"`
	TokenConfigured           bool       `json:"token_configured"`
	AgentUUID                 string     `json:"agent_uuid,omitempty"`
	CollectionIntervalSeconds int        `json:"collection_interval_seconds"`
	RequestTimeoutSeconds     int        `json:"request_timeout_seconds"`
	OfflineAfterSeconds       int        `json:"offline_after_seconds"`
	NextCollectionAt          *time.Time `json:"next_collection_at,omitempty"`
	LastAttemptAt             *time.Time `json:"last_attempt_at,omitempty"`
	LastContactAt             *time.Time `json:"last_contact_at,omitempty"`
	LastSuccessAt             *time.Time `json:"last_success_at,omitempty"`
	LastError                 string     `json:"last_error,omitempty"`
	CurrentInventoryID        *int64     `json:"current_inventory_id,omitempty"`
	Status                    string     `json:"status"`
	CreatedAt                 time.Time  `json:"created_at"`
	UpdatedAt                 time.Time  `json:"updated_at"`
}

type Job struct {
	ID           int64      `json:"id"`
	AgentID      int64      `json:"agent_id"`
	Kind         string     `json:"kind"`
	Source       string     `json:"source"`
	Status       string     `json:"status"`
	RequestedBy  *int64     `json:"requested_by_user_id,omitempty"`
	ScheduledAt  time.Time  `json:"scheduled_at"`
	StartedAt    *time.Time `json:"started_at,omitempty"`
	FinishedAt   *time.Time `json:"finished_at,omitempty"`
	AttemptCount int        `json:"attempt_count"`
	HTTPStatus   *int       `json:"http_status,omitempty"`
	DurationMS   *int64     `json:"duration_ms,omitempty"`
	ErrorCode    string     `json:"error_code,omitempty"`
	ErrorMessage string     `json:"error_message,omitempty"`
	CreatedAt    time.Time  `json:"created_at"`
}

type Inventory struct {
	ID                  int64      `json:"id"`
	AgentID             int64      `json:"agent_id"`
	CollectionJobID     int64      `json:"collection_job_id"`
	SchemaVersion       string     `json:"schema_version"`
	AgentUUID           string     `json:"agent_uuid"`
	Hostname            string     `json:"hostname"`
	OSName              string     `json:"os_name"`
	OSVersion           string     `json:"os_version"`
	PrimaryIP           string     `json:"primary_ip"`
	BootTime            *time.Time `json:"boot_time,omitempty"`
	CollectorTotal      int        `json:"collector_total"`
	CollectorOK         int        `json:"collector_ok"`
	CollectorError      int        `json:"collector_error"`
	CollectorTimeout    int        `json:"collector_timeout"`
	PayloadSize         int64      `json:"payload_size"`
	PayloadSHA256       string     `json:"payload_sha256"`
	ChangedFromPrevious bool       `json:"changed_from_previous"`
	RawJSON             []byte     `json:"raw_json,omitempty"`
	CollectedAt         *time.Time `json:"collected_at,omitempty"`
	ReceivedAt          time.Time  `json:"received_at"`
}

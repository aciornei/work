package agents

import (
	"strings"
	"testing"
	"time"

	"vm-doc-server/internal/config"
)

func testService() Service {
	return Service{Config: config.CollectorConfig{
		LeaseDuration:             config.Duration(2 * time.Minute),
		DefaultCollectionInterval: config.Duration(15 * time.Minute),
		DefaultRequestTimeout:     config.Duration(45 * time.Second),
		DefaultOfflineAfter:       config.Duration(45 * time.Minute),
		RefreshBeforeCollect:      true,
	}}
}

func TestNormalizeRejectsAgentURLWithPath(t *testing.T) {
	s := testService()
	in := Input{Name: "vm1", BaseURL: "https://vm1:9078/unexpected", Token: "secret"}
	if err := s.normalizeAndValidate(&in, true); err == nil {
		t.Fatal("agent URL with a path unexpectedly accepted")
	}
}

func TestNormalizeRejectsTimeoutOutsideLease(t *testing.T) {
	s := testService()
	in := Input{Name: "vm1", BaseURL: "https://vm1:9078", Token: "secret", RequestTimeoutSeconds: 60}
	err := s.normalizeAndValidate(&in, true)
	if err == nil || !strings.Contains(err.Error(), "lease_duration") {
		t.Fatalf("got error %v, want lease duration validation", err)
	}
}

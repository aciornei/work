package auth

import (
	"context"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"database/sql"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"slices"
	"strings"
	"time"

	"github.com/coreos/go-oidc/v3/oidc"
	"github.com/go-ldap/ldap/v3"
	"golang.org/x/oauth2"
	"vm-doc-server/internal/audit"
	"vm-doc-server/internal/config"
	"vm-doc-server/internal/cryptox"
	"vm-doc-server/internal/domain"
)

type contextKey string

const userKey contextKey = "vm-doc-user"

type Service struct {
	DB       *sql.DB
	Config   config.Config
	Secrets  config.Secrets
	Audit    audit.Service
	provider *oidc.Provider
	verifier *oidc.IDTokenVerifier
	oauth    oauth2.Config
}

type Identity struct {
	Username        string
	DisplayName     string
	Email           string
	Source          string
	ExternalSubject string
	Groups          []string
}

func New(ctx context.Context, db *sql.DB, cfg config.Config, secrets config.Secrets, auditService audit.Service) (*Service, error) {
	s := &Service{DB: db, Config: cfg, Secrets: secrets, Audit: auditService}
	if cfg.Auth.OIDC.Enabled {
		provider, err := oidc.NewProvider(ctx, cfg.Auth.OIDC.IssuerURL)
		if err != nil {
			return nil, fmt.Errorf("initialize OIDC provider: %w", err)
		}
		s.provider = provider
		s.verifier = provider.Verifier(&oidc.Config{ClientID: cfg.Auth.OIDC.ClientID})
		s.oauth = oauth2.Config{
			ClientID:     cfg.Auth.OIDC.ClientID,
			ClientSecret: secrets.OIDCClientSecret,
			Endpoint:     provider.Endpoint(),
			RedirectURL:  strings.TrimRight(cfg.App.BaseURL, "/") + "/api/v1/auth/oidc/callback",
			Scopes:       append([]string{oidc.ScopeOpenID}, cfg.Auth.OIDC.Scopes...),
		}
	}
	return s, nil
}

func UserFromContext(ctx context.Context) (domain.User, bool) {
	u, ok := ctx.Value(userKey).(domain.User)
	return u, ok
}

func (s *Service) Middleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		cookie, err := r.Cookie(s.Config.Session.CookieName)
		if err != nil || cookie.Value == "" {
			next.ServeHTTP(w, r)
			return
		}
		u, err := s.loadSession(r.Context(), cookie.Value)
		if err != nil {
			s.clearCookie(w)
			next.ServeHTTP(w, r)
			return
		}
		ctx := context.WithValue(r.Context(), userKey, u)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

func (s *Service) RequireAuth(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if _, ok := UserFromContext(r.Context()); !ok {
			writeJSON(w, http.StatusUnauthorized, map[string]any{"error": "unauthorized"})
			return
		}
		next.ServeHTTP(w, r)
	})
}

func (s *Service) RequireCSRF(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodGet || r.Method == http.MethodHead || r.Method == http.MethodOptions {
			next.ServeHTTP(w, r)
			return
		}
		u, ok := UserFromContext(r.Context())
		if !ok || u.CSRFToken == "" || r.Header.Get("X-CSRF-Token") != u.CSRFToken {
			writeJSON(w, http.StatusForbidden, map[string]any{"error": "invalid_csrf_token"})
			return
		}
		next.ServeHTTP(w, r)
	})
}

func (s *Service) Providers(w http.ResponseWriter, _ *http.Request) {
	writeJSON(w, http.StatusOK, map[string]bool{
		"ldap": s.Config.Auth.LDAP.Enabled || s.Config.Auth.Dev.Enabled,
		"oidc": s.Config.Auth.OIDC.Enabled,
	})
}

func (s *Service) LDAPLogin(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Username string `json:"username"`
		Password string `json:"password"`
	}
	if err := decodeJSON(r, &in); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": "invalid_request"})
		return
	}
	in.Username = strings.TrimSpace(in.Username)
	if in.Username == "" || in.Password == "" {
		writeJSON(w, http.StatusBadRequest, map[string]any{"error": "username_and_password_required"})
		return
	}
	var ident Identity
	var err error
	if s.Config.Auth.Dev.Enabled && in.Username == s.Config.Auth.Dev.Username && in.Password == s.Config.Auth.Dev.Password {
		ident = Identity{Username: in.Username, DisplayName: "Development Administrator", Source: "dev", Groups: []string{"dev-admin"}}
	} else {
		ident, err = s.authenticateLDAP(in.Username, in.Password)
	}
	if err != nil {
		s.auditAuthentication(r, "auth.login", nil, in.Username, "ldap", "failure", "invalid_credentials")
		writeJSON(w, http.StatusUnauthorized, map[string]any{"error": "invalid_credentials"})
		return
	}
	u, err := s.loginIdentity(r.Context(), ident)
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]any{"error": "login_failed"})
		return
	}
	if err := s.createSession(w, r, &u); err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]any{"error": "session_failed"})
		return
	}
	s.auditAuthentication(r, "auth.login", &u, u.Username, ident.Source, "success", "")
	writeJSON(w, http.StatusOK, u)
}

func (s *Service) OIDCStart(w http.ResponseWriter, r *http.Request) {
	if !s.Config.Auth.OIDC.Enabled {
		writeJSON(w, http.StatusNotFound, map[string]any{"error": "oidc_disabled"})
		return
	}
	_, _ = s.DB.ExecContext(r.Context(), `DELETE FROM oidc_transactions WHERE expires_at<?`, time.Now().UTC())
	state, _ := cryptox.RandomToken(32)
	nonce, _ := cryptox.RandomToken(32)
	verifier, _ := cryptox.RandomToken(48)
	challengeHash := sha256.Sum256([]byte(verifier))
	challenge := base64.RawURLEncoding.EncodeToString(challengeHash[:])
	_, err := s.DB.ExecContext(r.Context(), `INSERT INTO oidc_transactions(state,nonce,code_verifier,created_at,expires_at) VALUES(?,?,?,?,?)`, state, nonce, verifier, time.Now().UTC(), time.Now().UTC().Add(10*time.Minute))
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]any{"error": "oidc_start_failed"})
		return
	}
	http.SetCookie(w, &http.Cookie{
		Name:     s.Config.Session.CookieName + "_oidc_state",
		Value:    state,
		Path:     "/api/v1/auth/oidc/callback",
		HttpOnly: true,
		Secure:   s.Config.Session.Secure,
		SameSite: http.SameSiteLaxMode,
		MaxAge:   600,
	})
	location := s.oauth.AuthCodeURL(state,
		oauth2.SetAuthURLParam("nonce", nonce),
		oauth2.SetAuthURLParam("code_challenge", challenge),
		oauth2.SetAuthURLParam("code_challenge_method", "S256"),
	)
	http.Redirect(w, r, location, http.StatusFound)
}

func (s *Service) OIDCCallback(w http.ResponseWriter, r *http.Request) {
	if !s.Config.Auth.OIDC.Enabled {
		http.Error(w, "OIDC disabled", http.StatusNotFound)
		return
	}
	state := r.URL.Query().Get("state")
	code := r.URL.Query().Get("code")
	stateCookie, cookieErr := r.Cookie(s.Config.Session.CookieName + "_oidc_state")
	http.SetCookie(w, &http.Cookie{Name: s.Config.Session.CookieName + "_oidc_state", Value: "", Path: "/api/v1/auth/oidc/callback", HttpOnly: true, Secure: s.Config.Session.Secure, SameSite: http.SameSiteLaxMode, MaxAge: -1})
	if cookieErr != nil || state == "" || stateCookie.Value != state {
		http.Error(w, "Invalid OIDC state", http.StatusBadRequest)
		return
	}
	var nonce, verifier string
	var expires time.Time
	err := s.DB.QueryRowContext(r.Context(), `SELECT nonce,code_verifier,expires_at FROM oidc_transactions WHERE state=?`, state).Scan(&nonce, &verifier, &expires)
	_, _ = s.DB.ExecContext(r.Context(), `DELETE FROM oidc_transactions WHERE state=?`, state)
	if err != nil || time.Now().UTC().After(expires) || code == "" {
		http.Error(w, "Invalid OIDC transaction", http.StatusBadRequest)
		return
	}
	token, err := s.oauth.Exchange(r.Context(), code, oauth2.SetAuthURLParam("code_verifier", verifier))
	if err != nil {
		http.Error(w, "OIDC token exchange failed", http.StatusUnauthorized)
		return
	}
	rawID, ok := token.Extra("id_token").(string)
	if !ok {
		http.Error(w, "Missing ID token", http.StatusUnauthorized)
		return
	}
	idToken, err := s.verifier.Verify(r.Context(), rawID)
	if err != nil {
		http.Error(w, "Invalid ID token", http.StatusUnauthorized)
		return
	}
	var claims map[string]any
	if err := idToken.Claims(&claims); err != nil {
		http.Error(w, "Invalid claims", http.StatusUnauthorized)
		return
	}
	if fmt.Sprint(claims["nonce"]) != nonce {
		http.Error(w, "Invalid nonce", http.StatusUnauthorized)
		return
	}
	usernameClaim := s.Config.Auth.OIDC.UsernameClaim
	if usernameClaim == "" {
		usernameClaim = "preferred_username"
	}
	groupsClaim := s.Config.Auth.OIDC.GroupsClaim
	if groupsClaim == "" {
		groupsClaim = "groups"
	}
	ident := Identity{
		Username:        stringClaim(claims, usernameClaim),
		DisplayName:     stringClaim(claims, "name"),
		Email:           stringClaim(claims, "email"),
		Source:          "oidc",
		ExternalSubject: idToken.Subject,
		Groups:          stringSliceClaim(claims, groupsClaim),
	}
	if ident.Username == "" {
		ident.Username = idToken.Subject
	}
	u, err := s.loginIdentity(r.Context(), ident)
	if err != nil {
		http.Error(w, "Login failed", http.StatusInternalServerError)
		return
	}
	if err := s.createSession(w, r, &u); err != nil {
		http.Error(w, "Session failed", http.StatusInternalServerError)
		return
	}
	s.auditAuthentication(r, "auth.login", &u, u.Username, "oidc", "success", "")
	http.Redirect(w, r, "/", http.StatusFound)
}

func (s *Service) Me(w http.ResponseWriter, r *http.Request) {
	u, ok := UserFromContext(r.Context())
	if !ok {
		writeJSON(w, http.StatusUnauthorized, map[string]any{"error": "unauthorized"})
		return
	}
	writeJSON(w, http.StatusOK, u)
}

func (s *Service) Logout(w http.ResponseWriter, r *http.Request) {
	if user, ok := UserFromContext(r.Context()); ok {
		s.auditAuthentication(r, "auth.logout", &user, user.Username, user.Source, "success", "")
	}
	if cookie, err := r.Cookie(s.Config.Session.CookieName); err == nil {
		_, _ = s.DB.ExecContext(r.Context(), `DELETE FROM sessions WHERE id=?`, cookie.Value)
	}
	s.clearCookie(w)
	writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

func (s *Service) authenticateLDAP(username, password string) (Identity, error) {
	cfg := s.Config.Auth.LDAP
	if !cfg.Enabled {
		return Identity{}, errors.New("LDAP disabled")
	}
	var lastErr error
	for _, host := range cfg.Hosts {
		conn, err := dialLDAP(host, cfg)
		if err != nil {
			lastErr = err
			continue
		}
		ident, authErr := func() (Identity, error) {
			defer conn.Close()
			if s.Secrets.LDAPBindDN != "" {
				if err := conn.Bind(s.Secrets.LDAPBindDN, s.Secrets.LDAPBindPassword); err != nil {
					return Identity{}, err
				}
			}
			base := cfg.UserBaseDN
			if base == "" {
				base = cfg.BaseDN
			}
			filter := strings.ReplaceAll(cfg.UserFilter, "{username}", ldap.EscapeFilter(username))
			if filter == "" {
				filter = fmt.Sprintf("(sAMAccountName=%s)", ldap.EscapeFilter(username))
			}
			attrs := []string{cfg.UsernameAttribute, cfg.DisplayNameAttribute, cfg.EmailAttribute, cfg.GroupsAttribute}
			request := ldap.NewSearchRequest(base, ldap.ScopeWholeSubtree, ldap.NeverDerefAliases, 2, 10, false, filter, attrs, nil)
			result, err := conn.Search(request)
			if err != nil {
				return Identity{}, err
			}
			if len(result.Entries) != 1 {
				return Identity{}, errors.New("user not found or ambiguous")
			}
			entry := result.Entries[0]
			if err := conn.Bind(entry.DN, password); err != nil {
				return Identity{}, err
			}
			ident := Identity{
				Username:        entry.GetAttributeValue(cfg.UsernameAttribute),
				DisplayName:     entry.GetAttributeValue(cfg.DisplayNameAttribute),
				Email:           entry.GetAttributeValue(cfg.EmailAttribute),
				Source:          "ldap",
				ExternalSubject: entry.DN,
				Groups:          entry.GetAttributeValues(cfg.GroupsAttribute),
			}
			if ident.Username == "" {
				ident.Username = username
			}
			return ident, nil
		}()
		if authErr == nil {
			return ident, nil
		}
		lastErr = authErr
	}
	if lastErr == nil {
		lastErr = errors.New("LDAP authentication failed")
	}
	return Identity{}, lastErr
}

func dialLDAP(host string, cfg config.LDAPConfig) (*ldap.Conn, error) {
	mode := strings.ToLower(cfg.Mode)
	if mode == "ldaps" {
		tlsCfg, err := ldapTLSConfig(host, cfg)
		if err != nil {
			return nil, err
		}
		return ldap.DialURL("ldaps://"+host, ldap.DialWithTLSConfig(tlsCfg))
	}
	conn, err := ldap.DialURL("ldap://" + host)
	if err != nil {
		return nil, err
	}
	if mode == "starttls" {
		tlsCfg, err := ldapTLSConfig(host, cfg)
		if err != nil {
			conn.Close()
			return nil, err
		}
		if err := conn.StartTLS(tlsCfg); err != nil {
			conn.Close()
			return nil, err
		}
	}
	return conn, nil
}

func ldapTLSConfig(host string, cfg config.LDAPConfig) (*tls.Config, error) {
	serverName := host
	if h, _, err := net.SplitHostPort(host); err == nil {
		serverName = h
	}
	tlsCfg := &tls.Config{MinVersion: tls.VersionTLS12, ServerName: serverName, InsecureSkipVerify: cfg.InsecureSkipVerify} //nolint:gosec
	if cfg.CAFile != "" {
		b, err := os.ReadFile(cfg.CAFile)
		if err != nil {
			return nil, err
		}
		pool := x509.NewCertPool()
		if !pool.AppendCertsFromPEM(b) {
			return nil, errors.New("invalid LDAP CA file")
		}
		tlsCfg.RootCAs = pool
	}
	return tlsCfg, nil
}

func (s *Service) loginIdentity(ctx context.Context, ident Identity) (domain.User, error) {
	roles, err := s.resolveRoles(ctx, ident.Source, ident.Groups)
	if err != nil {
		return domain.User{}, err
	}
	groupsJSON, _ := json.Marshal(ident.Groups)
	rolesJSON, _ := json.Marshal(roles)
	_, err = s.DB.ExecContext(ctx, `INSERT INTO users(username,display_name,email,source,external_subject,groups_json,roles_json,last_login_at) VALUES(?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE display_name=VALUES(display_name),email=VALUES(email),external_subject=VALUES(external_subject),groups_json=VALUES(groups_json),roles_json=VALUES(roles_json),last_login_at=VALUES(last_login_at)`, ident.Username, ident.DisplayName, ident.Email, ident.Source, ident.ExternalSubject, groupsJSON, rolesJSON, time.Now().UTC())
	if err != nil {
		return domain.User{}, err
	}
	var u domain.User
	err = s.DB.QueryRowContext(ctx, `SELECT id,username,display_name,email,source,groups_json,roles_json FROM users WHERE source=? AND username=?`, ident.Source, ident.Username).Scan(&u.ID, &u.Username, &u.DisplayName, &u.Email, &u.Source, &groupsJSON, &rolesJSON)
	if err != nil {
		return u, err
	}
	_ = json.Unmarshal(groupsJSON, &u.Groups)
	_ = json.Unmarshal(rolesJSON, &u.Roles)
	return u, nil
}

func (s *Service) resolveRoles(ctx context.Context, provider string, groups []string) ([]string, error) {
	roles := map[string]bool{}
	if provider == "dev" {
		roles["admin"] = true
	}
	for _, g := range groups {
		for _, admin := range s.Config.RBAC.BootstrapAdminGroups {
			if strings.EqualFold(normalizeGroup(g), normalizeGroup(admin)) {
				roles["admin"] = true
			}
		}
	}
	groupVariants := roleGroupVariants(groups)
	if len(groupVariants) > 0 {
		args := append([]any{provider}, stringsToAny(groupVariants)...)
		rows, err := s.DB.QueryContext(ctx, `SELECT DISTINCT r.name FROM group_role_mappings gm JOIN roles r ON r.id=gm.role_id WHERE gm.provider IN (?, 'any') AND gm.group_name IN (`+placeholders(len(groupVariants))+`)`, args...)
		if err != nil {
			return nil, err
		}
		defer rows.Close()
		for rows.Next() {
			var role string
			if err := rows.Scan(&role); err != nil {
				return nil, err
			}
			roles[role] = true
		}
	}
	if len(roles) == 0 {
		roles["viewer"] = true
	}
	out := make([]string, 0, len(roles))
	for role := range roles {
		out = append(out, role)
	}
	slices.Sort(out)
	return out, nil
}

func (s *Service) createSession(w http.ResponseWriter, r *http.Request, u *domain.User) error {
	id, err := cryptox.RandomToken(48)
	if err != nil {
		return err
	}
	csrf, err := cryptox.RandomToken(32)
	if err != nil {
		return err
	}
	now := time.Now().UTC()
	expires := now.Add(s.Config.Session.IdleTimeout.Value())
	absolute := now.Add(s.Config.Session.AbsoluteTimeout.Value())
	_, err = s.DB.ExecContext(r.Context(), `INSERT INTO sessions(id,user_id,csrf_token,created_at,last_seen_at,expires_at,absolute_expires_at,ip_address,user_agent) VALUES(?,?,?,?,?,?,?,?,?)`, id, u.ID, csrf, now, now, expires, absolute, clientIP(r), r.UserAgent())
	if err != nil {
		return err
	}
	u.CSRFToken = csrf
	http.SetCookie(w, &http.Cookie{Name: s.Config.Session.CookieName, Value: id, Path: "/", HttpOnly: true, Secure: s.Config.Session.Secure, SameSite: sameSite(s.Config.Session.SameSite), Expires: absolute})
	return nil
}

func (s *Service) loadSession(ctx context.Context, id string) (domain.User, error) {
	var u domain.User
	var groupsJSON, rolesJSON []byte
	var expires, absolute time.Time
	err := s.DB.QueryRowContext(ctx, `SELECT u.id,u.username,u.display_name,u.email,u.source,u.groups_json,u.roles_json,s.csrf_token,s.expires_at,s.absolute_expires_at FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.id=?`, id).Scan(&u.ID, &u.Username, &u.DisplayName, &u.Email, &u.Source, &groupsJSON, &rolesJSON, &u.CSRFToken, &expires, &absolute)
	if err != nil {
		return u, err
	}
	now := time.Now().UTC()
	if now.After(expires) || now.After(absolute) {
		_, _ = s.DB.ExecContext(ctx, `DELETE FROM sessions WHERE id=?`, id)
		return u, errors.New("session expired")
	}
	_ = json.Unmarshal(groupsJSON, &u.Groups)
	_ = json.Unmarshal(rolesJSON, &u.Roles)
	newExpiry := now.Add(s.Config.Session.IdleTimeout.Value())
	if newExpiry.After(absolute) {
		newExpiry = absolute
	}
	_, _ = s.DB.ExecContext(ctx, `UPDATE sessions SET last_seen_at=?,expires_at=? WHERE id=?`, now, newExpiry, id)
	return u, nil
}

func (s *Service) clearCookie(w http.ResponseWriter) {
	http.SetCookie(w, &http.Cookie{Name: s.Config.Session.CookieName, Value: "", Path: "/", HttpOnly: true, Secure: s.Config.Session.Secure, SameSite: sameSite(s.Config.Session.SameSite), MaxAge: -1})
}

func sameSite(v string) http.SameSite {
	switch strings.ToLower(v) {
	case "strict":
		return http.SameSiteStrictMode
	case "none":
		return http.SameSiteNoneMode
	default:
		return http.SameSiteLaxMode
	}
}

func normalizeGroup(v string) string {
	v = strings.TrimSpace(v)
	if strings.Contains(v, ",") {
		for _, p := range strings.Split(v, ",") {
			p = strings.TrimSpace(p)
			if strings.HasPrefix(strings.ToUpper(p), "CN=") {
				return strings.TrimSpace(p[3:])
			}
		}
	}
	return v
}

func roleGroupVariants(groups []string) []string {
	seen := make(map[string]bool, len(groups)*2)
	out := make([]string, 0, len(groups)*2)
	for _, group := range groups {
		for _, candidate := range []string{strings.TrimSpace(group), normalizeGroup(group)} {
			key := strings.ToLower(candidate)
			if candidate == "" || seen[key] {
				continue
			}
			seen[key] = true
			out = append(out, candidate)
		}
	}
	return out
}

func placeholders(n int) string {
	if n <= 0 {
		return "NULL"
	}
	return strings.TrimRight(strings.Repeat("?,", n), ",")
}

func stringsToAny(v []string) []any {
	out := make([]any, len(v))
	for i := range v {
		out[i] = v[i]
	}
	return out
}

func stringClaim(m map[string]any, k string) string {
	if v, ok := m[k].(string); ok {
		return v
	}
	return ""
}

func stringSliceClaim(m map[string]any, k string) []string {
	switch v := m[k].(type) {
	case []any:
		out := make([]string, 0, len(v))
		for _, x := range v {
			out = append(out, fmt.Sprint(x))
		}
		return out
	case []string:
		return v
	case string:
		if v == "" {
			return nil
		}
		return []string{v}
	default:
		return nil
	}
}

func (s *Service) auditAuthentication(r *http.Request, action string, user *domain.User, username, provider, outcome, reason string) {
	var userID *int64
	if user != nil {
		id := user.ID
		userID = &id
	}
	details := map[string]any{"provider": provider}
	if reason != "" {
		details["reason"] = reason
	}
	_ = s.Audit.Log(r.Context(), audit.Event{
		Source:        "server",
		ActorUserID:   userID,
		ActorUsername: username,
		Action:        action,
		ResourceType:  "session",
		Outcome:       outcome,
		RequestID:     r.Header.Get("X-Request-ID"),
		IPAddress:     clientIP(r),
		UserAgent:     r.UserAgent(),
		Details:       details,
	})
}

func clientIP(r *http.Request) string {
	if value := strings.TrimSpace(r.Header.Get("X-VM-Doc-Client-IP")); value != "" {
		return value
	}
	h, _, err := net.SplitHostPort(r.RemoteAddr)
	if err == nil {
		return h
	}
	return strings.TrimSpace(r.RemoteAddr)
}

func decodeJSON(r *http.Request, v any) error {
	defer r.Body.Close()
	return json.NewDecoder(io.LimitReader(r.Body, 1<<20)).Decode(v)
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}

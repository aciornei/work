package cryptox

import (
	"bytes"
	"testing"
)

func TestEncryptDecryptWithAAD(t *testing.T) {
	box, err := New([]byte("0123456789abcdef0123456789abcdef"))
	if err != nil {
		t.Fatal(err)
	}
	plaintext := []byte("agent-token")
	ciphertext, err := box.Encrypt(plaintext, "vm-doc-agent-token:agent-1")
	if err != nil {
		t.Fatal(err)
	}
	decoded, err := box.Decrypt(ciphertext, "vm-doc-agent-token:agent-1")
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(decoded, plaintext) {
		t.Fatalf("decoded %q, want %q", decoded, plaintext)
	}
	if _, err := box.Decrypt(ciphertext, "vm-doc-agent-token:agent-2"); err == nil {
		t.Fatal("decrypt with another AAD unexpectedly succeeded")
	}
}

func TestNewRejectsShortMasterKey(t *testing.T) {
	if _, err := New([]byte("short")); err == nil {
		t.Fatal("short master key unexpectedly accepted")
	}
}

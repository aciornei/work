INSERT IGNORE INTO roles(name, description) VALUES
 ('admin', 'Administrare completă'),
 ('operator', 'Administrare agenți și colectări'),
 ('viewer', 'Vizualizare inventare'),
 ('auditor', 'Vizualizare audit');

INSERT IGNORE INTO permissions(name, description) VALUES
 ('dashboard.read', 'Vizualizare dashboard'),
 ('agents.read', 'Vizualizare agenți'),
 ('agents.manage', 'Administrare agenți'),
 ('collections.read', 'Vizualizare colectări'),
 ('collections.run', 'Pornire colectări'),
 ('inventories.read', 'Vizualizare inventare'),
 ('inventories.raw.read', 'Vizualizare JSON brut'),
 ('audit.read', 'Vizualizare audit'),
 ('rbac.manage', 'Administrare acces'),
 ('system.manage', 'Administrare sistem');

INSERT IGNORE INTO role_permissions(role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p WHERE r.name='admin';

INSERT IGNORE INTO role_permissions(role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.name IN ('dashboard.read','agents.read','agents.manage','collections.read','collections.run','inventories.read','inventories.raw.read') WHERE r.name='operator';

INSERT IGNORE INTO role_permissions(role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.name IN ('dashboard.read','agents.read','collections.read','inventories.read') WHERE r.name='viewer';

INSERT IGNORE INTO role_permissions(role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.name IN ('dashboard.read','agents.read','collections.read','inventories.read','inventories.raw.read','audit.read') WHERE r.name='auditor';

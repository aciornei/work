# vm-doc-server 0.1.0

Platformă centrală pentru inventarele produse de `vm-doc-agent 1.0.0`.

```text
vm-doc-agent -> vm-doc-collector -> MariaDB -> vm-doc-server -> browser
```

## Componente

- `vm-doc-server`: API, autentificare, RBAC, frontend, audit și Swagger UI.
- `vm-doc-collector`: scheduler, coadă de joburi și interogarea agenților.
- MariaDB: stare operațională, snapshoturi brute și istoric.

Serverul web nu contactează direct agenții. Testele și colectările manuale creează joburi persistente pe care collectorul le execută.

## Compilare

Necesită Go 1.23 sau mai nou și acces la modulele declarate în `go.mod`.

```bash
git clone <repository>
cd vm-doc-server
make test
make build
```

Binarele sunt generate în `bin/`.

## Instalare inițială

1. Creați baza și utilizatorul folosind `deploy/mariadb/create-database.sql.example`.
2. Copiați și adaptați `configs/config.example.yaml`.
3. Generați o cheie master:

```bash
install -d -m 0750 /etc/vm-doc-server
openssl rand -base64 48 > /etc/vm-doc-server/master.key
chmod 0600 /etc/vm-doc-server/master.key
```

4. Completați o copie a `configs/secrets.example.yaml`, apoi criptați-o:

```bash
go run ./tools/encrypt-secrets -in /tmp/secrets.yaml \
  -out /etc/vm-doc-server/secrets.enc \
  -key /etc/vm-doc-server/master.key
rm -f /tmp/secrets.yaml
chown root:vm-doc /etc/vm-doc-server/secrets.enc
chmod 0640 /etc/vm-doc-server/secrets.enc
```

5. Rulați `make build` și `sudo scripts/install.sh`.
6. Instalați configurația Nginx și certificatul TLS.
7. Porniți serviciile:

```bash
systemctl enable --now vm-doc-server vm-doc-collector
```

Migrațiile sunt aplicate automat la pornirea fiecărui proces, sub un lock MariaDB comun. Fișierele de migrare sunt pregătite pentru reluare după o întrerupere.

## Autentificare și primul administrator

Configurați în `rbac.bootstrap_admin_groups` un grup LDAP/OIDC controlat de administratori. Membrii lui primesc rolul `admin` la autentificare. Ceilalți utilizatori primesc implicit `viewer`, până când sunt create mapări în pagina **Acces**.

Modul `auth.dev` este acceptat numai când `app.environment` nu este `production`.

## Agenți

Pentru fiecare agent se configurează:

- nume și URL, de regulă `https://hostname:9078`;
- Bearer Token;
- verificare TLS și opțional `tls_server_name`;
- intervalul de colectare;
- timeout și pragul offline.

Tokenul este criptat înainte de a fi salvat în MariaDB. API-ul nu returnează tokenul.

## API

- document OpenAPI: `/api/openapi.yaml`;
- Swagger UI local: `/docs/`;
- health: `/healthz`;
- readiness: `/readyz`.

Swagger UI și documentul OpenAPI sunt protejate de sesiunea aplicației.

## Limitări 0.1.0

- sumarizarea inventarului este tolerantă la structura JSON, iar ecranul complet pe colectoare folosește momentan JSON-ul brut;
- nu există încă politici de retenție executate automat;
- nu există încă export DOCX/PDF al fișei VM;
- schimbarea cheii master și recriptarea tokenurilor vor fi introduse într-o versiune ulterioară.

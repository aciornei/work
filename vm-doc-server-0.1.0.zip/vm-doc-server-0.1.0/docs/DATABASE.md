# Database

Migrațiile sunt în `migrations/` și sunt incluse în binar. Tabelul `schema_migrations` reține migrațiile aplicate.

Tabele principale:

- `users`, `sessions`, `oidc_transactions`;
- `roles`, `permissions`, `role_permissions`, `group_role_mappings`;
- `agents`;
- `collection_jobs`;
- `inventory_snapshots`;
- `audit_events`.

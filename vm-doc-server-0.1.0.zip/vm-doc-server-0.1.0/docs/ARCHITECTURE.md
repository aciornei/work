# Architecture

## Procese

`vm-doc-server` deservește browserul și API-ul. `vm-doc-collector` este singurul proces care contactează agenții.

## Coada de colectare

Joburile sunt stocate în `collection_jobs`. Un worker revendică un job printr-un lease în MariaDB. Un job rămas `running` poate fi revendicat după expirarea lease-ului.

## Inventar

Fiecare colectare reușită produce un rând în `inventory_snapshots`. JSON-ul original este păstrat, iar câmpurile folosite în liste sunt extrase separat. SHA-256 permite identificarea schimbărilor fără a pierde istoricul.

## Frontend

Frontendul este HTML/CSS/JavaScript fără toolchain Node.js și este inclus în binarul Go cu `go:embed`.

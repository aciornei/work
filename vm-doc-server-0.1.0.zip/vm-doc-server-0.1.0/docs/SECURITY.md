# Security

- sesiuni opace stocate în MariaDB;
- cookie `HttpOnly`, `Secure` și `SameSite=Lax`;
- token CSRF pentru operații de modificare;
- OIDC Authorization Code Flow cu state, nonce și PKCE;
- LDAP prin LDAPS sau StartTLS;
- AES-256-GCM pentru fișierul de secrete și tokenurile agenților;
- AAD diferit pentru fiecare agent;
- protecție SSRF prin `collector.allowed_networks`;
- UUID binding după prima colectare reușită;
- limită pentru răspunsul agentului;
- secretele și headerul Authorization nu sunt scrise în audit;
- systemd rulează fără privilegii și cu restricții de filesystem/kernel.

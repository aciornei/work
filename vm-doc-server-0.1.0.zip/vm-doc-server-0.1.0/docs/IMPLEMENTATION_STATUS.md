# Implementation status 0.1.0

## Implemented

- two Go entry points: `vm-doc-server` and `vm-doc-collector`;
- YAML configuration with strict field validation;
- encrypted application secrets and individually encrypted agent tokens;
- embedded MariaDB migrations with an advisory migration lock;
- LDAP and Keycloak/OIDC login, opaque sessions, CSRF and built-in RBAC;
- agent CRUD, connection test jobs and manual/periodic collection jobs;
- lease-based collector workers, response limits, network allow-list and UUID binding;
- raw inventory snapshots, SHA-256 change detection, history and online/offline state;
- administrative and collection audit events;
- embedded vanilla HTML/CSS/JavaScript frontend;
- OpenAPI 3.1 document and locally embedded Swagger UI;
- Nginx and systemd deployment examples.

## Validation performed

- Go formatting and package-level static checks;
- unit tests for encryption, inventory summarization, URL validation, RBAC and trusted proxy handling;
- YAML parsing for configuration examples and OpenAPI;
- JavaScript and shell syntax checks.

## Known limitations

- no automated inventory/audit retention worker yet;
- no DOCX/PDF export of the VM sheet yet;
- OIDC discovery is performed when `vm-doc-server` starts;
- built-in role permissions are fixed in 0.1.0; group-to-role mappings are configurable;
- dependencies are not vendored in the source archive.

# Configuration

Configurația este YAML. Parolele nu se introduc în `config.yaml`; ele se păstrează în `secrets.enc`.

`collector.allowed_networks` trebuie restrâns la rețelele în care se află VM-urile. În mediul `production`, lista este obligatorie. Conexiunea este realizată direct către o adresă permisă, fără proxy HTTP și fără urmărirea redirecturilor.

În producție, `collector.allow_http` trebuie să rămână `false`, iar `verify_tls` trebuie activat pentru agenți.

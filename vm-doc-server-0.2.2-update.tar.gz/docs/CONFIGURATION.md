# Configuration

Configurația este YAML și păstrează `version: 1`. Parolele globale nu se introduc în `config.yaml`; parolele surselor vCenter și tokenurile agenților sunt criptate individual în MariaDB.

## vCenter

```yaml
vcenter:
  allow_http: false
  request_timeout: "60s"
  detail_workers: 8
  scheduler_interval: "1m"
```

- `allow_http`: numai pentru laborator; în producție trebuie să fie `false`;
- `request_timeout`: timeout pentru cererile REST vCenter;
- `detail_workers`: numărul de VM-uri citite concurent, între 1 și 64;
- `scheduler_interval`: frecvența cu care serverul verifică programările zilnice.

Ora fiecărei surse se configurează în interfață și este interpretată folosind `app.timezone`.

## Collector

`collector.allowed_networks` trebuie restrâns la rețelele în care se află VM-urile. Conexiunea către agent este directă, fără proxy HTTP și fără redirecturi.

În producție, `collector.allow_http` trebuie să rămână `false`, iar `verify_tls` trebuie activat pentru agenți.

## Autoînregistrarea agenților

```yaml
agent_registration:
  enabled: true
  max_request_body_bytes: 26214400
```

Tokenul se află în fișierul criptat de secrete sub cheia `agent_registration_token`.

# Autoînregistrarea agenților

`vm-doc-server 0.2.2` primește înregistrări, heartbeat-uri și inventare de la
`vm-doc-agent 1.1.0`. Agenții nu mai trebuie creați manual în interfață.

## Flux

```text
agent pornește
  -> register: creează/actualizează înregistrarea și salvează tokenul local criptat
  -> inventory: creează snapshotul și încearcă asocierea după BIOS/DMI UUID
  -> heartbeat: actualizează last_contact_at și starea online/offline
```

Dacă VM-ul nu există încă în inventarul vCenter, agentul rămâne neasociat. După
o sincronizare vCenter, asocierea este încercată din nou folosind inventarul
curent.

## Token comun

Generează un token:

```bash
openssl rand -hex 32
```

Adaugă-l în fișierul YAML care este criptat în `secrets.enc`:

```yaml
agent_registration_token: "TOKEN_GENERAT"
```

Același token se distribuie pe agenți în:

```text
/etc/vm-doc-agent/central-registration-token
```

cu permisiuni `0600`.

## Configurația serverului

```yaml
agent_registration:
  enabled: true
  max_request_body_bytes: 26214400
```

Agentul local 1.1.0 publică implicit URL-uri `http://IP:9078`. Pentru ca
butoanele **Testează agentul** și **Sincronizează acum** să poată apela acel API,
serverul trebuie să permită HTTP în rețeaua de management:

```yaml
collector:
  allow_http: true
```

Accesul la portul 9078 trebuie limitat prin firewall la nodul central.

## Endpointuri

- `POST /api/v1/agent-registration/register`
- `POST /api/v1/agent-registration/heartbeat`
- `POST /api/v1/agent-registration/inventory`

Toate folosesc:

```http
Authorization: Bearer TOKENUL_DE_INREGISTRARE
```

Aceste endpointuri nu folosesc sesiunea web și nu necesită CSRF.

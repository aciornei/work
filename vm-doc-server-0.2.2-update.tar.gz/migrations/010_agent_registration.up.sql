ALTER TABLE agents
  ADD COLUMN IF NOT EXISTS registration_source VARCHAR(16) NOT NULL DEFAULT 'manual' AFTER updated_by,
  ADD COLUMN IF NOT EXISTS registered_at DATETIME(6) NULL AFTER registration_source,
  ADD COLUMN IF NOT EXISTS last_heartbeat_at DATETIME(6) NULL AFTER registered_at,
  ADD COLUMN IF NOT EXISTS agent_version VARCHAR(64) NOT NULL DEFAULT '' AFTER last_heartbeat_at,
  ADD COLUMN IF NOT EXISTS host_hostname VARCHAR(255) NOT NULL DEFAULT '' AFTER agent_version,
  ADD COLUMN IF NOT EXISTS host_fqdn VARCHAR(255) NOT NULL DEFAULT '' AFTER host_hostname,
  ADD COLUMN IF NOT EXISTS product_uuid VARCHAR(64) NOT NULL DEFAULT '' AFTER host_fqdn,
  ADD COLUMN IF NOT EXISTS product_uuid_legacy VARCHAR(64) NOT NULL DEFAULT '' AFTER product_uuid,
  ADD COLUMN IF NOT EXISTS machine_id VARCHAR(128) NOT NULL DEFAULT '' AFTER product_uuid_legacy,
  ADD COLUMN IF NOT EXISTS last_advertised_ip VARCHAR(64) NOT NULL DEFAULT '' AFTER machine_id,
  ADD COLUMN IF NOT EXISTS last_registration_ip VARCHAR(64) NOT NULL DEFAULT '' AFTER last_advertised_ip;

CREATE INDEX IF NOT EXISTS idx_agents_uuid ON agents(agent_uuid);
CREATE INDEX IF NOT EXISTS idx_agents_registration_source ON agents(registration_source, enabled);
CREATE INDEX IF NOT EXISTS idx_agents_heartbeat ON agents(last_heartbeat_at);

package collection

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"log/slog"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"

	"vm-doc-server/internal/agentclient"
	"vm-doc-server/internal/agents"
	"vm-doc-server/internal/audit"
	"vm-doc-server/internal/config"
	"vm-doc-server/internal/domain"
	"vm-doc-server/internal/inventory"
)

type Service struct {
	DB        *sql.DB
	Agents    agents.Service
	Inventory inventory.Service
	Audit     audit.Service
	Client    *agentclient.Client
	Config    config.Config
	Owner     string
	Logger    *slog.Logger
}

func New(db *sql.DB, agentSvc agents.Service, inv inventory.Service, auditSvc audit.Service, client *agentclient.Client, cfg config.Config, logger *slog.Logger) *Service {
	host, _ := os.Hostname()
	return &Service{DB: db, Agents: agentSvc, Inventory: inv, Audit: auditSvc, Client: client, Config: cfg, Owner: fmt.Sprintf("%s-%d", host, os.Getpid()), Logger: logger}
}

func (s *Service) Queue(ctx context.Context, agentID int64, kind, source string, requestedBy *int64) (domain.Job, error) {
	if kind != "test" && kind != "collect" {
		return domain.Job{}, errors.New("kind must be test or collect")
	}
	res, err := s.DB.ExecContext(ctx, `INSERT INTO collection_jobs(agent_id,kind,source,status,requested_by_user_id,scheduled_at,error_message) VALUES(?,?,?,'queued',?,?, '')`, agentID, kind, source, requestedBy, time.Now().UTC())
	if err != nil {
		return domain.Job{}, err
	}
	id, _ := res.LastInsertId()
	return s.Get(ctx, id)
}

func (s *Service) Get(ctx context.Context, id int64) (domain.Job, error) {
	return scanJob(s.DB.QueryRowContext(ctx, jobSelect+` WHERE id=?`, id))
}
func (s *Service) ListForAgent(ctx context.Context, agentID int64, limit int) ([]domain.Job, error) {
	if limit <= 0 || limit > 500 {
		limit = 100
	}
	rows, err := s.DB.QueryContext(ctx, jobSelect+` WHERE agent_id=? ORDER BY id DESC LIMIT ?`, agentID, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.Job, 0)
	for rows.Next() {
		j, err := scanJob(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, j)
	}
	return out, rows.Err()
}

func (s *Service) Run(ctx context.Context) error {
	if s.Logger == nil {
		s.Logger = slog.Default()
	}
	var wg sync.WaitGroup
	wg.Add(1)
	go func() { defer wg.Done(); s.scheduler(ctx) }()
	for i := 0; i < s.Config.Collector.Workers; i++ {
		wg.Add(1)
		go func(worker int) { defer wg.Done(); s.worker(ctx, worker) }(i + 1)
	}
	<-ctx.Done()
	wg.Wait()
	return nil
}

func (s *Service) scheduler(ctx context.Context) {
	ticker := time.NewTicker(s.Config.Collector.PollInterval.Value())
	defer ticker.Stop()
	for {
		if err := s.enqueueDue(ctx); err != nil && ctx.Err() == nil {
			s.Logger.Error("enqueue due agents", "error", err)
		}
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
		}
	}
}
func (s *Service) worker(ctx context.Context, worker int) {
	ticker := time.NewTicker(s.Config.Collector.PollInterval.Value())
	defer ticker.Stop()
	for {
		job, err := s.claim(ctx)
		if err != nil && ctx.Err() == nil {
			s.Logger.Error("claim job", "worker", worker, "error", err)
		}
		if err == nil && job != nil {
			s.process(ctx, *job)
			continue
		}
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
		}
	}
}

func (s *Service) enqueueDue(ctx context.Context) error {
	rows, err := s.DB.QueryContext(ctx, `SELECT id FROM agents WHERE enabled=1 AND registration_source<>'auto' AND (next_collection_at IS NULL OR next_collection_at<=?) ORDER BY COALESCE(next_collection_at,'1970-01-01') LIMIT 500`, time.Now().UTC())
	if err != nil {
		return err
	}
	defer rows.Close()
	var ids []int64
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			return err
		}
		ids = append(ids, id)
	}
	for _, id := range ids {
		res, err := s.DB.ExecContext(ctx, `UPDATE agents SET next_collection_at=DATE_ADD(?, INTERVAL collection_interval_seconds SECOND) WHERE id=? AND enabled=1 AND registration_source<>'auto' AND (next_collection_at IS NULL OR next_collection_at<=?)`, time.Now().UTC(), id, time.Now().UTC())
		if err != nil {
			return err
		}
		n, _ := res.RowsAffected()
		if n == 1 {
			key := fmt.Sprintf("periodic:%d:%d", id, time.Now().UTC().UnixNano())
			_, err = s.DB.ExecContext(ctx, `INSERT INTO collection_jobs(agent_id,kind,source,status,dedupe_key,scheduled_at,error_message) VALUES(?,'collect','scheduler','queued',?,?, '')`, id, key, time.Now().UTC())
			if err != nil {
				return err
			}
		}
	}
	return nil
}

func (s *Service) claim(ctx context.Context) (*domain.Job, error) {
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback()
	row := tx.QueryRowContext(ctx, jobSelect+` WHERE (status='queued' AND scheduled_at<=?) OR (status='running' AND lease_expires_at<?) ORDER BY scheduled_at,id LIMIT 1 FOR UPDATE`, time.Now().UTC(), time.Now().UTC())
	job, err := scanJob(row)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	_, err = tx.ExecContext(ctx, `UPDATE collection_jobs SET status='running',started_at=COALESCE(started_at,?),lease_owner=?,lease_expires_at=?,attempt_count=attempt_count+1 WHERE id=?`, time.Now().UTC(), s.Owner, time.Now().UTC().Add(s.Config.Collector.LeaseDuration.Value()), job.ID)
	if err != nil {
		return nil, err
	}
	if err := tx.Commit(); err != nil {
		return nil, err
	}
	job.Status = "running"
	job.AttemptCount++
	return &job, nil
}

func (s *Service) process(ctx context.Context, job domain.Job) {
	start := time.Now()
	rec, err := s.Agents.GetRecord(ctx, job.AgentID)
	if err != nil {
		s.fail(ctx, job, start, 0, "agent_load_failed", err)
		return
	}
	token, err := s.Agents.DecryptToken(rec)
	if err != nil {
		s.fail(ctx, job, start, 0, "token_decrypt_failed", err)
		return
	}
	var result agentclient.Result
	if job.Kind == "test" {
		result, err = s.Client.Test(ctx, rec.Agent, token)
	} else {
		result, err = s.Client.Collect(ctx, rec.Agent, token, s.Config.Collector.RefreshBeforeCollect)
	}
	if err != nil {
		s.fail(ctx, job, start, result.StatusCode, "agent_request_failed", err)
		return
	}
	summary, err := inventory.Summarize(result.Body)
	if err != nil {
		s.fail(ctx, job, start, result.StatusCode, "invalid_agent_payload", err)
		return
	}
	if job.Kind == "collect" {
		if strings.TrimSpace(summary.AgentUUID) == "" {
			s.fail(ctx, job, start, result.StatusCode, "missing_agent_uuid", errors.New("inventory does not contain the agent UUID"))
			return
		}
		major := schemaMajor(summary.SchemaVersion)
		if major == 0 {
			s.fail(ctx, job, start, result.StatusCode, "missing_schema", errors.New("inventory does not contain a valid schema version"))
			return
		}
		if major != s.Config.Inventory.AcceptedSchemaMajor {
			s.fail(ctx, job, start, result.StatusCode, "unsupported_schema", fmt.Errorf("schema %s is not supported", summary.SchemaVersion))
			return
		}
	}
	if summary.AgentUUID != "" {
		if err := s.Agents.BindUUID(ctx, job.AgentID, summary.AgentUUID); err != nil {
			s.fail(ctx, job, start, result.StatusCode, "uuid_mismatch", err)
			return
		}
	}
	if job.Kind == "collect" {
		if _, err := s.Inventory.Save(ctx, job.AgentID, job.ID, result.Body, summary); err != nil {
			s.fail(ctx, job, start, result.StatusCode, "inventory_save_failed", err)
			return
		}
	} else {
		_ = s.Agents.TouchContact(ctx, job.AgentID)
	}
	duration := time.Since(start).Milliseconds()
	_, err = s.DB.ExecContext(ctx, `UPDATE collection_jobs SET status='succeeded',finished_at=?,lease_owner=NULL,lease_expires_at=NULL,http_status=?,duration_ms=?,error_code='',error_message='' WHERE id=?`, time.Now().UTC(), result.StatusCode, duration, job.ID)
	if err != nil {
		s.Logger.Error("finish job", "job", job.ID, "error", err)
	}
	_ = s.Audit.Log(ctx, audit.Event{Source: "collector", Action: "collection." + job.Kind, ResourceType: "agent", ResourceID: strconv.FormatInt(job.AgentID, 10), Outcome: "success", Details: map[string]any{"job_id": job.ID, "duration_ms": duration, "http_status": result.StatusCode}})
}

func (s *Service) fail(ctx context.Context, job domain.Job, start time.Time, httpStatus int, code string, err error) {
	duration := time.Since(start).Milliseconds()
	_, dbErr := s.DB.ExecContext(ctx, `UPDATE collection_jobs SET status='failed',finished_at=?,lease_owner=NULL,lease_expires_at=NULL,http_status=?,duration_ms=?,error_code=?,error_message=? WHERE id=?`, time.Now().UTC(), nullableInt(httpStatus), duration, code, truncate(err.Error(), 4000), job.ID)
	if dbErr != nil {
		s.Logger.Error("fail job update", "job", job.ID, "error", dbErr)
	}
	_ = s.Agents.TouchFailure(ctx, job.AgentID, err.Error())
	_ = s.Audit.Log(ctx, audit.Event{Source: "collector", Action: "collection." + job.Kind, ResourceType: "agent", ResourceID: strconv.FormatInt(job.AgentID, 10), Outcome: "failure", Details: map[string]any{"job_id": job.ID, "duration_ms": duration, "error_code": code, "error": truncate(err.Error(), 1000)}})
}

const jobSelect = `SELECT id,agent_id,kind,source,status,requested_by_user_id,scheduled_at,started_at,finished_at,attempt_count,http_status,duration_ms,error_code,error_message,created_at FROM collection_jobs`

type scanner interface{ Scan(dest ...any) error }

func scanJob(s scanner) (domain.Job, error) {
	var j domain.Job
	var requested, httpStatus, duration sql.NullInt64
	var started, finished sql.NullTime
	err := s.Scan(&j.ID, &j.AgentID, &j.Kind, &j.Source, &j.Status, &requested, &j.ScheduledAt, &started, &finished, &j.AttemptCount, &httpStatus, &duration, &j.ErrorCode, &j.ErrorMessage, &j.CreatedAt)
	if err != nil {
		return j, err
	}
	if requested.Valid {
		v := requested.Int64
		j.RequestedBy = &v
	}
	if started.Valid {
		t := started.Time
		j.StartedAt = &t
	}
	if finished.Valid {
		t := finished.Time
		j.FinishedAt = &t
	}
	if httpStatus.Valid {
		v := int(httpStatus.Int64)
		j.HTTPStatus = &v
	}
	if duration.Valid {
		v := duration.Int64
		j.DurationMS = &v
	}
	return j, nil
}
func schemaMajor(v string) int {
	parts := strings.Split(strings.TrimSpace(v), ".")
	if len(parts) == 0 {
		return 0
	}
	n, _ := strconv.Atoi(parts[0])
	return n
}
func nullableInt(v int) any {
	if v == 0 {
		return nil
	}
	return v
}
func truncate(v string, n int) string {
	if len(v) > n {
		return v[:n]
	}
	return v
}

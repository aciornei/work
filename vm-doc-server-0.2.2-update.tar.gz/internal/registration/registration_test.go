package registration

import (
	"testing"
	"time"
)

func TestAuthorized(t *testing.T) {
	svc := Service{Token: "registration-token-12345678901234567890"}
	if !svc.Authorized("Bearer registration-token-12345678901234567890") {
		t.Fatal("expected valid bearer token")
	}
	if svc.Authorized("Bearer wrong-token") || svc.Authorized("") {
		t.Fatal("unexpected authorization")
	}
}

func TestValidateRegistration(t *testing.T) {
	svc := Service{AllowHTTPAgents: true}
	request := RegistrationRequest{
		ProtocolVersion: "1",
		Agent:           RegistrationAgent{ID: "agent-1", Version: "1.1.0"},
		Host:            RegistrationHost{Hostname: "vm01"},
		BaseURL:         "http://10.20.30.40:9078",
		AgentToken:      "local-agent-token-1234567890",
	}
	if err := svc.validateRegistration(&request); err != nil {
		t.Fatal(err)
	}
}

func TestDurationOrDefault(t *testing.T) {
	fallback := 15 * time.Minute
	if got := durationOrDefault(300, fallback, time.Minute, time.Hour); got != 5*time.Minute {
		t.Fatalf("unexpected duration %s", got)
	}
	if got := durationOrDefault(1, fallback, time.Minute, time.Hour); got != fallback {
		t.Fatalf("expected fallback, got %s", got)
	}
}

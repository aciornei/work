# Changelog

## 0.2.1

- căutare și filtre VM după nume/hostname, power, OS, IP, agent, `Retired` și sursă vCenter;
- paginare server-side și selector 25/50/100/200 înregistrări;
- statistici pentru rezultatele filtrate;
- export Excel `.xlsx` fără dependențe Go suplimentare;
- antet fix corect în tabelul VM, fără suprapunerea primului rând;
- API-ul `GET /api/v1/vms` întoarce un obiect paginat;
- endpoint nou `GET /api/v1/vms/export`;
- listele vCenter goale sunt serializate ca `[]`, nu `null`;
- rutele Swagger sunt înregistrate explicit ca `GET`, evitând panic în Go 1.23.

## 0.2.0

- vCenter devine sursa principală pentru lista de VM-uri;
- CRUD pentru surse vCenter, cu parolă criptată și verificare TLS;
- sincronizare manuală per sursă sau pentru toate sursele;
- scheduler zilnic configurabil per sursă, în fusul orar al aplicației;
- tabele `vcenter_sources`, `virtual_machines` și `vcenter_sync_runs`;
- VM-urile absente sunt marcate `missing_from_vcenter`, fără ștergere automată;
- lifecycle local `Retired`, cu dată, utilizator și notă;
- asociere automată după BIOS/DMI UUID, inclusiv ordinea SMBIOS legacy VMware;
- asociere manuală și dezlegare agent din fișa VM;
- stare agent și colectare manuală direct din fișa VM;
- parser pentru `agent.id`, `agent.version`, `collection.collectors`, FQDN și UUID-uri de corelare;
- listă VM, filtre, pagină de detaliu și istoric sincronizări în frontend;
- permisiuni RBAC noi: `vcenter.read`, `vcenter.manage`, `vms.manage`;
- OpenAPI 3.1 și documentație actualizate.

## 0.1.0

- două binare: `vm-doc-server` și `vm-doc-collector`;
- configurație YAML și secrete criptate AES-256-GCM;
- migrații MariaDB incluse în binar;
- autentificare LDAP și Keycloak/OIDC cu PKCE;
- sesiuni server-side, CSRF și RBAC;
- administrarea agenților și tokenuri criptate individual;
- joburi manuale și periodice cu lease;
- testare agent, colectare, UUID binding și validare schemă 2.x;
- snapshoturi brute, istoric, hash și stare online/offline;
- audit server/collector;
- frontend static fără Node.js;
- OpenAPI 3.1 și Swagger UI embedded;
- unități systemd și reverse proxy Nginx.

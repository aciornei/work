package vcenter

import (
	"strings"
	"testing"
)

func TestNormalizeVMFilter(t *testing.T) {
	got := NormalizeVMFilter(VMFilter{Page: -1, PageSize: 1000, Agent: " ONLINE ", Retired: " FALSE "})
	if got.Page != 1 || got.PageSize != maxVMPageSize || got.Agent != "online" || got.Retired != "false" {
		t.Fatalf("unexpected normalized filter: %+v", got)
	}
}

func TestBuildVMWhere(t *testing.T) {
	where, args, err := buildVMWhere(NormalizeVMFilter(VMFilter{
		Query: "ubuntu", Power: "POWERED_ON", Agent: "configured", Retired: "false", SourceID: 4,
	}))
	if err != nil {
		t.Fatal(err)
	}
	for _, part := range []string{"vm.name LIKE ?", "vm.power_state=?", "vm.vcenter_source_id=?", "vm.retired=0", "vm.agent_id IS NOT NULL"} {
		if !strings.Contains(where, part) {
			t.Errorf("where clause missing %q: %s", part, where)
		}
	}
	if len(args) != 13 {
		t.Fatalf("got %d args, want 13", len(args))
	}
}

func TestBuildVMWhereRejectsUnknownAgent(t *testing.T) {
	_, _, err := buildVMWhere(NormalizeVMFilter(VMFilter{Agent: "broken"}))
	if err == nil {
		t.Fatal("expected error")
	}
}

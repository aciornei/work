package xlsx

import (
	"archive/zip"
	"bytes"
	"testing"
)

func TestWriteCreatesWorkbook(t *testing.T) {
	var out bytes.Buffer
	if err := Write(&out, "VM-uri", [][]Cell{
		{Text("Nume"), Text("CPU")},
		{Text("vm-test"), Number(4)},
	}); err != nil {
		t.Fatal(err)
	}
	zr, err := zip.NewReader(bytes.NewReader(out.Bytes()), int64(out.Len()))
	if err != nil {
		t.Fatal(err)
	}
	wanted := map[string]bool{
		"[Content_Types].xml":        false,
		"xl/workbook.xml":            false,
		"xl/worksheets/sheet1.xml":   false,
		"xl/styles.xml":              false,
		"xl/_rels/workbook.xml.rels": false,
	}
	for _, file := range zr.File {
		if _, ok := wanted[file.Name]; ok {
			wanted[file.Name] = true
		}
	}
	for name, found := range wanted {
		if !found {
			t.Errorf("missing %s", name)
		}
	}
}

func TestCellReference(t *testing.T) {
	cases := map[[2]int]string{{1, 1}: "A1", {26, 2}: "Z2", {27, 3}: "AA3", {52, 4}: "AZ4"}
	for in, want := range cases {
		if got := cellReference(in[0], in[1]); got != want {
			t.Fatalf("cellReference(%d,%d)=%q want %q", in[0], in[1], got, want)
		}
	}
}

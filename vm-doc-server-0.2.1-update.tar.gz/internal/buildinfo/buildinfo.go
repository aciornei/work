package buildinfo

var (
	Version = "0.2.1-dev"
	Commit  = "unknown"
	Date    = "unknown"
)

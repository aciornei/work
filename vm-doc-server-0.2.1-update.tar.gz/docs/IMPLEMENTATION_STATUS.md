# Implementation status 0.2.1

## Implementat

- surse vCenter cu secrete criptate;
- client REST cu sesiune, TLS și limită de răspuns;
- sincronizare asincronă și programare zilnică;
- upsert VM, marcaj missing și lifecycle Retired;
- corelare automată/manuală cu agentul;
- listă și fișă VM bazate pe vCenter;
- căutare multi-câmp, filtre și paginare server-side;
- export Excel XLSX cu filtrele curente;
- colectare agent din fișa VM;
- parser pentru JSON-ul real al agentului 1.0.0;
- migrații și permisiuni RBAC;
- OpenAPI, documentație și teste unitare actualizate.

## Validare efectuată

- `gofmt` pentru toate pachetele Go;
- teste unitare pentru parserul inventarului și clientul vCenter;
- type-check/test pentru toate pachetele cu interfețe temporare pentru dependențele externe indisponibile în mediul de generare;
- validare YAML pentru OpenAPI și configurația exemplu;
- verificare sintactică JavaScript cu `node --check`;
- verificare shell pentru scripturile de instalare/build.

## Limitări

- custom attributes generale din vCenter nu sunt încă extrase;
- nu există worker automat pentru retenția inventarelor/auditului;
- nu există încă export DOCX/PDF; exportul XLSX este disponibil;
- arhiva sursă nu include `vendor/`;
- buildul final cu dependențele reale trebuie executat într-un mediu cu modulele Go disponibile sau cu directorul `vendor/` pregătit anterior.

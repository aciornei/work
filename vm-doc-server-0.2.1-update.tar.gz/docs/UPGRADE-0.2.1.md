# Upgrade 0.2.0 → 0.2.1

Versiunea 0.2.1 nu adaugă migrații MariaDB și nu schimbă configurația `config.yaml`.

## 1. Backup

```bash
sudo cp -a /opt/vm-doc-server/bin /opt/vm-doc-server/bin.backup-0.2.0
sudo cp -a /etc/vm-doc-server /etc/vm-doc-server.backup-0.2.0
```

## 2. Compilare

Pe mașina cu sursele și directorul `vendor/`:

```bash
cd vm-doc-server-0.2.1
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

## 3. Instalare

```bash
sudo systemctl stop vm-doc-collector vm-doc-server
sudo install -m 0755 bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-server
sudo install -m 0755 bin/vm-doc-collector /opt/vm-doc-server/bin/vm-doc-collector
sudo systemctl start vm-doc-server
curl -fsS http://127.0.0.1:9080/readyz
sudo systemctl start vm-doc-collector
```

Fișierele web sunt incluse în binarul `vm-doc-server`; nu trebuie copiate separat.

## 4. Browser

După upgrade, executați o reîncărcare completă:

```text
Ctrl + F5
```

## 5. Schimbare API

`GET /api/v1/vms` nu mai întoarce direct un array. Răspunsul este paginat:

```json
{
  "items": [],
  "page": 1,
  "page_size": 50,
  "total": 0,
  "pages": 0,
  "present_count": 0,
  "with_agent_count": 0,
  "retired_count": 0
}
```

Filtre disponibile:

```text
q, power, agent, retired, source_id, page, page_size
```

Exportul Excel folosește aceleași filtre:

```text
GET /api/v1/vms/export?q=ubuntu&power=POWERED_ON&retired=false
```

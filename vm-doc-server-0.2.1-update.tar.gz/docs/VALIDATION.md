# Validation notes for 0.2.1

În mediul de împachetare au fost efectuate:

- `gofmt` pentru sursele Go modificate;
- verificarea sintaxei JavaScript cu `node --check web/static/js/app.js`;
- parsarea documentului OpenAPI YAML;
- teste unitare pentru generatorul XLSX;
- teste unitare izolate pentru normalizarea și construirea filtrelor VM;
- deschiderea unui XLSX generat cu `openpyxl`, inclusiv verificarea foii, valorilor, freeze pane și auto-filter;
- verificarea sintaxei scripturilor shell și a integrității arhivei finale.

Mediul nu are acces la internet și nu conține cache-ul complet al modulelor Go. Din acest motiv, testul complet `go test ./...` trebuie executat pe stația cu internet sau pe mașina care are directorul `vendor/` complet:

```bash
go mod download all
go mod vendor
go test -mod=vendor ./...
go vet -mod=vendor ./...
make build
```

Nu au fost efectuate în mediul de împachetare:

- test de sincronizare cu un vCenter real;
- test runtime cu baza MariaDB a utilizatorului;
- test de export cu inventarul real de producție.

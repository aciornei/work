package agents

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"net/url"
	"strings"
	"time"

	"vm-doc-server/internal/config"
	"vm-doc-server/internal/cryptox"
	"vm-doc-server/internal/domain"
)

type Service struct {
	DB     *sql.DB
	Box    *cryptox.Box
	Config config.CollectorConfig
}

type Input struct {
	Name                      string `json:"name"`
	BaseURL                   string `json:"base_url"`
	Enabled                   *bool  `json:"enabled,omitempty"`
	VerifyTLS                 *bool  `json:"verify_tls,omitempty"`
	TLSServerName             string `json:"tls_server_name,omitempty"`
	Token                     string `json:"token,omitempty"`
	CollectionIntervalSeconds int    `json:"collection_interval_seconds,omitempty"`
	RequestTimeoutSeconds     int    `json:"request_timeout_seconds,omitempty"`
	OfflineAfterSeconds       int    `json:"offline_after_seconds,omitempty"`
}

type Record struct {
	domain.Agent
	TokenCiphertext string
}

type Page struct {
	Items    []domain.Agent `json:"items"`
	Page     int            `json:"page"`
	PageSize int            `json:"page_size"`
	Total    int            `json:"total"`
	Pages    int            `json:"pages"`
}

func (s Service) ListPage(ctx context.Context, query, status string, page, pageSize int) (Page, error) {
	values, err := s.List(ctx)
	if err != nil {
		return Page{}, err
	}
	query = strings.ToLower(strings.TrimSpace(query))
	status = strings.ToLower(strings.TrimSpace(status))
	filtered := make([]domain.Agent, 0, len(values))
	for _, value := range values {
		if status != "" && value.Status != status {
			continue
		}
		if query != "" {
			haystack := strings.ToLower(strings.Join([]string{value.Name, value.BaseURL, value.AgentUUID, value.Status, value.LastError}, " "))
			if !strings.Contains(haystack, query) {
				continue
			}
		}
		filtered = append(filtered, value)
	}
	if page < 1 {
		page = 1
	}
	if pageSize < 1 {
		pageSize = 25
	}
	total := len(filtered)
	pages := 0
	if total > 0 {
		pages = (total + pageSize - 1) / pageSize
		if page > pages {
			page = pages
		}
	}
	start := (page - 1) * pageSize
	if start < 0 {
		start = 0
	}
	if start > total {
		start = total
	}
	end := start + pageSize
	if end > total {
		end = total
	}
	return Page{Items: filtered[start:end], Page: page, PageSize: pageSize, Total: total, Pages: pages}, nil
}

func (s Service) List(ctx context.Context) ([]domain.Agent, error) {
	rows, err := s.DB.QueryContext(ctx, agentSelect+` ORDER BY a.name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.Agent, 0)
	for rows.Next() {
		r, err := scanAgent(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, r.Agent)
	}
	return out, rows.Err()
}

func (s Service) Get(ctx context.Context, id int64) (domain.Agent, error) {
	r, err := s.GetRecord(ctx, id)
	return r.Agent, err
}

func (s Service) GetRecord(ctx context.Context, id int64) (Record, error) {
	row := s.DB.QueryRowContext(ctx, agentSelect+` WHERE a.id=?`, id)
	return scanAgent(row)
}

func (s Service) Create(ctx context.Context, in Input, userID int64) (domain.Agent, error) {
	if err := s.normalizeAndValidate(&in, true); err != nil {
		return domain.Agent{}, err
	}
	secretRef, err := cryptox.RandomToken(24)
	if err != nil {
		return domain.Agent{}, err
	}
	ciphertext, err := s.Box.Encrypt([]byte(in.Token), "vm-doc-agent-token:"+secretRef)
	if err != nil {
		return domain.Agent{}, err
	}
	enabled, verify := true, true
	if in.Enabled != nil {
		enabled = *in.Enabled
	}
	if in.VerifyTLS != nil {
		verify = *in.VerifyTLS
	}
	res, err := s.DB.ExecContext(ctx, `INSERT INTO agents(secret_ref,name,base_url,enabled,verify_tls,tls_server_name,token_ciphertext,collection_interval_seconds,request_timeout_seconds,offline_after_seconds,next_collection_at,last_error,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, secretRef, in.Name, strings.TrimRight(in.BaseURL, "/"), enabled, verify, in.TLSServerName, ciphertext, in.CollectionIntervalSeconds, in.RequestTimeoutSeconds, in.OfflineAfterSeconds, time.Now().UTC(), "", userID, userID)
	if err != nil {
		return domain.Agent{}, err
	}
	id, _ := res.LastInsertId()
	return s.Get(ctx, id)
}

func (s Service) Update(ctx context.Context, id int64, in Input, userID int64) (domain.Agent, error) {
	current, err := s.GetRecord(ctx, id)
	if err != nil {
		return domain.Agent{}, err
	}
	if in.Name == "" {
		in.Name = current.Name
	}
	if in.BaseURL == "" {
		in.BaseURL = current.BaseURL
	}
	if in.CollectionIntervalSeconds == 0 {
		in.CollectionIntervalSeconds = current.CollectionIntervalSeconds
	}
	if in.RequestTimeoutSeconds == 0 {
		in.RequestTimeoutSeconds = current.RequestTimeoutSeconds
	}
	if in.OfflineAfterSeconds == 0 {
		in.OfflineAfterSeconds = current.OfflineAfterSeconds
	}
	if in.Enabled == nil {
		v := current.Enabled
		in.Enabled = &v
	}
	if in.VerifyTLS == nil {
		v := current.VerifyTLS
		in.VerifyTLS = &v
	}
	if in.TLSServerName == "" {
		in.TLSServerName = current.TLSServerName
	}
	if err := s.normalizeAndValidate(&in, false); err != nil {
		return domain.Agent{}, err
	}
	ciphertext := current.TokenCiphertext
	if in.Token != "" {
		ciphertext, err = s.Box.Encrypt([]byte(in.Token), "vm-doc-agent-token:"+current.SecretRef)
		if err != nil {
			return domain.Agent{}, err
		}
	}
	_, err = s.DB.ExecContext(ctx, `UPDATE agents SET name=?,base_url=?,enabled=?,verify_tls=?,tls_server_name=?,token_ciphertext=?,collection_interval_seconds=?,request_timeout_seconds=?,offline_after_seconds=?,updated_by=? WHERE id=?`, in.Name, strings.TrimRight(in.BaseURL, "/"), *in.Enabled, *in.VerifyTLS, in.TLSServerName, ciphertext, in.CollectionIntervalSeconds, in.RequestTimeoutSeconds, in.OfflineAfterSeconds, userID, id)
	if err != nil {
		return domain.Agent{}, err
	}
	return s.Get(ctx, id)
}

func (s Service) Delete(ctx context.Context, id int64) error {
	res, err := s.DB.ExecContext(ctx, `DELETE FROM agents WHERE id=?`, id)
	if err != nil {
		return err
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return sql.ErrNoRows
	}
	return nil
}

func (s Service) DecryptToken(r Record) (string, error) {
	plain, err := s.Box.Decrypt(r.TokenCiphertext, "vm-doc-agent-token:"+r.SecretRef)
	return string(plain), err
}

func (s Service) normalizeAndValidate(in *Input, create bool) error {
	in.Name = strings.TrimSpace(in.Name)
	in.BaseURL = strings.TrimSpace(in.BaseURL)
	if in.Name == "" || in.BaseURL == "" {
		return errors.New("name and base_url are required")
	}
	u, err := url.Parse(in.BaseURL)
	if err != nil || u.Host == "" {
		return errors.New("invalid base_url")
	}
	if u.User != nil || u.RawQuery != "" || u.Fragment != "" || (u.Path != "" && u.Path != "/") {
		return errors.New("base_url must contain only scheme, host and optional port")
	}
	if u.Scheme != "https" && !(s.Config.AllowHTTP && u.Scheme == "http") {
		return errors.New("base_url must use HTTPS")
	}
	if create && strings.TrimSpace(in.Token) == "" {
		return errors.New("token is required")
	}
	if in.CollectionIntervalSeconds == 0 {
		in.CollectionIntervalSeconds = int(s.Config.DefaultCollectionInterval.Value().Seconds())
	}
	if in.RequestTimeoutSeconds == 0 {
		in.RequestTimeoutSeconds = int(s.Config.DefaultRequestTimeout.Value().Seconds())
	}
	if in.OfflineAfterSeconds == 0 {
		in.OfflineAfterSeconds = int(s.Config.DefaultOfflineAfter.Value().Seconds())
	}
	if in.CollectionIntervalSeconds < 60 {
		return errors.New("collection interval must be at least 60 seconds")
	}
	if in.RequestTimeoutSeconds < 1 || in.RequestTimeoutSeconds > 600 {
		return errors.New("request timeout must be between 1 and 600 seconds")
	}
	requestBudget := time.Duration(in.RequestTimeoutSeconds) * time.Second
	if s.Config.RefreshBeforeCollect {
		requestBudget *= 2
	}
	if requestBudget+5*time.Second >= s.Config.LeaseDuration.Value() {
		return errors.New("request timeout is too large for collector.lease_duration")
	}
	if in.OfflineAfterSeconds < in.CollectionIntervalSeconds {
		return errors.New("offline_after must be greater than or equal to collection interval")
	}
	return nil
}

const agentSelect = `SELECT a.id,a.secret_ref,a.name,a.base_url,a.enabled,a.verify_tls,a.tls_server_name,a.token_ciphertext,a.agent_uuid,a.collection_interval_seconds,a.request_timeout_seconds,a.offline_after_seconds,a.next_collection_at,a.last_attempt_at,a.last_contact_at,a.last_success_at,a.last_error,a.current_inventory_id,a.created_at,a.updated_at FROM agents a`

type scanner interface{ Scan(dest ...any) error }

func scanAgent(s scanner) (Record, error) {
	var r Record
	var next, attempt, contact, success sql.NullTime
	var current sql.NullInt64
	if err := s.Scan(&r.ID, &r.SecretRef, &r.Name, &r.BaseURL, &r.Enabled, &r.VerifyTLS, &r.TLSServerName, &r.TokenCiphertext, &r.AgentUUID, &r.CollectionIntervalSeconds, &r.RequestTimeoutSeconds, &r.OfflineAfterSeconds, &next, &attempt, &contact, &success, &r.LastError, &current, &r.CreatedAt, &r.UpdatedAt); err != nil {
		return r, err
	}
	r.TokenConfigured = r.TokenCiphertext != ""
	if next.Valid {
		r.NextCollectionAt = &next.Time
	}
	if attempt.Valid {
		r.LastAttemptAt = &attempt.Time
	}
	if contact.Valid {
		r.LastContactAt = &contact.Time
	}
	if success.Valid {
		r.LastSuccessAt = &success.Time
	}
	if current.Valid {
		v := current.Int64
		r.CurrentInventoryID = &v
	}
	r.Status = calculateStatus(r.Agent)
	return r, nil
}

func calculateStatus(a domain.Agent) string {
	if !a.Enabled {
		return "disabled"
	}
	if a.LastContactAt == nil {
		return "unknown"
	}
	if time.Since(a.LastContactAt.UTC()) > time.Duration(a.OfflineAfterSeconds)*time.Second {
		return "offline"
	}
	return "online"
}

func (s Service) TouchFailure(ctx context.Context, id int64, message string) error {
	_, err := s.DB.ExecContext(ctx, `UPDATE agents SET last_attempt_at=?,last_error=? WHERE id=?`, time.Now().UTC(), truncate(message, 4000), id)
	return err
}

func (s Service) TouchContact(ctx context.Context, id int64) error {
	_, err := s.DB.ExecContext(ctx, `UPDATE agents SET last_attempt_at=?,last_contact_at=?,last_error='' WHERE id=?`, time.Now().UTC(), time.Now().UTC(), id)
	return err
}

func (s Service) BindUUID(ctx context.Context, id int64, uuid string) error {
	if uuid == "" {
		return nil
	}
	var existing string
	if err := s.DB.QueryRowContext(ctx, `SELECT agent_uuid FROM agents WHERE id=?`, id).Scan(&existing); err != nil {
		return err
	}
	if existing != "" && existing != uuid {
		return fmt.Errorf("uuid_mismatch: expected %s, received %s", existing, uuid)
	}
	if existing == "" {
		_, err := s.DB.ExecContext(ctx, `UPDATE agents SET agent_uuid=? WHERE id=?`, uuid, id)
		return err
	}
	return nil
}

func truncate(v string, n int) string {
	if len(v) > n {
		return v[:n]
	}
	return v
}

package server

import (
	"database/sql"
	"errors"
	"fmt"
	"io"
	"mime/multipart"
	"net/http"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/documents"
	"vm-doc-server/internal/inventory"
)

func (a *App) listDocumentTemplates(w http.ResponseWriter, r *http.Request) {
	includeInactive := r.URL.Query().Get("include_inactive") == "true"
	objectType := strings.TrimSpace(r.URL.Query().Get("object_type"))
	values, err := a.Documents.ListTemplatesFor(r.Context(), includeInactive, objectType)
	respond(w, values, err)
}

func (a *App) createDocumentTemplate(w http.ResponseWriter, r *http.Request) {
	input, err := parseTemplateMultipart(w, r, a.Config.Server.MaxRequestBody)
	if err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.Documents.CreateTemplate(r.Context(), input, user.ID)
	if err == nil {
		a.auditRequest(r, "document_template.create", "document_template", strconv.FormatInt(value.ID, 10), "success", map[string]any{"name": value.Name, "code": value.Code, "object_type": value.ObjectType, "sha256": value.SHA256, "size_bytes": value.SizeBytes})
	}
	respondStatus(w, value, err, http.StatusCreated)
}

func (a *App) updateDocumentTemplate(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var input documents.TemplateUpdate
	if err := decodeJSON(r, &input, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.Documents.UpdateTemplate(r.Context(), id, user.ID, input)
	if err == nil {
		a.auditRequest(r, "document_template.update", "document_template", strconv.FormatInt(id, 10), "success", map[string]any{"name": value.Name, "code": value.Code, "object_type": value.ObjectType, "active": value.Active, "is_default": value.Default})
	}
	respond(w, value, err)
}

func (a *App) downloadDocumentTemplate(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	value, err := a.Documents.GetTemplate(r.Context(), id, true)
	if err != nil {
		respond(w, nil, err)
		return
	}
	writeDownload(w, value.MIMEType, value.FileName, value.Content)
}

func (a *App) listVMDocuments(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	values, err := a.Documents.ListGeneratedVM(r.Context(), vmID)
	respond(w, values, err)
}

func (a *App) previewVMDocument(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	template, data, err := a.documentGenerationData(r, vmID)
	if err != nil {
		respond(w, nil, err)
		return
	}
	jsonResponse(w, http.StatusOK, documents.BuildPreview(template, data))
}

func (a *App) generateVMDocument(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	template, data, err := a.documentGenerationData(r, vmID)
	if err != nil {
		respond(w, nil, err)
		return
	}
	value, err := a.Documents.Generate(r.Context(), template, data)
	if err == nil {
		a.auditRequest(r, "vm_document.generate", "generated_document", strconv.FormatInt(value.ID, 10), "success", map[string]any{"vm_id": vmID, "document_number": value.DocumentNumber, "template_id": value.TemplateID, "sha256": value.SHA256, "size_bytes": value.SizeBytes})
	}
	respondStatus(w, value, err, http.StatusCreated)
}

func (a *App) listInternalServiceDocuments(w http.ResponseWriter, r *http.Request) {
	serviceID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	values, err := a.Documents.ListGeneratedService(r.Context(), serviceID)
	respond(w, values, err)
}

func (a *App) previewInternalServiceDocument(w http.ResponseWriter, r *http.Request) {
	serviceID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	request, err := decodeTemplateRequest(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	template, data, err := a.serviceDocumentGenerationData(r, serviceID, request, false)
	if err != nil {
		respond(w, nil, err)
		return
	}
	jsonResponse(w, http.StatusOK, documents.BuildServicePreview(template, data))
}

func (a *App) generateInternalServiceDocument(w http.ResponseWriter, r *http.Request) {
	serviceID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	request, err := decodeTemplateRequest(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	template, data, err := a.serviceDocumentGenerationData(r, serviceID, request, true)
	if err != nil {
		respond(w, nil, err)
		return
	}
	value, err := a.Documents.GenerateService(r.Context(), template, data)
	if err == nil {
		a.auditRequest(r, "internal_service_document.generate", "generated_document", strconv.FormatInt(value.ID, 10), "success", map[string]any{"internal_service_id": serviceID, "document_number": value.DocumentNumber, "template_id": value.TemplateID, "sha256": value.SHA256, "size_bytes": value.SizeBytes, "vm_annexes": len(data.VMDocuments), "regenerated_vm_annexes": data.RegeneratedVMAnnexes})
	}
	respondStatus(w, value, err, http.StatusCreated)
}

func (a *App) downloadGeneratedDocument(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	value, err := a.Documents.GetGenerated(r.Context(), id, true)
	if err != nil {
		respond(w, nil, err)
		return
	}
	meta := map[string]any{"object_type": value.ObjectType, "document_number": value.DocumentNumber}
	if value.VMID != nil {
		meta["vm_id"] = *value.VMID
	}
	if value.InternalServiceID != nil {
		meta["internal_service_id"] = *value.InternalServiceID
	}
	a.auditRequest(r, "document.download", "generated_document", strconv.FormatInt(id, 10), "success", meta)
	writeDownload(w, value.MIMEType, value.FileName, value.Content)
}

func (a *App) downloadGeneratedServicePackage(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	content, filename, err := a.Documents.BuildServiceDocumentPackage(r.Context(), id)
	if err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "service_document.package_download", "generated_document", strconv.FormatInt(id, 10), "success", nil)
	writeDownload(w, "application/zip", filename, content)
}

func (a *App) documentGenerationData(r *http.Request, vmID int64) (documents.Template, documents.GenerationData, error) {
	request, err := decodeTemplateRequest(r)
	if err != nil {
		return documents.Template{}, documents.GenerationData{}, err
	}
	var template documents.Template
	if request.TemplateID > 0 {
		template, err = a.Documents.GetTemplate(r.Context(), request.TemplateID, true)
	} else {
		template, err = a.Documents.DefaultTemplateFor(r.Context(), "vm")
	}
	if err != nil {
		return documents.Template{}, documents.GenerationData{}, err
	}
	if template.ObjectType != "vm" {
		return documents.Template{}, documents.GenerationData{}, errors.New("selected template is not a VM template")
	}
	data, err := a.buildVMGenerationData(r, vmID)
	if err != nil {
		return documents.Template{}, documents.GenerationData{}, err
	}
	return template, data, nil
}

func (a *App) buildVMGenerationData(r *http.Request, vmID int64) (documents.GenerationData, error) {
	vm, err := a.VCenter.GetVM(r.Context(), vmID)
	if err != nil {
		return documents.GenerationData{}, err
	}
	operational, err := a.VCenter.GetOperationalMetadata(r.Context(), vmID)
	if err != nil {
		return documents.GenerationData{}, err
	}
	backup, err := a.VCenter.GetBackupSummary(r.Context(), vmID)
	if err != nil {
		return documents.GenerationData{}, err
	}
	user, _ := auth.UserFromContext(r.Context())
	now := time.Now().UTC()
	data := documents.GenerationData{VM: vm, Operational: operational, Backup: backup, GeneratedBy: user, GeneratedAt: now, DocumentNumber: documents.NewDocumentNumber(vmID, now)}
	if a.Catalog.DB != nil {
		dependencies, dependencyErr := a.Catalog.ListVMDependencies(r.Context(), vmID)
		if dependencyErr != nil {
			return documents.GenerationData{}, fmt.Errorf("load common dependencies: %w", dependencyErr)
		}
		data.CommonDependencies = dependencies
	}
	if vm.CurrentInventoryID != nil {
		current, inventoryErr := a.Inventory.Get(r.Context(), *vm.CurrentInventoryID, true)
		if inventoryErr != nil && !errors.Is(inventoryErr, sql.ErrNoRows) {
			return documents.GenerationData{}, inventoryErr
		}
		if inventoryErr == nil {
			data.Inventory = &current
			view, viewErr := inventory.BuildDocumentView(current.RawJSON)
			if viewErr != nil {
				return documents.GenerationData{}, fmt.Errorf("build inventory document: %w", viewErr)
			}
			data.InventoryDocument = &view
		}
	}
	return data, nil
}

func (a *App) serviceDocumentGenerationData(r *http.Request, serviceID int64, request templateRequest, prepareAnnexes bool) (documents.Template, documents.ServiceGenerationData, error) {
	var template documents.Template
	var err error
	if request.TemplateID > 0 {
		template, err = a.Documents.GetTemplate(r.Context(), request.TemplateID, true)
	} else {
		template, err = a.Documents.DefaultTemplateFor(r.Context(), "service")
	}
	if err != nil {
		return documents.Template{}, documents.ServiceGenerationData{}, err
	}
	if template.ObjectType != "service" {
		return documents.Template{}, documents.ServiceGenerationData{}, errors.New("selected template is not an internal service template")
	}
	service, err := a.Catalog.Get(r.Context(), serviceID)
	if err != nil {
		return documents.Template{}, documents.ServiceGenerationData{}, err
	}
	user, _ := auth.UserFromContext(r.Context())
	now := time.Now().UTC()
	data := documents.ServiceGenerationData{Service: service, GeneratedBy: user, GeneratedAt: now, DocumentNumber: documents.NewServiceDocumentNumber(serviceID, now), BaseURL: strings.TrimRight(a.Config.App.BaseURL, "/"), IncludeVMAnnexes: request.IncludeVMAnnexes}
	vmEnvironment := make(map[int64]string)
	vmName := make(map[int64]string)
	order := make([]int64, 0)
	for _, item := range service.VMs {
		if _, ok := vmName[item.ID]; !ok {
			order = append(order, item.ID)
			vmName[item.ID] = firstServerNonEmpty(item.GuestHostname, item.Name)
			vmEnvironment[item.ID] = item.Environment
		}
	}
	var vmTemplate documents.Template
	if request.IncludeVMAnnexes && prepareAnnexes {
		vmTemplate, err = a.Documents.DefaultTemplateFor(r.Context(), "vm")
		if err != nil {
			return documents.Template{}, documents.ServiceGenerationData{}, err
		}
	}
	for _, vmID := range order {
		var generated documents.GeneratedDocument
		existing, listErr := a.Documents.ListGeneratedVM(r.Context(), vmID)
		if listErr != nil {
			return documents.Template{}, documents.ServiceGenerationData{}, listErr
		}
		needGenerate := request.IncludeVMAnnexes && prepareAnnexes && (request.RegenerateVMAnnexes || len(existing) == 0)
		if needGenerate {
			vmData, dataErr := a.buildVMGenerationData(r, vmID)
			if dataErr != nil {
				return documents.Template{}, documents.ServiceGenerationData{}, dataErr
			}
			generated, dataErr = a.Documents.Generate(r.Context(), vmTemplate, vmData)
			if dataErr != nil {
				return documents.Template{}, documents.ServiceGenerationData{}, dataErr
			}
			data.RegeneratedVMAnnexes = true
		} else if len(existing) > 0 {
			generated = existing[0]
		}
		if generated.ID > 0 {
			url := ""
			if data.BaseURL != "" {
				url = data.BaseURL + "/api/v1/documents/" + strconv.FormatInt(generated.ID, 10) + "/download"
			}
			data.VMDocuments = append(data.VMDocuments, documents.ServiceVMDocument{VMID: vmID, VMName: vmName[vmID], Environment: vmEnvironment[vmID], DocumentID: generated.ID, DocumentNumber: generated.DocumentNumber, FileName: generated.FileName, GeneratedAt: generated.GeneratedAt, DownloadURL: url})
		}
	}
	return template, data, nil
}

func firstServerNonEmpty(values ...string) string {
	for _, value := range values {
		if strings.TrimSpace(value) != "" {
			return strings.TrimSpace(value)
		}
	}
	return ""
}

type templateRequest struct {
	TemplateID          int64 `json:"template_id"`
	IncludeVMAnnexes    bool  `json:"include_vm_annexes"`
	RegenerateVMAnnexes bool  `json:"regenerate_vm_annexes"`
}

func decodeTemplateRequest(r *http.Request) (templateRequest, error) {
	var request templateRequest
	if err := decodeJSON(r, &request, 1<<20); err != nil {
		return request, err
	}
	return request, nil
}

func parseTemplateMultipart(w http.ResponseWriter, r *http.Request, max int64) (documents.TemplateInput, error) {
	if max <= 0 || max > 24<<20 {
		max = 24 << 20
	}
	r.Body = http.MaxBytesReader(w, r.Body, max)
	if err := r.ParseMultipartForm(max); err != nil {
		return documents.TemplateInput{}, fmt.Errorf("invalid multipart form: %w", err)
	}
	file, header, err := r.FormFile("file")
	if err != nil {
		return documents.TemplateInput{}, errors.New("DOCX file is required")
	}
	defer file.Close()
	content, err := readMultipartFile(file, 20<<20)
	if err != nil {
		return documents.TemplateInput{}, err
	}
	return documents.TemplateInput{
		Name:        r.FormValue("name"),
		Code:        r.FormValue("code"),
		ObjectType:  r.FormValue("object_type"),
		Description: r.FormValue("description"),
		FileName:    filepath.Base(header.Filename),
		MIMEType:    header.Header.Get("Content-Type"),
		Content:     content,
		Active:      parseFormBool(r.FormValue("active"), true),
		Default:     parseFormBool(r.FormValue("is_default"), false),
	}, nil
}

func readMultipartFile(file multipart.File, max int64) ([]byte, error) {
	content, err := io.ReadAll(io.LimitReader(file, max+1))
	if err != nil {
		return nil, err
	}
	if int64(len(content)) > max {
		return nil, fmt.Errorf("DOCX file must be at most %d MiB", max>>20)
	}
	return content, nil
}

func parseFormBool(value string, fallback bool) bool {
	value = strings.ToLower(strings.TrimSpace(value))
	if value == "" {
		return fallback
	}
	return value == "1" || value == "true" || value == "yes" || value == "on"
}

func writeDownload(w http.ResponseWriter, contentType, filename string, content []byte) {
	filename = strings.ReplaceAll(strings.ReplaceAll(filepath.Base(filename), "\r", ""), "\n", "")
	if filename == "" || filename == "." {
		filename = "document.docx"
	}
	if contentType == "" {
		contentType = "application/octet-stream"
	}
	w.Header().Set("Content-Type", contentType)
	w.Header().Set("Content-Disposition", `attachment; filename="`+strings.ReplaceAll(filename, `"`, "")+`"`)
	w.Header().Set("Content-Length", strconv.Itoa(len(content)))
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.Header().Set("Cache-Control", "private, no-store")
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write(content)
}

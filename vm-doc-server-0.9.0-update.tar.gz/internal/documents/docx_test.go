package documents

import (
	"archive/zip"
	"bytes"
	"encoding/json"
	"io"
	"strings"
	"testing"
	"time"

	"vm-doc-server/internal/domain"
	"vm-doc-server/internal/inventory"
)

func TestDefaultTemplateAndRender(t *testing.T) {
	template, err := DefaultTemplate()
	if err != nil {
		t.Fatal(err)
	}
	if err := ValidateTemplate(template); err != nil {
		t.Fatal(err)
	}
	now := time.Date(2026, 9, 1, 12, 30, 0, 0, time.UTC)
	view := inventory.DocumentView{Sections: []inventory.DocumentSection{{Key: "network", Title: "Rețea", Data: map[string]any{"primary_ip": "10.0.0.10"}}}}
	data := GenerationData{
		VM:                domain.VirtualMachine{ID: 295, Name: "vm-test", CPUCount: 4, MemoryMiB: 8192, PowerState: "poweredOn", GuestHostname: "vm-test", PrimaryIP: "10.0.0.10"},
		Operational:       domain.VMOperationalMetadata{Environment: "Producție", OperationalStatus: "Activ"},
		InventoryDocument: &view,
		GeneratedBy:       domain.User{Username: "tester", DisplayName: "Test User"},
		GeneratedAt:       now,
		DocumentNumber:    "FVM-20260901-000295-ABCD",
	}
	output, err := RenderDOCX(template, data)
	if err != nil {
		t.Fatal(err)
	}
	reader, err := zip.NewReader(bytes.NewReader(output), int64(len(output)))
	if err != nil {
		t.Fatal(err)
	}
	var document string
	for _, file := range reader.File {
		if file.Name != "word/document.xml" {
			continue
		}
		handle, err := file.Open()
		if err != nil {
			t.Fatal(err)
		}
		content, err := io.ReadAll(handle)
		handle.Close()
		if err != nil {
			t.Fatal(err)
		}
		document = string(content)
	}
	if document == "" {
		t.Fatal("word/document.xml missing")
	}
	if strings.Contains(document, BodyPlaceholder) {
		t.Fatal("body placeholder was not replaced")
	}
	for _, expected := range []string{"Fișă tehnică VM", "vm-test", "FVM-20260901-000295-ABCD", "Rețea", "10.0.0.10"} {
		if !strings.Contains(document, expected) {
			t.Fatalf("document does not contain %q", expected)
		}
	}
}

func TestValidateTemplateRequiresBodyPlaceholder(t *testing.T) {
	template, err := DefaultTemplate()
	if err != nil {
		t.Fatal(err)
	}
	reader, err := zip.NewReader(bytes.NewReader(template), int64(len(template)))
	if err != nil {
		t.Fatal(err)
	}
	var output bytes.Buffer
	writer := zip.NewWriter(&output)
	for _, source := range reader.File {
		handle, err := source.Open()
		if err != nil {
			t.Fatal(err)
		}
		content, err := io.ReadAll(handle)
		handle.Close()
		if err != nil {
			t.Fatal(err)
		}
		if source.Name == "word/document.xml" {
			content = bytes.ReplaceAll(content, []byte(BodyPlaceholder), []byte("missing"))
		}
		destination, err := writer.Create(source.Name)
		if err != nil {
			t.Fatal(err)
		}
		if _, err := destination.Write(content); err != nil {
			t.Fatal(err)
		}
	}
	if err := writer.Close(); err != nil {
		t.Fatal(err)
	}
	if err := ValidateTemplate(output.Bytes()); err == nil {
		t.Fatal("expected validation error")
	}
}

func TestCompactInventoryRendering(t *testing.T) {
	template, err := DefaultTemplate()
	if err != nil {
		t.Fatal(err)
	}
	view := inventory.DocumentView{Sections: []inventory.DocumentSection{
		{Key: "schema", Data: map[string]any{"name": "vm-doc-agent-inventory", "version": "2.0"}},
		{Key: "agent", Data: map[string]any{"version": "1.0.0"}},
		{Key: "system", Data: map[string]any{"architecture": "x86_64", "uptime_seconds": json.Number("123456")}},
		{Key: "os", Data: map[string]any{"name": "Ubuntu", "version": "24.04"}},
		{Key: "storage", Data: map[string]any{"mounts": []any{
			map[string]any{"mount_point": "/", "filesystem": "ext4", "size_bytes": json.Number("107374182400")},
			map[string]any{"mount_point": "/data", "filesystem": "xfs", "size_bytes": json.Number("1099511627776")},
		}}},
		{Key: "network", Data: map[string]any{"interfaces": []any{
			map[string]any{"name": "ens192", "addresses": []any{"10.20.30.40/24"}, "gateway": "10.20.30.1", "dns_servers": []any{"10.20.0.10", "10.20.0.11"}},
		}}},
		{Key: "proxy", Data: map[string]any{"http_proxy": "http://proxy.example"}},
		{Key: "services", Data: []any{
			map[string]any{"name": "sshd.service", "description": "OpenSSH server", "status": "active"},
			map[string]any{"name": "cups.service", "description": "Printing", "status": "inactive"},
		}},
		{Key: "listening_ports", Data: []any{
			map[string]any{"name": "sshd", "executable": "/usr/sbin/sshd", "port": json.Number("22"), "protocol": "tcp"},
		}},
		{Key: "firewall", Data: map[string]any{"ufw_status_numbered": []any{"[ 1] 22/tcp ALLOW IN 10.0.0.0/8", "[ 2] 443/tcp ALLOW IN Anywhere"}}},
		{Key: "accounts", Data: []any{
			map[string]any{"username": "root", "uid": json.Number("0"), "home": "/root", "shell": "/bin/bash"},
			map[string]any{"username": "service", "uid": json.Number("500"), "home": "/srv/service", "shell": "/usr/sbin/nologin"},
			map[string]any{"username": "appadmin", "uid": json.Number("1001"), "home": "/home/appadmin", "groups": []any{"sudo"}},
		}},
		{Key: "sssd", Data: map[string]any{"installed": true, "ldap_search_base": "OU=Linux,DC=example,DC=ro", "version": "2.9.4"}},
		{Key: "integrations", Data: map[string]any{
			"auditbeat":     map[string]any{"installed": true, "version": "8.16", "config_ok": true, "output_host": "graylog.example.ro", "details": "system module"},
			"filebeat":      map[string]any{"installed": true, "version": "8.16", "config_ok": true, "output_host": "logstash.example.ro"},
			"glpi_agent":    map[string]any{"installed": true, "version": "1.15", "config_ok": true, "server": "glpi.example.ro"},
			"node_exporter": map[string]any{"installed": true, "version": "1.9.1", "config_ok": true, "host": "0.0.0.0:9100"},
			"syslog":        map[string]any{"enabled": true, "version": "8.2312", "config_ok": true, "destination": "graylog.example.ro:514"},
		}},
		{Key: "cron", Data: []any{map[string]any{"schedule": "0 2 * * *", "command": "/opt/app/backup.sh", "user": "root"}}},
		{Key: "ntp", Data: map[string]any{"conf_file": "/etc/chrony/chrony.conf", "sources": []any{"ntp1.example.ro", "ntp2.example.ro"}, "version": "4.5"}},
	}}
	data := GenerationData{
		VM:                domain.VirtualMachine{ID: 295, Name: "metabase", CPUCount: 4, MemoryMiB: 8192},
		InventoryDocument: &view,
		GeneratedAt:       time.Date(2026, 9, 1, 12, 30, 0, 0, time.UTC),
		DocumentNumber:    "FVM-TEST",
	}
	output, err := RenderDOCX(template, data)
	if err != nil {
		t.Fatal(err)
	}
	document := documentXMLFromDOCX(t, output)
	for _, expected := range []string{
		"6.5 Stocare", "100 GB", "1.00 TB", "ens192", "10.20.30.40", "sshd.service", "/usr/sbin/sshd", "appadmin", "OU=Linux,DC=example,DC=ro", "Auditbeat", "graylog.example.ro", "/etc/chrony/chrony.conf", "<w:tblGrid>",
	} {
		if !strings.Contains(document, expected) {
			t.Fatalf("document does not contain %q", expected)
		}
	}
	for _, unexpected := range []string{"6.2 Agent", "6.7 Proxy", "uptime_seconds", "cups.service", "/srv/service", "http://proxy.example"} {
		if strings.Contains(document, unexpected) {
			t.Fatalf("document unexpectedly contains %q", unexpected)
		}
	}
}

func documentXMLFromDOCX(t *testing.T, content []byte) string {
	t.Helper()
	reader, err := zip.NewReader(bytes.NewReader(content), int64(len(content)))
	if err != nil {
		t.Fatal(err)
	}
	for _, file := range reader.File {
		if file.Name != "word/document.xml" {
			continue
		}
		handle, err := file.Open()
		if err != nil {
			t.Fatal(err)
		}
		data, err := io.ReadAll(handle)
		handle.Close()
		if err != nil {
			t.Fatal(err)
		}
		return string(data)
	}
	t.Fatal("word/document.xml missing")
	return ""
}

func TestDefaultServiceTemplateAndRender(t *testing.T) {
	template, err := DefaultServiceTemplate()
	if err != nil {
		t.Fatal(err)
	}
	if err := ValidateTemplateFor(template, "service"); err != nil {
		t.Fatal(err)
	}
	now := time.Date(2026, 9, 2, 8, 30, 0, 0, time.UTC)
	service := domain.InternalService{
		ID:          17,
		Name:        "Metabase",
		ServiceCode: "metabase",
		Description: "Platformă internă de raportare.",
		Purpose:     "Serviciul furnizează raportare BI internă pentru echipele operaționale și management.",
		PurposeRichText: &domain.RichTextDocument{Version: 1, Blocks: []domain.RichTextBlock{
			{Type: "paragraph", Runs: []domain.RichTextRun{{Text: "Serviciul furnizează ", Bold: false}, {Text: "raportare BI internă", Bold: true}, {Text: " pentru echipele operaționale și management."}}},
		}},
		Objectives: "Centralizarea indicatorilor.\nReducerea raportării manuale.\nAcces controlat la dashboard-uri.",
		ObjectivesRichText: &domain.RichTextDocument{Version: 1, Blocks: []domain.RichTextBlock{
			{Type: "bullet", Runs: []domain.RichTextRun{{Text: "Centralizarea indicatorilor.", Italic: true}}},
			{Type: "bullet", Runs: []domain.RichTextRun{{Text: "Reducerea raportării manuale.", Underline: true}}},
			{Type: "number", Runs: []domain.RichTextRun{{Text: "Acces controlat la dashboard-uri."}}},
		}},
		Criticality:         "high",
		DocumentationStatus: "approved",
		Active:              true,
		VMCount:             2,
		Classifications: []domain.InternalServiceClassification{{
			ArchitecturalDomainID: 1, ArchitecturalDomain: "Aplicații de business", ITILCategoryID: 2, ITILCategory: "Raportare", VMCount: 2, AssignmentCount: 2,
		}},
		SolutionTypes: []domain.InternalServiceSolutionType{{SolutionTypeID: 3, SolutionType: "Open source", VMCount: 2, AssignmentCount: 2}},
		Dependencies:  []domain.ServiceDependency{{TargetServiceID: 90, TargetServiceName: "Active Directory", DependencyTypeID: 91, DependencyType: "Autentificare", TargetVMCount: 2, TargetVMNames: "dc01, dc02", Notes: "Autentificare utilizatori"}},
		RoleMappings: []domain.ServiceRoleMapping{
			{LayerID: 1, LayerName: "Aplicație", TechnicalRoleID: 2, TechnicalRole: "Aplicație BI", VMCount: 1},
			{LayerID: 3, LayerName: "Date", TechnicalRoleID: 4, TechnicalRole: "MariaDB", VMCount: 1},
		},
		VMs: []domain.InternalServiceVM{
			{AssignmentID: 101, ID: 10, Name: "metabase01", GuestHostname: "metabase01", PrimaryIP: "10.20.30.40", PowerState: "poweredOn", Environment: "PROD", LatestDocumentNumber: "FVM-20260902-000010-AAAA", ArchitecturalDomain: "Aplicații de business", ITILCategory: "Raportare", LayerID: int64Ptr(1), LayerName: "Aplicație", TechnicalRoleID: int64Ptr(2), TechnicalRole: "Aplicație BI", SolutionType: "Open source", UsageType: "dedicated", Primary: true},
			{AssignmentID: 102, ID: 10, Name: "metabase01", GuestHostname: "metabase01", PrimaryIP: "10.20.30.40", PowerState: "poweredOn", Environment: "PROD", LatestDocumentNumber: "FVM-20260902-000010-AAAA", ArchitecturalDomain: "Aplicații de business", ITILCategory: "Raportare", LayerID: int64Ptr(3), LayerName: "Date", TechnicalRoleID: int64Ptr(4), TechnicalRole: "MariaDB", SolutionType: "Open source", UsageType: "dedicated"},
		},
	}
	data := ServiceGenerationData{Service: service, GeneratedBy: domain.User{Username: "tester", DisplayName: "Test User"}, GeneratedAt: now, DocumentNumber: "FSI-20260902-000017-ABCD", BaseURL: "https://vm-doc.example", IncludeVMAnnexes: true, VMDocuments: []ServiceVMDocument{{VMID: 10, VMName: "metabase01", Environment: "PROD", DocumentID: 77, DocumentNumber: "FVM-20260902-000010-AAAA", FileName: "metabase01.docx", GeneratedAt: now, DownloadURL: "https://vm-doc.example/api/v1/documents/77/download"}}}
	output, err := RenderServiceDOCX(template, data)
	if err != nil {
		t.Fatal(err)
	}
	document := documentXMLFromDOCX(t, output)
	if strings.Contains(document, ServiceBodyPlaceholder) {
		t.Fatal("service body placeholder was not replaced")
	}
	for _, expected := range []string{"Fișă serviciu intern", "Metabase", "FSI-20260902-000017-ABCD", "Scop și domeniu", "Obiective", "Schemă logică a serviciului", "Multi-layer", "Aplicații de business", "Open source", "Aplicație BI", "MariaDB", "metabase01", "10.20.30.40", "PROD", "Încadrare pe medii", "Legături către fișele VM", "Deschide fișa", "https://vm-doc.example/api/v1/documents/77/download", "Anexe", "FVM-20260902-000010-AAAA", "Reducerea raportării manuale", "Active Directory", "Autentificare", "dc01, dc02", "• ", "1. ", `<w:u w:val="single"/>`, `<w:i/>`} {
		if !strings.Contains(document, expected) {
			t.Fatalf("service document does not contain %q", expected)
		}
	}
}

func TestServiceDiagramGroupsVMOnlyOnce(t *testing.T) {
	assignments := []domain.InternalServiceVM{
		{ID: 10, Name: "vm01", LayerName: "Aplicație", TechnicalRole: "Backend"},
		{ID: 10, Name: "vm01", LayerName: "Date", TechnicalRole: "MariaDB"},
		{ID: 11, Name: "vm02", LayerName: "Aplicație", TechnicalRole: "Frontend"},
	}
	lanes := buildServiceDiagramLanes(assignments)
	vmCount := 0
	var vm01 *serviceDiagramVM
	for i := range lanes {
		vmCount += len(lanes[i].VMs)
		for j := range lanes[i].VMs {
			if lanes[i].VMs[j].ID == 10 {
				vm01 = &lanes[i].VMs[j]
			}
		}
	}
	if vmCount != 2 {
		t.Fatalf("expected 2 unique VM nodes, got %d", vmCount)
	}
	if vm01 == nil || len(vm01.Assignments) != 2 {
		t.Fatalf("expected vm01 once with 2 assignments, got %#v", vm01)
	}
}

func int64Ptr(value int64) *int64 { return &value }

func TestServiceTemplateRejectsVMTemplate(t *testing.T) {
	template, err := DefaultTemplate()
	if err != nil {
		t.Fatal(err)
	}
	if err := ValidateTemplateFor(template, "service"); err == nil {
		t.Fatal("expected service template validation error")
	}
}

func TestCommonServiceDocumentIncludesDirectVMImpact(t *testing.T) {
	template, err := DefaultServiceTemplate()
	if err != nil {
		t.Fatal(err)
	}
	service := domain.InternalService{
		ID:                    90,
		Name:                  "OpenLDAP",
		ServiceCode:           "openldap",
		Criticality:           "high",
		DocumentationStatus:   "approved",
		Active:                true,
		IsCommon:              true,
		CommonDependencyType:  "Directory / Identity",
		DependentServiceCount: 1,
		Dependents: []domain.ServiceDependency{{
			SourceServiceID: 12, SourceServiceName: "Resurse Umane", TargetServiceID: 90, TargetServiceName: "OpenLDAP", DependencyTypeID: 2, DependencyType: "Directory / Identity",
		}},
		DirectVMDependents: []domain.VMDependencyImpact{{
			VMID: 44, VMName: "legacy-app01", DependencyTypeID: 2, DependencyType: "Directory / Identity", Notes: "Integrare LDAP directă",
		}},
	}
	data := ServiceGenerationData{Service: service, GeneratedBy: domain.User{Username: "tester"}, GeneratedAt: time.Date(2026, 9, 2, 12, 0, 0, 0, time.UTC), DocumentNumber: "FSI-TEST"}
	output, err := RenderServiceDOCX(template, data)
	if err != nil {
		t.Fatal(err)
	}
	document := documentXMLFromDOCX(t, output)
	for _, expected := range []string{"Impact asupra serviciilor dependente", "Resurse Umane", "VM-uri dependente direct", "legacy-app01", "Integrare LDAP directă"} {
		if !strings.Contains(document, expected) {
			t.Fatalf("common service document does not contain %q", expected)
		}
	}
}

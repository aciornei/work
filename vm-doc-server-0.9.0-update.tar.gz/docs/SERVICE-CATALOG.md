# Catalogul serviciilor interne

## Scop

Serviciul intern reprezintă obiectul documentat, de exemplu `Metabase`, `Platforma Mail` sau `Alfresco`. Încadrarea arhitecturală nu este proprietatea fixă a serviciului, ci a modului în care un VM participă la acel serviciu.

## Tip soluție (0.6.0)

Fiecare asociere VM–serviciu păstrează și **Tip soluție**, ales din nomenclatorul `solution_type`. Valorile inițiale sunt **Open source**, **Dezvoltată intern** și **Comercială**. Tipul este atributul asocierii, nu al serviciului în ansamblu, astfel încât același serviciu poate conține tehnologii de natură diferită. Pagina serviciului agregă automat tipurile observate și numărul de VM-uri/asocieri pentru fiecare.


## Model

```text
Nomenclatoare
├── Domeniu arhitectural
│   └── Categorie de serviciu
├── Layer arhitectural
│   └── Rol tehnic permis
└── Tip soluție
    ├── Open source
    ├── Dezvoltată intern
    └── Comercială

Fișă VM
└── Asociere serviciu
    ├── Domeniu arhitectural
    ├── Categorie de serviciu
    ├── Serviciu intern
    ├── Layer arhitectural
    ├── Rol tehnic
    ├── Tip soluție
    ├── Tip utilizare
    └── Principal / observații
```

## Reguli

- fiecare categorie de serviciu are exact un domeniu arhitectural părinte;
- serviciul intern nu are domeniu sau categorie configurate manual;
- domeniul, categoria și tipul soluției se salvează pe asocierea VM–serviciu;
- fiecare rol tehnic aparține unuia sau mai multor layer-e;
- un VM poate avea mai multe asocieri;
- același serviciu poate fi folosit în mai multe domenii sau categorii;
- combinația `VM + domeniu + categorie + serviciu + layer + rol` este unică;
- cel mult o asociere a unui VM poate fi marcată drept principală;
- backendul verifică faptul că categoria aparține domeniului și rolul aparține layer-ului.

## Selecția pe fișa VM

```text
Alegi domeniul
  → apar numai categoriile de serviciu ale domeniului
    → alegi serviciul intern
      → alegi layer-ul
        → apar numai rolurile permise în layer
          → alegi tipul soluției
```

Serviciile interne sunt independente de încadrare și pot fi reutilizate. Un serviciu nou poate fi definit în catalog înainte de a avea VM-uri asociate; până la prima asociere apare ca „Neîncadrat încă”.

## Pagina Servicii

La nivelul serviciului se administrează manual doar:

- denumirea și codul intern;
- descrierea și scopul;
- criticitatea;
- starea și linkul documentației;
- starea activ/inactiv.

Din fișele VM sunt calculate automat:

- domeniile arhitecturale observate;
- categoriile de serviciu observate;
- numărul de VM-uri și asocieri pentru fiecare încadrare;
- layer-ele și rolurile tehnice;
- tipul de utilizare și asocierea principală.

## Exemplu

```text
Serviciu intern: Metabase
├── Business Intelligence → Raportare
│   ├── metabase01 → Aplicație → Aplicație BI
│   └── postgres-shared01 → Bază de date → PostgreSQL
└── Platforme comune → Publicare aplicații
    └── nginx01 → Acces și publicare → Reverse proxy
```

Pagina Metabase va afișa automat ambele încadrări, fără ca acestea să fie introduse în formularul serviciului.

## Documentare

Din 0.6.0, pagina serviciului poate genera direct fișa DOCX a Serviciului intern. Documentul agregă încadrările, tipurile de soluție, layer-ele/rolurile și VM-urile asociate. Conversia PDF și semnarea digitală rămân pentru o versiune ulterioară.


## Conținut narativ al serviciului (0.7.1)

Fiecare Serviciu intern poate documenta direct **Descriere**, **Scop și domeniu** și **Obiective**. Scop și domeniu descrie aria funcțională, beneficiarii și limitele serviciului; Obiective descrie rezultatele urmărite și criteriile operaționale principale. Ambele sunt preluate automat în fișa DOCX.


## Editor narativ rich-text (0.7.2)

Câmpurile **Scop și domeniu** și **Obiective** au editor cu formatare directă: bold, italic, underline, bullets, numerotare și indentare. Modelul salvat nu este HTML, ci un document JSON restricționat și validat server-side. Aceeași structură este folosită pentru afișarea din aplicație și pentru generarea DOCX, în timp ce `purpose` și `objectives` rămân sincronizate ca text simplu pentru compatibilitate.

## Servicii comune și dependențe (0.9.0)

Un serviciu intern poate fi marcat **Serviciu comun** atunci când reprezintă infrastructură partajată de alte servicii: Active Directory, DNS, OpenLDAP, NTP, PKI, SMTP relay, proxy, logging, monitoring, backup, storage etc.

Un serviciu comun are un **Tip dependență implicit**. Dacă este marcat și **Global implicit**, relația este moștenită automat de toate celelalte servicii active. În caz contrar, dependențele se declară explicit din pagina serviciului consumator.

Modelul recomandat este `Serviciu aplicație → Serviciu comun`, nu `VM aplicație → VM infrastructură`. Astfel, înlocuirea unui domain controller sau a unui server DNS necesită numai actualizarea VM-urilor serviciului comun, fără modificarea tuturor consumatorilor.

Pentru excepții tehnice există și o dependență directă pe VM. Aceasta se folosește numai când relația nu este valabilă pentru întreg serviciul.

Pagina unui serviciu comun afișează și serviciile dependente / impactul potențial.

### Excepții directe pe VM

Dependențele directe declarate pe un VM sunt tratate separat de relațiile moștenite din serviciu. Ele apar atât în fișa VM, cât și în analiza de impact a serviciului comun furnizor. Un serviciu comun nu poate fi transformat în serviciu normal cât timp există relații explicite Serviciu → Serviciu comun sau VM → Serviciu comun care îl referă.

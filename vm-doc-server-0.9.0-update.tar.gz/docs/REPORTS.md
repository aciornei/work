# Rapoarte

Meniul **Rapoarte** oferă o vedere agregată asupra infrastructurii, a Serviciilor interne și a gradului de documentare. Graficele sunt randate direct de interfața vm-doc-server și nu necesită biblioteci JavaScript externe sau acces la Internet.

## Indicatori principali

- VM-uri active și pornite;
- servicii active și critice;
- VM-uri fără mediu, fără serviciu și fără fișă tehnică;
- servicii fără fișă generată.

## Infrastructură VM

- power state;
- medii PROD / TEST / UAT / DEV;
- status operațional;
- acoperire și stare agent;
- protecție backup;
- prospețime inventar;
- acoperire cu fișe tehnice;
- dimensionare vCPU și RAM;
- sisteme de operare;
- distribuție pe surse vCenter;
- versiuni hardware VM.

## Servicii interne

- criticitate;
- status documentație;
- acoperire cu fișe de serviciu;
- tipuri de soluție și servicii cu tehnologie mixtă;
- număr de VM-uri per serviciu;
- medii în care sunt prezente serviciile;
- tip de utilizare dedicat / partajat / dependență;
- asociere principală / secundară;
- completitudinea asocierilor (layer, rol tehnic, tip soluție);
- distribuție pe domenii și categorii;
- utilizare layer-e și roluri tehnice;
- servicii cu cele mai multe VM-uri.

## Documentație și calitatea datelor

- timeline al fișelor VM și fișelor de serviciu generate în ultimele 30 de zile;
- servicii cu Scop și domeniu, Obiective, mediu, VM sau fișă lipsă;
- VM-uri cu mediu, inventar, serviciu, fișă sau agent lipsă.

Rapoartele folosesc datele operaționale curente și sunt destinate atât verificării documentației, cât și identificării rapide a zonelor care necesită completare.

## Servicii comune și impact (0.9.0)

Rapoartele includ:

- numărul serviciilor comune și globale;
- distribuția serviciilor comune vs. globale implicit;
- tipurile de dependență folosite;
- numărul serviciilor dependente pentru fiecare serviciu comun;
- numărul VM-urilor potențial afectate de indisponibilitatea unui serviciu comun.

Pentru un serviciu `Global implicit`, impactul la nivel de serviciu include toate celelalte servicii active. Pentru un serviciu comun normal sunt folosite relațiile declarate explicit.

Impactul VM pentru un serviciu comun include și excepțiile declarate direct prin `VM → Serviciu comun`, fără a dubla VM-urile deja afectate prin relațiile serviciului lor.

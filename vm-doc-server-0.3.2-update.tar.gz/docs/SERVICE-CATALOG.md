# Catalogul serviciilor interne

## Scop

Catalogul separă clasificarea ITIL de serviciul tehnic documentat. Un serviciu intern, de exemplu `Metabase`, este obiectul pentru care va fi generată documentația completă. VM-urile asociate sunt incluse ulterior ca fișe sau referințe în anexele documentului.

## Ierarhie

```text
Domeniu arhitectural
  → Categorie ITIL
    → Serviciu intern
      → Layer
        → Rol tehnic
```

Exemplu:

```text
Date și raportare
  → Raportare și analiză
    → Metabase
      → Aplicație
        → Server aplicație
```

Un alt exemplu:

```text
Comunicații
  → Mesagerie și colaborare
    → Platformă Mail
      → Transport e-mail
        → Postfix SMTP
```

## Reguli

- fiecare categorie ITIL are exact un domeniu arhitectural părinte;
- fiecare serviciu intern aparține unei categorii ITIL;
- fiecare serviciu definește explicit combinațiile layer–rol acceptate;
- un VM poate avea un singur serviciu intern principal în versiunea curentă;
- layer-ul și rolul tehnic se selectează împreună;
- backendul validează întreaga ramură, nu doar interfața browserului.

Această validare împiedică, de exemplu, asocierea rolului `Solr` unui serviciu intern de mail dacă acea combinație nu a fost definită explicit.

## Meniul Servicii

Pentru fiecare serviciu intern se pot administra în 0.3.2:

- denumirea și codul intern;
- domeniul și categoria ITIL, prin categoria selectată;
- descrierea și scopul;
- criticitatea;
- starea documentației;
- linkul către documentația existentă;
- starea activ/inactiv;
- combinațiile layer–rol permise;
- lista VM-urilor asociate.

Modelul este pregătit pentru extinderea ulterioară cu dependențe, baze de date, autentificare, monitorizare, continuitate, responsabili și documente generate.

## Documentația viitoare

Unitatea de documentare va fi serviciul intern:

```text
Documentație serviciu intern – Metabase
  1. Prezentare și scop
  2. Arhitectură și dependențe
  3. Autentificare și securitate
  4. Monitorizare și jurnalizare
  5. Backup și restaurare
  6. Continuitate
  7. Responsabilități
  Anexa A – Fișa VM metabase-app-01
  Anexa B – Fișa VM metabase-db-01
  Anexa C – Referință către un VM partajat
```

Un VM partajat poate fi referit de mai multe servicii în documentațiile viitoare, fără duplicarea sursei sale de adevăr.

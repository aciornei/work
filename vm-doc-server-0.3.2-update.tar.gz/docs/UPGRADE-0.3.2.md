# Upgrade vm-doc-server 0.3.1 → 0.3.2

Versiunea 0.3.2 introduce catalogul ierarhic de servicii interne și înlocuiește selecțiile independente `Serviciu` / `Componentă` cu următorul lanț validat:

```text
Domeniu arhitectural
  → Categorie ITIL
    → Serviciu intern
      → Layer
        → Rol tehnic
```

## Pași

1. Faceți backup bazei MariaDB, configurației și binarelor instalate.
2. Păstrați directorul `vendor/` din sursa 0.3.1 folosită la compilarea offline.
3. Aplicați arhiva incrementală 0.3.2 peste o copie a sursei 0.3.1.
4. Rulați:

```bash
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

5. Opriți collectorul și serverul, înlocuiți binarele, apoi porniți mai întâi `vm-doc-server`.
6. Verificați logul serverului pentru aplicarea migrării `013_internal_service_catalog.up.sql`.
7. În interfață:
   - verificați **Nomenclatoare → Domenii arhitecturale**;
   - verificați sau corectați **Categoriile ITIL** și domeniul părinte;
   - deschideți meniul **Servicii**;
   - pentru fiecare serviciu configurați combinațiile permise `Layer → Rol tehnic`;
   - reveniți în fișele VM și completați selecția în cascadă.

## Ce face migrarea 013

- creează nomenclatoarele `Categorie ITIL` și `Rol tehnic`;
- marchează vechile nomenclatoare `Serviciu` și `Componentă` ca legacy și le ascunde din interfața curentă;
- leagă fiecare categorie ITIL de un domeniu arhitectural;
- creează catalogul `internal_services`;
- creează combinațiile permise layer–rol pentru fiecare serviciu;
- creează asocierea strictă dintre VM și serviciul intern;
- migrează, pe cât posibil, vechile valori Serviciu/Componentă;
- adaugă permisiunile `services.read` și `services.manage`.

## Verificarea datelor migrate

Migrarea păstrează câmpurile vechi pentru compatibilitate. Datele care nu aveau o relație completă sunt plasate temporar sub `Necategorizat`.

Pentru VM-urile migrate poate exista un layer vechi fără rol tehnic. Aceste VM-uri rămân vizibile, însă la următoarea salvare trebuie aleasă o combinație layer–rol definită în serviciul intern.

## Rollback operațional

Migrarea nu șterge tabelele și coloanele vechi. Pentru revenire rapidă:

1. opriți serviciile;
2. restaurați baza de date din backup;
3. restaurați binarele 0.3.1;
4. porniți mai întâi serverul, apoi collectorul.

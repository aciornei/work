package nomenclature

import "testing"

func TestNormalizeItem(t *testing.T) {
	parentID := int64(7)
	input := ItemInput{CategoryCode: " ITIL_CATEGORY ", Name: "  Mail  ", ItemCode: " MAIL.PROD ", Description: " test ", ParentID: &parentID}
	if err := normalizeItem(&input); err != nil {
		t.Fatal(err)
	}
	if input.CategoryCode != "itil_category" || input.Name != "Mail" || input.ItemCode != "mail.prod" {
		t.Fatalf("unexpected normalized input: %#v", input)
	}
}

func TestNormalizeItemRejectsLegacyAndUnknownCategories(t *testing.T) {
	for _, category := range []string{"service", "component", "unknown"} {
		if err := normalizeItem(&ItemInput{CategoryCode: category, Name: "X"}); err == nil {
			t.Fatalf("expected invalid category for %q", category)
		}
	}
}

func TestNormalizePerson(t *testing.T) {
	input := PersonInput{DisplayName: "  Ion Popescu ", Email: "ION@EXAMPLE.TEST"}
	if err := normalizePerson(&input); err != nil {
		t.Fatal(err)
	}
	if input.DisplayName != "Ion Popescu" || input.Email != "ion@example.test" {
		t.Fatalf("unexpected normalized person: %#v", input)
	}
}

package catalog

import "testing"

func TestNormalizeService(t *testing.T) {
	input := InternalServiceInput{ITILCategoryID: 7, Name: "  Metabase ", ServiceCode: " BI.METABASE ", Criticality: " HIGH ", DocumentationStatus: " IN_PROGRESS "}
	if err := normalizeService(&input); err != nil {
		t.Fatal(err)
	}
	if input.Name != "Metabase" || input.ServiceCode != "bi.metabase" || input.Criticality != "high" || input.DocumentationStatus != "in_progress" {
		t.Fatalf("unexpected normalization: %#v", input)
	}
}

func TestNormalizeServiceRejectsInvalidValues(t *testing.T) {
	tests := []InternalServiceInput{
		{Name: "X"},
		{ITILCategoryID: 1, Name: "X", Criticality: "urgent"},
		{ITILCategoryID: 1, Name: "X", DocumentationStatus: "done"},
		{ITILCategoryID: 1, Name: "X", ServiceCode: "BAD CODE"},
		{ITILCategoryID: 1, Name: "X", DocumentationURL: "file:///tmp/x"},
	}
	for i := range tests {
		if err := normalizeService(&tests[i]); err == nil {
			t.Fatalf("test %d: expected error", i)
		}
	}
}

func TestMappingKey(t *testing.T) {
	if got := mappingKey(12, 34); got != "12:34" {
		t.Fatalf("unexpected key %q", got)
	}
}

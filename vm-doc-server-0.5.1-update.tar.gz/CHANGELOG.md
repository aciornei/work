# Changelog


## 0.5.1

- inventarul agentului este randat în tabele compacte, specifice fiecărei secțiuni, în locul flatten-ului generic;
- eliminate din document secțiunile Agent și Proxy și câmpul `uptime_seconds`;
- stocare în format partiție/filesystem/capacitate cu unități lizibile;
- rețea pe câte un rând pentru adresă și interfață;
- numai servicii active, porturi esențiale, reguli UFW numbered și conturi relevante;
- rezumat SSSD și matrice compactă pentru Auditbeat, Filebeat, GLPI Agent, Node Exporter și Syslog;
- cron și NTP simplificate; politici lăsate pregătite pentru completare ulterioară;
- tabele DOCX cu grilă explicită și lățimi fixe, compatibile cu randarea LibreOffice;
- fără migrare de bază de date.

## 0.5.0

- generator DOCX pentru fișa tehnică a VM-ului, disponibil direct în pagina VM;
- previzualizare a datelor și avertismente pentru inventar, servicii sau responsabilități lipsă;
- șabloane DOCX încărcabile și administrabile, cu șablon implicit creat automat;
- placeholder obligatoriu `{{VM_DOCUMENT_BODY}}` și placeholdere scalare pentru antetul șablonului;
- documentul include identificare, resurse, date operaționale, servicii, roluri, responsabilități, backup și inventarul structurat al agentului;
- istoric al documentelor generate, număr unic, fișier, dimensiune, SHA-256, autor și snapshot sursă;
- permisiuni noi `documents.read` și `documents.manage`;
- migrarea `018_document_generation.up.sql` creează `document_templates` și `generated_documents`.

## 0.4.4

- toate valorile nomenclatoarelor sunt sortate consecvent după ordinea părintelui, apoi după ordinea proprie și denumire;
- categoriile de serviciu sunt grupate după ordinea domeniului arhitectural;
- rolurile tehnice sunt grupate după primul layer în ordinea layer-elor, apoi după ordinea proprie; valorile nemapate sunt afișate la final;
- registrul Persoane este ordonat după departament, apoi după nume;
- filtre pe fiecare pagină de nomenclator: căutare text și stare, plus domeniu pentru categorii și layer pentru roluri;
- filtre suplimentare pentru Persoane: departament, sursă și stare;
- paginarea se aplică rezultatului filtrat, iar exportul Excel păstrează lista completă în ordinea nouă;
- fără migrare de bază de date.

## 0.4.3

- paginare pentru toate nomenclatoarele și pentru registrul Persoane, cu dimensiune selectabilă a paginii;
- export Excel pentru nomenclatorul curent, disponibil tuturor utilizatorilor cu permisiunea `nomenclatures.read`;
- exportul include toate rândurile active și inactive, nu numai pagina vizibilă;
- coloane relaționale în Excel pentru `Domeniu → Categorie de serviciu` și `Layer → Rol tehnic`;
- export complet pentru persoane, inclusiv departament, sursă și cont AD;
- fără migrare de bază de date.

## 0.4.2

- corectată interogarea de citire a inventarului după ID: parametrul `id` este transmis către `QueryRowContext`;
- eliminată eroarea MariaDB `Error 1064 ... near '?' at line 1` la deschiderea fișei VM;
- inventarul curent și vederea structurată a JSON-ului agentului se încarcă din nou fără recollectare;
- fără migrare de bază de date.

## 0.4.1

- termenul vizibil **Categorie ITIL** este înlocuit cu **Categorie de serviciu**; cheia tehnică `itil_category` rămâne neschimbată pentru compatibilitate;
- integrare de tip director cu Active Directory, reutilizând gazdele LDAP, TLS-ul și contul bind deja configurate pentru autentificare;
- OU rădăcină configurabil, citire recursivă a utilizatorilor și afișare arborescentă după sub-OU-uri;
- filtrare obligatorie după atributul `department`, cu primul departament în ordine alfabetică selectat implicit sau cu un departament implicit configurabil;
- import multiplu și actualizare idempotentă a persoanelor din AD în registrul local de responsabilități, folosind `objectGUID` ca identitate stabilă;
- persoanele importate păstrează sursa LDAP și contul AD, iar reimportul actualizează numele, e-mailul, telefonul și departamentul;
- migrarea `017_service_category_ad_directory.up.sql` actualizează eticheta nomenclatorului și extinde tabelul `people` cu identitatea de director;
- migrarea `016_vm_service_classification.up.sql` este corectată astfel încât indexul nou să fie creat înainte de eliminarea indexului folosit de cheia externă.

## 0.4.0

- domeniul arhitectural și categoria de serviciu sunt mutate de la serviciul intern la asocierea VM–serviciu;
- formularul serviciului intern păstrează numai identitatea, descrierea, criticitatea și informațiile de documentare;
- fișa VM adaugă selectorul Categorie de serviciu între Domeniu și Serviciu intern;
- domeniul filtrează categoriile de serviciu, iar layer-ul filtrează rolurile tehnice;
- pagina și lista Servicii agregă automat încadrările domeniu–categorie din VM-uri;
- VM-urile din pagina serviciului afișează încadrarea folosită de fiecare asociere;
- validare backend pentru relația `Domeniu → Categorie de serviciu` și `Layer → Rol tehnic`;
- migrarea `016_vm_service_classification.up.sql` păstrează încadrările existente și extinde cheia unică a asocierii.

## 0.3.9

- pagina Nomenclatoare nu mai afișează toate listele simultan;
- submeniu lateral grupat în Catalog servicii, Arhitectură tehnică, Operare VM și Responsabilități;
- se afișează o singură listă la un moment dat, cu numărul valorilor în submeniu;
- ruta păstrează categoria selectată, de exemplu `#nomenclatures/technical_role`;
- pe ecrane înguste, submeniul devine o grilă adaptivă de opțiuni;
- actualizarea este exclusiv de interfață și nu necesită migrare MariaDB.

## 0.3.8

- selecție în cascadă pe fișa VM: domeniu → serviciu intern → layer → rol tehnic;
- serviciile interne nu mai păstrează configurații layer–rol proprii; combinațiile observate sunt agregate automat din asocierile VM;
- validarea backend verifică serviciul și relația globală layer–rol, fără o restricție suplimentară la nivelul serviciului;
- selector multiplu cu căutare, stil Select2 și complet offline, pentru layer-ele permise ale unui rol tehnic;
- rolurile tehnice sunt ordonate după ordinea layer-ului, apoi după ordinea rolului;
- endpointul de modificare a combinațiilor layer–rol pe serviciu a fost eliminat din API și OpenAPI;
- actualizarea nu necesită migrare de schemă.

## 0.3.7

- fiecare rol tehnic este legat explicit de unul sau mai multe layer-e arhitecturale;
- rolurile sunt filtrate după layer în configurarea serviciului intern;
- validare server-side globală layer–rol, suplimentară față de validarea serviciului;
- relațiile deja folosite sunt migrate automat prin `015_layer_technical_role_mappings.up.sql`;
- relațiile utilizate nu pot fi eliminate accidental;
- Nomenclatoare afișează layer-ele permise pentru fiecare rol tehnic.

## 0.3.6

- relație multiplă VM–serviciu intern–layer–rol tehnic;
- mai multe servicii interne și mai multe roluri pentru același serviciu pe un singur VM;
- tip de utilizare `dedicated`, `shared` sau `dependency`, marcaj principal și observații pe asociere;
- profilul/data provisionării eliminate din modelul funcțional și din nomenclatoare;
- vechiul lifecycle `Retired` migrat la `Status operațional: Retras` și eliminat din interfața/API curent;
- cardul redundant „Rezumat ultimul inventar” eliminat;
- migrarea `014_multi_service_assignments.up.sql`, API, OpenAPI și documentație actualizate.

## 0.3.5

- fișa VM continuă să se încarce dacă datele operaționale sau sumarul de backup au o eroare;
- toate etapele de încărcare a fișei VM sunt jurnalizate cu `stage` și `vm_id`;
- versiunea din interfață este citită din `/version`, nu mai este hard-codată.

## 0.3.4

- pagina VM se încarcă degradat dacă datele agentului, snapshotul curent sau vederea structurată nu pot fi citite;
- erorile opționale din fișa VM sunt jurnalizate cu etapa exactă și `vm_id`;
- interfața afișează un avertisment fără a bloca datele vCenter și operaționale.

## 0.3.3

- secțiunile cu datele colectate de agent sunt restrânse implicit, inclusiv listele de obiecte din interior;
- istoricul inventarelor VM este paginat server-side, cu 10, 20, 50 sau 100 de înregistrări pe pagină;
- pagina Audit este paginată server-side, cu 25, 50, 100 sau 200 de evenimente pe pagină;
- endpointurile de inventar și audit acceptă `page` și `page_size` și întorc metadate de paginare;
- OpenAPI, testele și documentația de upgrade au fost actualizate;
- include corecția de compilare pentru funcția `nullableInt64Ptr` din 0.3.2.

## 0.3.2

- meniu principal **Servicii** pentru catalogul serviciilor interne;
- `Serviciu` ITIL este redenumit **Categorie de serviciu**, iar vechea `Componentă` devine **Serviciu intern**;
- ierarhie validată `Domeniu arhitectural → Categorie de serviciu → Serviciu intern → Layer → Rol tehnic`;
- categoriile de serviciu sunt legate de domeniul arhitectural părinte;
- fiecare serviciu definește explicit combinațiile layer–rol permise;
- fișa VM folosește list-box-uri în cascadă și backendul respinge combinațiile incompatibile;
- pagina serviciului afișează descrierea, criticitatea, starea documentației, combinațiile permise și VM-urile asociate;
- migrare automată a datelor 0.3.1 și permisiuni RBAC `services.read` / `services.manage`;
- API și OpenAPI pentru catalogul serviciilor prin migrarea `013_internal_service_catalog.up.sql`.

## 0.3.1

- meniu nou **Nomenclatoare** pentru serviciu, componentă, domeniu arhitectural, layer, mediu, status operațional, profil de provisionare și clasificare;
- câmpurile controlate din fișa VM sunt list-box-uri și nu mai acceptă text liber;
- registru de persoane și mai multe responsabilități pe aceeași VM;
- secțiune separată **Backup și restaurare · Veeam**, cu model de date pregătit pentru sincronizarea prin API;
- migrarea automată a valorilor și responsabililor existenți din 0.3.0;
- endpointuri API, audit și OpenAPI pentru nomenclatoare și persoane;
- migrarea `012_nomenclatures_responsibilities_backup.up.sql`.

## 0.3.0

- pagină VM refăcută ca fișă tehnică structurată pe carduri și secțiuni pliabile;
- vedere sigură a inventarului agentului, cu mascarea câmpurilor sensibile;
- date operaționale separate de snapshoturile agentului și sincronizarea vCenter;
- tabel nou `vm_operational_metadata` prin migrarea 011;
- endpoint `PUT /api/v1/vms/{id}/operational` și audit `vm.operational.update`;
- formular pentru serviciu, componentă, domeniu, layer, mediu, status, scop, responsabili, provisionare, RPO/RTO, backup, clasificare și referințe;
- OpenAPI, documentație și teste actualizate.

## 0.2.2

- autoînregistrare pentru vm-doc-agent 1.1.0;
- heartbeat și stare online/offline fără creare manuală;
- push direct al inventarului;
- asociere automată cu VM după UUID;
- migrarea 010 și documentația de upgrade.


## 0.2.1

- căutare și filtre VM după nume/hostname, power, OS, IP, agent, `Retired` și sursă vCenter;
- paginare server-side și selector 25/50/100/200 înregistrări;
- statistici pentru rezultatele filtrate;
- export Excel `.xlsx` fără dependențe Go suplimentare;
- antet fix corect în tabelul VM, fără suprapunerea primului rând;
- API-ul `GET /api/v1/vms` întoarce un obiect paginat;
- endpoint nou `GET /api/v1/vms/export`;
- listele vCenter goale sunt serializate ca `[]`, nu `null`;
- rutele Swagger sunt înregistrate explicit ca `GET`, evitând panic în Go 1.23.

## 0.2.0

- vCenter devine sursa principală pentru lista de VM-uri;
- CRUD pentru surse vCenter, cu parolă criptată și verificare TLS;
- sincronizare manuală per sursă sau pentru toate sursele;
- scheduler zilnic configurabil per sursă, în fusul orar al aplicației;
- tabele `vcenter_sources`, `virtual_machines` și `vcenter_sync_runs`;
- VM-urile absente sunt marcate `missing_from_vcenter`, fără ștergere automată;
- lifecycle local `Retired`, cu dată, utilizator și notă;
- asociere automată după BIOS/DMI UUID, inclusiv ordinea SMBIOS legacy VMware;
- asociere manuală și dezlegare agent din fișa VM;
- stare agent și colectare manuală direct din fișa VM;
- parser pentru `agent.id`, `agent.version`, `collection.collectors`, FQDN și UUID-uri de corelare;
- listă VM, filtre, pagină de detaliu și istoric sincronizări în frontend;
- permisiuni RBAC noi: `vcenter.read`, `vcenter.manage`, `vms.manage`;
- OpenAPI 3.1 și documentație actualizate.

## 0.1.0

- două binare: `vm-doc-server` și `vm-doc-collector`;
- configurație YAML și secrete criptate AES-256-GCM;
- migrații MariaDB incluse în binar;
- autentificare LDAP și Keycloak/OIDC cu PKCE;
- sesiuni server-side, CSRF și RBAC;
- administrarea agenților și tokenuri criptate individual;
- joburi manuale și periodice cu lease;
- testare agent, colectare, UUID binding și validare schemă 2.x;
- snapshoturi brute, istoric, hash și stare online/offline;
- audit server/collector;
- frontend static fără Node.js;
- OpenAPI 3.1 și Swagger UI embedded;
- unități systemd și reverse proxy Nginx.

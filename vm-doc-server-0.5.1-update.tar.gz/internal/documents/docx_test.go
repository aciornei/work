package documents

import (
	"archive/zip"
	"bytes"
	"encoding/json"
	"io"
	"strings"
	"testing"
	"time"

	"vm-doc-server/internal/domain"
	"vm-doc-server/internal/inventory"
)

func TestDefaultTemplateAndRender(t *testing.T) {
	template, err := DefaultTemplate()
	if err != nil {
		t.Fatal(err)
	}
	if err := ValidateTemplate(template); err != nil {
		t.Fatal(err)
	}
	now := time.Date(2026, 9, 1, 12, 30, 0, 0, time.UTC)
	view := inventory.DocumentView{Sections: []inventory.DocumentSection{{Key: "network", Title: "Rețea", Data: map[string]any{"primary_ip": "10.0.0.10"}}}}
	data := GenerationData{
		VM:                domain.VirtualMachine{ID: 295, Name: "vm-test", CPUCount: 4, MemoryMiB: 8192, PowerState: "poweredOn", GuestHostname: "vm-test", PrimaryIP: "10.0.0.10"},
		Operational:       domain.VMOperationalMetadata{Environment: "Producție", OperationalStatus: "Activ"},
		InventoryDocument: &view,
		GeneratedBy:       domain.User{Username: "tester", DisplayName: "Test User"},
		GeneratedAt:       now,
		DocumentNumber:    "FVM-20260901-000295-ABCD",
	}
	output, err := RenderDOCX(template, data)
	if err != nil {
		t.Fatal(err)
	}
	reader, err := zip.NewReader(bytes.NewReader(output), int64(len(output)))
	if err != nil {
		t.Fatal(err)
	}
	var document string
	for _, file := range reader.File {
		if file.Name != "word/document.xml" {
			continue
		}
		handle, err := file.Open()
		if err != nil {
			t.Fatal(err)
		}
		content, err := io.ReadAll(handle)
		handle.Close()
		if err != nil {
			t.Fatal(err)
		}
		document = string(content)
	}
	if document == "" {
		t.Fatal("word/document.xml missing")
	}
	if strings.Contains(document, BodyPlaceholder) {
		t.Fatal("body placeholder was not replaced")
	}
	for _, expected := range []string{"Fișă tehnică VM", "vm-test", "FVM-20260901-000295-ABCD", "Rețea", "10.0.0.10"} {
		if !strings.Contains(document, expected) {
			t.Fatalf("document does not contain %q", expected)
		}
	}
}

func TestValidateTemplateRequiresBodyPlaceholder(t *testing.T) {
	template, err := DefaultTemplate()
	if err != nil {
		t.Fatal(err)
	}
	reader, err := zip.NewReader(bytes.NewReader(template), int64(len(template)))
	if err != nil {
		t.Fatal(err)
	}
	var output bytes.Buffer
	writer := zip.NewWriter(&output)
	for _, source := range reader.File {
		handle, err := source.Open()
		if err != nil {
			t.Fatal(err)
		}
		content, err := io.ReadAll(handle)
		handle.Close()
		if err != nil {
			t.Fatal(err)
		}
		if source.Name == "word/document.xml" {
			content = bytes.ReplaceAll(content, []byte(BodyPlaceholder), []byte("missing"))
		}
		destination, err := writer.Create(source.Name)
		if err != nil {
			t.Fatal(err)
		}
		if _, err := destination.Write(content); err != nil {
			t.Fatal(err)
		}
	}
	if err := writer.Close(); err != nil {
		t.Fatal(err)
	}
	if err := ValidateTemplate(output.Bytes()); err == nil {
		t.Fatal("expected validation error")
	}
}

func TestCompactInventoryRendering(t *testing.T) {
	template, err := DefaultTemplate()
	if err != nil {
		t.Fatal(err)
	}
	view := inventory.DocumentView{Sections: []inventory.DocumentSection{
		{Key: "schema", Data: map[string]any{"name": "vm-doc-agent-inventory", "version": "2.0"}},
		{Key: "agent", Data: map[string]any{"version": "1.0.0"}},
		{Key: "system", Data: map[string]any{"architecture": "x86_64", "uptime_seconds": json.Number("123456")}},
		{Key: "os", Data: map[string]any{"name": "Ubuntu", "version": "24.04"}},
		{Key: "storage", Data: map[string]any{"mounts": []any{
			map[string]any{"mount_point": "/", "filesystem": "ext4", "size_bytes": json.Number("107374182400")},
			map[string]any{"mount_point": "/data", "filesystem": "xfs", "size_bytes": json.Number("1099511627776")},
		}}},
		{Key: "network", Data: map[string]any{"interfaces": []any{
			map[string]any{"name": "ens192", "addresses": []any{"10.20.30.40/24"}, "gateway": "10.20.30.1", "dns_servers": []any{"10.20.0.10", "10.20.0.11"}},
		}}},
		{Key: "proxy", Data: map[string]any{"http_proxy": "http://proxy.example"}},
		{Key: "services", Data: []any{
			map[string]any{"name": "sshd.service", "description": "OpenSSH server", "status": "active"},
			map[string]any{"name": "cups.service", "description": "Printing", "status": "inactive"},
		}},
		{Key: "listening_ports", Data: []any{
			map[string]any{"name": "sshd", "executable": "/usr/sbin/sshd", "port": json.Number("22"), "protocol": "tcp"},
		}},
		{Key: "firewall", Data: map[string]any{"ufw_status_numbered": []any{"[ 1] 22/tcp ALLOW IN 10.0.0.0/8", "[ 2] 443/tcp ALLOW IN Anywhere"}}},
		{Key: "accounts", Data: []any{
			map[string]any{"username": "root", "uid": json.Number("0"), "home": "/root", "shell": "/bin/bash"},
			map[string]any{"username": "service", "uid": json.Number("500"), "home": "/srv/service", "shell": "/usr/sbin/nologin"},
			map[string]any{"username": "appadmin", "uid": json.Number("1001"), "home": "/home/appadmin", "groups": []any{"sudo"}},
		}},
		{Key: "sssd", Data: map[string]any{"installed": true, "ldap_search_base": "OU=Linux,DC=example,DC=ro", "version": "2.9.4"}},
		{Key: "integrations", Data: map[string]any{
			"auditbeat":     map[string]any{"installed": true, "version": "8.16", "config_ok": true, "output_host": "graylog.example.ro", "details": "system module"},
			"filebeat":      map[string]any{"installed": true, "version": "8.16", "config_ok": true, "output_host": "logstash.example.ro"},
			"glpi_agent":    map[string]any{"installed": true, "version": "1.15", "config_ok": true, "server": "glpi.example.ro"},
			"node_exporter": map[string]any{"installed": true, "version": "1.9.1", "config_ok": true, "host": "0.0.0.0:9100"},
			"syslog":        map[string]any{"enabled": true, "version": "8.2312", "config_ok": true, "destination": "graylog.example.ro:514"},
		}},
		{Key: "cron", Data: []any{map[string]any{"schedule": "0 2 * * *", "command": "/opt/app/backup.sh", "user": "root"}}},
		{Key: "ntp", Data: map[string]any{"conf_file": "/etc/chrony/chrony.conf", "sources": []any{"ntp1.example.ro", "ntp2.example.ro"}, "version": "4.5"}},
	}}
	data := GenerationData{
		VM:                domain.VirtualMachine{ID: 295, Name: "metabase", CPUCount: 4, MemoryMiB: 8192},
		InventoryDocument: &view,
		GeneratedAt:       time.Date(2026, 9, 1, 12, 30, 0, 0, time.UTC),
		DocumentNumber:    "FVM-TEST",
	}
	output, err := RenderDOCX(template, data)
	if err != nil {
		t.Fatal(err)
	}
	document := documentXMLFromDOCX(t, output)
	for _, expected := range []string{
		"6.5 Stocare", "100 GB", "1.00 TB", "ens192", "10.20.30.40", "sshd.service", "/usr/sbin/sshd", "appadmin", "OU=Linux,DC=example,DC=ro", "Auditbeat", "graylog.example.ro", "/etc/chrony/chrony.conf", "<w:tblGrid>",
	} {
		if !strings.Contains(document, expected) {
			t.Fatalf("document does not contain %q", expected)
		}
	}
	for _, unexpected := range []string{"6.2 Agent", "6.7 Proxy", "uptime_seconds", "cups.service", "/srv/service", "http://proxy.example"} {
		if strings.Contains(document, unexpected) {
			t.Fatalf("document unexpectedly contains %q", unexpected)
		}
	}
}

func documentXMLFromDOCX(t *testing.T, content []byte) string {
	t.Helper()
	reader, err := zip.NewReader(bytes.NewReader(content), int64(len(content)))
	if err != nil {
		t.Fatal(err)
	}
	for _, file := range reader.File {
		if file.Name != "word/document.xml" {
			continue
		}
		handle, err := file.Open()
		if err != nil {
			t.Fatal(err)
		}
		data, err := io.ReadAll(handle)
		handle.Close()
		if err != nil {
			t.Fatal(err)
		}
		return string(data)
	}
	t.Fatal("word/document.xml missing")
	return ""
}

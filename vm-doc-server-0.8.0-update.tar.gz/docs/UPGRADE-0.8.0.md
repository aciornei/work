# Upgrade la vm-doc-server 0.8.0

Versiunea 0.8.0 introduce evidențierea mediilor în documentația Serviciilor interne, anexarea fișelor VM și modulul Rapoarte.

## Migrare MariaDB

La prima pornire se aplică automat:

```text
023_reports_service_annexes.up.sql
```

Migrarea:

- creează `service_document_annexes`, care fixează versiunea exactă a fiecărei fișe VM folosite ca anexă la o fișă de serviciu;
- adaugă permisiunea `reports.read` și o acordă rolurilor standard admin, operator, viewer și auditor;
- nu modifică documentele deja generate și nu șterge date.

## Upgrade din 0.7.3

```bash
cd /usr/local/src
cp -a vm-doc-server-0.7.3 vm-doc-server-0.8.0
tar -xzf /tmp/vm-doc-server-0.8.0-update.tar.gz -C /usr/local/src/vm-doc-server-0.8.0
cd /usr/local/src/vm-doc-server-0.8.0
cat VERSION
GOPROXY=off GOFLAGS=-mod=vendor make build
```

După backup-ul bazei și al binarelor, opriți serviciile, copiați binarele noi și porniți mai întâi `vm-doc-server`. Verificați aplicarea migrării 023 în log înainte de a porni collectorul.

## Verificări funcționale

1. deschideți un Serviciu intern cu VM-uri în PROD, TEST și/sau DEV;
2. verificați cardurile de mediu și mediul afișat pentru fiecare VM;
3. generați cel puțin o fișă VM și verificați linkul din pagina serviciului;
4. generați fișa serviciului cu `Include fișele VM ca anexe` activ;
5. descărcați pachetul ZIP și verificați DOCX-ul principal și directorul `anexe/`;
6. deschideți meniul **Rapoarte** și verificați graficele și listele de completitudine.

## Observație despre anexe

DOCX-urile nu sunt concatenate fizic într-un singur fișier Word. Fișa serviciului conține referințe și linkuri către fișele VM, iar pachetul ZIP conține documentele originale ca anexe. Această abordare păstrează fișierele Word valide și, prin tabela de relație, garantează că se poate identifica ulterior exact ce versiune a fiecărei fișe VM a fost anexată.

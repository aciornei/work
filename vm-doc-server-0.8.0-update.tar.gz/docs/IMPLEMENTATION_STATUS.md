# Implementation status 0.8.0

## Implementat

- schemă logică automată a Serviciilor interne, cu VM-uri unice și asocieri multiple în același nod;
- pictograme configurabile pentru nomenclatoare prin `icon_key`;

- surse vCenter cu secrete criptate, sincronizare asincronă și programare zilnică;
- upsert VM și marcaj `missing` când o mașină nu mai este văzută în vCenter;
- corelare automată sau manuală cu agentul;
- listă VM, fișă tehnică structurată, căutare, paginare și export Excel;
- date operaționale independente de inventarul automat;
- catalog de servicii interne independent de încadrarea arhitecturală;
- domeniu și categorie de serviciu salvate pe fiecare asociere VM–serviciu;
- agregarea automată a domeniilor și categoriilor în pagina serviciului;
- roluri tehnice legate global de unul sau mai multe layer-e;
- selecție `domeniu–categorie–serviciu–layer–rol–tip soluție` pe fișa VM;
- asocieri multiple, cu tip de utilizare, prioritate și observații;
- validare server-side a relației categorie–domeniu și layer–rol;
- nomenclatoare grupate în submeniuri;
- registru de persoane și responsabilități multiple pe VM;
- structură separată de backup, pregătită pentru Veeam API;
- inventar agent structurat și restrâns implicit, istoric și audit paginate;
- generare DOCX pe bază de șabloane, previzualizare și istoric pentru VM și Serviciu intern;
- editor rich-text pentru Scop și domeniu / Obiective, cu bullets, numerotare, indentare și stiluri reproduse în DOCX;
- evidențiere PROD / TEST-UAT / DEV în pagina și documentația Serviciului intern;
- legături către fișele VM și pachete ZIP de documentație cu anexe VM versionate;
- modul Rapoarte cu indicatori, donut/pie charts, bar charts, timeline și liste de completitudine;
- șabloane separate pe tip de obiect (`vm` / `service`) și documente de serviciu numerotate `FSI-*`;
- agregarea automată a tipurilor de soluție în pagina Serviciului intern;
- inventar agent compact în DOCX, cu tabele specializate și randare stabilă Word/LibreOffice;
- migrații, audit, RBAC și OpenAPI actualizate.

## Schimbări de model în 0.4.0

- serviciul intern nu mai are domeniu sau categorie de serviciu configurate manual;
- `vm_internal_service_assignments` păstrează domeniul și categoria alese pe VM;
- pagina serviciului agregă automat toate încadrările observate;
- același serviciu poate fi reutilizat în mai multe domenii și categorii;
- datele existente sunt migrate din vechea categorie a serviciului.

## Validare necesară în mediul offline final

Arhiva standard nu include `vendor/`. În sursa offline care păstrează dependențele executați:

```bash
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

## Limitări

- datele efective din Veeam API nu sunt încă sincronizate;
- serviciile nu au încă dependențe și responsabilități proprii;
- conversia PDF și semnarea digitală nu sunt încă implementate;
- custom attributes generale din vCenter nu sunt încă extrase;
- nu există încă worker automat pentru retenția inventarelor și auditului.

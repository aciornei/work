package documents

import (
	"archive/zip"
	"bytes"
	"context"
	"crypto/rand"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"errors"
	"fmt"
	"path/filepath"
	"regexp"
	"strings"
	"time"
)

var templateCodePattern = regexp.MustCompile(`^[a-z0-9][a-z0-9._-]{1,63}$`)

var allowedObjectTypes = map[string]bool{"vm": true, "service": true}

type Service struct {
	DB *sql.DB
}

func (s Service) EnsureDefault(ctx context.Context) error {
	if err := s.ensureDefaultFor(ctx, "vm"); err != nil {
		return err
	}
	return s.ensureDefaultFor(ctx, "service")
}

func (s Service) ensureDefaultFor(ctx context.Context, objectType string) error {
	var count int
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM document_templates WHERE object_type=?`, objectType).Scan(&count); err != nil {
		return err
	}
	if count > 0 {
		return nil
	}
	var content []byte
	var err error
	input := TemplateInput{ObjectType: objectType, MIMEType: DOCXContentType, Active: true, Default: true}
	if objectType == "service" {
		content, err = DefaultServiceTemplate()
		input.Name = "Fișă serviciu intern standard"
		input.Code = "service.standard"
		input.Description = "Șablonul implicit pentru serviciile interne. Conține placeholderul {{SERVICE_DOCUMENT_BODY}}."
		input.FileName = "fisa-serviciu-intern-standard.docx"
	} else {
		content, err = DefaultTemplate()
		input.Name = "Fișă tehnică VM standard"
		input.Code = "vm.standard"
		input.Description = "Șablonul implicit livrat cu vm-doc-server. Conține placeholderul {{VM_DOCUMENT_BODY}}."
		input.FileName = "fisa-tehnica-vm-standard.docx"
	}
	if err != nil {
		return err
	}
	input.Content = content
	_, err = s.CreateTemplate(ctx, input, 0)
	return err
}

func (s Service) ListTemplates(ctx context.Context, includeInactive bool) ([]Template, error) {
	return s.ListTemplatesFor(ctx, includeInactive, "")
}

func (s Service) ListTemplatesFor(ctx context.Context, includeInactive bool, objectType string) ([]Template, error) {
	query := `SELECT id,name,template_code,object_type,description,file_name,mime_type,sha256,size_bytes,active,is_default,created_by,updated_by,created_at,updated_at FROM document_templates`
	args := make([]any, 0, 2)
	where := make([]string, 0, 2)
	if !includeInactive {
		where = append(where, `active=1`)
	}
	objectType = normalizeObjectType(objectType)
	if objectType != "" {
		where = append(where, `object_type=?`)
		args = append(args, objectType)
	}
	if len(where) > 0 {
		query += ` WHERE ` + strings.Join(where, ` AND `)
	}
	query += ` ORDER BY object_type,is_default DESC,active DESC,name,id`
	rows, err := s.DB.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]Template, 0)
	for rows.Next() {
		value, err := scanTemplate(rows, false)
		if err != nil {
			return nil, err
		}
		out = append(out, value)
	}
	return out, rows.Err()
}

func (s Service) GetTemplate(ctx context.Context, id int64, withContent bool) (Template, error) {
	columns := `id,name,template_code,object_type,description,file_name,mime_type,sha256,size_bytes,active,is_default,created_by,updated_by,created_at,updated_at`
	if withContent {
		columns += `,content`
	}
	return scanTemplate(s.DB.QueryRowContext(ctx, `SELECT `+columns+` FROM document_templates WHERE id=?`, id), withContent)
}

func (s Service) DefaultTemplate(ctx context.Context) (Template, error) {
	return s.DefaultTemplateFor(ctx, "vm")
}

func (s Service) DefaultTemplateFor(ctx context.Context, objectType string) (Template, error) {
	objectType = normalizeObjectType(objectType)
	if !allowedObjectTypes[objectType] {
		return Template{}, errors.New("invalid document object type")
	}
	return scanTemplate(s.DB.QueryRowContext(ctx, `SELECT id,name,template_code,object_type,description,file_name,mime_type,sha256,size_bytes,active,is_default,created_by,updated_by,created_at,updated_at,content FROM document_templates WHERE active=1 AND object_type=? ORDER BY is_default DESC,name,id LIMIT 1`, objectType), true)
}

func (s Service) CreateTemplate(ctx context.Context, input TemplateInput, userID int64) (Template, error) {
	if err := normalizeTemplateInput(&input); err != nil {
		return Template{}, err
	}
	if err := ValidateTemplateFor(input.Content, input.ObjectType); err != nil {
		return Template{}, err
	}
	hash := sha256.Sum256(input.Content)
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return Template{}, err
	}
	defer tx.Rollback()
	if input.Default {
		if _, err := tx.ExecContext(ctx, `UPDATE document_templates SET is_default=0 WHERE is_default=1 AND object_type=?`, input.ObjectType); err != nil {
			return Template{}, err
		}
	}
	var createdBy any
	if userID > 0 {
		createdBy = userID
	}
	result, err := tx.ExecContext(ctx, `INSERT INTO document_templates(name,template_code,object_type,description,file_name,mime_type,content,sha256,size_bytes,active,is_default,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`,
		input.Name, input.Code, input.ObjectType, input.Description, input.FileName, input.MIMEType, input.Content, hex.EncodeToString(hash[:]), len(input.Content), input.Active, input.Default, createdBy, createdBy)
	if err != nil {
		return Template{}, err
	}
	id, err := result.LastInsertId()
	if err != nil {
		return Template{}, err
	}
	if err := tx.Commit(); err != nil {
		return Template{}, err
	}
	return s.GetTemplate(ctx, id, false)
}

func (s Service) UpdateTemplate(ctx context.Context, id, userID int64, input TemplateUpdate) (Template, error) {
	input.Name = strings.TrimSpace(input.Name)
	input.Code = strings.ToLower(strings.TrimSpace(input.Code))
	input.Description = strings.TrimSpace(input.Description)
	if input.Name == "" || input.Code == "" {
		return Template{}, errors.New("name and code are required")
	}
	if !templateCodePattern.MatchString(input.Code) {
		return Template{}, errors.New("template code is invalid")
	}
	current, err := s.GetTemplate(ctx, id, false)
	if err != nil {
		return Template{}, err
	}
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return Template{}, err
	}
	defer tx.Rollback()
	if input.Default {
		if !input.Active {
			return Template{}, errors.New("default template must be active")
		}
		if _, err := tx.ExecContext(ctx, `UPDATE document_templates SET is_default=0 WHERE is_default=1 AND object_type=? AND id<>?`, current.ObjectType, id); err != nil {
			return Template{}, err
		}
	}
	result, err := tx.ExecContext(ctx, `UPDATE document_templates SET name=?,template_code=?,description=?,active=?,is_default=?,updated_by=? WHERE id=?`, input.Name, input.Code, input.Description, input.Active, input.Default, nullableUserID(userID), id)
	if err != nil {
		return Template{}, err
	}
	if rows, _ := result.RowsAffected(); rows == 0 {
		return Template{}, sql.ErrNoRows
	}
	if err := tx.Commit(); err != nil {
		return Template{}, err
	}
	return s.GetTemplate(ctx, id, false)
}

func (s Service) ListGenerated(ctx context.Context, vmID int64) ([]GeneratedDocument, error) {
	return s.ListGeneratedVM(ctx, vmID)
}

func (s Service) ListGeneratedVM(ctx context.Context, vmID int64) ([]GeneratedDocument, error) {
	return s.listGenerated(ctx, `d.object_type='vm' AND d.vm_id=?`, vmID)
}

func (s Service) ListGeneratedService(ctx context.Context, serviceID int64) ([]GeneratedDocument, error) {
	return s.listGenerated(ctx, `d.object_type='service' AND d.internal_service_id=?`, serviceID)
}

func (s Service) listGenerated(ctx context.Context, where string, arg any) ([]GeneratedDocument, error) {
	rows, err := s.DB.QueryContext(ctx, generatedSelect(false)+` WHERE `+where+` ORDER BY d.id DESC`, arg)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]GeneratedDocument, 0)
	for rows.Next() {
		value, err := scanGenerated(rows, false)
		if err != nil {
			return nil, err
		}
		out = append(out, value)
	}
	return out, rows.Err()
}

func (s Service) GetGenerated(ctx context.Context, id int64, withContent bool) (GeneratedDocument, error) {
	return scanGenerated(s.DB.QueryRowContext(ctx, generatedSelect(withContent)+` WHERE d.id=?`, id), withContent)
}

func generatedSelect(withContent bool) string {
	columns := `d.id,d.object_type,d.vm_id,COALESCE(vm.name,''),d.internal_service_id,COALESCE(service.name,''),d.template_id,COALESCE(t.name,d.template_name),d.document_number,d.file_name,d.mime_type,d.sha256,d.size_bytes,d.source_inventory_id,d.generated_by,COALESCE(u.display_name,u.username,''),d.generated_at`
	if withContent {
		columns += `,d.content`
	}
	return `SELECT ` + columns + ` FROM generated_documents d
		LEFT JOIN virtual_machines vm ON vm.id=d.vm_id
		LEFT JOIN internal_services service ON service.id=d.internal_service_id
		LEFT JOIN document_templates t ON t.id=d.template_id
		LEFT JOIN users u ON u.id=d.generated_by`
}

func (s Service) Generate(ctx context.Context, template Template, data GenerationData) (GeneratedDocument, error) {
	if template.ObjectType != "vm" {
		return GeneratedDocument{}, errors.New("template is not a VM template")
	}
	if !template.Active {
		return GeneratedDocument{}, errors.New("template is inactive")
	}
	if len(template.Content) == 0 {
		var err error
		template, err = s.GetTemplate(ctx, template.ID, true)
		if err != nil {
			return GeneratedDocument{}, err
		}
	}
	if data.GeneratedAt.IsZero() {
		data.GeneratedAt = time.Now().UTC()
	}
	if data.DocumentNumber == "" {
		data.DocumentNumber = NewDocumentNumber(data.VM.ID, data.GeneratedAt)
	}
	content, err := RenderDOCX(template.Content, data)
	if err != nil {
		return GeneratedDocument{}, err
	}
	hash := sha256.Sum256(content)
	filename := safeDocumentFileName(data.VM.Name, data.DocumentNumber, "vm")
	var inventoryID any
	if data.Inventory != nil {
		inventoryID = data.Inventory.ID
	}
	result, err := s.DB.ExecContext(ctx, `INSERT INTO generated_documents(object_type,vm_id,internal_service_id,template_id,template_name,document_number,file_name,mime_type,content,sha256,size_bytes,source_inventory_id,generated_by,generated_at) VALUES('vm',?,NULL,?,?,?,?,?,?,?,?,?,?,?)`,
		data.VM.ID, template.ID, template.Name, data.DocumentNumber, filename, DOCXContentType, content, hex.EncodeToString(hash[:]), len(content), inventoryID, nullableUserID(data.GeneratedBy.ID), data.GeneratedAt)
	if err != nil {
		return GeneratedDocument{}, err
	}
	id, err := result.LastInsertId()
	if err != nil {
		return GeneratedDocument{}, err
	}
	return s.GetGenerated(ctx, id, false)
}

func (s Service) GenerateService(ctx context.Context, template Template, data ServiceGenerationData) (GeneratedDocument, error) {
	if template.ObjectType != "service" {
		return GeneratedDocument{}, errors.New("template is not an internal service template")
	}
	if !template.Active {
		return GeneratedDocument{}, errors.New("template is inactive")
	}
	if len(template.Content) == 0 {
		var err error
		template, err = s.GetTemplate(ctx, template.ID, true)
		if err != nil {
			return GeneratedDocument{}, err
		}
	}
	if data.GeneratedAt.IsZero() {
		data.GeneratedAt = time.Now().UTC()
	}
	if data.DocumentNumber == "" {
		data.DocumentNumber = NewServiceDocumentNumber(data.Service.ID, data.GeneratedAt)
	}
	content, err := RenderServiceDOCX(template.Content, data)
	if err != nil {
		return GeneratedDocument{}, err
	}
	hash := sha256.Sum256(content)
	filename := safeDocumentFileName(firstNonEmpty(data.Service.ServiceCode, data.Service.Name), data.DocumentNumber, "service")
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return GeneratedDocument{}, err
	}
	defer tx.Rollback()
	result, err := tx.ExecContext(ctx, `INSERT INTO generated_documents(object_type,vm_id,internal_service_id,template_id,template_name,document_number,file_name,mime_type,content,sha256,size_bytes,source_inventory_id,generated_by,generated_at) VALUES('service',NULL,?,?,?,?,?,?,?,?,?,NULL,?,?)`,
		data.Service.ID, template.ID, template.Name, data.DocumentNumber, filename, DOCXContentType, content, hex.EncodeToString(hash[:]), len(content), nullableUserID(data.GeneratedBy.ID), data.GeneratedAt)
	if err != nil {
		return GeneratedDocument{}, err
	}
	id, err := result.LastInsertId()
	if err != nil {
		return GeneratedDocument{}, err
	}
	if data.IncludeVMAnnexes {
		seen := make(map[int64]bool)
		sortOrder := 0
		for _, annex := range data.VMDocuments {
			if annex.DocumentID <= 0 || annex.VMID <= 0 || seen[annex.VMID] {
				continue
			}
			seen[annex.VMID] = true
			if _, err := tx.ExecContext(ctx, `INSERT INTO service_document_annexes(service_document_id,vm_id,vm_document_id,sort_order) VALUES(?,?,?,?)`, id, annex.VMID, annex.DocumentID, sortOrder); err != nil {
				return GeneratedDocument{}, err
			}
			sortOrder++
		}
	}
	if err := tx.Commit(); err != nil {
		return GeneratedDocument{}, err
	}
	return s.GetGenerated(ctx, id, false)
}

func (s Service) ListServiceDocumentAnnexes(ctx context.Context, serviceDocumentID int64) ([]ServiceDocumentAnnex, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT a.sort_order,d.id,d.object_type,d.vm_id,COALESCE(vm.name,''),d.internal_service_id,COALESCE(service.name,''),d.template_id,COALESCE(t.name,d.template_name),d.document_number,d.file_name,d.mime_type,d.sha256,d.size_bytes,d.source_inventory_id,d.generated_by,COALESCE(u.display_name,u.username,''),d.generated_at
		FROM service_document_annexes a
		JOIN generated_documents d ON d.id=a.vm_document_id
		LEFT JOIN virtual_machines vm ON vm.id=d.vm_id
		LEFT JOIN internal_services service ON service.id=d.internal_service_id
		LEFT JOIN document_templates t ON t.id=d.template_id
		LEFT JOIN users u ON u.id=d.generated_by
		WHERE a.service_document_id=? ORDER BY a.sort_order,a.vm_id`, serviceDocumentID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]ServiceDocumentAnnex, 0)
	for rows.Next() {
		var value ServiceDocumentAnnex
		var vmID, serviceID, templateID, inventoryID, generatedBy sql.NullInt64
		if err := rows.Scan(&value.SortOrder, &value.Document.ID, &value.Document.ObjectType, &vmID, &value.Document.VMName, &serviceID, &value.Document.InternalServiceName, &templateID, &value.Document.TemplateName, &value.Document.DocumentNumber, &value.Document.FileName, &value.Document.MIMEType, &value.Document.SHA256, &value.Document.SizeBytes, &inventoryID, &generatedBy, &value.Document.GeneratedByName, &value.Document.GeneratedAt); err != nil {
			return nil, err
		}
		value.ServiceDocumentID = serviceDocumentID
		if vmID.Valid {
			id := vmID.Int64
			value.Document.VMID = &id
		}
		if serviceID.Valid {
			id := serviceID.Int64
			value.Document.InternalServiceID = &id
		}
		if templateID.Valid {
			id := templateID.Int64
			value.Document.TemplateID = &id
		}
		if inventoryID.Valid {
			id := inventoryID.Int64
			value.Document.SourceInventoryID = &id
		}
		if generatedBy.Valid {
			id := generatedBy.Int64
			value.Document.GeneratedBy = &id
		}
		out = append(out, value)
	}
	return out, rows.Err()
}

func (s Service) BuildServiceDocumentPackage(ctx context.Context, serviceDocumentID int64) ([]byte, string, error) {
	main, err := s.GetGenerated(ctx, serviceDocumentID, true)
	if err != nil {
		return nil, "", err
	}
	if main.ObjectType != "service" {
		return nil, "", errors.New("document is not an internal service document")
	}
	annexes, err := s.ListServiceDocumentAnnexes(ctx, serviceDocumentID)
	if err != nil {
		return nil, "", err
	}
	var output bytes.Buffer
	writer := zip.NewWriter(&output)
	entry, err := writer.Create(filepath.Base(main.FileName))
	if err != nil {
		return nil, "", err
	}
	if _, err := entry.Write(main.Content); err != nil {
		return nil, "", err
	}
	for index, annex := range annexes {
		doc, err := s.GetGenerated(ctx, annex.Document.ID, true)
		if err != nil {
			writer.Close()
			return nil, "", err
		}
		name := fmt.Sprintf("anexe/A%02d_%s", index+1, filepath.Base(doc.FileName))
		entry, err := writer.Create(name)
		if err != nil {
			writer.Close()
			return nil, "", err
		}
		if _, err := entry.Write(doc.Content); err != nil {
			writer.Close()
			return nil, "", err
		}
	}
	if err := writer.Close(); err != nil {
		return nil, "", err
	}
	base := strings.TrimSuffix(filepath.Base(main.FileName), filepath.Ext(main.FileName))
	return output.Bytes(), base + "_cu_anexe.zip", nil
}

func NewDocumentNumber(vmID int64, now time.Time) string {
	return newDocumentNumber("FVM", vmID, now)
}

func NewServiceDocumentNumber(serviceID int64, now time.Time) string {
	return newDocumentNumber("FSI", serviceID, now)
}

func newDocumentNumber(prefix string, objectID int64, now time.Time) string {
	var suffix [4]byte
	if _, err := rand.Read(suffix[:]); err != nil {
		suffix[0], suffix[1], suffix[2], suffix[3] = byte(now.UnixNano()), byte(now.UnixNano()>>8), byte(now.UnixNano()>>16), byte(now.UnixNano()>>24)
	}
	return fmt.Sprintf("%s-%s-%06d-%s", prefix, now.UTC().Format("20060102"), objectID, strings.ToUpper(hex.EncodeToString(suffix[:])))
}

func normalizeTemplateInput(input *TemplateInput) error {
	input.Name = strings.TrimSpace(input.Name)
	input.Code = strings.ToLower(strings.TrimSpace(input.Code))
	input.ObjectType = normalizeObjectType(input.ObjectType)
	if input.ObjectType == "" {
		input.ObjectType = "vm"
	}
	input.Description = strings.TrimSpace(input.Description)
	input.FileName = filepath.Base(strings.TrimSpace(input.FileName))
	input.MIMEType = strings.TrimSpace(input.MIMEType)
	if input.Name == "" || input.Code == "" || input.FileName == "" || len(input.Content) == 0 {
		return errors.New("name, code and DOCX file are required")
	}
	if !allowedObjectTypes[input.ObjectType] {
		return errors.New("object_type must be vm or service")
	}
	if !templateCodePattern.MatchString(input.Code) {
		return errors.New("template code is invalid")
	}
	if !strings.EqualFold(filepath.Ext(input.FileName), ".docx") {
		return errors.New("template file must have .docx extension")
	}
	if input.MIMEType == "" || input.MIMEType == "application/octet-stream" {
		input.MIMEType = DOCXContentType
	}
	if len(input.Content) > 20<<20 {
		return errors.New("template file must be at most 20 MiB")
	}
	if input.Default && !input.Active {
		return errors.New("default template must be active")
	}
	return nil
}

func normalizeObjectType(value string) string {
	value = strings.ToLower(strings.TrimSpace(value))
	switch value {
	case "internal_service", "internal-service", "serviciu", "service":
		return "service"
	case "vm", "virtual_machine", "virtual-machine":
		return "vm"
	default:
		return value
	}
}

func safeDocumentFileName(name, number, fallback string) string {
	name = strings.TrimSpace(name)
	if name == "" {
		name = fallback
	}
	var builder strings.Builder
	for _, r := range name {
		switch {
		case r >= 'a' && r <= 'z', r >= 'A' && r <= 'Z', r >= '0' && r <= '9', r == '-', r == '_', r == '.':
			builder.WriteRune(r)
		default:
			builder.WriteByte('-')
		}
	}
	clean := strings.Trim(builder.String(), "-._")
	if clean == "" {
		clean = fallback
	}
	return clean + "-" + strings.ToLower(number) + ".docx"
}

func nullableUserID(id int64) any {
	if id <= 0 {
		return nil
	}
	return id
}

type rowScanner interface{ Scan(dest ...any) error }

func scanTemplate(scanner rowScanner, withContent bool) (Template, error) {
	var value Template
	var createdBy, updatedBy sql.NullInt64
	args := []any{&value.ID, &value.Name, &value.Code, &value.ObjectType, &value.Description, &value.FileName, &value.MIMEType, &value.SHA256, &value.SizeBytes, &value.Active, &value.Default, &createdBy, &updatedBy, &value.CreatedAt, &value.UpdatedAt}
	if withContent {
		args = append(args, &value.Content)
	}
	if err := scanner.Scan(args...); err != nil {
		return value, err
	}
	if createdBy.Valid {
		id := createdBy.Int64
		value.CreatedBy = &id
	}
	if updatedBy.Valid {
		id := updatedBy.Int64
		value.UpdatedBy = &id
	}
	return value, nil
}

func scanGenerated(scanner rowScanner, withContent bool) (GeneratedDocument, error) {
	var value GeneratedDocument
	var vmID, serviceID, templateID, inventoryID, generatedBy sql.NullInt64
	args := []any{&value.ID, &value.ObjectType, &vmID, &value.VMName, &serviceID, &value.InternalServiceName, &templateID, &value.TemplateName, &value.DocumentNumber, &value.FileName, &value.MIMEType, &value.SHA256, &value.SizeBytes, &inventoryID, &generatedBy, &value.GeneratedByName, &value.GeneratedAt}
	if withContent {
		args = append(args, &value.Content)
	}
	if err := scanner.Scan(args...); err != nil {
		return value, err
	}
	if vmID.Valid {
		id := vmID.Int64
		value.VMID = &id
	}
	if serviceID.Valid {
		id := serviceID.Int64
		value.InternalServiceID = &id
	}
	if templateID.Valid {
		id := templateID.Int64
		value.TemplateID = &id
	}
	if inventoryID.Valid {
		id := inventoryID.Int64
		value.SourceInventoryID = &id
	}
	if generatedBy.Valid {
		id := generatedBy.Int64
		value.GeneratedBy = &id
	}
	return value, nil
}

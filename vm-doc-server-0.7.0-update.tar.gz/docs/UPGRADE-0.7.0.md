# Upgrade la vm-doc-server 0.7.0

Versiunea 0.7.0 adaugă schema logică automată a Serviciilor interne și pictograme configurabile pentru nomenclatoare.

## Migrare MariaDB

La prima pornire, serverul aplică:

```text
020_service_diagram_icons.up.sql
```

Migrarea adaugă `nomenclature_items.icon_key` și completează pictograme implicite. Nu șterge și nu modifică asocierile VM–serviciu existente.

## Upgrade recomandat

```bash
sudo systemctl stop vm-doc-collector vm-doc-server
# backup MariaDB + binare/configurație
# aplicați pachetul 0.7.0 și recompilați
sudo systemctl start vm-doc-server
sudo journalctl -u vm-doc-server -n 80 --no-pager
sudo systemctl start vm-doc-collector
```

După pornire verificați **Nomenclatoare** (câmpul Pictogramă) și **Servicii interne → Schemă serviciu**.

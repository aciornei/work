# vm-doc-agent 0.5.0

Agent Linux universal pentru inventarierea datelor locale necesare fișei VM. Același binar static și același pachet rulează pe Ubuntu, Debian, CentOS/RHEL și SUSE, inclusiv sisteme vechi cu SysV Init.

Agentul detectează automat distribuția și init system-ul, scrie inventarul într-un JSON local și expune un API HTTP protejat cu token Bearer.

CPU și RAM nu sunt colectate; acestea vor fi preluate ulterior din vCenter.

## Date colectate

### Identitate

- hostname și FQDN;
- distribuție, versiune, kernel, arhitectură și init system;
- `machine-id`;
- UUID DMI/SMBIOS și varianta alternativă de byte-order pentru vCenter/GLPI;
- vendor, model, serial, virtualizare și ID persistent al agentului.

### Stocare, rețea, servicii și porturi

- partiții montate relevante, filesystem, capacitate și utilizare;
- interfețe, MAC, MTU, IPv4/IPv6 și CIDR;
- servicii systemd sau SysV și starea lor;
- porturi TCP/UDP ascultate, PID, proces și executabil.

### Firewall local

Agentul detectează, în funcție de sistem:

- nftables;
- iptables și ip6tables;
- firewalld;
- UFW;
- SUSEfirewall2.

Sunt raportate backend-urile, starea, politicile implicite, zonele, regulile și fișierele de configurare găsite.

### Utilizatori locali și parole

Pentru conturile din `/etc/passwd` și metadatele din `/etc/shadow`:

- UID/GID, home și shell;
- cont de sistem sau cont normal;
- parolă setată, blocată sau goală;
- ultima dată când parola a fost setată;
- data expirării parolei;
- data expirării contului;
- min/max age, warning și inactive days.

Nu sunt citite în inventar hash-urile de parole. Informațiile se referă la conturile locale. Expirarea parolelor utilizatorilor din AD/LDAP nu poate fi stabilită sigur doar din configurația SSSD și va fi preluată ulterior prin integrarea centrală cu AD/LDAP.

### Politica de parole

- valorile relevante din `/etc/login.defs`;
- `pam_pwquality`, `pam_cracklib`, `pam_pwcheck`, `pam_pwhistory` și opțiunile lor;
- fișierele `pwquality.conf`;
- password history și indicatorul că există o politică de complexitate.

Complexitatea este o politică a sistemului, nu un atribut separat pentru fiecare utilizator.

### SSSD

- instalare și versiune;
- serviciu activ/enabled;
- existența, permisiunile și proprietarul `sssd.conf`;
- servicii și domenii declarate;
- opțiuni sigure precum provider, realm, LDAP URI, search base, cache, home și shell;
- rezultatul `sssctl config-check`, când comanda există.

Parolele, bind password, authtok, tokenurile și cheile private sunt excluse.

### GLPI Agent

- detectează `glpi-agent` și vechiul `fusioninventory-agent`;
- versiunea binarului sau a pachetului;
- serviciul și fișierele de configurare.

### Node Exporter / Prometheus

- instalare și versiune;
- serviciu și adresele pe care ascultă;
- endpoint-urile `/metrics`;
- verificare locală că endpoint-ul răspunde și returnează metrici;
- status HTTP și numărul de mostre găsite.

Dacă Node Exporter folosește TLS sau autentificare, verificarea locală poate apărea nereușită chiar dacă serviciul este intenționat protejat.

### Auditbeat și Filebeat

- instalare și versiune;
- serviciu activ/enabled;
- fișiere de configurare;
- validarea configurației cu `test config`;
- output-urile și modulele detectate.

### Syslog

- rsyslog, syslog-ng sau syslog clasic;
- versiune și serviciu;
- fișiere de configurare;
- destinații remote detectate, protocol și port.

### Politici de sistem

- SELinux și AppArmor;
- fișiere audit rules;
- sudoers;
- limits;
- sysctl;
- marker-e de politici organizaționale definite prin `policy_paths`.

Pentru fișiere se salvează metadata și SHA256, nu conținutul complet.

### Crontab

- `/etc/crontab` și `/etc/cron.d/*`;
- crontab-urile utilizatorilor din spool;
- scripturile hourly/daily/weekly/monthly;
- schedule, utilizator, sursă și comandă.

Valorile de tip password/token/secret și credentialele din URL sunt mascate best-effort. Este recomandat să nu fie introduse secrete direct în crontab.

### NTP

- chrony, ntpd/ntpsec sau systemd-timesyncd;
- versiune și serviciu;
- servere/pool-uri configurate;
- sursa selectată și reachability, când sunt disponibile;
- starea de sincronizare;
- tracking summary pentru chrony.

## Sisteme vizate

- Ubuntu 20.04 și mai noi;
- Debian, inclusiv versiuni vechi cu SysV;
- CentOS 7, RHEL, Rocky, AlmaLinux și Oracle Linux;
- SUSE Linux Enterprise Server 11 și mai noi.

Pachetul este unic pentru toate sistemele `x86_64/amd64`.

## Instalare

```bash
tar -xzf vm-doc-agent-0.5.0-linux-amd64.tar.gz
cd vm-doc-agent-0.5.0-linux-amd64
sudo ./install.sh
```

Installerul alege automat systemd sau SysV.

## Update de la 0.4.0

```bash
tar -xzf vm-doc-agent-0.5.0-linux-amd64.tar.gz
cd vm-doc-agent-0.5.0-linux-amd64
sudo ./update.sh
```

Configurația, tokenul, inventarul și `agent-id` sunt păstrate. Câmpul nou `policy_paths` este opțional, deci configurația veche rămâne validă.

## Configurație

```json
{
  "listen": "0.0.0.0:9078",
  "output_file": "/var/lib/vm-doc-agent/inventory.json",
  "state_dir": "/var/lib/vm-doc-agent",
  "refresh_interval": "15m",
  "auth_token_file": "/etc/vm-doc-agent/token",
  "policy_paths": []
}
```

Exemplu pentru politici organizaționale:

```json
"policy_paths": [
  "/etc/company/policies/*",
  "/opt/company/policy-markers",
  "/etc/company/hardening.conf"
]
```

## API

`GET /health` este public. Toate endpoint-urile `/v1/*` cer token Bearer.

```bash
TOKEN=$(sudo cat /etc/vm-doc-agent/token)

curl http://127.0.0.1:9078/health
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/inventory
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/firewall
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/accounts
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/sssd
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/integrations
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/policies
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/cron
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/ntp
curl -X POST -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/inventory/refresh
```

Endpoint-urile existente rămân disponibile:

- `/v1/version`
- `/v1/identity`
- `/v1/storage`
- `/v1/network`
- `/v1/services`
- `/v1/listening-ports`

## Fișier local

```text
/var/lib/vm-doc-agent/inventory.json
```

Scrierea este atomică, prin fișier temporar și `rename`.

## Build

Go este necesar doar pe mașina de build:

```bash
./scripts/build.sh
./scripts/package.sh
```

Binarul este static, `linux/amd64`, `CGO_ENABLED=0`, `GOAMD64=v1`.

## Securitate

- agentul rulează ca root deoarece `/etc/shadow`, regulile firewall și crontab-urile tuturor utilizatorilor necesită acces privilegiat;
- nu salvează hash-uri de parole;
- filtrează cheile cunoscute ca parole/tokenuri/secrete;
- nu colectează argumentele complete ale proceselor;
- portul 9078 trebuie permis numai din serverul central/rețeaua de management;
- versiunea curentă folosește HTTP cu token; pentru producție rămâne recomandată adăugarea TLS/mTLS.

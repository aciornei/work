# Upgrade 0.2.2 → 0.3.0

## 1. Backup

```bash
mysqldump --single-transaction vm_doc > /root/vm_doc-before-0.3.0.sql
cp -a /etc/vm-doc-server /etc/vm-doc-server.backup-0.2.2
```

## 2. Configurație și dependențe

Versiunea 0.3.0 nu adaugă module Go și nu schimbă formatul fișierelor YAML. Directorul `vendor` folosit la 0.2.2 poate fi păstrat.

## 3. Compilare offline

Păstrează directorul `vendor/` existent și aplică pachetul de update peste o copie a surselor 0.2.2:

```bash
cp -a /usr/local/src/vm-doc-server-0.2.2 /usr/local/src/vm-doc-server-0.3.0
tar -xzf vm-doc-server-0.3.0-update.tar.gz -C /usr/local/src/vm-doc-server-0.3.0
cd /usr/local/src/vm-doc-server-0.3.0
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

Arhiva completă `vm-doc-server-0.3.0.zip` este utilă pentru consultarea surselor, dar nu conține `vendor/`.

## 4. Instalare

```bash
systemctl stop vm-doc-collector vm-doc-server
install -m 0755 bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-server
install -m 0755 bin/vm-doc-collector /opt/vm-doc-server/bin/vm-doc-collector
systemctl start vm-doc-server
journalctl -u vm-doc-server -n 100 --no-pager
curl -s http://127.0.0.1:9080/version
systemctl start vm-doc-collector
```

La pornirea serverului se aplică automat migrarea:

```text
011_vm_operational_metadata.up.sql
```

Aceasta creează tabelul `vm_operational_metadata`. Nu modifică și nu șterge inventarele existente.

## 5. Validare funcțională

1. autentifică-te prin Keycloak/OIDC;
2. deschide **VM-uri** și selectează o VM cu agent;
3. confirmă că pagina conține secțiunea **Date colectate de agent** cu carduri pliabile;
4. completează câteva câmpuri din **Date operaționale** și salvează;
5. execută o colectare nouă și verifică faptul că datele operaționale au rămas neschimbate;
6. verifică auditul pentru acțiunea `vm.operational.update`.

Verificare directă în MariaDB:

```sql
SELECT vm_id, service_name, environment, operational_status, updated_at
FROM vm_operational_metadata
ORDER BY updated_at DESC
LIMIT 20;
```

## 6. Revenire

Pentru revenire la binarele 0.2.2, tabelul nou poate rămâne în baza de date; versiunea veche îl ignoră. Nu îl șterge dacă dorești să păstrezi datele introduse manual.

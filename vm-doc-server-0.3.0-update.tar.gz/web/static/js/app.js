const state={user:null,csrf:'',agents:[],sources:[],vms:[],vmFilters:{q:'',power:'',agent:'',retired:'all',sourceId:'',page:1,pageSize:50}};
const content=document.getElementById('content');
const title=document.getElementById('pageTitle');
const subtitle=document.getElementById('pageSubtitle');
const agentDialog=document.getElementById('agentDialog');
const agentForm=document.getElementById('agentForm');
const vcenterDialog=document.getElementById('vcenterDialog');
const vcenterForm=document.getElementById('vcenterForm');

const rolePermissions={
  admin:new Set(['*']),
  operator:new Set(['dashboard.read','agents.read','agents.manage','collections.read','collections.run','inventories.read','inventories.raw.read','vcenter.read','vcenter.manage','vms.manage']),
  viewer:new Set(['dashboard.read','agents.read','collections.read','inventories.read','vcenter.read']),
  auditor:new Set(['dashboard.read','agents.read','collections.read','inventories.read','inventories.raw.read','audit.read','vcenter.read'])
};
function can(permission){return (state.user?.roles||[]).some(role=>rolePermissions[role]?.has('*')||rolePermissions[role]?.has(permission))}

async function api(path,options={}){
  const headers={Accept:'application/json',...(options.headers||{})};
  if(options.body&&!headers['Content-Type'])headers['Content-Type']='application/json';
  if(!['GET','HEAD'].includes((options.method||'GET').toUpperCase())&&state.csrf)headers['X-CSRF-Token']=state.csrf;
  const response=await fetch(path,{...options,headers});
  if(response.status===401){location.href='/login';throw new Error('Sesiunea a expirat.');}
  const type=response.headers.get('content-type')||'';
  const body=response.status===204?null:type.includes('json')?await response.json():await response.text();
  if(!response.ok)throw new Error(body?.message||body?.error||`HTTP ${response.status}`);
  return body;
}
const e=v=>String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const dt=v=>v?new Date(v).toLocaleString('ro-RO'):'—';
const badge=v=>{const text=String(v??'unknown');return `<span class="badge ${e(text.toLowerCase().replaceAll('_','-'))}">${e(text)}</span>`};
const boolText=v=>v?'Da':'Nu';
const memory=v=>v?`${(Number(v)/1024).toFixed(Number(v)>=10240?0:1)} GB`:'—';
function toast(message,error=false){const box=document.getElementById('toast');box.textContent=message;box.className=`toast show${error?' error':''}`;setTimeout(()=>box.className='toast',3200)}
function pageMeta(name,sub){title.textContent=name;subtitle.textContent=sub||''}
function panel(head,body,tools=''){return `<section class="panel"><div class="panel-header"><h2>${head}</h2><div class="toolbar">${tools}</div></div>${body}</section>`}
function empty(text){return `<div class="empty">${e(text)}</div>`}
function detail(label,value,mono=false){return `<div class="detail-item"><span>${e(label)}</span><div class="${mono?'mono':''}">${value??'—'}</div></div>`}
function jsonSections(raw){const entries=raw&&typeof raw==='object'&&!Array.isArray(raw)?Object.entries(raw):[['inventory',raw]];return `<div class="json-sections">${entries.map(([name,value])=>`<details><summary>${e(name)}</summary><pre class="json">${e(JSON.stringify(value,null,2))}</pre></details>`).join('')}</div>`}

async function init(){
  try{
    state.user=await api('/api/v1/auth/me');state.csrf=state.user.csrf_token;
    document.getElementById('currentUser').textContent=state.user.display_name||state.user.username;
    document.querySelector('[data-page="audit"]').hidden=!can('audit.read');
    document.querySelector('[data-page="access"]').hidden=!can('rbac.manage');
    document.body.classList.remove('booting');route();
  }catch{location.href='/login'}
}

async function route(){
  const raw=(location.hash||'#dashboard').slice(1);const [page,id]=raw.split('/');
  document.querySelectorAll('#nav a[data-page]').forEach(a=>a.classList.toggle('active',a.dataset.page===page));
  content.innerHTML='<div class="loading">Se încarcă…</div>';
  try{
    if(page==='dashboard')await dashboard();
    else if(page==='agents')await agentsPage();
    else if(page==='vms'&&id)await vmDetail(Number(id));
    else if(page==='vms')await vmsPage();
    else if(page==='audit')await auditPage();
    else if(page==='access')await accessPage();
    else location.hash='#dashboard';
  }catch(err){content.innerHTML=empty(err.message);toast(err.message,true)}
}

async function dashboard(){
  pageMeta('Dashboard','Starea centralizată a platformei');
  const d=await api('/api/v1/dashboard');
  content.innerHTML=`<div class="cards">
    <div class="card"><div class="label">VM-uri din vCenter</div><div class="value">${d.vms}</div></div>
    <div class="card"><div class="label">Agenți configurați</div><div class="value">${d.agents_total}</div></div>
    <div class="card"><div class="label">Agenți online</div><div class="value">${d.agents_online}</div></div>
    <div class="card"><div class="label">Joburi în așteptare</div><div class="value">${d.jobs_pending}</div></div>
  </div>${panel('Fluxul 0 → inventar',`<div class="detail-grid">${detail('0. vCenter','Lista completă de VM-uri')}${detail('1. Corelare','BIOS UUID / hostname unic')}${detail('2. Agent','Colectare JSON și stare')}${detail('3. Lifecycle','Retired și istoric local')}</div>`)}`;
}

async function agentsPage(){
  pageMeta('Agenți','Administrare, conectivitate și colectare');state.agents=await api('/api/v1/agents');
  const rows=state.agents.map(a=>{const actions=[can('collections.run')?`<button class="small secondary" data-action="test" data-id="${a.id}">Test</button><button class="small" data-action="collect" data-id="${a.id}">Colectează</button>`:'',can('agents.manage')?`<button class="small secondary" data-action="edit" data-id="${a.id}">Editează</button><button class="small danger" data-action="delete" data-id="${a.id}">Șterge</button>`:''].join('');return `<tr><td><strong>${e(a.name)}</strong><div class="muted mono">${e(a.base_url)}</div></td><td>${badge(a.status)}</td><td class="mono">${e(a.agent_uuid||'—')}</td><td>${dt(a.last_contact_at)}</td><td class="muted">${e(a.last_error||'—')}</td><td><div class="actions">${actions||'—'}</div></td></tr>`}).join('');
  content.innerHTML=panel('Lista agenților',state.agents.length?`<div class="table-wrap"><table><thead><tr><th>Agent</th><th>Status</th><th>UUID</th><th>Ultimul contact</th><th>Ultima eroare</th><th>Acțiuni</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există agenți configurați.'),can('agents.manage')?'<button id="newAgent">Adaugă agent</button>':'');
  document.getElementById('newAgent')?.addEventListener('click',()=>openAgent());
  content.querySelectorAll('[data-action]').forEach(b=>b.onclick=()=>agentAction(b.dataset.action,Number(b.dataset.id)));
}

function openAgent(agent=null){
  document.getElementById('agentDialogTitle').textContent=agent?'Editare agent':'Agent nou';
  document.getElementById('agentId').value=agent?.id||'';document.getElementById('agentName').value=agent?.name||'';document.getElementById('agentURL').value=agent?.base_url||'';document.getElementById('agentToken').value='';document.getElementById('agentToken').required=!agent;
  document.getElementById('agentInterval').value=agent?.collection_interval_seconds||900;document.getElementById('agentTimeout').value=agent?.request_timeout_seconds||45;document.getElementById('agentOffline').value=agent?.offline_after_seconds||2700;document.getElementById('agentEnabled').checked=agent?.enabled??true;document.getElementById('agentVerifyTLS').checked=agent?.verify_tls??true;agentDialog.showModal();
}
async function agentAction(action,id){
  const agent=state.agents.find(a=>a.id===id);
  if(action==='edit'){openAgent(agent);return}
  if(action==='delete'){if(!confirm(`Ștergi agentul ${agent.name}? Istoricul lui va fi șters.`))return;await api(`/api/v1/agents/${id}`,{method:'DELETE'});toast('Agent șters.');agentsPage();return}
  const job=await api(`/api/v1/agents/${id}/${action==='test'?'test':'collect'}`,{method:'POST'});toast(`Job ${job.id} introdus în coadă.`);setTimeout(agentsPage,1000);
}
agentForm.addEventListener('submit',async event=>{
  event.preventDefault();const id=Number(document.getElementById('agentId').value||0);
  const body={name:document.getElementById('agentName').value.trim(),base_url:document.getElementById('agentURL').value.trim(),token:document.getElementById('agentToken').value,enabled:document.getElementById('agentEnabled').checked,verify_tls:document.getElementById('agentVerifyTLS').checked,collection_interval_seconds:Number(document.getElementById('agentInterval').value),request_timeout_seconds:Number(document.getElementById('agentTimeout').value),offline_after_seconds:Number(document.getElementById('agentOffline').value)};
  if(id&&!body.token)delete body.token;
  try{await api(id?`/api/v1/agents/${id}`:'/api/v1/agents',{method:id?'PATCH':'POST',body:JSON.stringify(body)});agentDialog.close();toast(id?'Agent actualizat.':'Agent creat.');agentsPage()}catch(err){toast(err.message,true)}
});

async function vmsPage(){
  pageMeta('VM-uri','Căutare, filtrare, paginare și export din inventarul vCenter');
  const requests=[can('vcenter.read')?api('/api/v1/vcenter/sources'):Promise.resolve([]),can('vcenter.read')?api('/api/v1/vcenter/sync-runs'):Promise.resolve([])];
  const results=await Promise.all(requests);state.sources=Array.isArray(results[0])?results[0]:[];const runs=Array.isArray(results[1])?results[1]:[];
  const filters=state.vmFilters;
  const tools=`<a id="exportVMs" class="button secondary" href="/api/v1/vms/export">Export Excel</a>${can('vcenter.manage')?'<button id="syncAll">Sincronizează vCenter</button><button id="newVCenter" class="secondary">Adaugă sursă</button>':''}`;
  const sourceOptions=state.sources.map(s=>`<option value="${s.id}" ${String(filters.sourceId)===String(s.id)?'selected':''}>${e(s.name)}</option>`).join('');
  const sourceRows=state.sources.map(s=>`<tr><td><strong>${e(s.name)}</strong><div class="muted mono">${e(s.base_url)}</div></td><td>${e(s.username)}</td><td>${s.daily_sync_enabled?`Zilnic ${e(s.daily_sync_time)}`:'Manual'}</td><td>${dt(s.last_success_at)}<div class="error-text">${e(s.last_error||'')}</div></td><td><div class="actions">${can('vcenter.manage')?`<button class="small secondary vc-action" data-action="test" data-id="${s.id}">Test</button><button class="small vc-action" data-action="sync" data-id="${s.id}">Sync</button><button class="small secondary vc-action" data-action="edit" data-id="${s.id}">Editează</button><button class="small danger vc-action" data-action="delete" data-id="${s.id}">Șterge</button>`:'—'}</div></td></tr>`).join('');
  const runRows=runs.slice(0,15).map(r=>`<tr><td>${dt(r.created_at)}</td><td>${e(r.vcenter_source_name)}</td><td>${badge(r.status)}</td><td>${r.found_count}</td><td>+${r.created_count} / ~${r.updated_count} / lipsă ${r.missing_count}</td><td>${r.linked_agent_count}</td><td class="error-text">${e(r.error_message||'—')}</td></tr>`).join('');
  const filterBody=`<div class="filterbar vm-filterbar">
    <label class="vm-search-field"><span>Căutare</span><input id="vmSearch" value="${e(filters.q)}" placeholder="Nume, hostname, OS, IP, agent sau sursă"></label>
    <label><span>Power</span><select id="vmPower"><option value="">Toate</option><option value="POWERED_ON" ${filters.power==='POWERED_ON'?'selected':''}>Pornite</option><option value="POWERED_OFF" ${filters.power==='POWERED_OFF'?'selected':''}>Oprite</option><option value="SUSPENDED" ${filters.power==='SUSPENDED'?'selected':''}>Suspendate</option></select></label>
    <label><span>Agent</span><select id="vmAgentFilter"><option value="">Toți</option><option value="configured" ${filters.agent==='configured'?'selected':''}>Asociat</option><option value="unconfigured" ${filters.agent==='unconfigured'?'selected':''}>Fără agent</option><option value="online" ${filters.agent==='online'?'selected':''}>Online</option><option value="offline" ${filters.agent==='offline'?'selected':''}>Offline</option><option value="unknown" ${filters.agent==='unknown'?'selected':''}>Necunoscut</option><option value="disabled" ${filters.agent==='disabled'?'selected':''}>Dezactivat</option></select></label>
    <label><span>Retired</span><select id="vmRetiredFilter"><option value="all" ${filters.retired==='all'?'selected':''}>Toate</option><option value="false" ${filters.retired==='false'?'selected':''}>Nu</option><option value="true" ${filters.retired==='true'?'selected':''}>Da</option></select></label>
    <label><span>Sursă</span><select id="vmSource"><option value="">Toate sursele</option>${sourceOptions}</select></label>
    <label><span>Pe pagină</span><select id="vmPageSize">${[25,50,100,200].map(n=>`<option value="${n}" ${Number(filters.pageSize)===n?'selected':''}>${n}</option>`).join('')}</select></label>
    <button id="clearVMFilters" class="secondary vm-clear-filter" type="button">Curăță</button>
  </div><div id="vmTableArea" class="loading">Se încarcă VM-urile…</div>`;
  content.innerHTML=`<div class="cards"><div class="card"><div class="label">Rezultate</div><div id="vmTotal" class="value">—</div></div><div class="card"><div class="label">Prezente</div><div id="vmPresent" class="value">—</div></div><div class="card"><div class="label">Cu agent asociat</div><div id="vmWithAgent" class="value">—</div></div><div class="card"><div class="label">Retired</div><div id="vmRetiredCount" class="value">—</div></div></div>
  ${panel('Inventar VM',filterBody,tools)}
  ${can('vcenter.read')?panel('Surse vCenter',state.sources.length?`<div class="table-wrap"><table><thead><tr><th>Sursă</th><th>Utilizator</th><th>Program</th><th>Ultima sincronizare</th><th>Acțiuni</th></tr></thead><tbody>${sourceRows}</tbody></table></div>`:empty('Nu există surse vCenter configurate.')):''}
  ${can('vcenter.read')?panel('Ultimele sincronizări',runRows?`<div class="table-wrap"><table><thead><tr><th>Creat</th><th>Sursă</th><th>Status</th><th>Găsite</th><th>Modificări</th><th>Agenți legați</th><th>Eroare</th></tr></thead><tbody>${runRows}</tbody></table></div>`:empty('Nu există sincronizări.')):''}`;
  document.getElementById('syncAll')?.addEventListener('click',async()=>{try{const r=await api('/api/v1/vcenter/sync',{method:'POST'});toast(`${Array.isArray(r)?r.length:0} sincronizări introduse în coadă.`);setTimeout(vmsPage,1200)}catch(err){toast(err.message,true)}});
  document.getElementById('newVCenter')?.addEventListener('click',()=>openVCenter());
  content.querySelectorAll('.vc-action').forEach(b=>b.onclick=()=>vcenterAction(b.dataset.action,Number(b.dataset.id)));
  bindVMFilters();
  await loadVMPage();
}

function vmQuery(includePage=true){
  const f=state.vmFilters,params=new URLSearchParams();
  if(f.q)params.set('q',f.q);if(f.power)params.set('power',f.power);if(f.agent)params.set('agent',f.agent);if(f.retired&&f.retired!=='all')params.set('retired',f.retired);if(f.sourceId)params.set('source_id',f.sourceId);
  if(includePage){params.set('page',String(f.page));params.set('page_size',String(f.pageSize))}
  return params.toString();
}

function bindVMFilters(){
  let timer;
  document.getElementById('vmSearch')?.addEventListener('input',event=>{clearTimeout(timer);timer=setTimeout(()=>{state.vmFilters.q=event.target.value.trim();state.vmFilters.page=1;loadVMPage()},300)});
  const bindings={vmPower:'power',vmAgentFilter:'agent',vmRetiredFilter:'retired',vmSource:'sourceId'};
  Object.entries(bindings).forEach(([id,key])=>document.getElementById(id)?.addEventListener('change',event=>{state.vmFilters[key]=event.target.value;state.vmFilters.page=1;loadVMPage()}));
  document.getElementById('vmPageSize')?.addEventListener('change',event=>{state.vmFilters.pageSize=Number(event.target.value);state.vmFilters.page=1;loadVMPage()});
  document.getElementById('clearVMFilters')?.addEventListener('click',()=>{state.vmFilters={q:'',power:'',agent:'',retired:'all',sourceId:'',page:1,pageSize:50};vmsPage()});
}

async function loadVMPage(){
  const area=document.getElementById('vmTableArea');if(!area)return;area.className='loading';area.textContent='Se încarcă VM-urile…';
  try{
    const result=await api(`/api/v1/vms?${vmQuery(true)}`);state.vms=Array.isArray(result?.items)?result.items:[];state.vmFilters.page=Number(result?.page||1);
    document.getElementById('vmTotal').textContent=Number(result?.total||0).toLocaleString('ro-RO');document.getElementById('vmPresent').textContent=Number(result?.present_count||0).toLocaleString('ro-RO');document.getElementById('vmWithAgent').textContent=Number(result?.with_agent_count||0).toLocaleString('ro-RO');document.getElementById('vmRetiredCount').textContent=Number(result?.retired_count||0).toLocaleString('ro-RO');
    const exportLink=document.getElementById('exportVMs');if(exportLink)exportLink.href=`/api/v1/vms/export?${vmQuery(false)}`;
    area.className='';area.innerHTML=renderVMPage(result);
    area.querySelectorAll('.vm-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==state.vmFilters.page){state.vmFilters.page=page;loadVMPage();area.scrollIntoView({behavior:'smooth',block:'start'})}}));
  }catch(err){area.className='';area.innerHTML=empty(err.message);toast(err.message,true)}
}

function renderVMPage(result){
  const items=Array.isArray(result?.items)?result.items:[];
  if(!items.length)return empty('Nu există VM-uri pentru filtrele selectate.');
  const rows=items.map(v=>`<tr><td><a href="#vms/${v.id}"><strong>${e(v.name)}</strong></a><div class="muted mono">${e(v.vcenter_moid)} · ${e(v.vcenter_source_name)}</div></td><td>${badge(v.power_state||'unknown')}</td><td>${v.cpu_count||'—'} / ${memory(v.memory_mib)}</td><td>${e(v.inventory_os_name||v.guest_os||'—')}<div class="muted">${e(v.inventory_os_version||'')}</div></td><td class="mono">${e(v.inventory_primary_ip||v.primary_ip||'—')}</td><td>${badge(v.agent_status)}<div class="muted">${e(v.agent_name||'Fără agent')}</div></td><td>${dt(v.inventory_received_at)}</td><td>${v.retired?badge('retired'):v.present_in_vcenter?badge('active'):badge('missing')}</td></tr>`).join('');
  const total=Number(result.total||0),page=Number(result.page||1),pageSize=Number(result.page_size||50),start=(page-1)*pageSize+1,end=Math.min(page*pageSize,total);
  return `<div class="table-wrap vm-table-wrap"><table><thead><tr><th>VM</th><th>Power</th><th>CPU / RAM</th><th>OS</th><th>IP</th><th>Agent</th><th>Ultimul JSON</th><th>Lifecycle</th></tr></thead><tbody>${rows}</tbody></table></div><div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons">${paginationButtons(page,Number(result.pages||1))}</div></div>`;
}

function paginationButtons(page,pages){
  if(pages<=1)return '';
  const values=new Set([1,pages,page-2,page-1,page,page+1,page+2]);const valid=[...values].filter(n=>n>=1&&n<=pages).sort((a,b)=>a-b);let previous=0,html=`<button class="small secondary vm-page" data-page="${page-1}" ${page<=1?'disabled':''}>Anterior</button>`;
  valid.forEach(n=>{if(previous&&n>previous+1)html+='<span class="pagination-gap">…</span>';html+=`<button class="small ${n===page?'':'secondary'} vm-page" data-page="${n}" ${n===page?'disabled':''}>${n}</button>`;previous=n});
  return html+`<button class="small secondary vm-page" data-page="${page+1}" ${page>=pages?'disabled':''}>Următor</button>`;
}

function openVCenter(source=null){
  document.getElementById('vcenterDialogTitle').textContent=source?'Editare sursă vCenter':'Sursă vCenter nouă';document.getElementById('vcenterId').value=source?.id||'';document.getElementById('vcenterName').value=source?.name||'';document.getElementById('vcenterURL').value=source?.base_url||'';document.getElementById('vcenterUsername').value=source?.username||'';document.getElementById('vcenterPassword').value='';document.getElementById('vcenterPassword').required=!source;document.getElementById('vcenterSyncTime').value=source?.daily_sync_time||'05:00';document.getElementById('vcenterTLSServerName').value=source?.tls_server_name||'';document.getElementById('vcenterEnabled').checked=source?.enabled??true;document.getElementById('vcenterVerifyTLS').checked=source?.verify_tls??true;document.getElementById('vcenterDailySync').checked=source?.daily_sync_enabled??true;vcenterDialog.showModal();
}
async function vcenterAction(action,id){
  const source=state.sources.find(s=>s.id===id);
  try{
    if(action==='edit'){openVCenter(source);return}
    if(action==='delete'){if(!confirm(`Ștergi sursa ${source.name} și VM-urile sincronizate din ea?`))return;await api(`/api/v1/vcenter/sources/${id}`,{method:'DELETE'});toast('Sursă vCenter ștearsă.');vmsPage();return}
    if(action==='test'){const r=await api(`/api/v1/vcenter/sources/${id}/test`,{method:'POST'});toast(`Conexiune reușită: ${r.vm_count} VM-uri vizibile.`);return}
    if(action==='sync'){const r=await api(`/api/v1/vcenter/sources/${id}/sync`,{method:'POST'});toast(`Sincronizarea ${r.id} a fost pornită.`);setTimeout(vmsPage,1200)}
  }catch(err){toast(err.message,true)}
}
vcenterForm.addEventListener('submit',async event=>{
  event.preventDefault();const id=Number(document.getElementById('vcenterId').value||0);const body={name:document.getElementById('vcenterName').value.trim(),base_url:document.getElementById('vcenterURL').value.trim(),username:document.getElementById('vcenterUsername').value.trim(),password:document.getElementById('vcenterPassword').value,enabled:document.getElementById('vcenterEnabled').checked,verify_tls:document.getElementById('vcenterVerifyTLS').checked,tls_server_name:document.getElementById('vcenterTLSServerName').value.trim(),daily_sync_enabled:document.getElementById('vcenterDailySync').checked,daily_sync_time:document.getElementById('vcenterSyncTime').value};if(id&&!body.password)delete body.password;
  try{await api(id?`/api/v1/vcenter/sources/${id}`:'/api/v1/vcenter/sources',{method:id?'PATCH':'POST',body:JSON.stringify(body)});vcenterDialog.close();toast(id?'Sursă actualizată.':'Sursă creată.');vmsPage()}catch(err){toast(err.message,true)}
});

function fieldLabel(key){
  const labels={hostname:'Hostname',fqdn:'FQDN',uuid:'UUID',product_uuid:'Product UUID',machine_id:'Machine ID',pretty_name:'Denumire OS',version_id:'Versiune',primary_ip:'IP principal',boot_time:'Pornire sistem',status:'Stare',name:'Nume',version:'Versiune',enabled:'Activ',active:'Activ',installed:'Instalat',service:'Serviciu',port:'Port',protocol:'Protocol',address:'Adresă'};
  if(labels[key])return labels[key];
  return String(key||'').replaceAll('_',' ').replaceAll('-',' ').replace(/\b\w/g,c=>c.toUpperCase());
}
function structuredValue(value,depth=0){
  if(value===null||value===undefined||value==='')return '<span class="muted">—</span>';
  if(typeof value==='boolean')return value?badge('active'):badge('disabled');
  if(typeof value==='number')return `<span>${e(value)}</span>`;
  if(typeof value==='string'){
    const low=value.toLowerCase();
    if(['ok','active','enabled','running','installed','success','succeeded','online','configured'].includes(low))return badge(low);
    if(['error','failed','disabled','stopped','missing','offline','not_installed','unconfigured','timeout'].includes(low))return badge(low);
    return `<span class="${value.length>70?'pre-wrap':''}">${e(value)}</span>`;
  }
  if(Array.isArray(value)){
    if(!value.length)return '<span class="muted">Listă goală</span>';
    const primitives=value.every(item=>item===null||['string','number','boolean'].includes(typeof item));
    if(primitives)return `<div class="value-list">${value.map(item=>`<span>${structuredValue(item,depth+1)}</span>`).join('')}</div>`;
    return `<div class="structured-list">${value.map((item,index)=>`<details ${value.length<=4?'open':''}><summary>Element ${index+1}</summary>${structuredValue(item,depth+1)}</details>`).join('')}</div>`;
  }
  const entries=Object.entries(value);
  if(!entries.length)return '<span class="muted">Fără date</span>';
  return `<dl class="inventory-kv ${depth>1?'nested':''}">${entries.map(([key,item])=>`<div><dt>${e(fieldLabel(key))}</dt><dd>${structuredValue(item,depth+1)}</dd></div>`).join('')}</dl>`;
}
function structuredInventory(documentView){
  const sections=Array.isArray(documentView?.sections)?documentView.sections:[];
  if(!sections.length)return empty('Agentul nu a furnizat încă date structurate.');
  const opened=new Set(['identity','host','system','os','operating_system','network','integrations']);
  return `<div class="inventory-sections">${sections.map(section=>`<details class="inventory-section" ${opened.has(section.key)?'open':''}><summary><span>${e(section.title||fieldLabel(section.key))}</span>${section.status?badge(section.status):''}</summary><div class="inventory-section-body">${structuredValue(section.data)}</div></details>`).join('')}</div>`;
}
function optionalNumber(id){const raw=document.getElementById(id)?.value.trim();return raw===''?null:Number(raw)}

async function vmDetail(id){
  const [data,history,agents]=await Promise.all([api(`/api/v1/vms/${id}`),api(`/api/v1/vms/${id}/inventories`),can('agents.read')?api('/api/v1/agents'):Promise.resolve([])]);
  const vm=data.vm,a=data.agent,v=data.inventory||{},op=data.operational||{},documentView=data.inventory_document||{};
  pageMeta(vm.name,'Fișă tehnică, inventar agent și date operaționale');
  const agentOptions=`<option value="">Fără agent</option>${agents.map(x=>`<option value="${x.id}" ${vm.agent_id===x.id?'selected':''}>${e(x.name)} (${e(x.status)})</option>`).join('')}`;
  const historyRows=(history||[]).map(i=>`<tr><td>${dt(i.received_at)}</td><td>${e(i.hostname)}</td><td>${e(i.os_name)} ${e(i.os_version)}</td><td>${i.collector_ok}/${i.collector_total}</td><td>${i.changed_from_previous?badge('changed'):badge('same')}</td><td>${can('inventories.raw.read')?`<button class="small secondary show-raw" data-id="${i.id}">JSON</button>`:''}</td></tr>`).join('');
  const documentLink=op.documentation_url?`<a href="${e(op.documentation_url)}" target="_blank" rel="noopener">${e(op.documentation_url)}</a>`:'—';
  content.innerHTML=`<div class="cards"><div class="card"><div class="label">Power state</div><div class="value compact">${badge(vm.power_state||'unknown')}</div></div><div class="card"><div class="label">Agent</div><div class="value compact">${badge(vm.agent_status)}</div><div class="muted">${e(vm.agent_name||'Neasociat')}</div></div><div class="card"><div class="label">Ultimul inventar</div><div class="value compact">${dt(vm.inventory_received_at)}</div></div><div class="card"><div class="label">Lifecycle</div><div class="value compact">${vm.retired?badge('retired'):vm.present_in_vcenter?badge('active'):badge('missing')}</div></div></div>
  ${panel('Identificare și încadrare',`<div class="detail-grid">${detail('Nume VM',e(vm.name))}${detail('Hostname',e(v.hostname||vm.guest_hostname||'—'),true)}${detail('IP principal',e(v.primary_ip||vm.primary_ip||'—'),true)}${detail('Sistem de operare',`${e(v.os_name||vm.guest_os||'—')} ${e(v.os_version||'')}`)}${detail('Serviciu',e(op.service_name||'—'))}${detail('Componentă',e(op.component_name||'—'))}${detail('Mediu',e(op.environment||'—'))}${detail('Status operațional',op.operational_status?badge(op.operational_status):'—')}${detail('Administrator tehnic',e(op.technical_admin||'—'))}${detail('Responsabil',e(op.business_owner||'—'))}${detail('Documentație',documentLink)}${detail('Referință tichet',e(op.ticket_reference||'—'))}</div>`) }
  ${panel('Date operaționale',`<form id="operationalForm" class="operational-form">
    <div class="form-section"><h3>Încadrare serviciu</h3><div class="form-grid"><label>Serviciu<input id="opService" value="${e(op.service_name||'')}" placeholder="Ex. Servicii GIS"></label><label>Componentă<input id="opComponent" value="${e(op.component_name||'')}" placeholder="Ex. GeoServer"></label><label>Domeniu arhitectural<input id="opDomain" value="${e(op.architectural_domain||'')}"></label><label>Layer<input id="opLayer" value="${e(op.layer_name||'')}" placeholder="Web / App / DB"></label><label>Mediu<input id="opEnvironment" value="${e(op.environment||'')}" placeholder="Producție / Test"></label><label>Status operațional<input id="opStatus" value="${e(op.operational_status||'')}" placeholder="Activ / Mentenanță"></label></div><label>Scopul VM-ului<textarea id="opPurpose" rows="3">${e(op.purpose||'')}</textarea></label></div>
    <div class="form-section"><h3>Responsabilități</h3><div class="form-grid"><label>Administrator tehnic<input id="opTechnicalAdmin" value="${e(op.technical_admin||'')}"></label><label>Responsabil serviciu<input id="opBusinessOwner" value="${e(op.business_owner||'')}"></label><label>Email responsabil<input id="opOwnerEmail" type="email" value="${e(op.owner_email||'')}"></label></div></div>
    <div class="form-section"><h3>Provisionare și continuitate</h3><div class="form-grid"><label>Profil provisionare<input id="opProfile" value="${e(op.provisioning_profile||'')}"></label><label>Data provisionării<input id="opProvisionedAt" type="date" value="${e(op.provisioned_at||'')}"></label><label>Politică backup<input id="opBackup" value="${e(op.backup_policy||'')}"></label><label>RPO (minute)<input id="opRPO" type="number" min="0" value="${op.rpo_minutes??''}"></label><label>RTO (minute)<input id="opRTO" type="number" min="0" value="${op.rto_minutes??''}"></label><label>Clasificare<input id="opClassification" value="${e(op.classification||'')}"></label></div></div>
    <div class="form-section"><h3>Referințe și observații</h3><div class="form-grid"><label class="span-2">URL documentație<input id="opDocumentation" type="url" value="${e(op.documentation_url||'')}" placeholder="https://..."></label><label>Referință tichet<input id="opTicket" value="${e(op.ticket_reference||'')}"></label></div><label>Observații<textarea id="opNotes" rows="4">${e(op.notes||'')}</textarea></label></div>
    ${can('vms.manage')?'<div class="form-actions"><button type="submit">Salvează datele operaționale</button></div>':'<div class="muted form-actions">Nu ai permisiunea de modificare.</div>'}
  </form>`) }
  ${panel('Date colectate de agent',structuredInventory(documentView),v.id&&can('inventories.raw.read')?'<button id="latestRaw" class="secondary">Vezi JSON brut</button>':'')}
  ${panel('Date vCenter',`<div class="detail-grid">${detail('Sursă',e(vm.vcenter_source_name))}${detail('MoID',e(vm.vcenter_moid),true)}${detail('BIOS UUID',e(vm.bios_uuid||'—'),true)}${detail('Instance UUID',e(vm.instance_uuid||'—'),true)}${detail('CPU',e(vm.cpu_count))}${detail('RAM',memory(vm.memory_mib))}${detail('Hardware',e(vm.hardware_version||'—'))}${detail('Ultima vedere',dt(vm.last_seen_at))}${detail('Guest hostname',e(vm.guest_hostname||'—'))}${detail('Guest OS',e(vm.guest_os||'—'))}${detail('IP vCenter',e(vm.primary_ip||'—'),true)}${detail('Prezentă în vCenter',boolText(vm.present_in_vcenter))}</div>`) }
  ${panel('Lifecycle și asociere agent',`<form id="vmManageForm" class="detail-grid"><label><span>Retired</span><select id="vmRetired"><option value="false" ${!vm.retired?'selected':''}>Nu</option><option value="true" ${vm.retired?'selected':''}>Da</option></select></label><label class="span-2"><span>Notă retired</span><input id="vmRetiredNote" value="${e(vm.retired_note||'')}" placeholder="Motiv / tichet / dată"></label><label><span>Agent asociat</span><select id="vmAgent">${agentOptions}</select></label>${can('vms.manage')?'<label class="form-submit"><button type="submit">Salvează</button></label>':''}</form>`,can('collections.run')&&vm.agent_id?'<button id="testVMAgent" class="secondary">Testează agentul</button><button id="collectVM">Colectează acum</button>':'')}
  ${panel('Rezumat ultimul inventar',v.id?`<div class="detail-grid">${detail('Hostname',e(v.hostname||'—'))}${detail('FQDN',e(v.fqdn||'—'))}${detail('Agent',`${e(v.agent_version||'—')} · ${e(v.agent_uuid||'—')}`,true)}${detail('Product UUID',e(v.product_uuid||'—'),true)}${detail('OS',`${e(v.os_name||'—')} ${e(v.os_version||'')}`)}${detail('IP',e(v.primary_ip||'—'),true)}${detail('Colectori OK',`${v.collector_ok}/${v.collector_total}`)}${detail('Primit',dt(v.received_at))}</div>`:empty('Agentul nu a furnizat încă un inventar.'))}
  ${panel('Istoric inventare',historyRows?`<div class="table-wrap"><table><thead><tr><th>Primit</th><th>Hostname</th><th>OS</th><th>Colectori</th><th>Schimbare</th><th></th></tr></thead><tbody>${historyRows}</tbody></table></div>`:empty('Nu există snapshoturi pentru această VM.'))}<section id="rawPanel"></section>`;

  document.getElementById('operationalForm')?.addEventListener('submit',async ev=>{ev.preventDefault();if(!can('vms.manage'))return;const body={service_name:document.getElementById('opService').value.trim(),component_name:document.getElementById('opComponent').value.trim(),architectural_domain:document.getElementById('opDomain').value.trim(),layer_name:document.getElementById('opLayer').value.trim(),environment:document.getElementById('opEnvironment').value.trim(),operational_status:document.getElementById('opStatus').value.trim(),purpose:document.getElementById('opPurpose').value.trim(),technical_admin:document.getElementById('opTechnicalAdmin').value.trim(),business_owner:document.getElementById('opBusinessOwner').value.trim(),owner_email:document.getElementById('opOwnerEmail').value.trim(),provisioning_profile:document.getElementById('opProfile').value.trim(),provisioned_at:document.getElementById('opProvisionedAt').value,backup_policy:document.getElementById('opBackup').value.trim(),rpo_minutes:optionalNumber('opRPO'),rto_minutes:optionalNumber('opRTO'),classification:document.getElementById('opClassification').value.trim(),documentation_url:document.getElementById('opDocumentation').value.trim(),ticket_reference:document.getElementById('opTicket').value.trim(),notes:document.getElementById('opNotes').value.trim()};try{await api(`/api/v1/vms/${id}/operational`,{method:'PUT',body:JSON.stringify(body)});toast('Datele operaționale au fost salvate.');vmDetail(id)}catch(err){toast(err.message,true)}});
  document.getElementById('vmManageForm')?.addEventListener('submit',async ev=>{ev.preventDefault();if(!can('vms.manage'))return;const selected=document.getElementById('vmAgent').value;const body={retired:document.getElementById('vmRetired').value==='true',retired_note:document.getElementById('vmRetiredNote').value.trim()};if(selected)body.agent_id=Number(selected);else if(vm.agent_id)body.clear_agent=true;try{await api(`/api/v1/vms/${id}`,{method:'PATCH',body:JSON.stringify(body)});toast('VM actualizată.');vmDetail(id)}catch(err){toast(err.message,true)}});
  document.getElementById('testVMAgent')?.addEventListener('click',()=>vmJob(id,'test-agent'));
  document.getElementById('collectVM')?.addEventListener('click',()=>vmJob(id,'collect'));
  document.getElementById('latestRaw')?.addEventListener('click',async()=>{try{const raw=await api(`/api/v1/inventories/${v.id}/raw`);document.getElementById('rawPanel').innerHTML=panel(`JSON inventar #${v.id}`,jsonSections(raw));document.getElementById('rawPanel').scrollIntoView({behavior:'smooth'})}catch(err){toast(err.message,true)}});
  content.querySelectorAll('.show-raw').forEach(b=>b.onclick=async()=>{try{const raw=await api(`/api/v1/inventories/${b.dataset.id}/raw`);document.getElementById('rawPanel').innerHTML=panel(`JSON inventar #${b.dataset.id}`,jsonSections(raw));document.getElementById('rawPanel').scrollIntoView({behavior:'smooth'})}catch(err){toast(err.message,true)}});
}
async function vmJob(id,action){try{const job=await api(`/api/v1/vms/${id}/${action}`,{method:'POST'});toast(`Job ${job.id} introdus în coadă.`);setTimeout(()=>vmDetail(id),1200)}catch(err){toast(err.message,true)}}

async function auditPage(){pageMeta('Audit','Acțiuni administrative și operaționale');const rows=await api('/api/v1/audit/events');content.innerHTML=panel('Evenimente recente',rows.length?`<div class="table-wrap"><table><thead><tr><th>Data</th><th>Sursă</th><th>Actor</th><th>Acțiune</th><th>Resursă</th><th>Rezultat</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${dt(r.occurred_at)}</td><td>${e(r.source)}</td><td>${e(r.actor_username||'sistem')}</td><td class="mono">${e(r.action)}</td><td>${e(r.resource_type)} ${e(r.resource_id)}</td><td>${badge(r.outcome)}</td></tr>`).join('')}</tbody></table></div>`:empty('Nu există evenimente de audit.'))}

async function accessPage(){pageMeta('Acces','Mapări grupuri LDAP/OIDC către roluri');const [roles,maps]=await Promise.all([api('/api/v1/rbac/roles'),api('/api/v1/rbac/group-mappings')]);content.innerHTML=`${panel('Adaugă mapare',`<form id="mappingForm" class="detail-grid"><label>Provider<select id="mapProvider"><option value="ldap">LDAP</option><option value="oidc">OIDC</option><option value="any">Oricare</option></select></label><label>Grup<input id="mapGroup" required placeholder="VM-DOC-Operators"></label><label>Rol<select id="mapRole">${roles.map(r=>`<option value="${e(r.name)}">${e(r.name)}</option>`).join('')}</select></label><label class="form-submit"><button type="submit">Adaugă</button></label></form>`)}${panel('Mapări existente',maps.length?`<div class="table-wrap"><table><thead><tr><th>Provider</th><th>Grup</th><th>Rol</th><th></th></tr></thead><tbody>${maps.map(m=>`<tr><td>${e(m.provider)}</td><td class="mono">${e(m.group_name)}</td><td>${badge(m.role)}</td><td><button class="small danger del-map" data-id="${m.id}">Șterge</button></td></tr>`).join('')}</tbody></table></div>`:empty('Nu există mapări.'))}`;
  document.getElementById('mappingForm').onsubmit=async ev=>{ev.preventDefault();await api('/api/v1/rbac/group-mappings',{method:'POST',body:JSON.stringify({provider:document.getElementById('mapProvider').value,group_name:document.getElementById('mapGroup').value.trim(),role:document.getElementById('mapRole').value})});toast('Mapare creată.');accessPage()};content.querySelectorAll('.del-map').forEach(b=>b.onclick=async()=>{await api(`/api/v1/rbac/group-mappings/${b.dataset.id}`,{method:'DELETE'});toast('Mapare ștearsă.');accessPage()})
}

document.getElementById('logoutButton').onclick=async()=>{await api('/api/v1/auth/logout',{method:'POST'});location.href='/login'};
document.getElementById('themeButton').onclick=()=>{const next=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=next;localStorage.setItem('vm-doc-theme',next)};
const savedTheme=localStorage.getItem('vm-doc-theme');if(savedTheme)document.documentElement.dataset.theme=savedTheme;
window.addEventListener('hashchange',route);
document.querySelectorAll('[data-close-dialog]').forEach(button=>button.addEventListener('click',()=>button.closest('dialog').close()));
init();

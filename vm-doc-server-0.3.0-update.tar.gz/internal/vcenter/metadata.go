package vcenter

import (
	"context"
	"database/sql"
	"errors"
	"net/mail"
	"net/url"
	"strings"
	"time"

	"vm-doc-server/internal/domain"
)

type OperationalMetadataInput struct {
	ServiceName         string `json:"service_name"`
	ComponentName       string `json:"component_name"`
	ArchitecturalDomain string `json:"architectural_domain"`
	LayerName           string `json:"layer_name"`
	Environment         string `json:"environment"`
	OperationalStatus   string `json:"operational_status"`
	Purpose             string `json:"purpose"`
	TechnicalAdmin      string `json:"technical_admin"`
	BusinessOwner       string `json:"business_owner"`
	OwnerEmail          string `json:"owner_email"`
	ProvisioningProfile string `json:"provisioning_profile"`
	ProvisionedAt       string `json:"provisioned_at"`
	RPOMinutes          *int   `json:"rpo_minutes"`
	RTOMinutes          *int   `json:"rto_minutes"`
	BackupPolicy        string `json:"backup_policy"`
	Classification      string `json:"classification"`
	DocumentationURL    string `json:"documentation_url"`
	TicketReference     string `json:"ticket_reference"`
	Notes               string `json:"notes"`
}

func (s *Service) GetOperationalMetadata(ctx context.Context, vmID int64) (domain.VMOperationalMetadata, error) {
	var value domain.VMOperationalMetadata
	var provisionedAt sql.NullTime
	var rpo, rto, updatedBy sql.NullInt64
	err := s.DB.QueryRowContext(ctx, `SELECT vm_id,service_name,component_name,architectural_domain,layer_name,environment,operational_status,purpose,technical_admin,business_owner,owner_email,provisioning_profile,provisioned_at,rpo_minutes,rto_minutes,backup_policy,classification,documentation_url,ticket_reference,notes,updated_by,created_at,updated_at FROM vm_operational_metadata WHERE vm_id=?`, vmID).Scan(
		&value.VMID, &value.ServiceName, &value.ComponentName, &value.ArchitecturalDomain, &value.LayerName, &value.Environment, &value.OperationalStatus, &value.Purpose, &value.TechnicalAdmin, &value.BusinessOwner, &value.OwnerEmail, &value.ProvisioningProfile, &provisionedAt, &rpo, &rto, &value.BackupPolicy, &value.Classification, &value.DocumentationURL, &value.TicketReference, &value.Notes, &updatedBy, &value.CreatedAt, &value.UpdatedAt,
	)
	if errors.Is(err, sql.ErrNoRows) {
		value.VMID = vmID
		return value, nil
	}
	if err != nil {
		return value, err
	}
	if provisionedAt.Valid {
		value.ProvisionedAt = provisionedAt.Time.Format("2006-01-02")
	}
	if rpo.Valid {
		n := int(rpo.Int64)
		value.RPOMinutes = &n
	}
	if rto.Valid {
		n := int(rto.Int64)
		value.RTOMinutes = &n
	}
	if updatedBy.Valid {
		n := updatedBy.Int64
		value.UpdatedBy = &n
	}
	return value, nil
}

func (s *Service) SaveOperationalMetadata(ctx context.Context, vmID, userID int64, input OperationalMetadataInput) (domain.VMOperationalMetadata, error) {
	if err := normalizeOperationalMetadata(&input); err != nil {
		return domain.VMOperationalMetadata{}, err
	}
	var vmExists int
	if err := s.DB.QueryRowContext(ctx, `SELECT 1 FROM virtual_machines WHERE id=?`, vmID).Scan(&vmExists); err != nil {
		return domain.VMOperationalMetadata{}, err
	}
	var provisionedAt any
	if input.ProvisionedAt != "" {
		parsed, _ := time.Parse("2006-01-02", input.ProvisionedAt)
		provisionedAt = parsed
	}
	_, err := s.DB.ExecContext(ctx, `INSERT INTO vm_operational_metadata(vm_id,service_name,component_name,architectural_domain,layer_name,environment,operational_status,purpose,technical_admin,business_owner,owner_email,provisioning_profile,provisioned_at,rpo_minutes,rto_minutes,backup_policy,classification,documentation_url,ticket_reference,notes,updated_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE service_name=VALUES(service_name),component_name=VALUES(component_name),architectural_domain=VALUES(architectural_domain),layer_name=VALUES(layer_name),environment=VALUES(environment),operational_status=VALUES(operational_status),purpose=VALUES(purpose),technical_admin=VALUES(technical_admin),business_owner=VALUES(business_owner),owner_email=VALUES(owner_email),provisioning_profile=VALUES(provisioning_profile),provisioned_at=VALUES(provisioned_at),rpo_minutes=VALUES(rpo_minutes),rto_minutes=VALUES(rto_minutes),backup_policy=VALUES(backup_policy),classification=VALUES(classification),documentation_url=VALUES(documentation_url),ticket_reference=VALUES(ticket_reference),notes=VALUES(notes),updated_by=VALUES(updated_by)`,
		vmID, input.ServiceName, input.ComponentName, input.ArchitecturalDomain, input.LayerName, input.Environment, input.OperationalStatus, input.Purpose, input.TechnicalAdmin, input.BusinessOwner, input.OwnerEmail, input.ProvisioningProfile, provisionedAt, nullableInt(input.RPOMinutes), nullableInt(input.RTOMinutes), input.BackupPolicy, input.Classification, input.DocumentationURL, input.TicketReference, input.Notes, userID,
	)
	if err != nil {
		return domain.VMOperationalMetadata{}, err
	}
	return s.GetOperationalMetadata(ctx, vmID)
}

func normalizeOperationalMetadata(input *OperationalMetadataInput) error {
	input.ServiceName = strings.TrimSpace(input.ServiceName)
	input.ComponentName = strings.TrimSpace(input.ComponentName)
	input.ArchitecturalDomain = strings.TrimSpace(input.ArchitecturalDomain)
	input.LayerName = strings.TrimSpace(input.LayerName)
	input.Environment = strings.TrimSpace(input.Environment)
	input.OperationalStatus = strings.TrimSpace(input.OperationalStatus)
	input.Purpose = strings.TrimSpace(input.Purpose)
	input.TechnicalAdmin = strings.TrimSpace(input.TechnicalAdmin)
	input.BusinessOwner = strings.TrimSpace(input.BusinessOwner)
	input.OwnerEmail = strings.TrimSpace(input.OwnerEmail)
	input.ProvisioningProfile = strings.TrimSpace(input.ProvisioningProfile)
	input.ProvisionedAt = strings.TrimSpace(input.ProvisionedAt)
	input.BackupPolicy = strings.TrimSpace(input.BackupPolicy)
	input.Classification = strings.TrimSpace(input.Classification)
	input.DocumentationURL = strings.TrimSpace(input.DocumentationURL)
	input.TicketReference = strings.TrimSpace(input.TicketReference)
	input.Notes = strings.TrimSpace(input.Notes)

	if input.ProvisionedAt != "" {
		if _, err := time.Parse("2006-01-02", input.ProvisionedAt); err != nil {
			return errors.New("provisioned_at must use YYYY-MM-DD")
		}
	}
	for _, item := range []*int{input.RPOMinutes, input.RTOMinutes} {
		if item != nil && (*item < 0 || *item > 5256000) {
			return errors.New("RPO/RTO must be between 0 and 5256000 minutes")
		}
	}
	if input.OwnerEmail != "" {
		address, err := mail.ParseAddress(input.OwnerEmail)
		if err != nil || address.Address != input.OwnerEmail {
			return errors.New("owner_email is invalid")
		}
	}
	if input.DocumentationURL != "" {
		parsed, err := url.ParseRequestURI(input.DocumentationURL)
		if err != nil || (parsed.Scheme != "http" && parsed.Scheme != "https") || parsed.Host == "" {
			return errors.New("documentation_url must be an absolute HTTP or HTTPS URL")
		}
	}
	limits := []struct {
		name  string
		value string
		max   int
	}{
		{"service_name", input.ServiceName, 255}, {"component_name", input.ComponentName, 255}, {"architectural_domain", input.ArchitecturalDomain, 255},
		{"layer_name", input.LayerName, 128}, {"environment", input.Environment, 64}, {"operational_status", input.OperationalStatus, 64},
		{"technical_admin", input.TechnicalAdmin, 255}, {"business_owner", input.BusinessOwner, 255}, {"owner_email", input.OwnerEmail, 255},
		{"provisioning_profile", input.ProvisioningProfile, 255}, {"backup_policy", input.BackupPolicy, 255}, {"classification", input.Classification, 128},
		{"documentation_url", input.DocumentationURL, 1024}, {"ticket_reference", input.TicketReference, 255},
	}
	for _, limit := range limits {
		if len([]rune(limit.value)) > limit.max {
			return errors.New(limit.name + " is too long")
		}
	}
	return nil
}

func nullableInt(value *int) any {
	if value == nil {
		return nil
	}
	return *value
}

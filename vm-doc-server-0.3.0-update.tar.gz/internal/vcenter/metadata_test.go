package vcenter

import "testing"

func TestNormalizeOperationalMetadata(t *testing.T) {
	rpo := 60
	input := OperationalMetadataInput{
		ServiceName:      "  Mail  ",
		OwnerEmail:       "owner@example.test",
		ProvisionedAt:    "2026-08-31",
		RPOMinutes:       &rpo,
		DocumentationURL: "https://docs.example.test/vm/1",
	}
	if err := normalizeOperationalMetadata(&input); err != nil {
		t.Fatal(err)
	}
	if input.ServiceName != "Mail" {
		t.Fatalf("service name was not trimmed: %q", input.ServiceName)
	}
}

func TestNormalizeOperationalMetadataRejectsInvalidValues(t *testing.T) {
	invalidRPO := -1
	cases := []OperationalMetadataInput{
		{ProvisionedAt: "31-08-2026"},
		{OwnerEmail: "not-an-email"},
		{DocumentationURL: "file:///tmp/doc"},
		{RPOMinutes: &invalidRPO},
	}
	for index := range cases {
		if err := normalizeOperationalMetadata(&cases[index]); err == nil {
			t.Fatalf("case %d should fail", index)
		}
	}
}

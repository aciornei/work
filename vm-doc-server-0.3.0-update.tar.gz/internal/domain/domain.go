package domain

import (
	"encoding/json"
	"time"
)

type User struct {
	ID          int64    `json:"id"`
	Username    string   `json:"username"`
	DisplayName string   `json:"display_name"`
	Email       string   `json:"email"`
	Source      string   `json:"source"`
	Groups      []string `json:"groups"`
	Roles       []string `json:"roles"`
	CSRFToken   string   `json:"csrf_token,omitempty"`
}

type Agent struct {
	ID                        int64      `json:"id"`
	SecretRef                 string     `json:"-"`
	Name                      string     `json:"name"`
	BaseURL                   string     `json:"base_url"`
	Enabled                   bool       `json:"enabled"`
	VerifyTLS                 bool       `json:"verify_tls"`
	TLSServerName             string     `json:"tls_server_name,omitempty"`
	TokenConfigured           bool       `json:"token_configured"`
	AgentUUID                 string     `json:"agent_uuid,omitempty"`
	CollectionIntervalSeconds int        `json:"collection_interval_seconds"`
	RequestTimeoutSeconds     int        `json:"request_timeout_seconds"`
	OfflineAfterSeconds       int        `json:"offline_after_seconds"`
	NextCollectionAt          *time.Time `json:"next_collection_at,omitempty"`
	LastAttemptAt             *time.Time `json:"last_attempt_at,omitempty"`
	LastContactAt             *time.Time `json:"last_contact_at,omitempty"`
	LastSuccessAt             *time.Time `json:"last_success_at,omitempty"`
	LastError                 string     `json:"last_error,omitempty"`
	CurrentInventoryID        *int64     `json:"current_inventory_id,omitempty"`
	Status                    string     `json:"status"`
	CreatedAt                 time.Time  `json:"created_at"`
	UpdatedAt                 time.Time  `json:"updated_at"`
}

type Job struct {
	ID           int64      `json:"id"`
	AgentID      int64      `json:"agent_id"`
	Kind         string     `json:"kind"`
	Source       string     `json:"source"`
	Status       string     `json:"status"`
	RequestedBy  *int64     `json:"requested_by_user_id,omitempty"`
	ScheduledAt  time.Time  `json:"scheduled_at"`
	StartedAt    *time.Time `json:"started_at,omitempty"`
	FinishedAt   *time.Time `json:"finished_at,omitempty"`
	AttemptCount int        `json:"attempt_count"`
	HTTPStatus   *int       `json:"http_status,omitempty"`
	DurationMS   *int64     `json:"duration_ms,omitempty"`
	ErrorCode    string     `json:"error_code,omitempty"`
	ErrorMessage string     `json:"error_message,omitempty"`
	CreatedAt    time.Time  `json:"created_at"`
}

type Inventory struct {
	ID                  int64      `json:"id"`
	AgentID             int64      `json:"agent_id"`
	CollectionJobID     int64      `json:"collection_job_id"`
	SchemaVersion       string     `json:"schema_version"`
	AgentUUID           string     `json:"agent_uuid"`
	AgentVersion        string     `json:"agent_version,omitempty"`
	Hostname            string     `json:"hostname"`
	FQDN                string     `json:"fqdn,omitempty"`
	ProductUUID         string     `json:"product_uuid,omitempty"`
	ProductUUIDLegacy   string     `json:"product_uuid_legacy,omitempty"`
	MachineID           string     `json:"machine_id,omitempty"`
	OSName              string     `json:"os_name"`
	OSVersion           string     `json:"os_version"`
	PrimaryIP           string     `json:"primary_ip"`
	BootTime            *time.Time `json:"boot_time,omitempty"`
	CollectorTotal      int        `json:"collector_total"`
	CollectorOK         int        `json:"collector_ok"`
	CollectorError      int        `json:"collector_error"`
	CollectorTimeout    int        `json:"collector_timeout"`
	PayloadSize         int64      `json:"payload_size"`
	PayloadSHA256       string     `json:"payload_sha256"`
	ChangedFromPrevious bool       `json:"changed_from_previous"`
	RawJSON             []byte     `json:"raw_json,omitempty"`
	CollectedAt         *time.Time `json:"collected_at,omitempty"`
	ReceivedAt          time.Time  `json:"received_at"`
}

type VCenterSource struct {
	ID                 int64      `json:"id"`
	SecretRef          string     `json:"-"`
	Name               string     `json:"name"`
	BaseURL            string     `json:"base_url"`
	Username           string     `json:"username"`
	Enabled            bool       `json:"enabled"`
	VerifyTLS          bool       `json:"verify_tls"`
	TLSServerName      string     `json:"tls_server_name,omitempty"`
	PasswordConfigured bool       `json:"password_configured"`
	DailySyncEnabled   bool       `json:"daily_sync_enabled"`
	DailySyncTime      string     `json:"daily_sync_time"`
	LastSyncAt         *time.Time `json:"last_sync_at,omitempty"`
	LastSuccessAt      *time.Time `json:"last_success_at,omitempty"`
	LastError          string     `json:"last_error,omitempty"`
	CreatedAt          time.Time  `json:"created_at"`
	UpdatedAt          time.Time  `json:"updated_at"`
}

type VCenterSyncRun struct {
	ID                int64      `json:"id"`
	VCenterSourceID   int64      `json:"vcenter_source_id"`
	VCenterSourceName string     `json:"vcenter_source_name,omitempty"`
	Source            string     `json:"source"`
	Status            string     `json:"status"`
	RequestedByUserID *int64     `json:"requested_by_user_id,omitempty"`
	StartedAt         *time.Time `json:"started_at,omitempty"`
	FinishedAt        *time.Time `json:"finished_at,omitempty"`
	FoundCount        int        `json:"found_count"`
	CreatedCount      int        `json:"created_count"`
	UpdatedCount      int        `json:"updated_count"`
	MissingCount      int        `json:"missing_count"`
	LinkedAgentCount  int        `json:"linked_agent_count"`
	ErrorMessage      string     `json:"error_message,omitempty"`
	CreatedAt         time.Time  `json:"created_at"`
}

type VirtualMachine struct {
	ID                   int64           `json:"id"`
	VCenterSourceID      int64           `json:"vcenter_source_id"`
	VCenterSourceName    string          `json:"vcenter_source_name"`
	VCenterMoID          string          `json:"vcenter_moid"`
	InstanceUUID         string          `json:"instance_uuid,omitempty"`
	BIOSUUID             string          `json:"bios_uuid,omitempty"`
	Name                 string          `json:"name"`
	PowerState           string          `json:"power_state,omitempty"`
	CPUCount             int             `json:"cpu_count"`
	MemoryMiB            int64           `json:"memory_mib"`
	HardwareVersion      string          `json:"hardware_version,omitempty"`
	GuestOS              string          `json:"guest_os,omitempty"`
	GuestHostname        string          `json:"guest_hostname,omitempty"`
	PrimaryIP            string          `json:"primary_ip,omitempty"`
	CustomAttributesJSON json.RawMessage `json:"custom_attributes,omitempty"`
	Retired              bool            `json:"retired"`
	RetiredAt            *time.Time      `json:"retired_at,omitempty"`
	RetiredBy            *int64          `json:"retired_by,omitempty"`
	RetiredNote          string          `json:"retired_note,omitempty"`
	PresentInVCenter     bool            `json:"present_in_vcenter"`
	FirstSeenAt          time.Time       `json:"first_seen_at"`
	LastSeenAt           time.Time       `json:"last_seen_at"`
	MissingSince         *time.Time      `json:"missing_since,omitempty"`
	LastVCenterSyncAt    *time.Time      `json:"last_vcenter_sync_at,omitempty"`
	AgentID              *int64          `json:"agent_id,omitempty"`
	AgentName            string          `json:"agent_name,omitempty"`
	AgentStatus          string          `json:"agent_status"`
	AgentLastContactAt   *time.Time      `json:"agent_last_contact_at,omitempty"`
	AgentLastSuccessAt   *time.Time      `json:"agent_last_success_at,omitempty"`
	AgentLastError       string          `json:"agent_last_error,omitempty"`
	CurrentInventoryID   *int64          `json:"current_inventory_id,omitempty"`
	InventoryHostname    string          `json:"inventory_hostname,omitempty"`
	InventoryOSName      string          `json:"inventory_os_name,omitempty"`
	InventoryOSVersion   string          `json:"inventory_os_version,omitempty"`
	InventoryPrimaryIP   string          `json:"inventory_primary_ip,omitempty"`
	InventoryReceivedAt  *time.Time      `json:"inventory_received_at,omitempty"`
	CreatedAt            time.Time       `json:"created_at"`
	UpdatedAt            time.Time       `json:"updated_at"`
}

type VMOperationalMetadata struct {
	VMID                int64     `json:"vm_id"`
	ServiceName         string    `json:"service_name"`
	ComponentName       string    `json:"component_name"`
	ArchitecturalDomain string    `json:"architectural_domain"`
	LayerName           string    `json:"layer_name"`
	Environment         string    `json:"environment"`
	OperationalStatus   string    `json:"operational_status"`
	Purpose             string    `json:"purpose"`
	TechnicalAdmin      string    `json:"technical_admin"`
	BusinessOwner       string    `json:"business_owner"`
	OwnerEmail          string    `json:"owner_email"`
	ProvisioningProfile string    `json:"provisioning_profile"`
	ProvisionedAt       string    `json:"provisioned_at,omitempty"`
	RPOMinutes          *int      `json:"rpo_minutes,omitempty"`
	RTOMinutes          *int      `json:"rto_minutes,omitempty"`
	BackupPolicy        string    `json:"backup_policy"`
	Classification      string    `json:"classification"`
	DocumentationURL    string    `json:"documentation_url"`
	TicketReference     string    `json:"ticket_reference"`
	Notes               string    `json:"notes"`
	UpdatedBy           *int64    `json:"updated_by,omitempty"`
	CreatedAt           time.Time `json:"created_at"`
	UpdatedAt           time.Time `json:"updated_at"`
}

package inventory

import "testing"

func TestBuildDocumentViewOrdersAndRedacts(t *testing.T) {
	raw := []byte(`{"network":{"primary_ip":"10.0.0.1","api_token":"abc","bind_password_file":"/etc/secret"},"identity":{"hostname":"vm01"},"generated_at":"2026-08-31T10:00:00Z"}`)
	view, err := BuildDocumentView(raw)
	if err != nil {
		t.Fatal(err)
	}
	if len(view.Sections) != 2 || view.Sections[0].Key != "identity" || view.Sections[1].Key != "network" {
		t.Fatalf("unexpected sections: %#v", view.Sections)
	}
	network := view.Sections[1].Data.(map[string]any)
	if network["api_token"] != "[redactat]" || network["bind_password_file"] != "[redactat]" {
		t.Fatalf("secret was not redacted: %#v", network)
	}
}

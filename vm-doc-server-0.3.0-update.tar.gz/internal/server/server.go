package server

import (
	"bytes"
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"log/slog"
	"net"
	"net/http"
	"strconv"
	"strings"
	"time"

	swgui "github.com/swaggest/swgui/v5emb"
	"vm-doc-server/internal/agents"
	"vm-doc-server/internal/audit"
	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/collection"
	"vm-doc-server/internal/config"
	"vm-doc-server/internal/cryptox"
	"vm-doc-server/internal/database"
	"vm-doc-server/internal/domain"
	"vm-doc-server/internal/inventory"
	"vm-doc-server/internal/rbac"
	"vm-doc-server/internal/registration"
	"vm-doc-server/internal/vcenter"
	"vm-doc-server/internal/xlsx"
	openapifs "vm-doc-server/openapi"
	webfs "vm-doc-server/web"
)

type App struct {
	Config       config.Config
	DB           *sql.DB
	Auth         *auth.Service
	Agents       agents.Service
	Collection   *collection.Service
	Inventory    inventory.Service
	VCenter      *vcenter.Service
	Registration *registration.Service
	Audit        audit.Service
	Logger       *slog.Logger
	Version      string
}

func (a *App) Handler() (http.Handler, error) {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /healthz", func(w http.ResponseWriter, _ *http.Request) { jsonResponse(w, 200, map[string]any{"status": "ok"}) })
	mux.HandleFunc("GET /readyz", a.ready)
	mux.HandleFunc("GET /version", func(w http.ResponseWriter, _ *http.Request) {
		jsonResponse(w, 200, map[string]any{"version": a.Version})
	})
	mux.HandleFunc("GET /api/v1/auth/providers", a.Auth.Providers)
	mux.HandleFunc("POST /api/v1/auth/ldap/login", a.Auth.LDAPLogin)
	mux.HandleFunc("GET /api/v1/auth/oidc/start", a.Auth.OIDCStart)
	mux.HandleFunc("GET /api/v1/auth/oidc/callback", a.Auth.OIDCCallback)
	mux.Handle("GET /api/v1/auth/me", a.protected("", http.HandlerFunc(a.Auth.Me)))
	mux.Handle("POST /api/v1/auth/logout", a.protected("", a.Auth.RequireCSRF(http.HandlerFunc(a.Auth.Logout))))

	if a.Registration != nil {
		mux.Handle("POST /api/v1/agent-registration/register", a.agentRegistrationAuth(http.HandlerFunc(a.registerAgent)))
		mux.Handle("POST /api/v1/agent-registration/heartbeat", a.agentRegistrationAuth(http.HandlerFunc(a.agentHeartbeat)))
		mux.Handle("POST /api/v1/agent-registration/inventory", a.agentRegistrationAuth(http.HandlerFunc(a.agentInventoryPush)))
	}

	mux.Handle("GET /api/v1/dashboard", a.protected("dashboard.read", http.HandlerFunc(a.dashboard)))
	mux.Handle("GET /api/v1/agents", a.protected("agents.read", http.HandlerFunc(a.listAgents)))
	mux.Handle("POST /api/v1/agents", a.protectedMutation("agents.manage", http.HandlerFunc(a.createAgent)))
	mux.Handle("GET /api/v1/agents/{id}", a.protected("agents.read", http.HandlerFunc(a.getAgent)))
	mux.Handle("PATCH /api/v1/agents/{id}", a.protectedMutation("agents.manage", http.HandlerFunc(a.updateAgent)))
	mux.Handle("DELETE /api/v1/agents/{id}", a.protectedMutation("agents.manage", http.HandlerFunc(a.deleteAgent)))
	mux.Handle("POST /api/v1/agents/{id}/test", a.protectedMutation("collections.run", http.HandlerFunc(a.queueTest)))
	mux.Handle("POST /api/v1/agents/{id}/collect", a.protectedMutation("collections.run", http.HandlerFunc(a.queueCollect)))
	mux.Handle("GET /api/v1/agents/{id}/jobs", a.protected("collections.read", http.HandlerFunc(a.agentJobs)))
	mux.Handle("GET /api/v1/jobs/{id}", a.protected("collections.read", http.HandlerFunc(a.getJob)))

	mux.Handle("GET /api/v1/vms", a.protected("inventories.read", http.HandlerFunc(a.listVMs)))
	mux.Handle("GET /api/v1/vms/export", a.protected("inventories.read", http.HandlerFunc(a.exportVMs)))
	mux.Handle("GET /api/v1/vms/{id}", a.protected("inventories.read", http.HandlerFunc(a.getVM)))
	mux.Handle("PATCH /api/v1/vms/{id}", a.protectedMutation("vms.manage", http.HandlerFunc(a.updateVM)))
	mux.Handle("PUT /api/v1/vms/{id}/operational", a.protectedMutation("vms.manage", http.HandlerFunc(a.updateVMOperational)))
	mux.Handle("POST /api/v1/vms/{id}/test-agent", a.protectedMutation("collections.run", http.HandlerFunc(a.testVMAgent)))
	mux.Handle("POST /api/v1/vms/{id}/collect", a.protectedMutation("collections.run", http.HandlerFunc(a.collectVM)))
	mux.Handle("GET /api/v1/vms/{id}/inventories", a.protected("inventories.read", http.HandlerFunc(a.inventoryHistory)))

	mux.Handle("GET /api/v1/vcenter/sources", a.protected("vcenter.read", http.HandlerFunc(a.listVCenterSources)))
	mux.Handle("POST /api/v1/vcenter/sources", a.protectedMutation("vcenter.manage", http.HandlerFunc(a.createVCenterSource)))
	mux.Handle("GET /api/v1/vcenter/sources/{id}", a.protected("vcenter.read", http.HandlerFunc(a.getVCenterSource)))
	mux.Handle("PATCH /api/v1/vcenter/sources/{id}", a.protectedMutation("vcenter.manage", http.HandlerFunc(a.updateVCenterSource)))
	mux.Handle("DELETE /api/v1/vcenter/sources/{id}", a.protectedMutation("vcenter.manage", http.HandlerFunc(a.deleteVCenterSource)))
	mux.Handle("POST /api/v1/vcenter/sources/{id}/test", a.protectedMutation("vcenter.manage", http.HandlerFunc(a.testVCenterSource)))
	mux.Handle("POST /api/v1/vcenter/sources/{id}/sync", a.protectedMutation("vcenter.manage", http.HandlerFunc(a.syncVCenterSource)))
	mux.Handle("POST /api/v1/vcenter/sync", a.protectedMutation("vcenter.manage", http.HandlerFunc(a.syncAllVCenters)))
	mux.Handle("GET /api/v1/vcenter/sync-runs", a.protected("vcenter.read", http.HandlerFunc(a.listVCenterRuns)))
	mux.Handle("GET /api/v1/inventories/{id}", a.protected("inventories.read", http.HandlerFunc(a.getInventory)))
	mux.Handle("GET /api/v1/inventories/{id}/raw", a.protected("inventories.raw.read", http.HandlerFunc(a.getInventoryRaw)))

	mux.Handle("GET /api/v1/audit/events", a.protected("audit.read", http.HandlerFunc(a.auditEvents)))
	mux.Handle("GET /api/v1/rbac/roles", a.protected("rbac.manage", http.HandlerFunc(a.roles)))
	mux.Handle("GET /api/v1/rbac/group-mappings", a.protected("rbac.manage", http.HandlerFunc(a.groupMappings)))
	mux.Handle("POST /api/v1/rbac/group-mappings", a.protectedMutation("rbac.manage", http.HandlerFunc(a.createGroupMapping)))
	mux.Handle("DELETE /api/v1/rbac/group-mappings/{id}", a.protectedMutation("rbac.manage", http.HandlerFunc(a.deleteGroupMapping)))

	mux.Handle("GET /api/openapi.yaml", a.protected("", http.HandlerFunc(a.openapi)))
	if a.Config.OpenAPI.Enabled {
		docsPath := "/" + strings.Trim(a.Config.OpenAPI.SwaggerPath, "/")
		docsPrefix := docsPath + "/"
		docs := swgui.New(a.Config.App.Name+" API", "/api/openapi.yaml", docsPath)
		mux.Handle("GET "+docsPrefix, a.protected("", docs))
		mux.Handle("GET "+docsPath, a.protected("", http.RedirectHandler(docsPrefix, http.StatusMovedPermanently)))
	}

	staticRoot, err := fs.Sub(webfs.Static, "static")
	if err != nil {
		return nil, err
	}
	files := http.FileServer(http.FS(staticRoot))
	mux.Handle("GET /static/", http.StripPrefix("/static/", files))
	mux.HandleFunc("GET /login", func(w http.ResponseWriter, r *http.Request) { serveEmbedded(w, staticRoot, "login.html") })
	mux.HandleFunc("GET /", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		serveEmbedded(w, staticRoot, "index.html")
	})

	return a.middleware(a.Auth.Middleware(mux)), nil
}

func (a *App) agentRegistrationAuth(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if a.Registration == nil || !a.Registration.Authorized(r.Header.Get("Authorization")) {
			w.Header().Set("WWW-Authenticate", `Bearer realm="vm-doc-agent-registration"`)
			jsonResponse(w, http.StatusUnauthorized, map[string]any{"error": "unauthorized"})
			return
		}
		next.ServeHTTP(w, r)
	})
}

func (a *App) protected(permission string, h http.Handler) http.Handler {
	if permission != "" {
		h = rbac.Require(permission, h)
	}
	return a.Auth.RequireAuth(h)
}

func (a *App) protectedMutation(permission string, h http.Handler) http.Handler {
	return a.protected(permission, a.Auth.RequireCSRF(h))
}

func (a *App) middleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		requestID, _ := cryptox.RandomToken(12)
		w.Header().Set("X-Request-ID", requestID)
		r.Header.Set("X-Request-ID", requestID)
		r.Header.Set("X-VM-Doc-Client-IP", resolvedClientIP(r, a.Config.Server.TrustedProxies))
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("Referrer-Policy", "same-origin")
		w.Header().Set("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
		scriptPolicy := "script-src 'self'"
		docsPath := "/" + strings.Trim(a.Config.OpenAPI.SwaggerPath, "/")
		if a.Config.OpenAPI.Enabled && (r.URL.Path == docsPath || strings.HasPrefix(r.URL.Path, docsPath+"/")) {
			scriptPolicy += " 'unsafe-inline'"
		}
		w.Header().Set("Content-Security-Policy", "default-src 'self'; "+scriptPolicy+"; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'")
		if a.Config.App.Environment == "production" {
			w.Header().Set("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
		}
		if strings.HasPrefix(r.URL.Path, "/api/") {
			w.Header().Set("Cache-Control", "no-store")
		}
		defer func() {
			if recovered := recover(); recovered != nil {
				a.Logger.Error("panic recovered", "request_id", requestID, "panic", recovered)
				jsonResponse(w, 500, map[string]any{"error": "internal_error", "request_id": requestID})
			}
			a.Logger.Info("http request", "request_id", requestID, "method", r.Method, "path", r.URL.Path, "duration_ms", time.Since(start).Milliseconds())
		}()
		next.ServeHTTP(w, r)
	})
}

func (a *App) registerAgent(w http.ResponseWriter, r *http.Request) {
	var in registration.RegistrationRequest
	if err := decodeJSON(r, &in, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	result, err := a.Registration.Register(r.Context(), in, resolvedClientIP(r, a.Config.Server.TrustedProxies))
	if err == nil && a.Logger != nil {
		a.Logger.Info("agent registered", "agent_id", result.AgentID, "vm_id", result.VMID, "created", result.Created, "linked", result.Linked)
	}
	respondStatus(w, result, err, http.StatusOK)
}

func (a *App) agentHeartbeat(w http.ResponseWriter, r *http.Request) {
	var in registration.HeartbeatRequest
	if err := decodeJSON(r, &in, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	result, err := a.Registration.Heartbeat(r.Context(), in, resolvedClientIP(r, a.Config.Server.TrustedProxies))
	respond(w, result, err)
}

func (a *App) agentInventoryPush(w http.ResponseWriter, r *http.Request) {
	defer r.Body.Close()
	limit := a.Config.AgentRegistration.MaxRequestBody
	raw, err := io.ReadAll(io.LimitReader(r.Body, limit+1))
	if err != nil {
		badRequest(w, err)
		return
	}
	if int64(len(raw)) > limit {
		jsonResponse(w, http.StatusRequestEntityTooLarge, map[string]any{"error": "payload_too_large"})
		return
	}
	result, err := a.Registration.SaveInventory(r.Context(), raw)
	if err == nil && a.Logger != nil {
		a.Logger.Info("agent inventory received", "agent_id", result.AgentID, "inventory_id", result.InventoryID, "vm_id", result.VMID, "linked", result.Linked)
	}
	respondStatus(w, result, err, http.StatusCreated)
}

func (a *App) ready(w http.ResponseWriter, r *http.Request) {
	ctx, cancel := context.WithTimeout(r.Context(), 2*time.Second)
	defer cancel()
	if err := a.DB.PingContext(ctx); err != nil {
		a.Logger.Error("readiness database check failed", "error", err)
		jsonResponse(w, 503, map[string]any{"status": "not_ready", "database": "unavailable"})
		return
	}
	jsonResponse(w, 200, map[string]any{"status": "ready"})
}

func (a *App) dashboard(w http.ResponseWriter, r *http.Request) {
	var agentsTotal, agentsOnline, vms, jobsQueued int
	_ = a.DB.QueryRowContext(r.Context(), `SELECT COUNT(*) FROM agents`).Scan(&agentsTotal)
	_ = a.DB.QueryRowContext(r.Context(), `SELECT COUNT(*) FROM agents WHERE enabled=1 AND last_contact_at IS NOT NULL AND TIMESTAMPDIFF(SECOND,last_contact_at,UTC_TIMESTAMP())<=offline_after_seconds`).Scan(&agentsOnline)
	_ = a.DB.QueryRowContext(r.Context(), `SELECT COUNT(*) FROM virtual_machines`).Scan(&vms)
	_ = a.DB.QueryRowContext(r.Context(), `SELECT COUNT(*) FROM collection_jobs WHERE status IN ('queued','running')`).Scan(&jobsQueued)
	jsonResponse(w, 200, map[string]any{"agents_total": agentsTotal, "agents_online": agentsOnline, "vms": vms, "jobs_pending": jobsQueued})
}

func (a *App) listAgents(w http.ResponseWriter, r *http.Request) {
	v, err := a.Agents.List(r.Context())
	respond(w, v, err)
}
func (a *App) getAgent(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.Agents.Get(r.Context(), id)
	respond(w, v, err)
}
func (a *App) createAgent(w http.ResponseWriter, r *http.Request) {
	var in agents.Input
	if err := decodeJSON(r, &in, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	v, err := a.Agents.Create(r.Context(), in, u.ID)
	if err == nil {
		a.auditRequest(r, "agent.create", "agent", strconv.FormatInt(v.ID, 10), "success", map[string]any{"name": v.Name, "base_url": v.BaseURL})
	}
	respondStatus(w, v, err, 201)
}
func (a *App) updateAgent(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var in agents.Input
	if err := decodeJSON(r, &in, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	v, err := a.Agents.Update(r.Context(), id, in, u.ID)
	if err == nil {
		a.auditRequest(r, "agent.update", "agent", strconv.FormatInt(id, 10), "success", map[string]any{"name": v.Name})
	}
	respond(w, v, err)
}
func (a *App) deleteAgent(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	err = a.Agents.Delete(r.Context(), id)
	if err == nil {
		a.auditRequest(r, "agent.delete", "agent", strconv.FormatInt(id, 10), "success", nil)
		w.WriteHeader(204)
		return
	}
	respond(w, nil, err)
}
func (a *App) queueTest(w http.ResponseWriter, r *http.Request)    { a.queueJob(w, r, "test") }
func (a *App) queueCollect(w http.ResponseWriter, r *http.Request) { a.queueJob(w, r, "collect") }
func (a *App) queueJob(w http.ResponseWriter, r *http.Request, kind string) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	job, err := a.Collection.Queue(r.Context(), id, kind, "manual", &u.ID)
	if err == nil {
		a.auditRequest(r, "collection.queue", "agent", strconv.FormatInt(id, 10), "success", map[string]any{"job_id": job.ID, "kind": kind})
	}
	respondStatus(w, job, err, 202)
}
func (a *App) agentJobs(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.Collection.ListForAgent(r.Context(), id, 100)
	respond(w, v, err)
}
func (a *App) getJob(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.Collection.Get(r.Context(), id)
	respond(w, v, err)
}
func (a *App) listVMs(w http.ResponseWriter, r *http.Request) {
	filter, err := vmFilterFromRequest(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.VCenter.ListVMs(r.Context(), filter)
	respond(w, v, err)
}

func (a *App) exportVMs(w http.ResponseWriter, r *http.Request) {
	filter, err := vmFilterFromRequest(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	vms, err := a.VCenter.ExportVMs(r.Context(), filter)
	if err != nil {
		respond(w, nil, err)
		return
	}
	rows := vmExportRows(vms)
	var output bytes.Buffer
	if err := xlsx.Write(&output, "VM-uri", rows); err != nil {
		respond(w, nil, err)
		return
	}
	filename := "vm-inventory-" + time.Now().Format("20060102-150405") + ".xlsx"
	w.Header().Set("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	w.Header().Set("Content-Disposition", `attachment; filename="`+filename+`"`)
	w.Header().Set("Content-Length", strconv.Itoa(output.Len()))
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write(output.Bytes())
}

func vmFilterFromRequest(r *http.Request) (vcenter.VMFilter, error) {
	query := r.URL.Query()
	filter := vcenter.VMFilter{
		Query:   query.Get("q"),
		Power:   query.Get("power"),
		Agent:   query.Get("agent"),
		Retired: query.Get("retired"),
	}
	var err error
	if value := query.Get("source_id"); value != "" {
		filter.SourceID, err = strconv.ParseInt(value, 10, 64)
		if err != nil || filter.SourceID < 1 {
			return filter, errors.New("invalid source_id")
		}
	}
	if value := query.Get("page"); value != "" {
		filter.Page, err = strconv.Atoi(value)
		if err != nil || filter.Page < 1 {
			return filter, errors.New("invalid page")
		}
	}
	if value := query.Get("page_size"); value != "" {
		filter.PageSize, err = strconv.Atoi(value)
		if err != nil || filter.PageSize < 1 {
			return filter, errors.New("invalid page_size")
		}
	}
	return filter, nil
}

func vmExportRows(vms []domain.VirtualMachine) [][]xlsx.Cell {
	headers := []string{
		"Nume VM", "Sursă vCenter", "Power", "CPU", "RAM MiB", "OS", "Versiune OS", "Hostname", "IP",
		"Agent", "Stare agent", "Ultimul contact agent", "Ultimul JSON", "Retired", "Prezentă în vCenter",
		"MoID", "Instance UUID", "BIOS UUID", "Ultima sincronizare vCenter",
	}
	rows := make([][]xlsx.Cell, 0, len(vms)+1)
	headerRow := make([]xlsx.Cell, 0, len(headers))
	for _, header := range headers {
		headerRow = append(headerRow, xlsx.Text(header))
	}
	rows = append(rows, headerRow)
	for _, vm := range vms {
		osName := vm.InventoryOSName
		if osName == "" {
			osName = vm.GuestOS
		}
		hostname := vm.InventoryHostname
		if hostname == "" {
			hostname = vm.GuestHostname
		}
		ip := vm.InventoryPrimaryIP
		if ip == "" {
			ip = vm.PrimaryIP
		}
		rows = append(rows, []xlsx.Cell{
			xlsx.Text(vm.Name), xlsx.Text(vm.VCenterSourceName), xlsx.Text(vm.PowerState), xlsx.Number(float64(vm.CPUCount)), xlsx.Number(float64(vm.MemoryMiB)),
			xlsx.Text(osName), xlsx.Text(vm.InventoryOSVersion), xlsx.Text(hostname), xlsx.Text(ip), xlsx.Text(vm.AgentName), xlsx.Text(vm.AgentStatus),
			xlsx.Text(exportTime(vm.AgentLastContactAt)), xlsx.Text(exportTime(vm.InventoryReceivedAt)), xlsx.Text(yesNo(vm.Retired)), xlsx.Text(yesNo(vm.PresentInVCenter)),
			xlsx.Text(vm.VCenterMoID), xlsx.Text(vm.InstanceUUID), xlsx.Text(vm.BIOSUUID), xlsx.Text(exportTime(vm.LastVCenterSyncAt)),
		})
	}
	return rows
}

func exportTime(value *time.Time) string {
	if value == nil {
		return ""
	}
	return value.Format(time.RFC3339)
}

func yesNo(value bool) string {
	if value {
		return "Da"
	}
	return "Nu"
}
func (a *App) getVM(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	vm, err := a.VCenter.GetVM(r.Context(), id)
	if err != nil {
		respond(w, nil, err)
		return
	}
	operational, err := a.VCenter.GetOperationalMetadata(r.Context(), id)
	if err != nil {
		respond(w, nil, err)
		return
	}
	var agent any
	var inv any
	var documentView any
	if vm.AgentID != nil {
		agent, err = a.Agents.Get(r.Context(), *vm.AgentID)
		if err != nil {
			respond(w, nil, err)
			return
		}
	}
	if vm.CurrentInventoryID != nil {
		inventoryValue, inventoryErr := a.Inventory.Get(r.Context(), *vm.CurrentInventoryID, true)
		if inventoryErr != nil {
			respond(w, nil, inventoryErr)
			return
		}
		documentView, err = inventory.BuildDocumentView(inventoryValue.RawJSON)
		if err != nil {
			respond(w, nil, err)
			return
		}
		inventoryValue.RawJSON = nil
		inv = inventoryValue
	}
	jsonResponse(w, 200, map[string]any{"vm": vm, "agent": agent, "inventory": inv, "inventory_document": documentView, "operational": operational})
}

func (a *App) updateVMOperational(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var input vcenter.OperationalMetadataInput
	if err := decodeJSON(r, &input, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.VCenter.SaveOperationalMetadata(r.Context(), id, user.ID, input)
	if err == nil {
		a.auditRequest(r, "vm.operational.update", "virtual_machine", strconv.FormatInt(id, 10), "success", map[string]any{"service_name": value.ServiceName, "environment": value.Environment, "operational_status": value.OperationalStatus})
	}
	respond(w, value, err)
}
func (a *App) updateVM(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var in vcenter.VMUpdate
	if err := decodeJSON(r, &in, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	vm, err := a.VCenter.UpdateVM(r.Context(), id, in, u.ID)
	if err == nil {
		a.auditRequest(r, "vm.update", "virtual_machine", strconv.FormatInt(id, 10), "success", in)
	}
	respond(w, vm, err)
}
func (a *App) testVMAgent(w http.ResponseWriter, r *http.Request) { a.queueVMJob(w, r, "test") }
func (a *App) collectVM(w http.ResponseWriter, r *http.Request)   { a.queueVMJob(w, r, "collect") }
func (a *App) queueVMJob(w http.ResponseWriter, r *http.Request, kind string) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	vm, err := a.VCenter.GetVM(r.Context(), id)
	if err != nil {
		respond(w, nil, err)
		return
	}
	if vm.AgentID == nil {
		badRequest(w, errors.New("VM does not have an associated agent"))
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	job, err := a.Collection.Queue(r.Context(), *vm.AgentID, kind, "manual", &u.ID)
	if err == nil {
		a.auditRequest(r, "collection.queue", "virtual_machine", strconv.FormatInt(id, 10), "success", map[string]any{"job_id": job.ID, "kind": kind, "agent_id": *vm.AgentID})
	}
	respondStatus(w, job, err, http.StatusAccepted)
}
func (a *App) inventoryHistory(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	vm, err := a.VCenter.GetVM(r.Context(), id)
	if err != nil {
		respond(w, nil, err)
		return
	}
	if vm.AgentID == nil {
		jsonResponse(w, 200, []any{})
		return
	}
	v, err := a.Inventory.History(r.Context(), *vm.AgentID, 100)
	respond(w, v, err)
}

func (a *App) listVCenterSources(w http.ResponseWriter, r *http.Request) {
	v, err := a.VCenter.ListSources(r.Context())
	respond(w, v, err)
}
func (a *App) getVCenterSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.VCenter.GetSource(r.Context(), id)
	respond(w, v, err)
}
func (a *App) createVCenterSource(w http.ResponseWriter, r *http.Request) {
	var in vcenter.SourceInput
	if err := decodeJSON(r, &in, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	v, err := a.VCenter.CreateSource(r.Context(), in, u.ID)
	if err == nil {
		a.auditRequest(r, "vcenter.source.create", "vcenter_source", strconv.FormatInt(v.ID, 10), "success", map[string]any{"name": v.Name})
	}
	respondStatus(w, v, err, http.StatusCreated)
}
func (a *App) updateVCenterSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var in vcenter.SourceInput
	if err := decodeJSON(r, &in, a.Config.Server.MaxRequestBody); err != nil {
		badRequest(w, err)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	v, err := a.VCenter.UpdateSource(r.Context(), id, in, u.ID)
	if err == nil {
		a.auditRequest(r, "vcenter.source.update", "vcenter_source", strconv.FormatInt(id, 10), "success", map[string]any{"name": v.Name})
	}
	respond(w, v, err)
}
func (a *App) deleteVCenterSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	err = a.VCenter.DeleteSource(r.Context(), id)
	if err == nil {
		a.auditRequest(r, "vcenter.source.delete", "vcenter_source", strconv.FormatInt(id, 10), "success", nil)
		w.WriteHeader(http.StatusNoContent)
		return
	}
	respond(w, nil, err)
}
func (a *App) testVCenterSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.VCenter.TestSource(r.Context(), id)
	if err == nil {
		a.auditRequest(r, "vcenter.source.test", "vcenter_source", strconv.FormatInt(id, 10), "success", v)
	}
	respond(w, v, err)
}
func (a *App) syncVCenterSource(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	u, _ := auth.UserFromContext(r.Context())
	run, err := a.VCenter.StartSync(r.Context(), id, "manual", &u.ID)
	if err == nil {
		a.auditRequest(r, "vcenter.sync.queue", "vcenter_source", strconv.FormatInt(id, 10), "success", map[string]any{"run_id": run.ID})
	}
	respondStatus(w, run, err, http.StatusAccepted)
}
func (a *App) syncAllVCenters(w http.ResponseWriter, r *http.Request) {
	u, _ := auth.UserFromContext(r.Context())
	runs, err := a.VCenter.StartAll(r.Context(), &u.ID)
	if err == nil {
		a.auditRequest(r, "vcenter.sync.queue_all", "vcenter", "all", "success", map[string]any{"runs": len(runs)})
	}
	respondStatus(w, runs, err, http.StatusAccepted)
}
func (a *App) listVCenterRuns(w http.ResponseWriter, r *http.Request) {
	v, err := a.VCenter.ListRuns(r.Context(), 100)
	respond(w, v, err)
}
func (a *App) getInventory(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.Inventory.Get(r.Context(), id, false)
	respond(w, v, err)
}
func (a *App) getInventoryRaw(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	v, err := a.Inventory.Get(r.Context(), id, true)
	if err != nil {
		respond(w, nil, err)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(200)
	_, _ = w.Write(v.RawJSON)
}
func (a *App) auditEvents(w http.ResponseWriter, r *http.Request) {
	v, err := a.Audit.List(r.Context(), 200)
	respond(w, v, err)
}

func (a *App) roles(w http.ResponseWriter, r *http.Request) {
	rows, err := a.DB.QueryContext(r.Context(), `SELECT id,name,description FROM roles ORDER BY name`)
	if err != nil {
		respond(w, nil, err)
		return
	}
	defer rows.Close()
	out := make([]map[string]any, 0)
	for rows.Next() {
		var id int64
		var name, desc string
		if err := rows.Scan(&id, &name, &desc); err != nil {
			respond(w, nil, err)
			return
		}
		out = append(out, map[string]any{"id": id, "name": name, "description": desc})
	}
	jsonResponse(w, 200, out)
}
func (a *App) groupMappings(w http.ResponseWriter, r *http.Request) {
	rows, err := a.DB.QueryContext(r.Context(), `SELECT gm.id,gm.provider,gm.group_name,r.name FROM group_role_mappings gm JOIN roles r ON r.id=gm.role_id ORDER BY gm.provider,gm.group_name`)
	if err != nil {
		respond(w, nil, err)
		return
	}
	defer rows.Close()
	out := make([]map[string]any, 0)
	for rows.Next() {
		var id int64
		var provider, group, role string
		if err := rows.Scan(&id, &provider, &group, &role); err != nil {
			respond(w, nil, err)
			return
		}
		out = append(out, map[string]any{"id": id, "provider": provider, "group_name": group, "role": role})
	}
	jsonResponse(w, 200, out)
}
func (a *App) createGroupMapping(w http.ResponseWriter, r *http.Request) {
	var in struct {
		Provider  string `json:"provider"`
		GroupName string `json:"group_name"`
		Role      string `json:"role"`
	}
	if err := decodeJSON(r, &in, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	in.Provider = strings.ToLower(strings.TrimSpace(in.Provider))
	in.GroupName = strings.TrimSpace(in.GroupName)
	in.Role = strings.ToLower(strings.TrimSpace(in.Role))
	if in.Provider != "ldap" && in.Provider != "oidc" && in.Provider != "any" {
		badRequest(w, errors.New("provider must be ldap, oidc or any"))
		return
	}
	if in.GroupName == "" || in.Role == "" {
		badRequest(w, errors.New("group_name and role are required"))
		return
	}
	res, err := a.DB.ExecContext(r.Context(), `INSERT INTO group_role_mappings(provider,group_name,role_id) SELECT ?,?,id FROM roles WHERE name=?`, in.Provider, in.GroupName, in.Role)
	if err != nil {
		respond(w, nil, err)
		return
	}
	rows, err := res.RowsAffected()
	if err != nil {
		respond(w, nil, err)
		return
	}
	if rows == 0 {
		badRequest(w, errors.New("invalid role"))
		return
	}
	id, _ := res.LastInsertId()
	a.auditRequest(r, "rbac.mapping.create", "group_role_mapping", strconv.FormatInt(id, 10), "success", in)
	jsonResponse(w, 201, map[string]any{"id": id})
}
func (a *App) deleteGroupMapping(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	res, err := a.DB.ExecContext(r.Context(), `DELETE FROM group_role_mappings WHERE id=?`, id)
	if err != nil {
		respond(w, nil, err)
		return
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		respond(w, nil, sql.ErrNoRows)
		return
	}
	a.auditRequest(r, "rbac.mapping.delete", "group_role_mapping", strconv.FormatInt(id, 10), "success", nil)
	w.WriteHeader(204)
}

func (a *App) openapi(w http.ResponseWriter, r *http.Request) {
	b, err := openapifs.Files.ReadFile("openapi.yaml")
	if err != nil {
		respond(w, nil, err)
		return
	}
	w.Header().Set("Content-Type", "application/yaml")
	_, _ = w.Write(b)
}
func (a *App) auditRequest(r *http.Request, action, resourceType, resourceID, outcome string, details any) {
	u, _ := auth.UserFromContext(r.Context())
	id := u.ID
	_ = a.Audit.Log(r.Context(), audit.Event{Source: "server", ActorUserID: &id, ActorUsername: u.Username, Action: action, ResourceType: resourceType, ResourceID: resourceID, Outcome: outcome, RequestID: r.Header.Get("X-Request-ID"), IPAddress: clientIP(r), UserAgent: r.UserAgent(), Details: details})
}

func serveEmbedded(w http.ResponseWriter, root fs.FS, name string) {
	b, err := fs.ReadFile(root, name)
	if err != nil {
		http.Error(w, "not found", http.StatusNotFound)
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	_, _ = w.Write(b)
}
func pathID(r *http.Request) (int64, error) {
	v := r.PathValue("id")
	id, err := strconv.ParseInt(v, 10, 64)
	if err != nil || id <= 0 {
		return 0, fmt.Errorf("invalid id")
	}
	return id, nil
}
func decodeJSON(r *http.Request, v any, max int64) error {
	defer r.Body.Close()
	dec := json.NewDecoder(io.LimitReader(r.Body, max))
	dec.DisallowUnknownFields()
	return dec.Decode(v)
}
func badRequest(w http.ResponseWriter, err error) {
	jsonResponse(w, 400, map[string]any{"error": "bad_request", "message": err.Error()})
}
func respond(w http.ResponseWriter, v any, err error) { respondStatus(w, v, err, 200) }
func respondStatus(w http.ResponseWriter, v any, err error, status int) {
	if err == nil {
		jsonResponse(w, status, v)
		return
	}
	if errors.Is(err, sql.ErrNoRows) {
		jsonResponse(w, 404, map[string]any{"error": "not_found"})
		return
	}
	msg := err.Error()
	lower := strings.ToLower(msg)
	if database.IsDuplicate(err) || strings.Contains(lower, "already running") {
		jsonResponse(w, http.StatusConflict, map[string]any{"error": "conflict", "message": msg})
		return
	}
	if strings.Contains(lower, "required") || strings.Contains(lower, "invalid") || strings.Contains(lower, "must ") || strings.Contains(lower, "between") || strings.Contains(lower, "at least") {
		jsonResponse(w, http.StatusBadRequest, map[string]any{"error": "bad_request", "message": msg})
		return
	}
	jsonResponse(w, http.StatusInternalServerError, map[string]any{"error": "internal_error", "message": "internal server error"})
}
func jsonResponse(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}
func clientIP(r *http.Request) string {
	if value := strings.TrimSpace(r.Header.Get("X-VM-Doc-Client-IP")); value != "" {
		return value
	}
	return remoteIP(r.RemoteAddr)
}

func resolvedClientIP(r *http.Request, trustedCIDRs []string) string {
	remote := remoteIP(r.RemoteAddr)
	remoteParsed := net.ParseIP(remote)
	if remoteParsed == nil || !ipInCIDRs(remoteParsed, trustedCIDRs) {
		return remote
	}
	chain := make([]string, 0, 8)
	for _, raw := range strings.Split(r.Header.Get("X-Forwarded-For"), ",") {
		if value := strings.TrimSpace(raw); net.ParseIP(value) != nil {
			chain = append(chain, value)
		}
	}
	chain = append(chain, remote)
	for i := len(chain) - 1; i >= 0; i-- {
		ip := net.ParseIP(chain[i])
		if ip == nil {
			continue
		}
		if i == len(chain)-1 || ipInCIDRs(ip, trustedCIDRs) {
			continue
		}
		return ip.String()
	}
	if len(chain) > 0 {
		return chain[0]
	}
	return remote
}

func ipInCIDRs(ip net.IP, cidrs []string) bool {
	for _, raw := range cidrs {
		_, network, err := net.ParseCIDR(raw)
		if err == nil && network.Contains(ip) {
			return true
		}
	}
	return false
}

func remoteIP(address string) string {
	host, _, err := net.SplitHostPort(address)
	if err == nil {
		return host
	}
	return strings.TrimSpace(address)
}

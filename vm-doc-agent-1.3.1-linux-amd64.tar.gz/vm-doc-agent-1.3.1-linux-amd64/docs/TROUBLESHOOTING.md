# Troubleshooting

## Configurație invalidă

```bash
vm-doc-agent -config /etc/vm-doc-agent/config.json -check-config
```

## Agentul nu pornește

Systemd:

```bash
systemctl status vm-doc-agent
journalctl -u vm-doc-agent -n 100
```

SysV:

```bash
/etc/init.d/vm-doc-agent status
tail -n 100 /var/log/vm-doc-agent.log
```

## Un colector apare `partial`

Verifică:

```bash
TOKEN=$(cat /etc/vm-doc-agent/token)
curl -s -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/status
```

Statusul colectorului include avertismentele și durata.

## Un colector apare `timeout`

Mărește temporar:

```json
"collector_timeout": "40s"
```

Pentru Beats:

```json
"output_test_timeout": "20s"
```

## Inventar trunchiat

Verifică secțiunea `truncations` și ajustează limitele din configurație.

## `insserv` afișează avertismente

`insserv` verifică toate scripturile SysV, nu numai agentul. Dacă serviciul apare `on` în runlevel-urile necesare și pornește după reboot, avertismentele pot proveni din alte scripturi `/etc/init.d` cu antete LSB incomplete.

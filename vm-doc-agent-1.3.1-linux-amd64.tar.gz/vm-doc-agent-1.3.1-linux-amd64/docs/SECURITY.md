# Securitate

Agentul rulează ca root deoarece trebuie să citească `/etc/shadow`, regulile firewall și crontab-urile tuturor utilizatorilor.

## Date excluse

Agentul nu salvează:

- hash-uri de parole;
- bind password SSSD/LDAP;
- API keys sau tokenuri Beats;
- chei private;
- argumentele complete ale proceselor.

Credentialele din URL-uri și valorile recunoscute ca `password`, `token`, `secret`, `api_key` sau `access_key` sunt mascate best-effort.

## Token API

```text
/etc/vm-doc-agent/token
```

Permisiuni așteptate:

```text
0600 root:root
```

## Firewall recomandat

Portul `9078` trebuie permis numai de la IP-ul nodului central sau din rețeaua de management.

API-ul local folosește HTTP cu token Bearer și trebuie limitat prin firewall la nodul central sau la rețeaua de management. Conexiunea outbound de autoînregistrare trebuie să folosească HTTPS.

## Tokenul de autoînregistrare

```text
/etc/vm-doc-agent/central-registration-token
```

Permisiuni recomandate: `0600 root:root`. Tokenul este separat de tokenul API
local și trebuie trimis numai către un server central HTTPS. Pentru CA internă
se folosește `central.ca_file`; `insecure_skip_verify` nu trebuie menținut în
producție.

## Profil intern 1.3.0

Distribuția internă 1.3.0 poate fi construită cu tokenul comun de
autoînregistrare inclus în arhiva binară, pentru instalare automată pe VM-uri.
O astfel de arhivă conține un secret și nu trebuie publicată într-un repository
public sau într-un loc accesibil neautorizat.

Configurația internă folosește momentan `http://172.20.1.20:9080` cu
`central.allow_http=true`. Această excepție este destinată exclusiv rețelei de
management controlate. La publicarea endpoint-ului în afara acestei zone se va
folosi HTTPS și `allow_http=false`.

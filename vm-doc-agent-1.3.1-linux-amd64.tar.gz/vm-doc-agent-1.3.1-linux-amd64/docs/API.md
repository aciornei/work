# API HTTP

Port implicit: `9078`.

## Autentificare

```bash
TOKEN=$(sudo cat /etc/vm-doc-agent/token)
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/status
```

## Endpoint public

### `GET /health`

Returnează starea de bază, versiunea agentului și versiunea schemei.

## Endpoint-uri protejate

- `GET /v1/status`
- `GET /v1/version`
- `GET /v1/identity`
- `GET /v1/system`
- `GET /v1/storage`
- `GET /v1/network`
- `GET /v1/proxy`
- `GET /v1/services`
- `GET /v1/listening-ports`
- `GET /v1/firewall`
- `GET /v1/accounts`
- `GET /v1/sssd`
- `GET /v1/integrations`
- `GET /v1/policies`
- `GET /v1/cron`
- `GET /v1/ntp`
- `GET /v1/inventory`
- `POST /v1/inventory/refresh`

## Status runtime

`GET /v1/status` include:

- uptime agent;
- ultima colectare;
- durata colectării;
- următoarea colectare;
- dimensiunea inventarului;
- statusul fiecărui colector;
- ultima eroare fatală.

## Refresh manual

```bash
curl -X POST \
  -H "Authorization: Bearer $TOKEN" \
  http://127.0.0.1:9078/v1/inventory/refresh
```

# vm-doc-agent 1.1.0

Agent Linux universal pentru colectarea inventarului local necesar fișei VM.
Versiunea 1.1.0 păstrează API-ul local din 1.0.0 și adaugă autoînregistrarea în
`vm-doc-server 0.2.2`, heartbeat și trimiterea automată a inventarului.

## Funcții principale

- identitate persistentă `agent.id` și corelare prin UUID VMware/DMI;
- inventar JSON local și API HTTP protejat cu token Bearer;
- autoînregistrare outbound la serverul central;
- heartbeat periodic pentru starea online/offline;
- push automat al inventarului după fiecare colectare reușită;
- retry automat dacă serverul central nu este disponibil;
- compatibilitate cu systemd și SysV Init;
- binar static universal `linux/amd64`, `GOAMD64=v1`.

## Instalare

```bash
tar -xzf vm-doc-agent-1.1.0-linux-amd64.tar.gz
cd vm-doc-agent-1.1.0-linux-amd64
sudo ./install.sh
```

## Update de la 1.0.0

```bash
tar -xzf vm-doc-agent-1.1.0-linux-amd64.tar.gz
cd vm-doc-agent-1.1.0-linux-amd64
sudo ./update.sh
```

Configurația, tokenul API local, `agent-id` și inventarele existente sunt păstrate.
Autoînregistrarea este dezactivată implicit până când secțiunea `central` este
adăugată sau activată în `/etc/vm-doc-agent/config.json`.

## Configurare centrală

Creează fișierul cu tokenul comun furnizat de server:

```bash
sudo sh -c 'umask 077; printf "%s\n" "TOKENUL_DE_INREGISTRARE" > /etc/vm-doc-agent/central-registration-token'
```

În `config.json`:

```json
"central": {
  "enabled": true,
  "url": "https://vm-doc-server.example.ro",
  "registration_token_file": "/etc/vm-doc-agent/central-registration-token",
  "heartbeat_interval": "5m",
  "retry_interval": "1m",
  "request_timeout": "60s",
  "advertise_url": "",
  "ca_file": "",
  "tls_server_name": "",
  "insecure_skip_verify": false,
  "allow_http": false
}
```

`advertise_url` poate rămâne gol. Agentul folosește IP-ul interfeței cu ruta
implicită și portul din `listen`. Se setează explicit doar când serverul central
trebuie să folosească alt DNS/IP, de exemplu `http://vm01.example.ro:9078`.

## Verificare

```bash
/usr/local/sbin/vm-doc-agent -version
/usr/local/sbin/vm-doc-agent -config /etc/vm-doc-agent/config.json -check-config
sudo systemctl restart vm-doc-agent
sudo journalctl -u vm-doc-agent -n 100 --no-pager
```

În log trebuie să apară evenimentele:

```text
event=central_registered
event=central_inventory_pushed
```

## API local

```bash
curl http://127.0.0.1:9078/health
TOKEN=$(sudo cat /etc/vm-doc-agent/token)
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/status
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/inventory
```

## Build

```bash
./scripts/build.sh
./scripts/package.sh
./scripts/package-source.sh
```

Documentația detaliată se află în `docs/`.

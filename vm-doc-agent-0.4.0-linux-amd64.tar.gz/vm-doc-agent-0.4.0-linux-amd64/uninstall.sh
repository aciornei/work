#!/bin/sh
set -eu

NAME=vm-doc-agent
PURGE=0
[ "${1:-}" = "--purge" ] && PURGE=1
[ "$(id -u)" -eq 0 ] || { echo "Run as root: sudo ./uninstall.sh"; exit 1; }

if [ -d /run/systemd/system ] && command -v systemctl >/dev/null 2>&1; then
    systemctl disable --now $NAME.service 2>/dev/null || true
    rm -f /etc/systemd/system/$NAME.service
    systemctl daemon-reload
elif [ -x /etc/init.d/$NAME ]; then
    /etc/init.d/$NAME stop 2>/dev/null || true
    if command -v insserv >/dev/null 2>&1; then insserv -r $NAME 2>/dev/null || true; fi
    if command -v chkconfig >/dev/null 2>&1; then chkconfig --del $NAME 2>/dev/null || true; fi
    rm -f /etc/init.d/$NAME
fi
rm -f /usr/local/sbin/$NAME /usr/local/sbin/${NAME}.previous
if [ "$PURGE" -eq 1 ]; then
    rm -rf /etc/$NAME /var/lib/$NAME
    echo "Removed $NAME including configuration, token, inventory and agent identity."
else
    echo "Removed $NAME. Configuration and state were preserved. Use --purge to delete them."
fi

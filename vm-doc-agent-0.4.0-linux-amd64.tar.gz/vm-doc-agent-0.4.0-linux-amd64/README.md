# vm-doc-agent 0.4.0

Un singur agent Linux pentru Ubuntu, Debian, CentOS/RHEL și SUSE. Agentul detectează automat distribuția și sistemul de inițializare, scrie inventarul local în JSON și expune un API HTTP protejat cu token.

## Ce colectează

### Identitate host

- hostname și FQDN;
- distribuție, versiune, kernel și arhitectură;
- systemd sau SysV;
- `machine-id`;
- UUID DMI/SMBIOS și varianta alternativă de byte-order pentru vCenter/GLPI;
- vendor, model, serial, virtualizare și ID persistent al agentului.

### Partiții montate

Pentru fiecare filesystem relevant:

- device și mount point;
- tip filesystem și opțiuni de montare;
- total, utilizat și disponibil în bytes;
- procent utilizat;
- read-only și remote/local.

Filesystem-urile tehnice precum `proc`, `sysfs`, `tmpfs`, `cgroup`, `squashfs` și `overlay` sunt ignorate.

### Rețea

- toate interfețele;
- index, MAC, MTU și flags;
- toate adresele IPv4 și IPv6;
- prefixul CIDR și scope-ul adresei.

### Servicii

- systemd: stare load/active/sub și enablement;
- SysV: servicii instalate, runlevel-uri active și stare când aceasta poate fi determinată sigur;
- descrierea serviciului când este disponibilă.

Pe unele sisteme SysV vechi, `active_state` poate fi `unknown` dacă serviciul nu are PID file și managerul nu oferă o metodă sigură de interogare.

### Porturi ascultate

Agentul citește direct `/proc/net/tcp*` și `/proc/net/udp*`, fără să depindă de `ss` sau `netstat`:

- protocol TCP/UDP;
- IPv4/IPv6;
- adresă și port;
- wildcard bind;
- PID, numele procesului și executabilul asociat, când sunt accesibile.

Nu se colectează argumentele complete ale proceselor, pentru a evita capturarea accidentală a parolelor sau tokenurilor din linia de comandă.

CPU și RAM nu sunt colectate în această etapă; ele vor fi preluate ulterior din vCenter.

## Sisteme vizate

- Ubuntu 20.04 și versiuni mai noi;
- Debian, inclusiv versiuni vechi cu SysV;
- CentOS 7, RHEL, Rocky Linux, AlmaLinux și Oracle Linux;
- SUSE Linux Enterprise Server 11 și versiuni mai noi.

Pachetul este unic pentru toate sistemele `x86_64/amd64`.

## Instalare

```bash
tar -xzf vm-doc-agent-0.4.0-linux-amd64.tar.gz
cd vm-doc-agent-0.4.0-linux-amd64
sudo ./install.sh
```

Installerul detectează automat:

- systemd: instalează `/etc/systemd/system/vm-doc-agent.service`;
- SysV: instalează `/etc/init.d/vm-doc-agent`.

## Configurație

```json
{
  "listen": "0.0.0.0:9078",
  "output_file": "/var/lib/vm-doc-agent/inventory.json",
  "state_dir": "/var/lib/vm-doc-agent",
  "refresh_interval": "15m",
  "auth_token_file": "/etc/vm-doc-agent/token"
}
```

## API

`GET /health` nu cere autentificare. Endpoint-urile `/v1/*` cer token Bearer.

```bash
TOKEN=$(sudo cat /etc/vm-doc-agent/token)

curl http://127.0.0.1:9078/health
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/version
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/identity
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/storage
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/network
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/services
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/listening-ports
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/inventory
curl -X POST -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/inventory/refresh
```

## Fișier local

```text
/var/lib/vm-doc-agent/inventory.json
```

Scrierea se face atomic, prin fișier temporar și `rename`.

## Corelare cu vCenter și GLPI

Folosește în această ordine:

1. `host.correlation.dmi_product_uuid` ↔ vCenter `config.uuid`;
2. `host.correlation.smbios_legacy_byte_order` ca variantă alternativă;
3. `host.machine_id`;
4. `agent.id`, persistent după update.

## Update

```bash
sudo ./update.sh
```

Configurația, tokenul și `agent-id` sunt păstrate. Binarul precedent este salvat în `/usr/local/sbin/vm-doc-agent.previous`.

## Dezinstalare

```bash
sudo ./uninstall.sh
```

Pentru ștergere completă:

```bash
sudo ./uninstall.sh --purge
```

## Build

Go este necesar doar pe mașina de build:

```bash
./scripts/build.sh
./scripts/package.sh
```

Binarul este compilat static cu `CGO_ENABLED=0`, `GOARCH=amd64` și `GOAMD64=v1`.

## Securitate

Portul 9078 trebuie permis în firewall doar din serverul central sau rețeaua de management. Tokenul protejează API-ul, însă traficul este HTTP în această versiune. Pentru producție, următorul pas este TLS/mTLS.

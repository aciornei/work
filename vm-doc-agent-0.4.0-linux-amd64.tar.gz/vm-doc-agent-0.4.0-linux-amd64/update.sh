#!/bin/sh
set -eu

NAME=vm-doc-agent
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if [ -x "$SCRIPT_DIR/vm-doc-agent" ]; then
    BASE_DIR="$SCRIPT_DIR"
else
    BASE_DIR=$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd)
fi
BINARY="$BASE_DIR/vm-doc-agent"

[ "$(id -u)" -eq 0 ] || { echo "Run as root: sudo ./update.sh"; exit 1; }
[ -x "$BINARY" ] || { echo "Missing executable: $BINARY"; exit 1; }
[ -x /usr/local/sbin/$NAME ] || { echo "$NAME is not installed; use install.sh"; exit 1; }

stop_service() {
    if [ -d /run/systemd/system ] && command -v systemctl >/dev/null 2>&1; then
        systemctl stop $NAME.service
    elif [ -x /etc/init.d/$NAME ]; then
        /etc/init.d/$NAME stop
    fi
}

start_service() {
    if [ -d /run/systemd/system ] && command -v systemctl >/dev/null 2>&1; then
        systemctl start $NAME.service
    elif [ -x /etc/init.d/$NAME ]; then
        /etc/init.d/$NAME start
    fi
}

stop_service
cp /usr/local/sbin/$NAME /usr/local/sbin/${NAME}.previous
cp "$BINARY" /usr/local/sbin/$NAME
chmod 0755 /usr/local/sbin/$NAME
if ! start_service; then
    echo "Update failed; restoring previous binary."
    cp /usr/local/sbin/${NAME}.previous /usr/local/sbin/$NAME
    chmod 0755 /usr/local/sbin/$NAME
    start_service || true
    exit 1
fi
sleep 1
/usr/local/sbin/$NAME -version
echo "Updated $NAME; configuration and agent identity were preserved."

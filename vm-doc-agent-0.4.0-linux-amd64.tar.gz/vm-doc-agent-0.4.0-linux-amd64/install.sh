#!/bin/sh
set -eu

NAME=vm-doc-agent
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if [ -x "$SCRIPT_DIR/vm-doc-agent" ]; then
    BASE_DIR="$SCRIPT_DIR"
else
    BASE_DIR=$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd)
fi
BINARY="$BASE_DIR/vm-doc-agent"
CONFIG_SOURCE="$BASE_DIR/config.json"
SYSTEMD_SOURCE="$BASE_DIR/packaging/systemd/vm-doc-agent.service"
SYSV_SOURCE="$BASE_DIR/packaging/sysv/vm-doc-agent"

[ "$(id -u)" -eq 0 ] || { echo "Run as root: sudo ./install.sh"; exit 1; }
[ -x "$BINARY" ] || { echo "Missing executable: $BINARY"; exit 1; }

install_file() {
    SRC=$1
    DST=$2
    MODE=$3
    if command -v install >/dev/null 2>&1; then
        install -m "$MODE" "$SRC" "$DST"
    else
        cp "$SRC" "$DST"
        chmod "$MODE" "$DST"
    fi
}

detect_os() {
    if [ -r /etc/os-release ]; then
        OS_ID=$(sed -n 's/^ID=["'\'']*\([^"'\'']*\)["'\'']*$/\1/p' /etc/os-release | head -1)
    elif [ -r /etc/SuSE-release ]; then
        OS_ID=sles
    elif [ -r /etc/redhat-release ]; then
        OS_ID=redhat
    elif [ -r /etc/debian_version ]; then
        OS_ID=debian
    else
        OS_ID=unknown
    fi
    echo "$OS_ID"
}

detect_init() {
    if [ -d /run/systemd/system ] && command -v systemctl >/dev/null 2>&1; then
        echo systemd
    elif [ -d /etc/init.d ]; then
        echo sysv
    else
        echo unknown
    fi
}

OS_ID=$(detect_os)
INIT_SYSTEM=$(detect_init)
echo "Detected OS: $OS_ID"
echo "Detected init system: $INIT_SYSTEM"

mkdir -p /usr/local/sbin /etc/$NAME /var/lib/$NAME

if [ -x /usr/local/sbin/$NAME ]; then
    cp /usr/local/sbin/$NAME /usr/local/sbin/${NAME}.previous
fi
install_file "$BINARY" /usr/local/sbin/$NAME 0755

if [ ! -f /etc/$NAME/config.json ]; then
    install_file "$CONFIG_SOURCE" /etc/$NAME/config.json 0640
else
    echo "Keeping existing configuration: /etc/$NAME/config.json"
fi

case "$INIT_SYSTEM" in
    systemd)
        install_file "$SYSTEMD_SOURCE" /etc/systemd/system/$NAME.service 0644
        systemctl daemon-reload
        systemctl enable $NAME.service
        systemctl restart $NAME.service
        ;;
    sysv)
        install_file "$SYSV_SOURCE" /etc/init.d/$NAME 0755
        if command -v insserv >/dev/null 2>&1; then
            insserv $NAME || true
        elif command -v chkconfig >/dev/null 2>&1; then
            chkconfig --add $NAME || true
            chkconfig $NAME on || true
        elif command -v update-rc.d >/dev/null 2>&1; then
            update-rc.d $NAME defaults || true
        fi
        /etc/init.d/$NAME restart
        ;;
    *)
        echo "Could not detect systemd or SysV init. Files were installed, but the service was not started."
        echo "Manual command: /usr/local/sbin/$NAME -config /etc/$NAME/config.json"
        exit 2
        ;;
esac

sleep 1
if [ -r /etc/$NAME/token ]; then
    echo "Authentication token: /etc/$NAME/token"
fi
echo "Installed $NAME successfully."
echo "Health: curl http://127.0.0.1:9078/health"
echo "Inventory: curl -H \"Authorization: Bearer \$(cat /etc/$NAME/token)\" http://127.0.0.1:9078/v1/inventory"

package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"os"

	"vm-doc-server/internal/agentupdates"
)

func main() {
	var (
		directory = flag.String("directory", "/var/lib/vm-doc-server/agent-updates", "agent update repository directory")
		list      = flag.Bool("list", false, "validate repository and list published releases")
		version   = flag.String("version", "", "release version, e.g. 1.3.0")
		channel   = flag.String("channel", "stable", "release channel: stable or testing")
		osName    = flag.String("os", "", "target OS: linux or windows")
		arch      = flag.String("arch", "amd64", "target architecture")
		agentPath = flag.String("agent", "", "path to vm-doc-agent binary")
		updater   = flag.String("updater", "", "path to vm-doc-updater binary")
		notes     = flag.String("notes", "", "optional release notes")
	)
	flag.Parse()

	svc := agentupdates.Service{Directory: *directory}
	if err := svc.Validate(); err != nil {
		fmt.Fprintf(os.Stderr, "repository validation failed: %v\n", err)
		os.Exit(1)
	}

	enc := json.NewEncoder(os.Stdout)
	enc.SetIndent("", "  ")
	if *list {
		releases, err := svc.List()
		if err != nil {
			fmt.Fprintf(os.Stderr, "list failed: %v\n", err)
			os.Exit(1)
		}
		if err := enc.Encode(releases); err != nil {
			fmt.Fprintf(os.Stderr, "encode result: %v\n", err)
			os.Exit(1)
		}
		return
	}

	if *version == "" || *osName == "" || *agentPath == "" || *updater == "" {
		fmt.Fprintln(os.Stderr, "required for publish: -version, -os, -agent, -updater (or use -list)")
		flag.Usage()
		os.Exit(2)
	}

	release, err := svc.Publish(agentupdates.PublishInput{
		Version: *version, Channel: *channel, OS: *osName, Arch: *arch,
		AgentPath: *agentPath, UpdaterPath: *updater, Notes: *notes,
	})
	if err != nil {
		fmt.Fprintf(os.Stderr, "publish failed: %v\n", err)
		os.Exit(1)
	}
	if err := enc.Encode(release); err != nil {
		fmt.Fprintf(os.Stderr, "encode result: %v\n", err)
		os.Exit(1)
	}
}

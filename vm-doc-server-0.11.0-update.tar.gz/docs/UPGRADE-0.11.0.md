# Upgrade la vm-doc-server 0.11.0

Versiunea 0.11.0 reorganizează inventarul agentului în pagina VM, împarte Rapoarte în subcategorii și readuce repository-ul central de auto-update pentru `vm-doc-agent 1.3.0+`.

## Baza de date

Nu există migrare MariaDB nouă. Schema 0.10.0 rămâne neschimbată.

## Configurație nouă pentru auto-update

În `/etc/vm-doc-server/config.yaml` adaugă:

```yaml
agent_updates:
  enabled: true
  directory: "/var/lib/vm-doc-server/agent-updates"
```

`agent_registration.enabled` trebuie să rămână `true`, deoarece manifestul și artifactele de update sunt protejate cu același `central-registration-token` folosit de agenți.

Pregătește directorul dacă nu există:

```bash
sudo install -d -o vm-doc -g vm-doc -m 0750 /var/lib/vm-doc-server/agent-updates
```

Release-ul 0.11.0 include și `vm-doc-agent-update-repository-1.3.1.tar.gz`, deja populat cu 1.3.1 stable pentru Linux amd64 și Windows amd64. Îl poți instala direct:

```bash
sudo tar -xzf /tmp/vm-doc-agent-update-repository-1.3.1.tar.gz -C /var/lib/vm-doc-server
sudo chown -R vm-doc:vm-doc /var/lib/vm-doc-server/agent-updates
```

Aceasta este alternativa recomandată publicării manuale a celor patru binare.

## Build și instalare

```bash
GOPROXY=off GOFLAGS=-mod=vendor make build
sudo scripts/install.sh
sudo systemctl restart vm-doc-server vm-doc-collector
```

Verifică:

```bash
curl http://127.0.0.1:9080/healthz
/opt/vm-doc-server/bin/vm-doc-agent-release -h
```

## Publicarea agentului 1.3.1

După extragerea pachetului agentului 1.3.1:

```bash
sudo -u vm-doc /opt/vm-doc-server/bin/vm-doc-agent-release \
  -directory /var/lib/vm-doc-server/agent-updates \
  -version 1.3.1 -channel stable -os linux -arch amd64 \
  -agent /tmp/vm-doc-agent \
  -updater /tmp/vm-doc-updater \
  -notes 'vm-doc-agent 1.3.1'
```

Pentru Windows, publicarea se face analog cu binarele `.exe` și `-os windows`.

Agenții 1.3.0+ care au `updates.enabled=true`, `updates.auto_install=true` și `central.enabled=true` vor verifica repository-ul central și vor face upgrade automat. Agentul validează SHA256 și versiunea, iar `vm-doc-updater` păstrează binarul anterior și face rollback dacă noua versiune nu trece health-check-ul.

## Interfață

- VM → Date colectate de agent → Servicii: căutare și filtru Active/Inactive/Toate; implicit sunt afișate serviciile active;
- Network → Routes: tabel cu familie, destinație, gateway, interfață, protocol și sursă;
- Firewall: regulile explicite sunt separate de regulile tehnice backend; regulile nftables/iptables generate de UFW sunt ascunse implicit;
- Rapoarte: subcategorii separate, în stilul paginii Nomenclatoare;
- Agenți: afișează versiunea raportată și release-urile disponibile în repository-ul de auto-update.

package agentupdates

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"
)

type Service struct {
	Directory string
}

type Repository struct {
	Releases []Release `json:"releases"`
}

type Release struct {
	Version          string    `json:"version"`
	Channel          string    `json:"channel"`
	OS               string    `json:"os"`
	Arch             string    `json:"arch"`
	AgentFilename    string    `json:"agent_filename"`
	AgentSHA256      string    `json:"agent_sha256"`
	AgentSizeBytes   int64     `json:"agent_size_bytes"`
	UpdaterFilename  string    `json:"updater_filename"`
	UpdaterSHA256    string    `json:"updater_sha256"`
	UpdaterSizeBytes int64     `json:"updater_size_bytes"`
	PublishedAt      time.Time `json:"published_at"`
	Notes            string    `json:"notes,omitempty"`
}

type LatestResponse struct {
	Available        bool   `json:"available"`
	Version          string `json:"version,omitempty"`
	Channel          string `json:"channel,omitempty"`
	OS               string `json:"os,omitempty"`
	Arch             string `json:"arch,omitempty"`
	AgentURL         string `json:"agent_url,omitempty"`
	AgentSHA256      string `json:"agent_sha256,omitempty"`
	AgentSizeBytes   int64  `json:"agent_size_bytes,omitempty"`
	UpdaterURL       string `json:"updater_url,omitempty"`
	UpdaterSHA256    string `json:"updater_sha256,omitempty"`
	UpdaterSizeBytes int64  `json:"updater_size_bytes,omitempty"`
	PublishedAt      string `json:"published_at,omitempty"`
	Notes            string `json:"notes,omitempty"`
}

type ReleaseStatus struct {
	Release
	AgentFilePresent   bool `json:"agent_file_present"`
	UpdaterFilePresent bool `json:"updater_file_present"`
	Valid              bool `json:"valid"`
}

func (s Service) Validate() error {
	if strings.TrimSpace(s.Directory) == "" {
		return errors.New("agent update directory is required")
	}
	if !filepath.IsAbs(s.Directory) {
		return errors.New("agent update directory must be absolute")
	}
	if err := os.MkdirAll(filepath.Join(s.Directory, "files"), 0750); err != nil {
		return fmt.Errorf("create agent update directory: %w", err)
	}
	repoPath := filepath.Join(s.Directory, "releases.json")
	if _, err := os.Stat(repoPath); errors.Is(err, os.ErrNotExist) {
		data, _ := json.MarshalIndent(Repository{Releases: []Release{}}, "", "  ")
		if err := os.WriteFile(repoPath, append(data, '\n'), 0640); err != nil {
			return fmt.Errorf("initialize agent update repository: %w", err)
		}
	}
	_, err := s.load()
	return err
}

func (s Service) Latest(channel, osName, arch, current string) (LatestResponse, error) {
	channel = strings.ToLower(strings.TrimSpace(channel))
	osName = strings.ToLower(strings.TrimSpace(osName))
	arch = strings.ToLower(strings.TrimSpace(arch))
	if channel != "stable" && channel != "testing" {
		return LatestResponse{}, errors.New("channel must be stable or testing")
	}
	if osName != "linux" && osName != "windows" {
		return LatestResponse{}, errors.New("os must be linux or windows")
	}
	if arch == "" {
		return LatestResponse{}, errors.New("arch is required")
	}
	repo, err := s.load()
	if err != nil {
		return LatestResponse{}, err
	}
	var candidates []Release
	for _, release := range repo.Releases {
		if release.Channel == channel && release.OS == osName && release.Arch == arch {
			candidates = append(candidates, release)
		}
	}
	if len(candidates) == 0 {
		return LatestResponse{Available: false, Channel: channel, OS: osName, Arch: arch}, nil
	}
	sort.Slice(candidates, func(i, j int) bool { return compareVersions(candidates[i].Version, candidates[j].Version) > 0 })
	release := candidates[0]
	if compareVersions(release.Version, current) <= 0 {
		return LatestResponse{Available: false, Channel: channel, OS: osName, Arch: arch}, nil
	}
	if err := s.validateReleaseFiles(release); err != nil {
		return LatestResponse{}, err
	}
	return LatestResponse{
		Available: true, Version: release.Version, Channel: release.Channel, OS: release.OS, Arch: release.Arch,
		AgentURL:    "/api/v1/agent-updates/download/" + release.AgentFilename,
		AgentSHA256: release.AgentSHA256, AgentSizeBytes: release.AgentSizeBytes,
		UpdaterURL:    "/api/v1/agent-updates/download/" + release.UpdaterFilename,
		UpdaterSHA256: release.UpdaterSHA256, UpdaterSizeBytes: release.UpdaterSizeBytes,
		PublishedAt: release.PublishedAt.UTC().Format(time.RFC3339), Notes: release.Notes,
	}, nil
}

func (s Service) List() ([]ReleaseStatus, error) {
	repo, err := s.load()
	if err != nil {
		return nil, err
	}
	out := make([]ReleaseStatus, 0, len(repo.Releases))
	for _, release := range repo.Releases {
		status := ReleaseStatus{Release: release}
		status.AgentFilePresent = fileExists(filepath.Join(s.Directory, "files", release.AgentFilename))
		status.UpdaterFilePresent = fileExists(filepath.Join(s.Directory, "files", release.UpdaterFilename))
		status.Valid = status.AgentFilePresent && status.UpdaterFilePresent && s.validateReleaseFiles(release) == nil
		out = append(out, status)
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i].Channel != out[j].Channel {
			return out[i].Channel < out[j].Channel
		}
		if out[i].OS != out[j].OS {
			return out[i].OS < out[j].OS
		}
		if out[i].Arch != out[j].Arch {
			return out[i].Arch < out[j].Arch
		}
		return compareVersions(out[i].Version, out[j].Version) > 0
	})
	return out, nil
}

func (s Service) Artifact(filename string) (*os.File, int64, error) {
	filename = strings.TrimSpace(filename)
	if filename == "" || filename != filepath.Base(filename) || strings.ContainsAny(filename, `/\\`) {
		return nil, 0, errors.New("invalid artifact filename")
	}
	repo, err := s.load()
	if err != nil {
		return nil, 0, err
	}
	allowed := false
	for _, release := range repo.Releases {
		if filename == release.AgentFilename || filename == release.UpdaterFilename {
			allowed = true
			break
		}
	}
	if !allowed {
		return nil, 0, os.ErrNotExist
	}
	path := filepath.Join(s.Directory, "files", filename)
	f, err := os.Open(path)
	if err != nil {
		return nil, 0, err
	}
	info, err := f.Stat()
	if err != nil {
		f.Close()
		return nil, 0, err
	}
	if !info.Mode().IsRegular() {
		f.Close()
		return nil, 0, errors.New("artifact is not a regular file")
	}
	return f, info.Size(), nil
}

func (s Service) load() (Repository, error) {
	var repo Repository
	path := filepath.Join(s.Directory, "releases.json")
	raw, err := os.ReadFile(path)
	if err != nil {
		return repo, fmt.Errorf("read agent update repository: %w", err)
	}
	decoder := json.NewDecoder(strings.NewReader(string(raw)))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&repo); err != nil {
		return repo, fmt.Errorf("parse agent update repository: %w", err)
	}
	if repo.Releases == nil {
		repo.Releases = []Release{}
	}
	seen := map[string]struct{}{}
	for i := range repo.Releases {
		normalizeRelease(&repo.Releases[i])
		r := repo.Releases[i]
		if err := validateMetadata(r); err != nil {
			return repo, fmt.Errorf("release %d: %w", i+1, err)
		}
		key := r.Channel + "|" + r.OS + "|" + r.Arch + "|" + r.Version
		if _, ok := seen[key]; ok {
			return repo, fmt.Errorf("duplicate release %s", key)
		}
		seen[key] = struct{}{}
	}
	return repo, nil
}

func normalizeRelease(r *Release) {
	r.Version = strings.TrimPrefix(strings.TrimSpace(r.Version), "v")
	r.Channel = strings.ToLower(strings.TrimSpace(r.Channel))
	r.OS = strings.ToLower(strings.TrimSpace(r.OS))
	r.Arch = strings.ToLower(strings.TrimSpace(r.Arch))
	r.AgentFilename = strings.TrimSpace(r.AgentFilename)
	r.UpdaterFilename = strings.TrimSpace(r.UpdaterFilename)
	r.AgentSHA256 = strings.ToLower(strings.TrimSpace(r.AgentSHA256))
	r.UpdaterSHA256 = strings.ToLower(strings.TrimSpace(r.UpdaterSHA256))
	r.Notes = strings.TrimSpace(r.Notes)
}

func validateMetadata(r Release) error {
	if r.Version == "" || parseVersion(r.Version) == [3]int{} {
		return errors.New("version must be semantic major.minor.patch")
	}
	if r.Channel != "stable" && r.Channel != "testing" {
		return errors.New("channel must be stable or testing")
	}
	if r.OS != "linux" && r.OS != "windows" {
		return errors.New("os must be linux or windows")
	}
	if r.Arch == "" {
		return errors.New("arch is required")
	}
	for _, name := range []string{r.AgentFilename, r.UpdaterFilename} {
		if name == "" || name != filepath.Base(name) || strings.ContainsAny(name, `/\\`) {
			return errors.New("artifact filenames must be simple basenames")
		}
	}
	if !validSHA256(r.AgentSHA256) || !validSHA256(r.UpdaterSHA256) {
		return errors.New("artifact SHA256 values must be 64 hex characters")
	}
	if r.AgentSizeBytes <= 0 || r.UpdaterSizeBytes <= 0 {
		return errors.New("artifact sizes must be greater than zero")
	}
	return nil
}

func (s Service) validateReleaseFiles(r Release) error {
	checks := []struct {
		filename, hash string
		size           int64
	}{{r.AgentFilename, r.AgentSHA256, r.AgentSizeBytes}, {r.UpdaterFilename, r.UpdaterSHA256, r.UpdaterSizeBytes}}
	for _, check := range checks {
		path := filepath.Join(s.Directory, "files", check.filename)
		f, err := os.Open(path)
		if err != nil {
			return fmt.Errorf("open %s: %w", check.filename, err)
		}
		h := sha256.New()
		n, copyErr := io.Copy(h, f)
		closeErr := f.Close()
		if copyErr != nil {
			return copyErr
		}
		if closeErr != nil {
			return closeErr
		}
		if n != check.size {
			return fmt.Errorf("artifact %s size mismatch", check.filename)
		}
		actual := hex.EncodeToString(h.Sum(nil))
		if !strings.EqualFold(actual, check.hash) {
			return fmt.Errorf("artifact %s SHA256 mismatch", check.filename)
		}
	}
	return nil
}

func validSHA256(v string) bool {
	if len(v) != 64 {
		return false
	}
	_, err := hex.DecodeString(v)
	return err == nil
}

func fileExists(path string) bool {
	info, err := os.Stat(path)
	return err == nil && info.Mode().IsRegular()
}

func compareVersions(a, b string) int {
	pa, pb := parseVersion(a), parseVersion(b)
	for i := 0; i < 3; i++ {
		if pa[i] < pb[i] {
			return -1
		}
		if pa[i] > pb[i] {
			return 1
		}
	}
	return strings.Compare(a, b)
}
func parseVersion(v string) [3]int {
	v = strings.TrimPrefix(strings.TrimSpace(v), "v")
	core := strings.SplitN(v, "-", 2)[0]
	parts := strings.Split(core, ".")
	var out [3]int
	for i := 0; i < len(parts) && i < 3; i++ {
		out[i], _ = strconv.Atoi(parts[i])
	}
	return out
}

type PublishInput struct {
	Version     string
	Channel     string
	OS          string
	Arch        string
	AgentPath   string
	UpdaterPath string
	Notes       string
}

func (s Service) Publish(in PublishInput) (Release, error) {
	version := strings.TrimPrefix(strings.TrimSpace(in.Version), "v")
	channel := strings.ToLower(strings.TrimSpace(in.Channel))
	osName := strings.ToLower(strings.TrimSpace(in.OS))
	arch := strings.ToLower(strings.TrimSpace(in.Arch))
	ext := ""
	if osName == "windows" {
		ext = ".exe"
	}
	release := Release{
		Version: version, Channel: channel, OS: osName, Arch: arch,
		AgentFilename:   fmt.Sprintf("vm-doc-agent-%s-%s-%s%s", version, osName, arch, ext),
		UpdaterFilename: fmt.Sprintf("vm-doc-updater-%s-%s-%s%s", version, osName, arch, ext),
		PublishedAt:     time.Now().UTC(), Notes: strings.TrimSpace(in.Notes),
	}
	if strings.TrimSpace(in.AgentPath) == "" || strings.TrimSpace(in.UpdaterPath) == "" {
		return Release{}, errors.New("agent and updater paths are required")
	}
	if err := os.MkdirAll(filepath.Join(s.Directory, "files"), 0750); err != nil {
		return Release{}, err
	}
	agentDest := filepath.Join(s.Directory, "files", release.AgentFilename)
	updaterDest := filepath.Join(s.Directory, "files", release.UpdaterFilename)
	if err := copyArtifact(in.AgentPath, agentDest); err != nil {
		return Release{}, fmt.Errorf("copy agent artifact: %w", err)
	}
	if err := copyArtifact(in.UpdaterPath, updaterDest); err != nil {
		return Release{}, fmt.Errorf("copy updater artifact: %w", err)
	}
	var err error
	release.AgentSHA256, release.AgentSizeBytes, err = hashFile(agentDest)
	if err != nil {
		return Release{}, err
	}
	release.UpdaterSHA256, release.UpdaterSizeBytes, err = hashFile(updaterDest)
	if err != nil {
		return Release{}, err
	}
	if err := validateMetadata(release); err != nil {
		return Release{}, err
	}
	repo, err := s.load()
	if err != nil {
		return Release{}, err
	}
	replaced := false
	for i := range repo.Releases {
		r := repo.Releases[i]
		if r.Version == release.Version && r.Channel == release.Channel && r.OS == release.OS && r.Arch == release.Arch {
			repo.Releases[i] = release
			replaced = true
			break
		}
	}
	if !replaced {
		repo.Releases = append(repo.Releases, release)
	}
	if err := s.writeRepository(repo); err != nil {
		return Release{}, err
	}
	return release, nil
}

func (s Service) writeRepository(repo Repository) error {
	raw, err := json.MarshalIndent(repo, "", "  ")
	if err != nil {
		return err
	}
	path := filepath.Join(s.Directory, "releases.json")
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, append(raw, '\n'), 0640); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}

func copyArtifact(source, destination string) error {
	in, err := os.Open(source)
	if err != nil {
		return err
	}
	defer in.Close()
	info, err := in.Stat()
	if err != nil {
		return err
	}
	if !info.Mode().IsRegular() {
		return errors.New("source artifact is not a regular file")
	}
	out, err := os.OpenFile(destination+".tmp", os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0750)
	if err != nil {
		return err
	}
	_, copyErr := io.Copy(out, in)
	syncErr := out.Sync()
	closeErr := out.Close()
	if copyErr != nil {
		_ = os.Remove(destination + ".tmp")
		return copyErr
	}
	if syncErr != nil {
		_ = os.Remove(destination + ".tmp")
		return syncErr
	}
	if closeErr != nil {
		_ = os.Remove(destination + ".tmp")
		return closeErr
	}
	return os.Rename(destination+".tmp", destination)
}

func hashFile(path string) (string, int64, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", 0, err
	}
	defer f.Close()
	h := sha256.New()
	n, err := io.Copy(h, f)
	if err != nil {
		return "", 0, err
	}
	return hex.EncodeToString(h.Sum(nil)), n, nil
}

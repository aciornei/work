package agentupdates

import "testing"

func TestCompareVersions(t *testing.T) {
	if compareVersions("1.3.0", "1.2.9") <= 0 {
		t.Fatal("expected newer")
	}
	if compareVersions("1.3.0", "1.3.0") != 0 {
		t.Fatal("expected equal")
	}
}

package agentupdates

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestLatest(t *testing.T) {
	dir := t.TempDir()
	files := filepath.Join(dir, "files")
	if err := os.MkdirAll(files, 0755); err != nil {
		t.Fatal(err)
	}
	agent := []byte("agent")
	upd := []byte("updater")
	if err := os.WriteFile(filepath.Join(files, "agent.bin"), agent, 0644); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(files, "updater.bin"), upd, 0644); err != nil {
		t.Fatal(err)
	}
	ah := sha256.Sum256(agent)
	uh := sha256.Sum256(upd)
	repo := Repository{Releases: []Release{{Version: "1.3.0", Channel: "stable", OS: "linux", Arch: "amd64", AgentFilename: "agent.bin", AgentSHA256: hex.EncodeToString(ah[:]), AgentSizeBytes: int64(len(agent)), UpdaterFilename: "updater.bin", UpdaterSHA256: hex.EncodeToString(uh[:]), UpdaterSizeBytes: int64(len(upd)), PublishedAt: time.Now().UTC()}}}
	raw, _ := json.Marshal(repo)
	if err := os.WriteFile(filepath.Join(dir, "releases.json"), raw, 0644); err != nil {
		t.Fatal(err)
	}
	svc := Service{Directory: dir}
	got, err := svc.Latest("stable", "linux", "amd64", "1.2.0")
	if err != nil {
		t.Fatal(err)
	}
	if !got.Available || got.Version != "1.3.0" {
		t.Fatalf("unexpected latest: %+v", got)
	}
	current, err := svc.Latest("stable", "linux", "amd64", "1.3.0")
	if err != nil {
		t.Fatal(err)
	}
	if current.Available {
		t.Fatalf("expected no update: %+v", current)
	}
}

package domain

import (
	"encoding/json"
	"time"
)

type User struct {
	ID          int64    `json:"id"`
	Username    string   `json:"username"`
	DisplayName string   `json:"display_name"`
	Email       string   `json:"email"`
	Source      string   `json:"source"`
	Groups      []string `json:"groups"`
	Roles       []string `json:"roles"`
	CSRFToken   string   `json:"csrf_token,omitempty"`
}

type Agent struct {
	ID                        int64      `json:"id"`
	SecretRef                 string     `json:"-"`
	Name                      string     `json:"name"`
	BaseURL                   string     `json:"base_url"`
	Enabled                   bool       `json:"enabled"`
	VerifyTLS                 bool       `json:"verify_tls"`
	TLSServerName             string     `json:"tls_server_name,omitempty"`
	TokenConfigured           bool       `json:"token_configured"`
	AgentUUID                 string     `json:"agent_uuid,omitempty"`
	AgentVersion              string     `json:"agent_version,omitempty"`
	CollectionIntervalSeconds int        `json:"collection_interval_seconds"`
	RequestTimeoutSeconds     int        `json:"request_timeout_seconds"`
	OfflineAfterSeconds       int        `json:"offline_after_seconds"`
	NextCollectionAt          *time.Time `json:"next_collection_at,omitempty"`
	LastAttemptAt             *time.Time `json:"last_attempt_at,omitempty"`
	LastContactAt             *time.Time `json:"last_contact_at,omitempty"`
	LastSuccessAt             *time.Time `json:"last_success_at,omitempty"`
	LastError                 string     `json:"last_error,omitempty"`
	CurrentInventoryID        *int64     `json:"current_inventory_id,omitempty"`
	Status                    string     `json:"status"`
	CreatedAt                 time.Time  `json:"created_at"`
	UpdatedAt                 time.Time  `json:"updated_at"`
}

type Job struct {
	ID           int64      `json:"id"`
	AgentID      int64      `json:"agent_id"`
	Kind         string     `json:"kind"`
	Source       string     `json:"source"`
	Status       string     `json:"status"`
	RequestedBy  *int64     `json:"requested_by_user_id,omitempty"`
	ScheduledAt  time.Time  `json:"scheduled_at"`
	StartedAt    *time.Time `json:"started_at,omitempty"`
	FinishedAt   *time.Time `json:"finished_at,omitempty"`
	AttemptCount int        `json:"attempt_count"`
	HTTPStatus   *int       `json:"http_status,omitempty"`
	DurationMS   *int64     `json:"duration_ms,omitempty"`
	ErrorCode    string     `json:"error_code,omitempty"`
	ErrorMessage string     `json:"error_message,omitempty"`
	CreatedAt    time.Time  `json:"created_at"`
}

type Inventory struct {
	ID                  int64      `json:"id"`
	AgentID             int64      `json:"agent_id"`
	CollectionJobID     int64      `json:"collection_job_id"`
	SchemaVersion       string     `json:"schema_version"`
	AgentUUID           string     `json:"agent_uuid"`
	AgentVersion        string     `json:"agent_version,omitempty"`
	Hostname            string     `json:"hostname"`
	FQDN                string     `json:"fqdn,omitempty"`
	ProductUUID         string     `json:"product_uuid,omitempty"`
	ProductUUIDLegacy   string     `json:"product_uuid_legacy,omitempty"`
	MachineID           string     `json:"machine_id,omitempty"`
	OSName              string     `json:"os_name"`
	OSVersion           string     `json:"os_version"`
	PrimaryIP           string     `json:"primary_ip"`
	BootTime            *time.Time `json:"boot_time,omitempty"`
	CollectorTotal      int        `json:"collector_total"`
	CollectorOK         int        `json:"collector_ok"`
	CollectorError      int        `json:"collector_error"`
	CollectorTimeout    int        `json:"collector_timeout"`
	PayloadSize         int64      `json:"payload_size"`
	PayloadSHA256       string     `json:"payload_sha256"`
	ChangedFromPrevious bool       `json:"changed_from_previous"`
	RawJSON             []byte     `json:"raw_json,omitempty"`
	CollectedAt         *time.Time `json:"collected_at,omitempty"`
	ReceivedAt          time.Time  `json:"received_at"`
}

// PrimaryAgentService reprezintă un serviciu software observat de agent pe VM
// și marcat explicit de operator ca fiind principal pentru documentația VM-ului.
type PrimaryAgentService struct {
	ServiceName    string `json:"service_name"`
	SoftwareName   string `json:"software_name,omitempty"`
	Version        string `json:"version,omitempty"`
	PackageName    string `json:"package_name,omitempty"`
	PackageVersion string `json:"package_version,omitempty"`
	VersionSource  string `json:"version_source,omitempty"`
	Manager        string `json:"manager,omitempty"`
	ActiveState    string `json:"active_state,omitempty"`
	SubState       string `json:"sub_state,omitempty"`
	EnabledState   string `json:"enabled_state,omitempty"`
	Description    string `json:"description,omitempty"`
	Detected       bool   `json:"detected"`
}

type VCenterSource struct {
	ID                 int64      `json:"id"`
	SecretRef          string     `json:"-"`
	Name               string     `json:"name"`
	BaseURL            string     `json:"base_url"`
	Username           string     `json:"username"`
	Enabled            bool       `json:"enabled"`
	VerifyTLS          bool       `json:"verify_tls"`
	TLSServerName      string     `json:"tls_server_name,omitempty"`
	PasswordConfigured bool       `json:"password_configured"`
	DailySyncEnabled   bool       `json:"daily_sync_enabled"`
	DailySyncTime      string     `json:"daily_sync_time"`
	LastSyncAt         *time.Time `json:"last_sync_at,omitempty"`
	LastSuccessAt      *time.Time `json:"last_success_at,omitempty"`
	LastError          string     `json:"last_error,omitempty"`
	CreatedAt          time.Time  `json:"created_at"`
	UpdatedAt          time.Time  `json:"updated_at"`
}

type VCenterSyncRun struct {
	ID                int64      `json:"id"`
	VCenterSourceID   int64      `json:"vcenter_source_id"`
	VCenterSourceName string     `json:"vcenter_source_name,omitempty"`
	Source            string     `json:"source"`
	Status            string     `json:"status"`
	RequestedByUserID *int64     `json:"requested_by_user_id,omitempty"`
	StartedAt         *time.Time `json:"started_at,omitempty"`
	FinishedAt        *time.Time `json:"finished_at,omitempty"`
	FoundCount        int        `json:"found_count"`
	CreatedCount      int        `json:"created_count"`
	UpdatedCount      int        `json:"updated_count"`
	MissingCount      int        `json:"missing_count"`
	LinkedAgentCount  int        `json:"linked_agent_count"`
	ErrorMessage      string     `json:"error_message,omitempty"`
	CreatedAt         time.Time  `json:"created_at"`
}

type VirtualMachine struct {
	ID                   int64           `json:"id"`
	VCenterSourceID      int64           `json:"vcenter_source_id"`
	VCenterSourceName    string          `json:"vcenter_source_name"`
	VCenterMoID          string          `json:"vcenter_moid"`
	InstanceUUID         string          `json:"instance_uuid,omitempty"`
	BIOSUUID             string          `json:"bios_uuid,omitempty"`
	Name                 string          `json:"name"`
	PowerState           string          `json:"power_state,omitempty"`
	CPUCount             int             `json:"cpu_count"`
	MemoryMiB            int64           `json:"memory_mib"`
	HardwareVersion      string          `json:"hardware_version,omitempty"`
	GuestOS              string          `json:"guest_os,omitempty"`
	GuestHostname        string          `json:"guest_hostname,omitempty"`
	PrimaryIP            string          `json:"primary_ip,omitempty"`
	CustomAttributesJSON json.RawMessage `json:"custom_attributes,omitempty"`
	Retired              bool            `json:"-"`
	RetiredAt            *time.Time      `json:"-"`
	RetiredBy            *int64          `json:"-"`
	RetiredNote          string          `json:"-"`
	PresentInVCenter     bool            `json:"present_in_vcenter"`
	FirstSeenAt          time.Time       `json:"first_seen_at"`
	LastSeenAt           time.Time       `json:"last_seen_at"`
	MissingSince         *time.Time      `json:"missing_since,omitempty"`
	LastVCenterSyncAt    *time.Time      `json:"last_vcenter_sync_at,omitempty"`
	AgentID              *int64          `json:"agent_id,omitempty"`
	AgentName            string          `json:"agent_name,omitempty"`
	AgentStatus          string          `json:"agent_status"`
	AgentLastContactAt   *time.Time      `json:"agent_last_contact_at,omitempty"`
	AgentLastSuccessAt   *time.Time      `json:"agent_last_success_at,omitempty"`
	AgentLastError       string          `json:"agent_last_error,omitempty"`
	CurrentInventoryID   *int64          `json:"current_inventory_id,omitempty"`
	InventoryHostname    string          `json:"inventory_hostname,omitempty"`
	InventoryOSName      string          `json:"inventory_os_name,omitempty"`
	InventoryOSVersion   string          `json:"inventory_os_version,omitempty"`
	InventoryPrimaryIP   string          `json:"inventory_primary_ip,omitempty"`
	InventoryReceivedAt  *time.Time      `json:"inventory_received_at,omitempty"`
	CreatedAt            time.Time       `json:"created_at"`
	UpdatedAt            time.Time       `json:"updated_at"`
}

type NomenclatureValue struct {
	ID           int64    `json:"id"`
	CategoryCode string   `json:"category_code"`
	Name         string   `json:"name"`
	ItemCode     string   `json:"item_code,omitempty"`
	Description  string   `json:"description,omitempty"`
	IconKey      string   `json:"icon_key,omitempty"`
	SortOrder    int      `json:"sort_order"`
	Active       bool     `json:"active"`
	ParentID     *int64   `json:"parent_id,omitempty"`
	ParentName   string   `json:"parent_name,omitempty"`
	LayerIDs     []int64  `json:"layer_ids,omitempty"`
	LayerNames   []string `json:"layer_names,omitempty"`
}

type NomenclatureCategory struct {
	Code      string              `json:"code"`
	Label     string              `json:"label"`
	SortOrder int                 `json:"sort_order"`
	Active    bool                `json:"active"`
	Items     []NomenclatureValue `json:"items"`
}

type Person struct {
	ID                int64     `json:"id"`
	DisplayName       string    `json:"display_name"`
	Email             string    `json:"email,omitempty"`
	Phone             string    `json:"phone,omitempty"`
	Department        string    `json:"department,omitempty"`
	Source            string    `json:"source"`
	DirectoryUsername string    `json:"directory_username,omitempty"`
	Active            bool      `json:"active"`
	CreatedAt         time.Time `json:"created_at"`
	UpdatedAt         time.Time `json:"updated_at"`
}

type VMResponsibility struct {
	ID                 int64  `json:"id"`
	PersonID           int64  `json:"person_id"`
	PersonName         string `json:"person_name"`
	PersonEmail        string `json:"person_email,omitempty"`
	PersonPhone        string `json:"person_phone,omitempty"`
	PersonDepartment   string `json:"person_department,omitempty"`
	ResponsibilityType string `json:"responsibility_type"`
	Notes              string `json:"notes,omitempty"`
	SortOrder          int    `json:"sort_order"`
}

type VMOperationalMetadata struct {
	VMID                int64                 `json:"vm_id"`
	EnvironmentID       *int64                `json:"environment_id,omitempty"`
	Environment         string                `json:"environment"`
	OperationalStatusID *int64                `json:"operational_status_id,omitempty"`
	OperationalStatus   string                `json:"operational_status"`
	Purpose             string                `json:"purpose"`
	ClassificationID    *int64                `json:"classification_id,omitempty"`
	Classification      string                `json:"classification"`
	DocumentationURL    string                `json:"documentation_url"`
	TicketReference     string                `json:"ticket_reference"`
	Notes               string                `json:"notes"`
	ServiceAssignments  []VMServiceAssignment `json:"service_assignments"`
	Responsibilities    []VMResponsibility    `json:"responsibilities"`
	UpdatedBy           *int64                `json:"updated_by,omitempty"`
	CreatedAt           time.Time             `json:"created_at"`
	UpdatedAt           time.Time             `json:"updated_at"`
}

type VMServiceAssignment struct {
	ID                    int64  `json:"id"`
	VMID                  int64  `json:"vm_id"`
	InternalServiceID     int64  `json:"internal_service_id"`
	InternalServiceName   string `json:"internal_service_name"`
	ITILCategoryID        int64  `json:"itil_category_id"`
	ITILCategory          string `json:"itil_category"`
	ArchitecturalDomainID *int64 `json:"architectural_domain_id,omitempty"`
	ArchitecturalDomain   string `json:"architectural_domain"`
	LayerID               *int64 `json:"layer_id,omitempty"`
	LayerName             string `json:"layer_name"`
	TechnicalRoleID       *int64 `json:"technical_role_id,omitempty"`
	TechnicalRole         string `json:"technical_role"`
	SolutionTypeID        *int64 `json:"solution_type_id,omitempty"`
	SolutionType          string `json:"solution_type,omitempty"`
	UsageType             string `json:"usage_type"`
	Primary               bool   `json:"is_primary"`
	Notes                 string `json:"notes,omitempty"`
	SortOrder             int    `json:"sort_order"`
}

type RichTextDocument struct {
	Version int             `json:"version"`
	Blocks  []RichTextBlock `json:"blocks"`
}

type RichTextBlock struct {
	Type  string        `json:"type"`
	Level int           `json:"level,omitempty"`
	Runs  []RichTextRun `json:"runs,omitempty"`
}

type RichTextRun struct {
	Text      string `json:"text"`
	Bold      bool   `json:"bold,omitempty"`
	Italic    bool   `json:"italic,omitempty"`
	Underline bool   `json:"underline,omitempty"`
}

type InternalService struct {
	ID int64 `json:"id"`
	// Câmpurile singulare sunt păstrate pentru compatibilitate. Începând cu
	// 0.4.0, încadrarea reală este calculată din Classifications.
	ITILCategoryID         int64                           `json:"itil_category_id,omitempty"`
	ITILCategory           string                          `json:"itil_category,omitempty"`
	ArchitecturalDomainID  *int64                          `json:"architectural_domain_id,omitempty"`
	ArchitecturalDomain    string                          `json:"architectural_domain,omitempty"`
	Name                   string                          `json:"name"`
	ServiceCode            string                          `json:"service_code,omitempty"`
	Description            string                          `json:"description,omitempty"`
	Purpose                string                          `json:"purpose,omitempty"` // compatibilitate: în UI este „Scop și domeniu”
	PurposeRichText        *RichTextDocument               `json:"purpose_richtext,omitempty"`
	Objectives             string                          `json:"objectives,omitempty"`
	ObjectivesRichText     *RichTextDocument               `json:"objectives_richtext,omitempty"`
	Criticality            string                          `json:"criticality"`
	DocumentationStatus    string                          `json:"documentation_status"`
	DocumentationURL       string                          `json:"documentation_url,omitempty"`
	Active                 bool                            `json:"active"`
	IsCommon               bool                            `json:"is_common"`
	ImplicitGlobal         bool                            `json:"implicit_global"`
	CommonDependencyTypeID *int64                          `json:"common_dependency_type_id,omitempty"`
	CommonDependencyType   string                          `json:"common_dependency_type,omitempty"`
	DependencyCount        int                             `json:"dependency_count"`
	DependentServiceCount  int                             `json:"dependent_service_count"`
	Dependencies           []ServiceDependency             `json:"dependencies,omitempty"`
	GlobalDependencies     []ServiceDependency             `json:"global_dependencies,omitempty"`
	Dependents             []ServiceDependency             `json:"dependents,omitempty"`
	DirectVMDependents     []VMDependencyImpact            `json:"direct_vm_dependents,omitempty"`
	VMCount                int                             `json:"vm_count"`
	ClassificationCount    int                             `json:"classification_count"`
	RoleMappingCount       int                             `json:"role_mapping_count"`
	SolutionTypeCount      int                             `json:"solution_type_count"`
	Classifications        []InternalServiceClassification `json:"classifications,omitempty"`
	RoleMappings           []ServiceRoleMapping            `json:"role_mappings,omitempty"`
	SolutionTypes          []InternalServiceSolutionType   `json:"solution_types,omitempty"`
	VMs                    []InternalServiceVM             `json:"vms,omitempty"`
	CreatedAt              time.Time                       `json:"created_at"`
	UpdatedAt              time.Time                       `json:"updated_at"`
}

type ServiceDependency struct {
	ID                 int64  `json:"id"`
	SourceServiceID    int64  `json:"source_service_id,omitempty"`
	SourceServiceName  string `json:"source_service_name,omitempty"`
	TargetServiceID    int64  `json:"target_service_id"`
	TargetServiceName  string `json:"target_service_name"`
	DependencyTypeID   int64  `json:"dependency_type_id"`
	DependencyType     string `json:"dependency_type"`
	DependencyTypeIcon string `json:"dependency_type_icon,omitempty"`
	Notes              string `json:"notes,omitempty"`
	Global             bool   `json:"global"`
	Direct             bool   `json:"direct,omitempty"`
	Inherited          bool   `json:"inherited,omitempty"`
	SourceLabel        string `json:"source_label,omitempty"`
	TargetVMCount      int    `json:"target_vm_count"`
	TargetVMNames      string `json:"target_vm_names,omitempty"`
}

type VMDependencyImpact struct {
	VMID             int64  `json:"vm_id"`
	VMName           string `json:"vm_name"`
	DependencyTypeID int64  `json:"dependency_type_id"`
	DependencyType   string `json:"dependency_type"`
	Notes            string `json:"notes,omitempty"`
}

type InternalServiceClassification struct {
	ArchitecturalDomainID int64  `json:"architectural_domain_id"`
	ArchitecturalDomain   string `json:"architectural_domain"`
	ITILCategoryID        int64  `json:"itil_category_id"`
	ITILCategory          string `json:"itil_category"`
	VMCount               int    `json:"vm_count"`
	AssignmentCount       int    `json:"assignment_count"`
}

type InternalServiceSolutionType struct {
	SolutionTypeID  int64  `json:"solution_type_id"`
	SolutionType    string `json:"solution_type"`
	VMCount         int    `json:"vm_count"`
	AssignmentCount int    `json:"assignment_count"`
}

type ServiceRoleMapping struct {
	ID              int64  `json:"id"`
	LayerID         int64  `json:"layer_id"`
	LayerName       string `json:"layer_name"`
	TechnicalRoleID int64  `json:"technical_role_id"`
	TechnicalRole   string `json:"technical_role"`
	SortOrder       int    `json:"sort_order"`
	Active          bool   `json:"active"`
	VMCount         int    `json:"vm_count"`
}

type InternalServiceVM struct {
	AssignmentID          int64      `json:"assignment_id"`
	ID                    int64      `json:"id"`
	Name                  string     `json:"name"`
	PowerState            string     `json:"power_state"`
	GuestHostname         string     `json:"guest_hostname,omitempty"`
	PrimaryIP             string     `json:"primary_ip,omitempty"`
	Environment           string     `json:"environment,omitempty"`
	LatestDocumentID      *int64     `json:"latest_document_id,omitempty"`
	LatestDocumentNumber  string     `json:"latest_document_number,omitempty"`
	LatestDocumentAt      *time.Time `json:"latest_document_at,omitempty"`
	ArchitecturalDomainID int64      `json:"architectural_domain_id"`
	ArchitecturalDomain   string     `json:"architectural_domain"`
	ITILCategoryID        int64      `json:"itil_category_id"`
	ITILCategory          string     `json:"itil_category"`
	LayerID               *int64     `json:"layer_id,omitempty"`
	LayerName             string     `json:"layer_name,omitempty"`
	TechnicalRoleID       *int64     `json:"technical_role_id,omitempty"`
	TechnicalRole         string     `json:"technical_role,omitempty"`
	SolutionTypeID        *int64     `json:"solution_type_id,omitempty"`
	SolutionType          string     `json:"solution_type,omitempty"`
	UsageType             string     `json:"usage_type"`
	Primary               bool       `json:"is_primary"`
	Notes                 string     `json:"notes,omitempty"`
}

type VMBackupSummary struct {
	VMID           int64           `json:"vm_id"`
	Provider       string          `json:"provider"`
	SourceName     string          `json:"source_name,omitempty"`
	Protected      bool            `json:"protected"`
	JobName        string          `json:"job_name,omitempty"`
	PolicyName     string          `json:"policy_name,omitempty"`
	RepositoryName string          `json:"repository_name,omitempty"`
	LastResult     string          `json:"last_result,omitempty"`
	LastBackupAt   *time.Time      `json:"last_backup_at,omitempty"`
	NextRunAt      *time.Time      `json:"next_run_at,omitempty"`
	RestorePoints  *int            `json:"restore_points,omitempty"`
	RPOMinutes     *int            `json:"rpo_minutes,omitempty"`
	RTOMinutes     *int            `json:"rto_minutes,omitempty"`
	SyncedAt       *time.Time      `json:"synced_at,omitempty"`
	ErrorMessage   string          `json:"error_message,omitempty"`
	RawJSON        json.RawMessage `json:"-"`
	UpdatedAt      time.Time       `json:"updated_at"`
}

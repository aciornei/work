#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
install -d -m 0755 /opt/vm-doc-server/bin /etc/vm-doc-server /etc/vm-doc-server/ca /var/lib/vm-doc-server /var/lib/vm-doc-server/agent-updates
id vm-doc >/dev/null 2>&1 || useradd --system --home /var/lib/vm-doc-server --shell /usr/sbin/nologin vm-doc
install -m 0755 "$ROOT/bin/vm-doc-server" /opt/vm-doc-server/bin/
install -m 0755 "$ROOT/bin/vm-doc-collector" /opt/vm-doc-server/bin/
[ ! -x "$ROOT/bin/vm-doc-agent-release" ] || install -m 0755 "$ROOT/bin/vm-doc-agent-release" /opt/vm-doc-server/bin/
[ -f /etc/vm-doc-server/config.yaml ] || install -m 0640 "$ROOT/configs/config.example.yaml" /etc/vm-doc-server/config.yaml
install -m 0644 "$ROOT/deploy/systemd/vm-doc-server.service" /etc/systemd/system/
install -m 0644 "$ROOT/deploy/systemd/vm-doc-collector.service" /etc/systemd/system/
chown -R root:vm-doc /etc/vm-doc-server
chmod 0750 /etc/vm-doc-server
[ ! -f /etc/vm-doc-server/config.yaml ] || chmod 0640 /etc/vm-doc-server/config.yaml
[ ! -f /etc/vm-doc-server/secrets.enc ] || chmod 0640 /etc/vm-doc-server/secrets.enc
[ ! -f /etc/vm-doc-server/master.key ] || chmod 0600 /etc/vm-doc-server/master.key
chown -R vm-doc:vm-doc /var/lib/vm-doc-server /var/lib/vm-doc-server/agent-updates
systemctl daemon-reload
echo "Edit /etc/vm-doc-server/config.yaml, create master.key and secrets.enc, then enable both services."

# Securitate

Agentul rulează ca root deoarece trebuie să citească `/etc/shadow`, regulile firewall și crontab-urile tuturor utilizatorilor.

## Date excluse

Agentul nu salvează:

- hash-uri de parole;
- bind password SSSD/LDAP;
- API keys sau tokenuri Beats;
- chei private;
- argumentele complete ale proceselor.

Credentialele din URL-uri și valorile recunoscute ca `password`, `token`, `secret`, `api_key` sau `access_key` sunt mascate best-effort.

## Token API

```text
/etc/vm-doc-agent/token
```

Permisiuni așteptate:

```text
0600 root:root
```

## Firewall recomandat

Portul `9078` trebuie permis numai de la IP-ul nodului central sau din rețeaua de management.

Versiunea 1.0.0 folosește HTTP cu token Bearer. TLS/mTLS este recomandat înainte de expunerea în rețele neîncrezătoare și va fi implementat împreună cu nodul central.

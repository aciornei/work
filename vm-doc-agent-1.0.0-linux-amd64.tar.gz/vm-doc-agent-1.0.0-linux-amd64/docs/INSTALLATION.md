# Instalare și update

## Instalare nouă

```bash
tar -xzf vm-doc-agent-1.0.0-linux-amd64.tar.gz
cd vm-doc-agent-1.0.0-linux-amd64
sudo ./install.sh
```

Installerul detectează automat systemd sau SysV.

## Verificare systemd

```bash
systemctl status vm-doc-agent
journalctl -u vm-doc-agent -f
```

## Verificare SysV

```bash
/etc/init.d/vm-doc-agent status
tail -f /var/log/vm-doc-agent.log
```

## Update

```bash
sudo ./update.sh
```

Updaterul:

1. validează configurația cu noul binar;
2. oprește serviciul;
3. salvează binarul anterior ca `vm-doc-agent.previous`;
4. actualizează binarul, serviciul și logrotate;
5. pornește serviciul;
6. revine la binarul anterior dacă pornirea eșuează.

## Dezinstalare

Păstrează configurația și datele:

```bash
sudo ./uninstall.sh
```

Șterge și configurația, tokenul, inventarul, logurile și identitatea agentului:

```bash
sudo ./uninstall.sh --purge
```

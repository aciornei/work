# Configurație

Fișier implicit:

```text
/etc/vm-doc-agent/config.json
```

Configurație completă:

```json
{
  "listen": "0.0.0.0:9078",
  "output_file": "/var/lib/vm-doc-agent/inventory.json",
  "state_dir": "/var/lib/vm-doc-agent",
  "refresh_interval": "15m",
  "auth_token_file": "/etc/vm-doc-agent/token",
  "collector_timeout": "20s",
  "output_test_timeout": "12s",
  "collectors": {
    "system": true,
    "storage": true,
    "network": true,
    "proxy": true,
    "services": true,
    "listening_ports": true,
    "firewall": true,
    "accounts": true,
    "sssd": true,
    "integrations": true,
    "policies": true,
    "cron": true,
    "ntp": true
  },
  "limits": {
    "max_partitions": 1000,
    "max_routes": 5000,
    "max_services": 5000,
    "max_ports": 5000,
    "max_firewall_rules": 10000,
    "max_firewall_zones": 1000,
    "max_accounts": 10000,
    "max_cron_entries": 5000,
    "max_cron_scripts": 5000,
    "max_policy_files": 10000,
    "max_inventory_bytes": 20971520
  },
  "policy_paths": []
}
```

## Validare

```bash
/usr/local/sbin/vm-doc-agent \
  -config /etc/vm-doc-agent/config.json \
  -check-config
```

Câmpurile necunoscute produc eroare, pentru a evita greșelile de scriere.

## Dezactivarea unui colector

```json
"collectors": {
  "cron": false,
  "accounts": false
}
```

Un colector dezactivat apare în inventar cu status `disabled`.

## Politici organizaționale

```json
"policy_paths": [
  "/etc/company/policies/*",
  "/opt/company/policy-markers",
  "/etc/company/hardening.conf"
]
```

Agentul salvează metadata și SHA256, nu conținutul complet.

## Timeout-uri

- `collector_timeout`: timpul maxim acordat unui colector;
- `output_test_timeout`: timpul maxim pentru `filebeat test output` și `auditbeat test output`.

Dacă un colector depășește timeout-ul, restul colectării continuă.

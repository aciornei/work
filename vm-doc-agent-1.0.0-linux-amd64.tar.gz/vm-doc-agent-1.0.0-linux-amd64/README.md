# vm-doc-agent 1.0.0

Agent Linux universal pentru colectarea inventarului local necesar fișei VM. Același binar static și același pachet se instalează pe Ubuntu, Debian, CentOS/RHEL și SUSE, inclusiv sisteme vechi cu SysV Init.

Agentul:

- detectează automat distribuția și sistemul de inițializare;
- scrie un inventar JSON local;
- păstrează ultima versiune validă a inventarului;
- expune un API HTTP protejat cu token Bearer;
- raportează separat starea și durata fiecărui colector;
- permite activarea/dezactivarea individuală a colectoarelor;
- limitează dimensiunea inventarului;
- oferă comenzi de diagnostic și validare.

CPU și RAM nu sunt colectate intenționat; acestea vor fi preluate ulterior din vCenter.

## Sisteme vizate

- Ubuntu 20.04 și mai noi;
- Debian, inclusiv versiuni vechi cu SysV;
- CentOS 7, RHEL, Rocky, AlmaLinux și Oracle Linux;
- SUSE Linux Enterprise Server 11 și mai noi;
- arhitectură `x86_64/amd64`.

## Instalare

```bash
tar -xzf vm-doc-agent-1.0.0-linux-amd64.tar.gz
cd vm-doc-agent-1.0.0-linux-amd64
sudo ./install.sh
```

Verificare:

```bash
/usr/local/sbin/vm-doc-agent -version
curl http://127.0.0.1:9078/health
TOKEN=$(sudo cat /etc/vm-doc-agent/token)
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/status
```

## Update de la 0.5.x

```bash
tar -xzf vm-doc-agent-1.0.0-linux-amd64.tar.gz
cd vm-doc-agent-1.0.0-linux-amd64
sudo ./update.sh
```

Configurația veche rămâne validă. Câmpurile noi primesc valori implicite dacă lipsesc. Sunt păstrate tokenul, `agent-id`, inventarul și configurația.

## Date colectate

- identitate host, distribuție, kernel, UUID DMI/SMBIOS și identificatori de corelare;
- partiții montate;
- interfețe, IP-uri, DNS, rute și gateway-uri implicite;
- timezone, boot time și uptime;
- proxy configurat, cu credentialele mascate;
- servicii systemd/SysV;
- porturi TCP/UDP ascultate și procese asociate;
- firewall local;
- utilizatori locali, expirarea parolei și politica de complexitate;
- SSSD;
- GLPI Agent, Node Exporter, Auditbeat, Filebeat și syslog;
- output-urile Filebeat/Auditbeat fără secrete;
- politici SELinux/AppArmor, audit, sudoers, limits, sysctl și markeri custom;
- crontab și scripturi periodice;
- NTP.

## Fișiere instalate

```text
/usr/local/sbin/vm-doc-agent
/etc/vm-doc-agent/config.json
/etc/vm-doc-agent/token
/var/lib/vm-doc-agent/agent-id
/var/lib/vm-doc-agent/inventory.json
/var/lib/vm-doc-agent/inventory.json.previous
```

Pe systemd:

```text
/etc/systemd/system/vm-doc-agent.service
```

Pe SysV:

```text
/etc/init.d/vm-doc-agent
/var/log/vm-doc-agent.log
/etc/logrotate.d/vm-doc-agent
```

## Comenzi administrative

```bash
vm-doc-agent -version
vm-doc-agent -config /etc/vm-doc-agent/config.json -check-config
vm-doc-agent -config /etc/vm-doc-agent/config.json -collect-once
vm-doc-agent -config /etc/vm-doc-agent/config.json -print-inventory
vm-doc-agent -config /etc/vm-doc-agent/config.json -diagnostics
```

## API

`GET /health` este public. Endpoint-urile `/v1/*` necesită token Bearer.

```bash
TOKEN=$(sudo cat /etc/vm-doc-agent/token)

curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/status
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/inventory
curl -X POST -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/inventory/refresh
```

## Documentație

- [Instalare și update](docs/INSTALLATION.md)
- [Configurație](docs/CONFIGURATION.md)
- [API](docs/API.md)
- [Schema inventarului](docs/INVENTORY-SCHEMA.md)
- [Arhitectură](docs/ARCHITECTURE.md)
- [Operațiuni și diagnostic](docs/OPERATIONS.md)
- [Securitate](docs/SECURITY.md)
- [Troubleshooting](docs/TROUBLESHOOTING.md)

## Build

Go este necesar numai pe mașina de build:

```bash
./scripts/build.sh
./scripts/package.sh
```

Binarul este static, `linux/amd64`, `CGO_ENABLED=0`, `GOAMD64=v1`.

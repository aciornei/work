# Changelog

## 1.0.0

Prima versiune stabilă a agentului.

### Adăugat

- status individual pentru fiecare colector: `success`, `partial`, `timeout`, `error`, `disabled`;
- endpoint `GET /v1/status`;
- comenzi `-check-config`, `-collect-once`, `-print-inventory`, `-diagnostics`;
- activare/dezactivare individuală a colectoarelor;
- timeout global pentru colectoare și timeout separat pentru testarea output-urilor Beats;
- DNS, rute, gateway-uri, proxy, timezone, boot time și uptime;
- păstrarea atomică a `inventory.json.previous`;
- limite configurabile și metadata de truncare;
- loguri structurate și logrotate pentru SysV;
- documentație completă în `docs/`.

### Modificat

- schema JSON a trecut la `2.0`;
- installerul și updaterul validează configurația înainte de pornire;
- updaterul actualizează și fișierele de serviciu/logrotate;
- API-ul adaugă `Cache-Control: no-store` și jurnalizare cu status HTTP.

### Compatibilitate

Configurațiile 0.5.x fără câmpurile noi sunt acceptate și primesc valorile implicite din 1.0.0.

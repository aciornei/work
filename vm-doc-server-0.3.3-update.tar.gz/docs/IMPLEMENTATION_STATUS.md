# Implementation status 0.3.3

## Implementat

- surse vCenter cu secrete criptate;
- sincronizare asincronă și programare zilnică;
- upsert VM, marcaj missing și lifecycle Retired;
- corelare automată/manuală cu agentul;
- listă VM bazată pe vCenter și fișă tehnică structurată;
- căutare, filtre, paginare și export Excel;
- date operaționale independente de inventarul automat;
- catalog ierarhic: domeniu arhitectural, categorie ITIL și serviciu intern;
- meniu separat **Servicii** cu pagină de detaliu și VM-uri asociate;
- combinații layer–rol permise pentru fiecare serviciu;
- selecție în cascadă în fișa VM și validare server-side a întregii ramuri;
- nomenclatoare administrabile pentru domenii, categorii ITIL, layer-e, roluri tehnice, medii, statusuri, profile și clasificări;
- registru de persoane și responsabilități multiple pe VM;
- structură separată de backup, pregătită pentru Veeam API;
- inventar agent structurat și sanitizat;
- migrații, audit, RBAC și OpenAPI actualizate.

## Validare efectuată în mediul de generare

- `gofmt` pentru codul Go modificat;
- teste unitare pentru pachetele `catalog` și `nomenclature`;
- compilare izolată a noului model operațional din `vcenter/metadata.go`;
- verificare sintactică JavaScript cu `node --check`;
- validare YAML pentru OpenAPI;
- verificare shell pentru scripturile proiectului;
- verificarea aplicării arhivei incrementale peste sursa 0.3.1.

## Validare necesară în mediul offline final

Arhiva standard nu include `vendor/`. În sursa offline care păstrează dependențele executați:

```bash
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

## Limitări

- datele efective din Veeam API nu sunt încă sincronizate;
- serviciile nu au încă dependențe și responsabilități proprii; modelul poate fi extins fără schimbarea relației VM–serviciu;
- un VM are în prezent un singur serviciu intern principal;
- generarea DOCX/PDF nu este încă implementată;
- VM-urile partajate vor necesita ulterior relații secundare pentru referințe în documentațiile mai multor servicii;
- custom attributes generale din vCenter nu sunt încă extrase;
- nu există încă worker automat pentru retenția inventarelor și auditului.

## Actualizare 0.3.3

- secțiunile inventarului agentului sunt restrânse implicit;
- istoricul snapshoturilor este paginat server-side;
- auditul este paginat server-side;
- nu este necesară o migrare SQL nouă.

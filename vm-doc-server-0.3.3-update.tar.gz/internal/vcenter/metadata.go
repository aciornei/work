package vcenter

import (
	"context"
	"database/sql"
	"errors"
	"net/mail"
	"net/url"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/domain"
)

var operationalCategories = []struct {
	Code string
	ID   func(*OperationalMetadataInput) *int64
	Name func(*OperationalMetadataInput) string
}{
	{"environment", func(v *OperationalMetadataInput) *int64 { return v.EnvironmentID }, func(v *OperationalMetadataInput) string { return v.Environment }},
	{"operational_status", func(v *OperationalMetadataInput) *int64 { return v.OperationalStatusID }, func(v *OperationalMetadataInput) string { return v.OperationalStatus }},
	{"provisioning_profile", func(v *OperationalMetadataInput) *int64 { return v.ProvisioningProfileID }, func(v *OperationalMetadataInput) string { return v.ProvisioningProfile }},
	{"classification", func(v *OperationalMetadataInput) *int64 { return v.ClassificationID }, func(v *OperationalMetadataInput) string { return v.Classification }},
}

var allowedResponsibilityTypes = map[string]bool{
	"technical_admin":      true,
	"service_owner":        true,
	"business_owner":       true,
	"application_owner":    true,
	"infrastructure_owner": true,
	"security_contact":     true,
	"backup_contact":       true,
	"other":                true,
}

type ResponsibilityInput struct {
	PersonID           int64  `json:"person_id"`
	ResponsibilityType string `json:"responsibility_type"`
	Notes              string `json:"notes"`
	SortOrder          int    `json:"sort_order"`
}

type OperationalMetadataInput struct {
	ITILCategoryID        *int64 `json:"itil_category_id"`
	InternalServiceID     *int64 `json:"internal_service_id"`
	ArchitecturalDomainID *int64 `json:"architectural_domain_id"`
	LayerID               *int64 `json:"layer_id"`
	TechnicalRoleID       *int64 `json:"technical_role_id"`
	EnvironmentID         *int64 `json:"environment_id"`
	OperationalStatusID   *int64 `json:"operational_status_id"`
	ProvisioningProfileID *int64 `json:"provisioning_profile_id"`
	ClassificationID      *int64 `json:"classification_id"`

	Purpose          string `json:"purpose"`
	ProvisionedAt    string `json:"provisioned_at"`
	DocumentationURL string `json:"documentation_url"`
	TicketReference  string `json:"ticket_reference"`
	Notes            string `json:"notes"`

	Responsibilities []ResponsibilityInput `json:"responsibilities"`

	// Compatibility with forms prior to 0.3.2.
	ServiceID           *int64 `json:"service_id,omitempty"`
	ComponentID         *int64 `json:"component_id,omitempty"`
	ServiceName         string `json:"service_name,omitempty"`
	ComponentName       string `json:"component_name,omitempty"`
	ArchitecturalDomain string `json:"architectural_domain,omitempty"`
	LayerName           string `json:"layer_name,omitempty"`
	Environment         string `json:"environment,omitempty"`
	OperationalStatus   string `json:"operational_status,omitempty"`
	TechnicalAdmin      string `json:"technical_admin,omitempty"`
	BusinessOwner       string `json:"business_owner,omitempty"`
	OwnerEmail          string `json:"owner_email,omitempty"`
	ProvisioningProfile string `json:"provisioning_profile,omitempty"`
	BackupPolicy        string `json:"backup_policy,omitempty"`
	RPOMinutes          *int   `json:"rpo_minutes,omitempty"`
	RTOMinutes          *int   `json:"rto_minutes,omitempty"`
	Classification      string `json:"classification,omitempty"`
}

type resolvedNomenclature struct {
	ID   int64
	Name string
}

type resolvedServiceAssignment struct {
	InternalServiceID     int64
	InternalServiceName   string
	ITILCategoryID        int64
	ITILCategory          string
	ArchitecturalDomainID *int64
	ArchitecturalDomain   string
	LayerID               *int64
	LayerName             string
	TechnicalRoleID       *int64
	TechnicalRole         string
}

func (s *Service) GetOperationalMetadata(ctx context.Context, vmID int64) (domain.VMOperationalMetadata, error) {
	value := domain.VMOperationalMetadata{VMID: vmID, Responsibilities: make([]domain.VMResponsibility, 0)}
	var provisionedAt sql.NullTime
	var updatedBy sql.NullInt64
	err := s.DB.QueryRowContext(ctx, `SELECT vm_id,service_name,component_name,architectural_domain,layer_name,environment,operational_status,purpose,provisioning_profile,provisioned_at,classification,documentation_url,ticket_reference,notes,updated_by,created_at,updated_at FROM vm_operational_metadata WHERE vm_id=?`, vmID).Scan(
		&value.VMID, &value.ServiceName, &value.ComponentName, &value.ArchitecturalDomain, &value.LayerName, &value.Environment, &value.OperationalStatus, &value.Purpose, &value.ProvisioningProfile, &provisionedAt, &value.Classification, &value.DocumentationURL, &value.TicketReference, &value.Notes, &updatedBy, &value.CreatedAt, &value.UpdatedAt,
	)
	if err != nil && !errors.Is(err, sql.ErrNoRows) {
		return value, err
	}
	if provisionedAt.Valid {
		value.ProvisionedAt = provisionedAt.Time.Format("2006-01-02")
	}
	if updatedBy.Valid {
		n := updatedBy.Int64
		value.UpdatedBy = &n
	}
	if err := s.loadOperationalNomenclatures(ctx, &value); err != nil {
		return value, err
	}
	if err := s.loadInternalServiceAssignment(ctx, &value); err != nil {
		return value, err
	}
	responsibilities, err := s.listResponsibilities(ctx, vmID)
	if err != nil {
		return value, err
	}
	value.Responsibilities = responsibilities
	return value, nil
}

func (s *Service) loadOperationalNomenclatures(ctx context.Context, value *domain.VMOperationalMetadata) error {
	rows, err := s.DB.QueryContext(ctx, `SELECT m.category_code,n.id,n.name FROM vm_operational_nomenclatures m JOIN nomenclature_items n ON n.id=m.item_id WHERE m.vm_id=?`, value.VMID)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var code, name string
		var id int64
		if err := rows.Scan(&code, &id, &name); err != nil {
			return err
		}
		switch code {
		case "service":
			value.ServiceID, value.ServiceName = int64Ptr(id), name
		case "component":
			value.ComponentID, value.ComponentName = int64Ptr(id), name
		case "architectural_domain":
			value.ArchitecturalDomainID, value.ArchitecturalDomain = int64Ptr(id), name
		case "layer":
			value.LayerID, value.LayerName = int64Ptr(id), name
		case "environment":
			value.EnvironmentID, value.Environment = int64Ptr(id), name
		case "operational_status":
			value.OperationalStatusID, value.OperationalStatus = int64Ptr(id), name
		case "provisioning_profile":
			value.ProvisioningProfileID, value.ProvisioningProfile = int64Ptr(id), name
		case "classification":
			value.ClassificationID, value.Classification = int64Ptr(id), name
		}
	}
	return rows.Err()
}

func (s *Service) loadInternalServiceAssignment(ctx context.Context, value *domain.VMOperationalMetadata) error {
	var assignment resolvedServiceAssignment
	var domainID, layerID, roleID sql.NullInt64
	var domainName, layerName, roleName sql.NullString
	err := s.DB.QueryRowContext(ctx, `SELECT service.id,service.name,category_item.id,category_item.name,parent_relation.parent_item_id,domain_item.name,assignment.layer_id,layer_item.name,assignment.technical_role_id,role_item.name
		FROM vm_internal_service_assignments assignment
		JOIN internal_services service ON service.id=assignment.internal_service_id
		JOIN nomenclature_items category_item ON category_item.id=service.itil_category_id
		LEFT JOIN nomenclature_item_parents parent_relation ON parent_relation.child_item_id=category_item.id
		LEFT JOIN nomenclature_items domain_item ON domain_item.id=parent_relation.parent_item_id
		LEFT JOIN nomenclature_items layer_item ON layer_item.id=assignment.layer_id
		LEFT JOIN nomenclature_items role_item ON role_item.id=assignment.technical_role_id
		WHERE assignment.vm_id=?`, value.VMID).Scan(&assignment.InternalServiceID, &assignment.InternalServiceName, &assignment.ITILCategoryID, &assignment.ITILCategory, &domainID, &domainName, &layerID, &layerName, &roleID, &roleName)
	if errors.Is(err, sql.ErrNoRows) {
		// Preserve readable labels for legacy rows that could not be migrated.
		value.ITILCategory = value.ServiceName
		value.InternalServiceName = value.ComponentName
		return nil
	}
	if err != nil {
		return err
	}
	if domainID.Valid {
		id := domainID.Int64
		assignment.ArchitecturalDomainID = &id
	}
	if domainName.Valid {
		assignment.ArchitecturalDomain = domainName.String
	}
	if layerID.Valid {
		id := layerID.Int64
		assignment.LayerID = &id
	}
	if layerName.Valid {
		assignment.LayerName = layerName.String
	}
	if roleID.Valid {
		id := roleID.Int64
		assignment.TechnicalRoleID = &id
	}
	if roleName.Valid {
		assignment.TechnicalRole = roleName.String
	}
	value.InternalServiceID = int64Ptr(assignment.InternalServiceID)
	value.InternalServiceName = assignment.InternalServiceName
	value.ITILCategoryID = int64Ptr(assignment.ITILCategoryID)
	value.ITILCategory = assignment.ITILCategory
	value.ArchitecturalDomainID = assignment.ArchitecturalDomainID
	value.ArchitecturalDomain = assignment.ArchitecturalDomain
	value.LayerID = assignment.LayerID
	value.LayerName = assignment.LayerName
	value.TechnicalRoleID = assignment.TechnicalRoleID
	value.TechnicalRole = assignment.TechnicalRole
	// Compatibility aliases.
	value.ServiceID, value.ServiceName = value.ITILCategoryID, value.ITILCategory
	value.ComponentID, value.ComponentName = value.InternalServiceID, value.InternalServiceName
	return nil
}

func (s *Service) listResponsibilities(ctx context.Context, vmID int64) ([]domain.VMResponsibility, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT r.id,r.person_id,p.display_name,p.email,p.phone,p.department,r.responsibility_type,r.notes,r.sort_order FROM vm_responsibilities r JOIN people p ON p.id=r.person_id WHERE r.vm_id=? ORDER BY r.sort_order,r.id`, vmID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.VMResponsibility, 0)
	for rows.Next() {
		var value domain.VMResponsibility
		if err := rows.Scan(&value.ID, &value.PersonID, &value.PersonName, &value.PersonEmail, &value.PersonPhone, &value.PersonDepartment, &value.ResponsibilityType, &value.Notes, &value.SortOrder); err != nil {
			return nil, err
		}
		out = append(out, value)
	}
	return out, rows.Err()
}

func (s *Service) SaveOperationalMetadata(ctx context.Context, vmID, userID int64, input OperationalMetadataInput) (domain.VMOperationalMetadata, error) {
	if err := normalizeOperationalMetadata(&input); err != nil {
		return domain.VMOperationalMetadata{}, err
	}
	var vmExists int
	if err := s.DB.QueryRowContext(ctx, `SELECT 1 FROM virtual_machines WHERE id=?`, vmID).Scan(&vmExists); err != nil {
		return domain.VMOperationalMetadata{}, err
	}
	resolved, err := s.resolveOperationalNomenclatures(ctx, &input)
	if err != nil {
		return domain.VMOperationalMetadata{}, err
	}
	serviceAssignment, err := s.resolveInternalServiceAssignment(ctx, &input)
	if err != nil {
		return domain.VMOperationalMetadata{}, err
	}
	responsibilities, err := s.resolveLegacyResponsibilities(ctx, input)
	if err != nil {
		return domain.VMOperationalMetadata{}, err
	}
	if err := validateResponsibilities(ctx, s.DB, responsibilities); err != nil {
		return domain.VMOperationalMetadata{}, err
	}

	var provisionedAt any
	for _, item := range []*int64{input.ITILCategoryID, input.InternalServiceID, input.ArchitecturalDomainID, input.LayerID, input.TechnicalRoleID, input.EnvironmentID, input.OperationalStatusID, input.ProvisioningProfileID, input.ClassificationID, input.ServiceID, input.ComponentID} {
		if item != nil && *item < 0 {
			return domain.VMOperationalMetadata{}, errors.New("identifier values must be positive")
		}
	}

	if input.ProvisionedAt != "" {
		parsed, _ := time.Parse("2006-01-02", input.ProvisionedAt)
		provisionedAt = parsed
	}
	labels := func(code string) string {
		if value, ok := resolved[code]; ok {
			return value.Name
		}
		return ""
	}
	var categoryName, serviceName, domainName, layerName string
	if serviceAssignment != nil {
		categoryName = serviceAssignment.ITILCategory
		serviceName = serviceAssignment.InternalServiceName
		domainName = serviceAssignment.ArchitecturalDomain
		layerName = serviceAssignment.LayerName
	}
	legacyAdmin, legacyOwner, legacyEmail := legacyResponsibilityFields(ctx, s.DB, responsibilities)

	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return domain.VMOperationalMetadata{}, err
	}
	defer tx.Rollback()
	_, err = tx.ExecContext(ctx, `INSERT INTO vm_operational_metadata(vm_id,service_name,component_name,architectural_domain,layer_name,environment,operational_status,purpose,technical_admin,business_owner,owner_email,provisioning_profile,provisioned_at,rpo_minutes,rto_minutes,backup_policy,classification,documentation_url,ticket_reference,notes,updated_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,NULL,NULL,'',?,?,?,?,?) ON DUPLICATE KEY UPDATE service_name=VALUES(service_name),component_name=VALUES(component_name),architectural_domain=VALUES(architectural_domain),layer_name=VALUES(layer_name),environment=VALUES(environment),operational_status=VALUES(operational_status),purpose=VALUES(purpose),technical_admin=VALUES(technical_admin),business_owner=VALUES(business_owner),owner_email=VALUES(owner_email),provisioning_profile=VALUES(provisioning_profile),provisioned_at=VALUES(provisioned_at),classification=VALUES(classification),documentation_url=VALUES(documentation_url),ticket_reference=VALUES(ticket_reference),notes=VALUES(notes),updated_by=VALUES(updated_by)`,
		vmID, categoryName, serviceName, domainName, layerName, labels("environment"), labels("operational_status"), input.Purpose, legacyAdmin, legacyOwner, legacyEmail, labels("provisioning_profile"), provisionedAt, labels("classification"), input.DocumentationURL, input.TicketReference, input.Notes, userID,
	)
	if err != nil {
		return domain.VMOperationalMetadata{}, err
	}
	if _, err := tx.ExecContext(ctx, `DELETE FROM vm_operational_nomenclatures WHERE vm_id=?`, vmID); err != nil {
		return domain.VMOperationalMetadata{}, err
	}
	for code, value := range resolved {
		if _, err := tx.ExecContext(ctx, `INSERT INTO vm_operational_nomenclatures(vm_id,category_code,item_id) VALUES(?,?,?)`, vmID, code, value.ID); err != nil {
			return domain.VMOperationalMetadata{}, err
		}
	}
	if serviceAssignment == nil {
		if _, err := tx.ExecContext(ctx, `DELETE FROM vm_internal_service_assignments WHERE vm_id=?`, vmID); err != nil {
			return domain.VMOperationalMetadata{}, err
		}
	} else {
		if _, err := tx.ExecContext(ctx, `INSERT INTO vm_internal_service_assignments(vm_id,internal_service_id,layer_id,technical_role_id,updated_by) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE internal_service_id=VALUES(internal_service_id),layer_id=VALUES(layer_id),technical_role_id=VALUES(technical_role_id),updated_by=VALUES(updated_by)`, vmID, serviceAssignment.InternalServiceID, nullableInt64Ptr(serviceAssignment.LayerID), nullableInt64Ptr(serviceAssignment.TechnicalRoleID), userID); err != nil {
			return domain.VMOperationalMetadata{}, err
		}
	}
	if _, err := tx.ExecContext(ctx, `DELETE FROM vm_responsibilities WHERE vm_id=?`, vmID); err != nil {
		return domain.VMOperationalMetadata{}, err
	}
	for _, item := range responsibilities {
		if _, err := tx.ExecContext(ctx, `INSERT INTO vm_responsibilities(vm_id,person_id,responsibility_type,notes,sort_order,created_by) VALUES(?,?,?,?,?,?)`, vmID, item.PersonID, item.ResponsibilityType, item.Notes, item.SortOrder, userID); err != nil {
			return domain.VMOperationalMetadata{}, err
		}
	}
	// A request from a stale browser tab may contain the former manual backup fields.
	if input.BackupPolicy != "" || input.RPOMinutes != nil || input.RTOMinutes != nil {
		_, err = tx.ExecContext(ctx, `INSERT INTO vm_backup_summary(vm_id,provider,protected,policy_name,rpo_minutes,rto_minutes,error_message) VALUES(?,'manual',?,?,?,?,'') ON DUPLICATE KEY UPDATE protected=VALUES(protected),policy_name=VALUES(policy_name),rpo_minutes=VALUES(rpo_minutes),rto_minutes=VALUES(rto_minutes)`, vmID, input.BackupPolicy != "", input.BackupPolicy, nullableInt(input.RPOMinutes), nullableInt(input.RTOMinutes))
		if err != nil {
			return domain.VMOperationalMetadata{}, err
		}
	}
	if err := tx.Commit(); err != nil {
		return domain.VMOperationalMetadata{}, err
	}
	return s.GetOperationalMetadata(ctx, vmID)
}

func (s *Service) resolveOperationalNomenclatures(ctx context.Context, input *OperationalMetadataInput) (map[string]resolvedNomenclature, error) {
	out := make(map[string]resolvedNomenclature)
	for _, field := range operationalCategories {
		id := field.ID(input)
		legacyName := strings.TrimSpace(field.Name(input))
		if id == nil || *id == 0 {
			if legacyName == "" {
				continue
			}
			var value resolvedNomenclature
			err := s.DB.QueryRowContext(ctx, `SELECT id,name FROM nomenclature_items WHERE category_code=? AND name=?`, field.Code, legacyName).Scan(&value.ID, &value.Name)
			if err != nil {
				return nil, errors.New(field.Code + " must be selected from nomenclatures")
			}
			out[field.Code] = value
			continue
		}
		var value resolvedNomenclature
		err := s.DB.QueryRowContext(ctx, `SELECT id,name FROM nomenclature_items WHERE id=? AND category_code=?`, *id, field.Code).Scan(&value.ID, &value.Name)
		if errors.Is(err, sql.ErrNoRows) {
			return nil, errors.New("invalid nomenclature value for " + field.Code)
		}
		if err != nil {
			return nil, err
		}
		out[field.Code] = value
	}
	return out, nil
}

func (s *Service) resolveInternalServiceAssignment(ctx context.Context, input *OperationalMetadataInput) (*resolvedServiceAssignment, error) {
	serviceID := pointerValue(input.InternalServiceID)
	if serviceID == 0 && input.ComponentID != nil && *input.ComponentID > 0 {
		categoryID, categoryKind, err := s.resolveInputITILCategory(ctx, input)
		if err != nil {
			return nil, err
		}
		if categoryKind == "itil_category" {
			// A 0.3.2-compatible client may still use the old aliases.
			serviceID = *input.ComponentID
			if input.ITILCategoryID == nil {
				input.ITILCategoryID = int64Ptr(categoryID)
			}
		} else {
			var componentName string
			if err := s.DB.QueryRowContext(ctx, `SELECT name FROM nomenclature_items WHERE id=? AND category_code='component'`, *input.ComponentID).Scan(&componentName); err != nil {
				if errors.Is(err, sql.ErrNoRows) {
					return nil, errors.New("invalid legacy component_id")
				}
				return nil, err
			}
			if categoryID == 0 {
				return nil, errors.New("ITIL category is required for the legacy component")
			}
			if err := s.DB.QueryRowContext(ctx, `SELECT id FROM internal_services WHERE itil_category_id=? AND name=?`, categoryID, componentName).Scan(&serviceID); err != nil {
				if errors.Is(err, sql.ErrNoRows) {
					return nil, errors.New("legacy component was not migrated to an internal service")
				}
				return nil, err
			}
		}
	}
	if serviceID == 0 && strings.TrimSpace(input.ComponentName) != "" {
		categoryID, _, err := s.resolveInputITILCategory(ctx, input)
		if err != nil {
			return nil, err
		}
		if categoryID == 0 {
			return nil, errors.New("ITIL category is required for the legacy component")
		}
		if err := s.DB.QueryRowContext(ctx, `SELECT id FROM internal_services WHERE itil_category_id=? AND name=?`, categoryID, strings.TrimSpace(input.ComponentName)).Scan(&serviceID); err != nil {
			if errors.Is(err, sql.ErrNoRows) {
				return nil, errors.New("legacy component was not migrated to an internal service")
			}
			return nil, err
		}
	}
	if serviceID == 0 {
		if pointerValue(input.ITILCategoryID) > 0 || pointerValue(input.ArchitecturalDomainID) > 0 || pointerValue(input.LayerID) > 0 || pointerValue(input.TechnicalRoleID) > 0 {
			return nil, errors.New("internal_service_id is required when service classification is selected")
		}
		return nil, nil
	}

	assignment := &resolvedServiceAssignment{InternalServiceID: serviceID}
	var domainID sql.NullInt64
	var domainName sql.NullString
	err := s.DB.QueryRowContext(ctx, `SELECT service.name,category_item.id,category_item.name,parent_relation.parent_item_id,domain_item.name
		FROM internal_services service
		JOIN nomenclature_items category_item ON category_item.id=service.itil_category_id AND category_item.category_code='itil_category'
		LEFT JOIN nomenclature_item_parents parent_relation ON parent_relation.child_item_id=category_item.id
		LEFT JOIN nomenclature_items domain_item ON domain_item.id=parent_relation.parent_item_id
		WHERE service.id=?`, serviceID).Scan(&assignment.InternalServiceName, &assignment.ITILCategoryID, &assignment.ITILCategory, &domainID, &domainName)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, errors.New("invalid internal_service_id")
	}
	if err != nil {
		return nil, err
	}
	if domainID.Valid {
		id := domainID.Int64
		assignment.ArchitecturalDomainID = &id
	}
	if domainName.Valid {
		assignment.ArchitecturalDomain = domainName.String
	}
	if selected := pointerValue(input.ITILCategoryID); selected > 0 && selected != assignment.ITILCategoryID {
		return nil, errors.New("selected ITIL category does not contain the internal service")
	}
	if selected := pointerValue(input.ArchitecturalDomainID); selected > 0 && (assignment.ArchitecturalDomainID == nil || selected != *assignment.ArchitecturalDomainID) {
		return nil, errors.New("selected architectural domain does not contain the ITIL category")
	}

	layerID := pointerValue(input.LayerID)
	if layerID == 0 && strings.TrimSpace(input.LayerName) != "" {
		if err := s.DB.QueryRowContext(ctx, `SELECT id FROM nomenclature_items WHERE category_code='layer' AND name=?`, strings.TrimSpace(input.LayerName)).Scan(&layerID); err != nil {
			if errors.Is(err, sql.ErrNoRows) {
				return nil, errors.New("layer must be selected from nomenclatures")
			}
			return nil, err
		}
	}
	roleID := pointerValue(input.TechnicalRoleID)
	if layerID == 0 && roleID == 0 {
		return assignment, nil
	}
	if layerID == 0 || roleID == 0 {
		return nil, errors.New("layer_id and technical_role_id must be selected together")
	}
	var mappingExists int
	if err := s.DB.QueryRowContext(ctx, `SELECT 1 FROM internal_service_role_mappings WHERE internal_service_id=? AND layer_id=? AND technical_role_id=? AND active=1`, serviceID, layerID, roleID).Scan(&mappingExists); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, errors.New("selected layer and technical role are not allowed for this internal service")
		}
		return nil, err
	}
	var layerName, roleName string
	if err := s.DB.QueryRowContext(ctx, `SELECT name FROM nomenclature_items WHERE id=? AND category_code='layer'`, layerID).Scan(&layerName); err != nil {
		return nil, errors.New("invalid layer_id")
	}
	if err := s.DB.QueryRowContext(ctx, `SELECT name FROM nomenclature_items WHERE id=? AND category_code='technical_role'`, roleID).Scan(&roleName); err != nil {
		return nil, errors.New("invalid technical_role_id")
	}
	assignment.LayerID = int64Ptr(layerID)
	assignment.LayerName = layerName
	assignment.TechnicalRoleID = int64Ptr(roleID)
	assignment.TechnicalRole = roleName
	return assignment, nil
}

func (s *Service) resolveInputITILCategory(ctx context.Context, input *OperationalMetadataInput) (int64, string, error) {
	if id := pointerValue(input.ITILCategoryID); id > 0 {
		var category string
		if err := s.DB.QueryRowContext(ctx, `SELECT category_code FROM nomenclature_items WHERE id=?`, id).Scan(&category); err != nil {
			if errors.Is(err, sql.ErrNoRows) {
				return 0, "", errors.New("invalid itil_category_id")
			}
			return 0, "", err
		}
		if category != "itil_category" {
			return 0, "", errors.New("invalid itil_category_id")
		}
		return id, category, nil
	}
	if id := pointerValue(input.ServiceID); id > 0 {
		var category, name string
		if err := s.DB.QueryRowContext(ctx, `SELECT category_code,name FROM nomenclature_items WHERE id=?`, id).Scan(&category, &name); err != nil {
			if errors.Is(err, sql.ErrNoRows) {
				return 0, "", errors.New("invalid legacy service_id")
			}
			return 0, "", err
		}
		if category == "itil_category" {
			return id, category, nil
		}
		if category != "service" {
			return 0, category, errors.New("invalid legacy service_id")
		}
		var migratedID int64
		if err := s.DB.QueryRowContext(ctx, `SELECT id FROM nomenclature_items WHERE category_code='itil_category' AND name=?`, name).Scan(&migratedID); err != nil {
			return 0, category, err
		}
		return migratedID, category, nil
	}
	if name := strings.TrimSpace(input.ServiceName); name != "" {
		var id int64
		if err := s.DB.QueryRowContext(ctx, `SELECT id FROM nomenclature_items WHERE category_code='itil_category' AND name=?`, name).Scan(&id); err != nil {
			if errors.Is(err, sql.ErrNoRows) {
				return 0, "service", errors.New("legacy service was not migrated to an ITIL category")
			}
			return 0, "service", err
		}
		return id, "service", nil
	}
	return 0, "", nil
}

func pointerValue(value *int64) int64 {
	if value == nil {
		return 0
	}
	return *value
}

func (s *Service) resolveLegacyResponsibilities(ctx context.Context, input OperationalMetadataInput) ([]ResponsibilityInput, error) {
	if len(input.Responsibilities) > 0 || (input.TechnicalAdmin == "" && input.BusinessOwner == "") {
		return input.Responsibilities, nil
	}
	out := make([]ResponsibilityInput, 0, 2)
	for _, legacy := range []struct {
		name, email, kind string
	}{{input.TechnicalAdmin, "", "technical_admin"}, {input.BusinessOwner, input.OwnerEmail, "service_owner"}} {
		if strings.TrimSpace(legacy.name) == "" {
			continue
		}
		var id int64
		err := s.DB.QueryRowContext(ctx, `SELECT id FROM people WHERE display_name=? AND email=?`, strings.TrimSpace(legacy.name), strings.ToLower(strings.TrimSpace(legacy.email))).Scan(&id)
		if errors.Is(err, sql.ErrNoRows) {
			return nil, errors.New("responsible person must be selected from People")
		}
		if err != nil {
			return nil, err
		}
		out = append(out, ResponsibilityInput{PersonID: id, ResponsibilityType: legacy.kind, SortOrder: len(out)})
	}
	return out, nil
}

func validateResponsibilities(ctx context.Context, db *sql.DB, values []ResponsibilityInput) error {
	seen := make(map[string]bool)
	for i := range values {
		values[i].ResponsibilityType = strings.ToLower(strings.TrimSpace(values[i].ResponsibilityType))
		values[i].Notes = strings.TrimSpace(values[i].Notes)
		if values[i].PersonID <= 0 {
			return errors.New("person_id is required for every responsibility")
		}
		if !allowedResponsibilityTypes[values[i].ResponsibilityType] {
			return errors.New("invalid responsibility_type")
		}
		if len([]rune(values[i].Notes)) > 512 {
			return errors.New("responsibility notes are too long")
		}
		key := strconv.FormatInt(values[i].PersonID, 10) + ":" + values[i].ResponsibilityType
		if seen[key] {
			return errors.New("duplicate VM responsibility")
		}
		seen[key] = true
		var exists int
		if err := db.QueryRowContext(ctx, `SELECT 1 FROM people WHERE id=?`, values[i].PersonID).Scan(&exists); err != nil {
			if errors.Is(err, sql.ErrNoRows) {
				return errors.New("responsible person does not exist")
			}
			return err
		}
	}
	return nil
}

func legacyResponsibilityFields(ctx context.Context, db *sql.DB, values []ResponsibilityInput) (technicalAdmin, owner, ownerEmail string) {
	for _, item := range values {
		var name, email string
		if err := db.QueryRowContext(ctx, `SELECT display_name,email FROM people WHERE id=?`, item.PersonID).Scan(&name, &email); err != nil {
			continue
		}
		if technicalAdmin == "" && item.ResponsibilityType == "technical_admin" {
			technicalAdmin = name
		}
		if owner == "" && (item.ResponsibilityType == "service_owner" || item.ResponsibilityType == "business_owner") {
			owner, ownerEmail = name, email
		}
	}
	return
}

func (s *Service) GetBackupSummary(ctx context.Context, vmID int64) (domain.VMBackupSummary, error) {
	value := domain.VMBackupSummary{VMID: vmID, Provider: "veeam"}
	var lastBackup, nextRun, syncedAt sql.NullTime
	var restorePoints, rpo, rto sql.NullInt64
	var rawJSON []byte
	err := s.DB.QueryRowContext(ctx, `SELECT vm_id,provider,source_name,protected,job_name,policy_name,repository_name,last_result,last_backup_at,next_run_at,restore_points,rpo_minutes,rto_minutes,synced_at,error_message,raw_json,updated_at FROM vm_backup_summary WHERE vm_id=?`, vmID).Scan(
		&value.VMID, &value.Provider, &value.SourceName, &value.Protected, &value.JobName, &value.PolicyName, &value.RepositoryName, &value.LastResult, &lastBackup, &nextRun, &restorePoints, &rpo, &rto, &syncedAt, &value.ErrorMessage, &rawJSON, &value.UpdatedAt,
	)
	if errors.Is(err, sql.ErrNoRows) {
		return value, nil
	}
	if err != nil {
		return value, err
	}
	value.RawJSON = rawJSON
	if lastBackup.Valid {
		value.LastBackupAt = &lastBackup.Time
	}
	if nextRun.Valid {
		value.NextRunAt = &nextRun.Time
	}
	if syncedAt.Valid {
		value.SyncedAt = &syncedAt.Time
	}
	if restorePoints.Valid {
		n := int(restorePoints.Int64)
		value.RestorePoints = &n
	}
	if rpo.Valid {
		n := int(rpo.Int64)
		value.RPOMinutes = &n
	}
	if rto.Valid {
		n := int(rto.Int64)
		value.RTOMinutes = &n
	}
	return value, nil
}

func normalizeOperationalMetadata(input *OperationalMetadataInput) error {
	input.Purpose = strings.TrimSpace(input.Purpose)
	input.ProvisionedAt = strings.TrimSpace(input.ProvisionedAt)
	input.DocumentationURL = strings.TrimSpace(input.DocumentationURL)
	input.TicketReference = strings.TrimSpace(input.TicketReference)
	input.Notes = strings.TrimSpace(input.Notes)
	input.ServiceName = strings.TrimSpace(input.ServiceName)
	input.ComponentName = strings.TrimSpace(input.ComponentName)
	input.ArchitecturalDomain = strings.TrimSpace(input.ArchitecturalDomain)
	input.LayerName = strings.TrimSpace(input.LayerName)
	input.Environment = strings.TrimSpace(input.Environment)
	input.OperationalStatus = strings.TrimSpace(input.OperationalStatus)
	input.TechnicalAdmin = strings.TrimSpace(input.TechnicalAdmin)
	input.BusinessOwner = strings.TrimSpace(input.BusinessOwner)
	input.OwnerEmail = strings.ToLower(strings.TrimSpace(input.OwnerEmail))
	input.ProvisioningProfile = strings.TrimSpace(input.ProvisioningProfile)
	input.BackupPolicy = strings.TrimSpace(input.BackupPolicy)
	input.Classification = strings.TrimSpace(input.Classification)

	if input.ProvisionedAt != "" {
		if _, err := time.Parse("2006-01-02", input.ProvisionedAt); err != nil {
			return errors.New("provisioned_at must use YYYY-MM-DD")
		}
	}
	for _, item := range []*int{input.RPOMinutes, input.RTOMinutes} {
		if item != nil && (*item < 0 || *item > 5256000) {
			return errors.New("RPO/RTO must be between 0 and 5256000 minutes")
		}
	}
	if input.OwnerEmail != "" {
		address, err := mail.ParseAddress(input.OwnerEmail)
		if err != nil || strings.ToLower(address.Address) != input.OwnerEmail {
			return errors.New("owner_email is invalid")
		}
	}
	if input.DocumentationURL != "" {
		parsed, err := url.ParseRequestURI(input.DocumentationURL)
		if err != nil || (parsed.Scheme != "http" && parsed.Scheme != "https") || parsed.Host == "" {
			return errors.New("documentation_url must be an absolute HTTP or HTTPS URL")
		}
	}
	limits := []struct {
		name  string
		value string
		max   int
	}{
		{"documentation_url", input.DocumentationURL, 1024}, {"ticket_reference", input.TicketReference, 255},
		{"backup_policy", input.BackupPolicy, 255}, {"service_name", input.ServiceName, 255}, {"component_name", input.ComponentName, 255},
		{"architectural_domain", input.ArchitecturalDomain, 255}, {"layer_name", input.LayerName, 128}, {"environment", input.Environment, 64},
		{"operational_status", input.OperationalStatus, 64}, {"technical_admin", input.TechnicalAdmin, 255}, {"business_owner", input.BusinessOwner, 255},
		{"owner_email", input.OwnerEmail, 255}, {"provisioning_profile", input.ProvisioningProfile, 255}, {"classification", input.Classification, 128},
	}
	for _, limit := range limits {
		if len([]rune(limit.value)) > limit.max {
			return errors.New(limit.name + " is too long")
		}
	}
	return nil
}

func nullableInt64Ptr(value *int64) any {
	if value == nil {
		return nil
	}
	return *value
}

func nullableInt(value *int) any {
	if value == nil {
		return nil
	}
	return *value
}

func int64Ptr(value int64) *int64 { return &value }

package audit

import (
	"context"
	"database/sql"
	"encoding/json"
	"time"
)

type Event struct {
	Source        string
	ActorUserID   *int64
	ActorUsername string
	Action        string
	ResourceType  string
	ResourceID    string
	Outcome       string
	RequestID     string
	IPAddress     string
	UserAgent     string
	Details       any
}

type Service struct{ DB *sql.DB }

func (s Service) Log(ctx context.Context, e Event) error {
	if e.Source == "" {
		e.Source = "server"
	}
	if e.Outcome == "" {
		e.Outcome = "success"
	}
	b, err := json.Marshal(e.Details)
	if err != nil {
		return err
	}
	if string(b) == "null" {
		b = []byte("{}")
	}
	_, err = s.DB.ExecContext(ctx, `INSERT INTO audit_events(occurred_at,source,actor_user_id,actor_username,action,resource_type,resource_id,outcome,request_id,ip_address,user_agent,details_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`, time.Now().UTC(), e.Source, e.ActorUserID, e.ActorUsername, e.Action, e.ResourceType, e.ResourceID, e.Outcome, e.RequestID, e.IPAddress, e.UserAgent, b)
	return err
}

type Record struct {
	ID            int64           `json:"id"`
	OccurredAt    time.Time       `json:"occurred_at"`
	Source        string          `json:"source"`
	ActorUsername string          `json:"actor_username"`
	Action        string          `json:"action"`
	ResourceType  string          `json:"resource_type"`
	ResourceID    string          `json:"resource_id"`
	Outcome       string          `json:"outcome"`
	IPAddress     string          `json:"ip_address"`
	Details       json.RawMessage `json:"details"`
}

const (
	defaultPageSize = 50
	maxPageSize     = 200
)

type Page struct {
	Items    []Record `json:"items"`
	Page     int      `json:"page"`
	PageSize int      `json:"page_size"`
	Total    int      `json:"total"`
	Pages    int      `json:"pages"`
}

func NormalizePagination(page, pageSize int) (int, int) {
	if page < 1 {
		page = 1
	}
	if pageSize <= 0 {
		pageSize = defaultPageSize
	}
	if pageSize > maxPageSize {
		pageSize = maxPageSize
	}
	return page, pageSize
}

func (s Service) List(ctx context.Context, page, pageSize int) (Page, error) {
	page, pageSize = NormalizePagination(page, pageSize)
	result := Page{Items: make([]Record, 0), Page: page, PageSize: pageSize}
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM audit_events`).Scan(&result.Total); err != nil {
		return Page{}, err
	}
	if result.Total == 0 {
		return result, nil
	}
	result.Pages = (result.Total + result.PageSize - 1) / result.PageSize
	if result.Page > result.Pages {
		result.Page = result.Pages
	}
	offset := (result.Page - 1) * result.PageSize
	rows, err := s.DB.QueryContext(ctx, `SELECT id,occurred_at,source,actor_username,action,resource_type,resource_id,outcome,ip_address,details_json FROM audit_events ORDER BY id DESC LIMIT ? OFFSET ?`, result.PageSize, offset)
	if err != nil {
		return Page{}, err
	}
	defer rows.Close()
	for rows.Next() {
		var r Record
		if err := rows.Scan(&r.ID, &r.OccurredAt, &r.Source, &r.ActorUsername, &r.Action, &r.ResourceType, &r.ResourceID, &r.Outcome, &r.IPAddress, &r.Details); err != nil {
			return Page{}, err
		}
		result.Items = append(result.Items, r)
	}
	return result, rows.Err()
}

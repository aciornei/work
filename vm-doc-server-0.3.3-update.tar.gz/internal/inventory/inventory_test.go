package inventory

import "testing"

func TestSummarizeSchemaTwoInventory(t *testing.T) {
	raw := []byte(`{
	  "schema": {"name": "vm-doc-agent-inventory", "version": "2.0"},
	  "generated_at": "2026-08-25T08:30:00Z",
	  "identity": {"hostname": "vm-app-01", "uuid": "host-uuid-123"},
	  "os": {"name": "Ubuntu", "version": "20.04"},
	  "system": {"boot_time": "2026-08-20T06:00:00Z"},
	  "network": {
	    "interfaces": [
	      {"name": "lo", "addresses": ["127.0.0.1/8"]},
	      {"name": "eth0", "addresses": ["10.20.30.40/24"]}
	    ]
	  },
	  "storage": {"partitions": [{"name": "/", "uuid": "partition-uuid-wrong"}]},
	  "collectors": {
	    "system": {"status": "ok"},
	    "network": {"status": "ok"},
	    "filebeat": {"status": "error"},
	    "ntp": {"status": "timeout"}
	  }
	}`)

	s, err := Summarize(raw)
	if err != nil {
		t.Fatal(err)
	}
	if s.SchemaVersion != "2.0" || s.AgentUUID != "host-uuid-123" || s.Hostname != "vm-app-01" {
		t.Fatalf("unexpected identity summary: %+v", s)
	}
	if s.OSName != "Ubuntu" || s.OSVersion != "20.04" {
		t.Fatalf("unexpected OS summary: %+v", s)
	}
	if s.PrimaryIP != "10.20.30.40" {
		t.Fatalf("primary IP %q, want 10.20.30.40", s.PrimaryIP)
	}
	if s.CollectorTotal != 4 || s.CollectorOK != 2 || s.CollectorError != 1 || s.CollectorTimeout != 1 {
		t.Fatalf("unexpected collector counts: %+v", s)
	}
	if s.BootTime == nil || s.CollectedAt == nil {
		t.Fatalf("times were not parsed: %+v", s)
	}
}

func TestSummarizeDoesNotUseUnrelatedUUID(t *testing.T) {
	raw := []byte(`{"schema_version":"2.0","hostname":"vm1","storage":{"partitions":[{"uuid":"partition-only"}]}}`)
	s, err := Summarize(raw)
	if err != nil {
		t.Fatal(err)
	}
	if s.AgentUUID != "" {
		t.Fatalf("agent UUID %q was taken from an unrelated object", s.AgentUUID)
	}
}

func TestSummarizeRejectsTrailingJSON(t *testing.T) {
	if _, err := Summarize([]byte(`{"schema_version":"2.0"} {}`)); err == nil {
		t.Fatal("trailing JSON unexpectedly accepted")
	}
}

func TestSummarizeAgentOneInventoryShape(t *testing.T) {
	raw := []byte(`{
	  "schema_version":"2.0",
	  "agent":{"name":"vm-doc-agent","version":"1.0.0","id":"28a0858a-d2f7-4e69-9bfb-67f8c578ce86"},
	  "collected_at":"2026-08-25T13:21:33Z",
	  "collection":{"status":"success","collectors":{"system":{"status":"success"},"firewall":{"status":"success"},"ntp":{"status":"failed"}}},
	  "host":{"hostname":"DTI-ANSIBLE-01","fqdn":"DTI-ANSIBLE-01.example.ro","machine_id":"machine-1","product_uuid":"a89b0542-0022-9e75-e7bb-3ca7d543a975","correlation":{"smbios_legacy_byte_order":"42059ba8-2200-759e-e7bb-3ca7d543a975"}},
	  "os":{"pretty_name":"Ubuntu 24.04.3 LTS","version_id":"24.04"},
	  "network":{"interfaces":[{"name":"ens160","addresses":[{"address":"172.20.1.20","family":"ipv4"}]}]}
	}`)
	s, err := Summarize(raw)
	if err != nil {
		t.Fatal(err)
	}
	if s.AgentUUID != "28a0858a-d2f7-4e69-9bfb-67f8c578ce86" || s.AgentVersion != "1.0.0" {
		t.Fatalf("agent identity was not parsed: %+v", s)
	}
	if s.ProductUUID != "a89b0542-0022-9e75-e7bb-3ca7d543a975" || s.ProductUUIDLegacy == "" || s.FQDN == "" {
		t.Fatalf("VM correlation fields were not parsed: %+v", s)
	}
	if s.CollectorTotal != 3 || s.CollectorOK != 2 || s.CollectorError != 1 {
		t.Fatalf("nested collector statuses were not parsed: %+v", s)
	}
	if s.PrimaryIP != "172.20.1.20" {
		t.Fatalf("primary IP %q, want 172.20.1.20", s.PrimaryIP)
	}
}

func TestNormalizeHistoryPagination(t *testing.T) {
	page, pageSize := NormalizeHistoryPagination(0, 0)
	if page != 1 || pageSize != 20 {
		t.Fatalf("unexpected defaults: page=%d pageSize=%d", page, pageSize)
	}
	page, pageSize = NormalizeHistoryPagination(3, 1000)
	if page != 3 || pageSize != 100 {
		t.Fatalf("unexpected normalized values: page=%d pageSize=%d", page, pageSize)
	}
}

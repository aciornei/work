package vcenter

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
	"time"

	"vm-doc-server/internal/domain"
)

const (
	defaultVMPageSize = 50
	maxVMPageSize     = 200
)

type VMFilter struct {
	Query    string
	Power    string
	Agent    string
	Retired  string
	SourceID int64
	Page     int
	PageSize int
}

type VMPage struct {
	Items          []domain.VirtualMachine `json:"items"`
	Page           int                     `json:"page"`
	PageSize       int                     `json:"page_size"`
	Total          int                     `json:"total"`
	Pages          int                     `json:"pages"`
	PresentCount   int                     `json:"present_count"`
	WithAgentCount int                     `json:"with_agent_count"`
}

func NormalizeVMFilter(in VMFilter) VMFilter {
	in.Query = strings.TrimSpace(in.Query)
	in.Power = strings.TrimSpace(in.Power)
	in.Agent = strings.ToLower(strings.TrimSpace(in.Agent))
	in.Retired = strings.ToLower(strings.TrimSpace(in.Retired))
	if in.Page < 1 {
		in.Page = 1
	}
	if in.PageSize <= 0 {
		in.PageSize = defaultVMPageSize
	}
	if in.PageSize > maxVMPageSize {
		in.PageSize = maxVMPageSize
	}
	return in
}

func (s *Service) ListVMs(ctx context.Context, filter VMFilter) (VMPage, error) {
	filter = NormalizeVMFilter(filter)
	where, args, err := buildVMWhere(filter)
	if err != nil {
		return VMPage{}, err
	}

	var result VMPage
	result.Page = filter.Page
	result.PageSize = filter.PageSize
	result.Items = make([]domain.VirtualMachine, 0)

	summaryQuery := `SELECT COUNT(*),
 COALESCE(SUM(vm.present_in_vcenter=1),0),
 COALESCE(SUM(vm.agent_id IS NOT NULL),0)` + vmFrom + where
	if err := s.DB.QueryRowContext(ctx, summaryQuery, args...).Scan(
		&result.Total,
		&result.PresentCount,
		&result.WithAgentCount,
	); err != nil {
		return VMPage{}, err
	}

	if result.Total == 0 {
		return result, nil
	}
	result.Pages = (result.Total + result.PageSize - 1) / result.PageSize
	if result.Page > result.Pages {
		result.Page = result.Pages
	}
	offset := (result.Page - 1) * result.PageSize

	query := vmSelect + where + ` ORDER BY vm.present_in_vcenter DESC,vm.name LIMIT ? OFFSET ?`
	queryArgs := append(append([]any{}, args...), result.PageSize, offset)
	rows, err := s.DB.QueryContext(ctx, query, queryArgs...)
	if err != nil {
		return VMPage{}, err
	}
	defer rows.Close()
	for rows.Next() {
		vm, err := scanVM(rows)
		if err != nil {
			return VMPage{}, err
		}
		result.Items = append(result.Items, vm)
	}
	return result, rows.Err()
}

func (s *Service) ExportVMs(ctx context.Context, filter VMFilter) ([]domain.VirtualMachine, error) {
	filter = NormalizeVMFilter(filter)
	where, args, err := buildVMWhere(filter)
	if err != nil {
		return nil, err
	}
	rows, err := s.DB.QueryContext(ctx, vmSelect+where+` ORDER BY vm.present_in_vcenter DESC,vm.name`, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.VirtualMachine, 0)
	for rows.Next() {
		vm, err := scanVM(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, vm)
	}
	return out, rows.Err()
}

func buildVMWhere(filter VMFilter) (string, []any, error) {
	clauses := make([]string, 0, 6)
	args := make([]any, 0, 8)

	if filter.Query != "" {
		pattern := "%" + filter.Query + "%"
		clauses = append(clauses, `(vm.name LIKE ? OR vm.guest_hostname LIKE ? OR i.hostname LIKE ? OR vm.power_state LIKE ? OR vm.guest_os LIKE ? OR i.os_name LIKE ? OR i.os_version LIKE ? OR vm.primary_ip LIKE ? OR i.primary_ip LIKE ? OR a.name LIKE ? OR src.name LIKE ?)`)
		for range 11 {
			args = append(args, pattern)
		}
	}
	if filter.Power != "" {
		clauses = append(clauses, `vm.power_state=?`)
		args = append(args, filter.Power)
	}
	if filter.SourceID > 0 {
		clauses = append(clauses, `vm.vcenter_source_id=?`)
		args = append(args, filter.SourceID)
	}
	switch filter.Retired {
	case "", "all":
	case "true", "1", "yes":
		clauses = append(clauses, `vm.retired=1`)
	case "false", "0", "no":
		clauses = append(clauses, `vm.retired=0`)
	default:
		return "", nil, fmt.Errorf("invalid retired filter %q", filter.Retired)
	}
	switch filter.Agent {
	case "", "all":
	case "configured":
		clauses = append(clauses, `vm.agent_id IS NOT NULL`)
	case "unconfigured":
		clauses = append(clauses, `vm.agent_id IS NULL`)
	case "disabled":
		clauses = append(clauses, `vm.agent_id IS NOT NULL AND a.enabled=0`)
	case "unknown":
		clauses = append(clauses, `vm.agent_id IS NOT NULL AND a.enabled=1 AND a.last_contact_at IS NULL`)
	case "online":
		clauses = append(clauses, `vm.agent_id IS NOT NULL AND a.enabled=1 AND a.last_contact_at IS NOT NULL AND a.offline_after_seconds>0 AND TIMESTAMPDIFF(SECOND,a.last_contact_at,UTC_TIMESTAMP())<=a.offline_after_seconds`)
	case "offline":
		clauses = append(clauses, `vm.agent_id IS NOT NULL AND a.enabled=1 AND a.last_contact_at IS NOT NULL AND (a.offline_after_seconds<=0 OR TIMESTAMPDIFF(SECOND,a.last_contact_at,UTC_TIMESTAMP())>a.offline_after_seconds)`)
	default:
		return "", nil, fmt.Errorf("invalid agent filter %q", filter.Agent)
	}

	if len(clauses) == 0 {
		return "", args, nil
	}
	return ` WHERE ` + strings.Join(clauses, ` AND `), args, nil
}

func (s *Service) GetVM(ctx context.Context, id int64) (domain.VirtualMachine, error) {
	return scanVM(s.DB.QueryRowContext(ctx, vmSelect+` WHERE vm.id=?`, id))
}

func (s *Service) UpdateVM(ctx context.Context, id int64, in VMUpdate, userID int64) (domain.VirtualMachine, error) {
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return domain.VirtualMachine{}, err
	}
	defer tx.Rollback()
	var exists int
	if err := tx.QueryRowContext(ctx, `SELECT 1 FROM virtual_machines WHERE id=? FOR UPDATE`, id).Scan(&exists); err != nil {
		return domain.VirtualMachine{}, err
	}
	if in.Retired != nil {
		if *in.Retired {
			_, err = tx.ExecContext(ctx, `UPDATE virtual_machines SET retired=1,retired_at=COALESCE(retired_at,?),retired_by=?,retired_note=? WHERE id=?`, time.Now().UTC(), userID, strings.TrimSpace(in.RetiredNote), id)
		} else {
			_, err = tx.ExecContext(ctx, `UPDATE virtual_machines SET retired=0,retired_at=NULL,retired_by=NULL,retired_note=? WHERE id=?`, strings.TrimSpace(in.RetiredNote), id)
		}
		if err != nil {
			return domain.VirtualMachine{}, err
		}
	} else if in.RetiredNote != "" {
		if _, err := tx.ExecContext(ctx, `UPDATE virtual_machines SET retired_note=? WHERE id=?`, strings.TrimSpace(in.RetiredNote), id); err != nil {
			return domain.VirtualMachine{}, err
		}
	}
	if in.ClearAgent {
		if _, err := tx.ExecContext(ctx, `UPDATE virtual_machines SET agent_id=NULL,current_inventory_id=NULL WHERE id=?`, id); err != nil {
			return domain.VirtualMachine{}, err
		}
	}
	if in.AgentID != nil {
		if *in.AgentID <= 0 {
			return domain.VirtualMachine{}, errors.New("invalid agent_id")
		}
		var currentInventory sql.NullInt64
		if err := tx.QueryRowContext(ctx, `SELECT current_inventory_id FROM agents WHERE id=?`, *in.AgentID).Scan(&currentInventory); err != nil {
			return domain.VirtualMachine{}, err
		}
		if _, err := tx.ExecContext(ctx, `UPDATE virtual_machines SET agent_id=NULL,current_inventory_id=NULL WHERE agent_id=? AND id<>?`, *in.AgentID, id); err != nil {
			return domain.VirtualMachine{}, err
		}
		if _, err := tx.ExecContext(ctx, `UPDATE virtual_machines SET agent_id=?,current_inventory_id=? WHERE id=?`, *in.AgentID, nullableInt64(currentInventory), id); err != nil {
			return domain.VirtualMachine{}, err
		}
	}
	if err := tx.Commit(); err != nil {
		return domain.VirtualMachine{}, err
	}
	return s.GetVM(ctx, id)
}

const vmFrom = `
 FROM virtual_machines vm
 JOIN vcenter_sources src ON src.id=vm.vcenter_source_id
 LEFT JOIN agents a ON a.id=vm.agent_id
 LEFT JOIN inventory_snapshots i ON i.id=vm.current_inventory_id`

const vmSelect = `SELECT
 vm.id,vm.vcenter_source_id,src.name,vm.vcenter_moid,vm.instance_uuid,vm.bios_uuid,vm.name,vm.power_state,vm.cpu_count,vm.memory_mib,vm.hardware_version,vm.guest_os,vm.guest_hostname,vm.primary_ip,vm.custom_attributes_json,
 vm.retired,vm.retired_at,vm.retired_by,vm.retired_note,vm.present_in_vcenter,vm.first_seen_at,vm.last_seen_at,vm.missing_since,vm.last_vcenter_sync_at,
 vm.agent_id,a.name,a.enabled,a.offline_after_seconds,a.last_contact_at,a.last_success_at,a.last_error,vm.current_inventory_id,
 i.hostname,i.os_name,i.os_version,i.primary_ip,i.received_at,vm.created_at,vm.updated_at,
 CAST(ROUND(100.0*(
  IF(vm.agent_id IS NOT NULL,1,0)+
  IF(vm.current_inventory_id IS NOT NULL,1,0)+
  IF(COALESCE(NULLIF(i.hostname,''),NULLIF(vm.guest_hostname,'')) IS NOT NULL,1,0)+
  IF(COALESCE(NULLIF(i.os_name,''),NULLIF(vm.guest_os,'')) IS NOT NULL,1,0)+
  IF(COALESCE(NULLIF(i.primary_ip,''),NULLIF(vm.primary_ip,'')) IS NOT NULL,1,0)+
  IF(EXISTS(SELECT 1 FROM vm_operational_nomenclatures c1 WHERE c1.vm_id=vm.id AND c1.category_code='environment'),1,0)+
  IF(EXISTS(SELECT 1 FROM vm_operational_nomenclatures c2 WHERE c2.vm_id=vm.id AND c2.category_code='operational_status'),1,0)+
  IF(EXISTS(SELECT 1 FROM vm_operational_nomenclatures c3 WHERE c3.vm_id=vm.id AND c3.category_code='classification'),1,0)+
  IF(EXISTS(SELECT 1 FROM vm_operational_metadata om WHERE om.vm_id=vm.id AND TRIM(om.purpose)<>''),1,0)+
  IF(EXISTS(SELECT 1 FROM vm_internal_service_assignments sa WHERE sa.vm_id=vm.id),1,0)+
  IF(EXISTS(SELECT 1 FROM vm_responsibilities vr WHERE vr.vm_id=vm.id),1,0)
 )/11) AS UNSIGNED) AS completion_percent` + vmFrom

func scanVM(scanner interface{ Scan(...any) error }) (domain.VirtualMachine, error) {
	var vm domain.VirtualMachine
	var retiredAt, missingSince, lastVCenter, agentContact, agentSuccess, inventoryReceived sql.NullTime
	var retiredBy, agentID, currentInventory sql.NullInt64
	var agentName, agentError, invHostname, invOSName, invOSVersion, invPrimaryIP sql.NullString
	var agentEnabled sql.NullBool
	var offlineAfter sql.NullInt64
	var custom []byte
	err := scanner.Scan(
		&vm.ID, &vm.VCenterSourceID, &vm.VCenterSourceName, &vm.VCenterMoID, &vm.InstanceUUID, &vm.BIOSUUID, &vm.Name, &vm.PowerState, &vm.CPUCount, &vm.MemoryMiB, &vm.HardwareVersion, &vm.GuestOS, &vm.GuestHostname, &vm.PrimaryIP, &custom,
		&vm.Retired, &retiredAt, &retiredBy, &vm.RetiredNote, &vm.PresentInVCenter, &vm.FirstSeenAt, &vm.LastSeenAt, &missingSince, &lastVCenter,
		&agentID, &agentName, &agentEnabled, &offlineAfter, &agentContact, &agentSuccess, &agentError, &currentInventory,
		&invHostname, &invOSName, &invOSVersion, &invPrimaryIP, &inventoryReceived, &vm.CreatedAt, &vm.UpdatedAt, &vm.CompletionPercent,
	)
	if err != nil {
		return vm, err
	}
	vm.CustomAttributesJSON = custom
	if retiredAt.Valid {
		vm.RetiredAt = &retiredAt.Time
	}
	if retiredBy.Valid {
		v := retiredBy.Int64
		vm.RetiredBy = &v
	}
	if missingSince.Valid {
		vm.MissingSince = &missingSince.Time
	}
	if lastVCenter.Valid {
		vm.LastVCenterSyncAt = &lastVCenter.Time
	}
	if agentID.Valid {
		v := agentID.Int64
		vm.AgentID = &v
		vm.AgentName = agentName.String
		vm.AgentLastError = agentError.String
		if agentContact.Valid {
			vm.AgentLastContactAt = &agentContact.Time
		}
		if agentSuccess.Valid {
			vm.AgentLastSuccessAt = &agentSuccess.Time
		}
		vm.AgentStatus = agentStatus(agentEnabled.Bool, agentContact, offlineAfter.Int64)
	} else {
		vm.AgentStatus = "unconfigured"
	}
	if currentInventory.Valid {
		v := currentInventory.Int64
		vm.CurrentInventoryID = &v
	}
	vm.InventoryHostname = invHostname.String
	vm.InventoryOSName = invOSName.String
	vm.InventoryOSVersion = invOSVersion.String
	vm.InventoryPrimaryIP = invPrimaryIP.String
	if inventoryReceived.Valid {
		vm.InventoryReceivedAt = &inventoryReceived.Time
	}
	return vm, nil
}

func agentStatus(enabled bool, lastContact sql.NullTime, offlineAfter int64) string {
	if !enabled {
		return "disabled"
	}
	if !lastContact.Valid {
		return "unknown"
	}
	if offlineAfter <= 0 || time.Since(lastContact.Time.UTC()) > time.Duration(offlineAfter)*time.Second {
		return "offline"
	}
	return "online"
}

func nullableInt64(value sql.NullInt64) any {
	if value.Valid {
		return value.Int64
	}
	return nil
}

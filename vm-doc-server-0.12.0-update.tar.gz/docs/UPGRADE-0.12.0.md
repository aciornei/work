# Upgrade la vm-doc-server 0.12.0

Versiunea 0.12.0 este un release de UX și vizibilitate peste 0.11.1. Nu schimbă schema bazei de date.

## Baza de date

Nu există migrare nouă. Ultima migrare rămâne `025_vm_primary_agent_services.up.sql`.

## Schimbări principale

- fișa VM este împărțită în subsecțiuni navigabile;
- lista VM primește scorul `completion_percent`;
- scorul este calculat la citire din datele deja existente, fără coloană nouă în MariaDB;
- Nomenclatoarele au paginare configurabilă și memorată în browser;
- pagina Agenți este separată în listare și administrare release-uri;
- căutarea Agenți nu mai rerandează câmpul activ și nu mai pierde focusul.

## Criteriile pentru Completare fișă

Scorul folosește 11 criterii egale: agent asociat, inventar curent, hostname, sistem de operare, IP principal, mediu, status operațional, clasificare, scop VM, cel puțin o asociere la un serviciu intern și cel puțin o responsabilitate.

Backup-ul și documentele generate nu intră în scor deoarece nu sunt obligatorii pentru toate VM-urile.

## Upgrade

Aplicați arhiva incrementală peste sursa 0.11.1, compilați și instalați ca de obicei:

```bash
GOPROXY=off GOFLAGS=-mod=vendor make build
sudo systemctl stop vm-doc-collector vm-doc-server
sudo cp bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-server
sudo cp bin/vm-doc-collector /opt/vm-doc-server/bin/vm-doc-collector
sudo chmod 755 /opt/vm-doc-server/bin/vm-doc-server /opt/vm-doc-server/bin/vm-doc-collector
sudo systemctl start vm-doc-server vm-doc-collector
```

După upgrade faceți `Ctrl+F5` în browser pentru a încărca JavaScript/CSS 0.12.0.

## Verificări rapide

1. `/version` trebuie să raporteze `0.12.0`.
2. În lista VM trebuie să existe coloana **Completare**.
3. O fișă VM trebuie să aibă tab-urile Rezumat / Servicii / Operațional / Inventar agent / Continuitate / Infrastructură / Istoric.
4. În Nomenclatoare, selectorul **Pe pagină** trebuie să fie vizibil lângă filtre și alegerea să rămână după revenirea în pagină.
5. În Agenți, tastarea în Căutare nu trebuie să mute focusul după actualizarea listei.

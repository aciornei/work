# Upgrade la vm-doc-server 0.3.9

Versiunea 0.3.9 reorganizează exclusiv pagina **Nomenclatoare**. Nu modifică API-ul și nu introduce migrare MariaDB.

## Interfață

Nomenclatoarele sunt afișate într-o structură cu submeniu:

```text
Catalog servicii
  ├── Domeniu arhitectural
  └── Categorie ITIL

Arhitectură tehnică
  ├── Layer
  └── Rol tehnic

Operare VM
  ├── Mediu
  ├── Status operațional
  └── Clasificare

Responsabilități
  └── Persoane
```

Se încarcă și se afișează o singură listă la un moment dat. Categoria selectată este păstrată în rută, de exemplu `#nomenclatures/technical_role`.

## Pași

1. Aplicați update-ul peste o copie a sursei 0.3.8 care conține directorul `vendor/`.
2. Rulați testele și build-ul offline.
3. Faceți backup la binarele active și la configurație.
4. Opriți `vm-doc-collector` și `vm-doc-server`.
5. Înlocuiți binarele.
6. Porniți serverul, apoi collectorul.
7. Executați `Ctrl+F5` în browser.

## Verificare

- accesarea meniului Nomenclatoare deschide primul submeniu;
- este vizibilă o singură listă, nu toate cardurile simultan;
- selectarea unui submeniu actualizează ruta și tabelul;
- butoanele Adaugă și Editează rămân funcționale;
- după salvare rămâne deschisă aceeași categorie;
- pe ecrane înguste, opțiunile se așază adaptiv.

## Rollback

Este suficientă revenirea la binarele 0.3.8. Restaurarea bazei de date nu este necesară.

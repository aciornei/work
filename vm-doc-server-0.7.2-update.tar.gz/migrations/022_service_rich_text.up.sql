-- 0.7.2 · formatare rich-text pentru Scop și domeniu / Obiective
-- Câmpurile plain-text existente rămân pentru compatibilitate API și căutare.
ALTER TABLE internal_services
  ADD COLUMN purpose_richtext LONGTEXT NULL AFTER purpose,
  ADD COLUMN objectives_richtext LONGTEXT NULL AFTER objectives;

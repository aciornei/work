package richtext

import (
	"encoding/json"
	"errors"
	"regexp"
	"strconv"
	"strings"
	"unicode/utf8"

	"vm-doc-server/internal/domain"
)

const (
	Version        = 1
	MaxBlocks      = 250
	MaxRuns        = 2000
	MaxPlainRunes  = 10000
	MaxIndentLevel = 4
)

var (
	bulletPattern = regexp.MustCompile(`^\s*[-*•]\s+`)
	numberPattern = regexp.MustCompile(`^\s*([0-9]+)[.)]\s+`)
)

// Normalize validates and canonicalizes the restricted rich-text document used by
// service narrative fields. It intentionally supports only the formatting that
// can be rendered consistently in the browser and in generated DOCX files.
func Normalize(input *domain.RichTextDocument) (*domain.RichTextDocument, error) {
	if input == nil {
		return nil, nil
	}
	if input.Version != 0 && input.Version != Version {
		return nil, errors.New("rich text version is not supported")
	}
	out := &domain.RichTextDocument{Version: Version, Blocks: make([]domain.RichTextBlock, 0, len(input.Blocks))}
	if len(input.Blocks) > MaxBlocks {
		return nil, errors.New("rich text has too many blocks")
	}
	runCount := 0
	plainRunes := 0
	for _, block := range input.Blocks {
		typeName := strings.ToLower(strings.TrimSpace(block.Type))
		switch typeName {
		case "", "paragraph":
			typeName = "paragraph"
		case "bullet", "number":
		default:
			return nil, errors.New("rich text contains an unsupported block type")
		}
		level := block.Level
		if level < 0 || level > MaxIndentLevel {
			return nil, errors.New("rich text indentation is outside the allowed range")
		}
		if typeName == "paragraph" {
			level = 0
		}
		canonical := domain.RichTextBlock{Type: typeName, Level: level}
		for _, run := range block.Runs {
			text := cleanText(strings.ToValidUTF8(run.Text, "�"))
			if !utf8.ValidString(text) {
				return nil, errors.New("rich text contains invalid UTF-8")
			}
			plainRunes += utf8.RuneCountInString(text)
			if plainRunes > MaxPlainRunes {
				return nil, errors.New("rich text exceeds the allowed length")
			}
			if text == "" {
				continue
			}
			normalizedRun := domain.RichTextRun{Text: text, Bold: run.Bold, Italic: run.Italic, Underline: run.Underline}
			if n := len(canonical.Runs); n > 0 && sameStyle(canonical.Runs[n-1], normalizedRun) {
				canonical.Runs[n-1].Text += normalizedRun.Text
				continue
			}
			canonical.Runs = append(canonical.Runs, normalizedRun)
			runCount++
			if runCount > MaxRuns {
				return nil, errors.New("rich text has too many formatted runs")
			}
		}
		out.Blocks = append(out.Blocks, canonical)
	}
	return out, nil
}

func cleanText(value string) string {
	return strings.Map(func(r rune) rune {
		if r == '\t' || r == '\n' || r == '\r' || r >= 0x20 {
			return r
		}
		return -1
	}, value)
}

func sameStyle(left, right domain.RichTextRun) bool {
	return left.Bold == right.Bold && left.Italic == right.Italic && left.Underline == right.Underline
}

// FromPlain upgrades legacy plain text. Common textual bullet and numbered-list
// prefixes are recognized so existing content becomes immediately nicer after
// opening it in the rich editor.
func FromPlain(value string) *domain.RichTextDocument {
	value = strings.ReplaceAll(strings.ToValidUTF8(value, "�"), "\r\n", "\n")
	value = strings.ReplaceAll(value, "\r", "\n")
	if value == "" {
		return &domain.RichTextDocument{Version: Version, Blocks: []domain.RichTextBlock{}}
	}
	lines := strings.Split(value, "\n")
	blocks := make([]domain.RichTextBlock, 0, len(lines))
	for _, line := range lines {
		blockType := "paragraph"
		text := line
		if bulletPattern.MatchString(line) {
			blockType = "bullet"
			text = bulletPattern.ReplaceAllString(line, "")
		} else if numberPattern.MatchString(line) {
			blockType = "number"
			text = numberPattern.ReplaceAllString(line, "")
		}
		block := domain.RichTextBlock{Type: blockType}
		if text != "" {
			block.Runs = []domain.RichTextRun{{Text: text}}
		}
		blocks = append(blocks, block)
	}
	return &domain.RichTextDocument{Version: Version, Blocks: blocks}
}

// PlainText keeps backward-compatible purpose/objectives strings for API
// clients and scalar template placeholders.
func PlainText(doc *domain.RichTextDocument) string {
	if doc == nil || len(doc.Blocks) == 0 {
		return ""
	}
	var out strings.Builder
	numberCounters := make([]int, MaxIndentLevel+1)
	previousType := ""
	previousLevel := 0
	for index, block := range doc.Blocks {
		if index > 0 {
			out.WriteByte('\n')
		}
		level := block.Level
		if level < 0 {
			level = 0
		}
		if level > MaxIndentLevel {
			level = MaxIndentLevel
		}
		if block.Type == "number" {
			if previousType != "number" || level > previousLevel {
				numberCounters[level] = 0
			}
			for i := level + 1; i < len(numberCounters); i++ {
				numberCounters[i] = 0
			}
			numberCounters[level]++
			out.WriteString(strings.Repeat("  ", level))
			out.WriteString(strconv.Itoa(numberCounters[level]))
			out.WriteString(". ")
		} else if block.Type == "bullet" {
			out.WriteString(strings.Repeat("  ", level))
			out.WriteString("• ")
		}
		for _, run := range block.Runs {
			out.WriteString(run.Text)
		}
		previousType = block.Type
		previousLevel = level
	}
	return strings.TrimSpace(out.String())
}

func Encode(doc *domain.RichTextDocument) (string, error) {
	normalized, err := Normalize(doc)
	if err != nil {
		return "", err
	}
	if normalized == nil {
		return "", nil
	}
	data, err := json.Marshal(normalized)
	if err != nil {
		return "", err
	}
	return string(data), nil
}

func Decode(value, fallback string) *domain.RichTextDocument {
	value = strings.TrimSpace(value)
	if value == "" {
		return FromPlain(fallback)
	}
	var doc domain.RichTextDocument
	if err := json.Unmarshal([]byte(value), &doc); err != nil {
		return FromPlain(fallback)
	}
	normalized, err := Normalize(&doc)
	if err != nil {
		return FromPlain(fallback)
	}
	return normalized
}

package inventory

import "testing"

func TestParseAgentServicesWithVersions(t *testing.T) {
	raw := []byte(`{"services":[{"name":"postfix.service","manager":"systemd","active_state":"active","enabled_state":"enabled","software_name":"Postfix","version":"3.8.6","package_name":"postfix","package_version":"3.8.6-1","version_source":"postconf -h mail_version"},{"name":"dovecot.service","software_name":"Dovecot","version":"2.3.21"}]}`)
	values, err := parseAgentServices(raw)
	if err != nil {
		t.Fatal(err)
	}
	postfix := values["postfix.service"]
	if postfix.SoftwareName != "Postfix" || postfix.Version != "3.8.6" || postfix.PackageVersion != "3.8.6-1" || !postfix.Detected {
		t.Fatalf("unexpected postfix value: %+v", postfix)
	}
	dovecot := values["dovecot.service"]
	if dovecot.Version != "2.3.21" {
		t.Fatalf("unexpected dovecot value: %+v", dovecot)
	}
}

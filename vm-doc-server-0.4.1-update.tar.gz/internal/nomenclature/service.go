package nomenclature

import (
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"errors"
	"net/mail"
	"regexp"
	"sort"
	"strings"

	"vm-doc-server/internal/directory"
	"vm-doc-server/internal/domain"
)

var codePattern = regexp.MustCompile(`^[a-z0-9][a-z0-9._-]{0,127}$`)

var AllowedCategories = map[string]bool{
	"architectural_domain": true,
	"itil_category":        true,
	"layer":                true,
	"technical_role":       true,
	"environment":          true,
	"operational_status":   true,
	"classification":       true,
}

type Service struct{ DB *sql.DB }

type ItemInput struct {
	CategoryCode string  `json:"category_code"`
	Name         string  `json:"name"`
	ItemCode     string  `json:"item_code"`
	Description  string  `json:"description"`
	SortOrder    int     `json:"sort_order"`
	Active       *bool   `json:"active,omitempty"`
	ParentID     *int64  `json:"parent_id,omitempty"`
	LayerIDs     []int64 `json:"layer_ids,omitempty"`
}

type PersonInput struct {
	DisplayName string `json:"display_name"`
	Email       string `json:"email"`
	Phone       string `json:"phone"`
	Department  string `json:"department"`
	Active      *bool  `json:"active,omitempty"`
}

func (s Service) ListCategories(ctx context.Context, includeInactive bool) ([]domain.NomenclatureCategory, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT code,label,sort_order,active FROM nomenclature_categories WHERE active=1 ORDER BY sort_order,label`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.NomenclatureCategory, 0)
	byCode := make(map[string]int)
	for rows.Next() {
		var category domain.NomenclatureCategory
		if err := rows.Scan(&category.Code, &category.Label, &category.SortOrder, &category.Active); err != nil {
			return nil, err
		}
		category.Items = make([]domain.NomenclatureValue, 0)
		byCode[category.Code] = len(out)
		out = append(out, category)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	query := `SELECT n.id,n.category_code,n.name,n.item_code,n.description,n.sort_order,n.active,p.parent_item_id,parent.name
		FROM nomenclature_items n
		LEFT JOIN nomenclature_item_parents p ON p.child_item_id=n.id
		LEFT JOIN nomenclature_items parent ON parent.id=p.parent_item_id`
	if !includeInactive {
		query += ` WHERE n.active=1`
	}
	query += ` ORDER BY n.category_code,n.sort_order,n.name`
	items, err := s.DB.QueryContext(ctx, query)
	if err != nil {
		return nil, err
	}
	defer items.Close()
	for items.Next() {
		var item domain.NomenclatureValue
		var parentID sql.NullInt64
		var parentName sql.NullString
		if err := items.Scan(&item.ID, &item.CategoryCode, &item.Name, &item.ItemCode, &item.Description, &item.SortOrder, &item.Active, &parentID, &parentName); err != nil {
			return nil, err
		}
		if parentID.Valid {
			value := parentID.Int64
			item.ParentID = &value
		}
		if parentName.Valid {
			item.ParentName = parentName.String
		}
		if idx, ok := byCode[item.CategoryCode]; ok {
			out[idx].Items = append(out[idx].Items, item)
		}
	}
	if err := items.Err(); err != nil {
		return nil, err
	}
	roleLayers, err := s.listRoleLayers(ctx)
	if err != nil {
		return nil, err
	}
	for categoryIndex := range out {
		if out[categoryIndex].Code != "technical_role" {
			continue
		}
		for itemIndex := range out[categoryIndex].Items {
			mapping := roleLayers[out[categoryIndex].Items[itemIndex].ID]
			out[categoryIndex].Items[itemIndex].LayerIDs = append([]int64(nil), mapping.IDs...)
			out[categoryIndex].Items[itemIndex].LayerNames = append([]string(nil), mapping.Names...)
		}
		sortTechnicalRoles(out, categoryIndex)
	}
	return out, nil
}

func sortTechnicalRoles(categories []domain.NomenclatureCategory, roleCategoryIndex int) {
	layerRank := make(map[int64]int)
	for _, category := range categories {
		if category.Code != "layer" {
			continue
		}
		for index, item := range category.Items {
			layerRank[item.ID] = index
		}
		break
	}
	const unmappedRank = int(^uint(0) >> 1)
	firstLayerRank := func(item domain.NomenclatureValue) int {
		rank := unmappedRank
		for _, layerID := range item.LayerIDs {
			if value, ok := layerRank[layerID]; ok && value < rank {
				rank = value
			}
		}
		return rank
	}
	items := categories[roleCategoryIndex].Items
	sort.SliceStable(items, func(i, j int) bool {
		leftRank, rightRank := firstLayerRank(items[i]), firstLayerRank(items[j])
		if leftRank != rightRank {
			return leftRank < rightRank
		}
		if items[i].SortOrder != items[j].SortOrder {
			return items[i].SortOrder < items[j].SortOrder
		}
		leftName, rightName := strings.ToLower(items[i].Name), strings.ToLower(items[j].Name)
		if leftName != rightName {
			return leftName < rightName
		}
		return items[i].ID < items[j].ID
	})
	categories[roleCategoryIndex].Items = items
}

type roleLayers struct {
	IDs   []int64
	Names []string
}

func (s Service) listRoleLayers(ctx context.Context) (map[int64]roleLayers, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT mapping.technical_role_id,mapping.layer_id,layer_item.name
		FROM layer_technical_role_mappings mapping
		JOIN nomenclature_items layer_item ON layer_item.id=mapping.layer_id
		ORDER BY mapping.technical_role_id,layer_item.sort_order,layer_item.name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make(map[int64]roleLayers)
	for rows.Next() {
		var roleID, layerID int64
		var layerName string
		if err := rows.Scan(&roleID, &layerID, &layerName); err != nil {
			return nil, err
		}
		value := out[roleID]
		value.IDs = append(value.IDs, layerID)
		value.Names = append(value.Names, layerName)
		out[roleID] = value
	}
	return out, rows.Err()
}

func (s Service) GetItem(ctx context.Context, id int64) (domain.NomenclatureValue, error) {
	var item domain.NomenclatureValue
	var parentID sql.NullInt64
	var parentName sql.NullString
	err := s.DB.QueryRowContext(ctx, `SELECT n.id,n.category_code,n.name,n.item_code,n.description,n.sort_order,n.active,p.parent_item_id,parent.name
		FROM nomenclature_items n
		LEFT JOIN nomenclature_item_parents p ON p.child_item_id=n.id
		LEFT JOIN nomenclature_items parent ON parent.id=p.parent_item_id
		WHERE n.id=?`, id).Scan(&item.ID, &item.CategoryCode, &item.Name, &item.ItemCode, &item.Description, &item.SortOrder, &item.Active, &parentID, &parentName)
	if err != nil {
		return item, err
	}
	if parentID.Valid {
		value := parentID.Int64
		item.ParentID = &value
	}
	if parentName.Valid {
		item.ParentName = parentName.String
	}
	if item.CategoryCode == "technical_role" {
		rows, err := s.DB.QueryContext(ctx, `SELECT mapping.layer_id,layer_item.name
			FROM layer_technical_role_mappings mapping
			JOIN nomenclature_items layer_item ON layer_item.id=mapping.layer_id
			WHERE mapping.technical_role_id=?
			ORDER BY layer_item.sort_order,layer_item.name`, id)
		if err != nil {
			return item, err
		}
		defer rows.Close()
		for rows.Next() {
			var layerID int64
			var layerName string
			if err := rows.Scan(&layerID, &layerName); err != nil {
				return item, err
			}
			item.LayerIDs = append(item.LayerIDs, layerID)
			item.LayerNames = append(item.LayerNames, layerName)
		}
		if err := rows.Err(); err != nil {
			return item, err
		}
	}
	return item, nil
}

func (s Service) CreateItem(ctx context.Context, userID int64, input ItemInput) (domain.NomenclatureValue, error) {
	if err := normalizeItem(&input); err != nil {
		return domain.NomenclatureValue{}, err
	}
	active := true
	if input.Active != nil {
		active = *input.Active
	}
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return domain.NomenclatureValue{}, err
	}
	defer tx.Rollback()
	if err := validateRelations(ctx, tx, input.CategoryCode, input.ParentID, input.LayerIDs); err != nil {
		return domain.NomenclatureValue{}, err
	}
	result, err := tx.ExecContext(ctx, `INSERT INTO nomenclature_items(category_code,name,item_code,description,sort_order,active,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?)`, input.CategoryCode, input.Name, input.ItemCode, input.Description, input.SortOrder, active, userID, userID)
	if err != nil {
		return domain.NomenclatureValue{}, err
	}
	id, _ := result.LastInsertId()
	if err := saveParent(ctx, tx, id, input.ParentID); err != nil {
		return domain.NomenclatureValue{}, err
	}
	if err := saveRoleLayers(ctx, tx, id, input.CategoryCode, input.LayerIDs, userID); err != nil {
		return domain.NomenclatureValue{}, err
	}
	if err := tx.Commit(); err != nil {
		return domain.NomenclatureValue{}, err
	}
	return s.GetItem(ctx, id)
}

func (s Service) UpdateItem(ctx context.Context, id, userID int64, input ItemInput) (domain.NomenclatureValue, error) {
	current, err := s.GetItem(ctx, id)
	if err != nil {
		return domain.NomenclatureValue{}, err
	}
	input.CategoryCode = current.CategoryCode
	if strings.TrimSpace(input.Name) == "" {
		input.Name = current.Name
	}
	if input.Active == nil {
		value := current.Active
		input.Active = &value
	}
	if input.CategoryCode == "itil_category" && input.ParentID == nil {
		input.ParentID = current.ParentID
	}
	if input.CategoryCode == "technical_role" && input.LayerIDs == nil {
		input.LayerIDs = append([]int64(nil), current.LayerIDs...)
	}
	if err := normalizeItem(&input); err != nil {
		return domain.NomenclatureValue{}, err
	}
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return domain.NomenclatureValue{}, err
	}
	defer tx.Rollback()
	if err := validateRelations(ctx, tx, input.CategoryCode, input.ParentID, input.LayerIDs); err != nil {
		return domain.NomenclatureValue{}, err
	}
	if input.CategoryCode == "technical_role" {
		if err := validateRoleLayerRemoval(ctx, tx, id, input.LayerIDs); err != nil {
			return domain.NomenclatureValue{}, err
		}
	}
	_, err = tx.ExecContext(ctx, `UPDATE nomenclature_items SET name=?,item_code=?,description=?,sort_order=?,active=?,updated_by=? WHERE id=?`, input.Name, input.ItemCode, input.Description, input.SortOrder, *input.Active, userID, id)
	if err != nil {
		return domain.NomenclatureValue{}, err
	}
	if err := saveParent(ctx, tx, id, input.ParentID); err != nil {
		return domain.NomenclatureValue{}, err
	}
	if err := saveRoleLayers(ctx, tx, id, input.CategoryCode, input.LayerIDs, userID); err != nil {
		return domain.NomenclatureValue{}, err
	}
	if err := tx.Commit(); err != nil {
		return domain.NomenclatureValue{}, err
	}
	return s.GetItem(ctx, id)
}

func validateRelations(ctx context.Context, tx *sql.Tx, category string, parentID *int64, layerIDs []int64) error {
	switch category {
	case "itil_category":
		if len(layerIDs) > 0 {
			return errors.New("layer_ids are only allowed for technical roles")
		}
		if parentID == nil || *parentID <= 0 {
			return errors.New("architectural domain is required for a service category")
		}
		var parentCategory string
		if err := tx.QueryRowContext(ctx, `SELECT category_code FROM nomenclature_items WHERE id=?`, *parentID).Scan(&parentCategory); err != nil {
			if errors.Is(err, sql.ErrNoRows) {
				return errors.New("architectural domain does not exist")
			}
			return err
		}
		if parentCategory != "architectural_domain" {
			return errors.New("parent_id must reference an architectural domain")
		}
		return nil
	case "technical_role":
		if parentID != nil && *parentID != 0 {
			return errors.New("parent_id is only allowed for service categories")
		}
		if len(layerIDs) == 0 {
			return errors.New("at least one layer is required for a technical role")
		}
		for _, layerID := range layerIDs {
			var layerCategory string
			if err := tx.QueryRowContext(ctx, `SELECT category_code FROM nomenclature_items WHERE id=?`, layerID).Scan(&layerCategory); err != nil {
				if errors.Is(err, sql.ErrNoRows) {
					return errors.New("selected layer does not exist")
				}
				return err
			}
			if layerCategory != "layer" {
				return errors.New("layer_ids must reference layer nomenclature values")
			}
		}
		return nil
	default:
		if parentID != nil && *parentID != 0 {
			return errors.New("parent_id is only allowed for service categories")
		}
		if len(layerIDs) > 0 {
			return errors.New("layer_ids are only allowed for technical roles")
		}
		return nil
	}
}

func saveParent(ctx context.Context, tx *sql.Tx, childID int64, parentID *int64) error {
	if _, err := tx.ExecContext(ctx, `DELETE FROM nomenclature_item_parents WHERE child_item_id=?`, childID); err != nil {
		return err
	}
	if parentID == nil || *parentID == 0 {
		return nil
	}
	_, err := tx.ExecContext(ctx, `INSERT INTO nomenclature_item_parents(child_item_id,parent_item_id) VALUES(?,?)`, childID, *parentID)
	return err
}

func saveRoleLayers(ctx context.Context, tx *sql.Tx, roleID int64, category string, layerIDs []int64, userID int64) error {
	if _, err := tx.ExecContext(ctx, `DELETE FROM layer_technical_role_mappings WHERE technical_role_id=?`, roleID); err != nil {
		return err
	}
	if category != "technical_role" {
		return nil
	}
	for _, layerID := range layerIDs {
		if _, err := tx.ExecContext(ctx, `INSERT INTO layer_technical_role_mappings(layer_id,technical_role_id,created_by) VALUES(?,?,?)`, layerID, roleID, userID); err != nil {
			return err
		}
	}
	return nil
}

func validateRoleLayerRemoval(ctx context.Context, tx *sql.Tx, roleID int64, layerIDs []int64) error {
	allowed := make(map[int64]bool, len(layerIDs))
	for _, layerID := range layerIDs {
		allowed[layerID] = true
	}
	rows, err := tx.QueryContext(ctx, `SELECT DISTINCT layer_id
		FROM vm_internal_service_assignments
		WHERE technical_role_id=? AND layer_id IS NOT NULL`, roleID)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var layerID int64
		if err := rows.Scan(&layerID); err != nil {
			return err
		}
		if !allowed[layerID] {
			return errors.New("a layer must not be removed from a technical role while the pair is used by a VM")
		}
	}
	return rows.Err()
}

func (s Service) ListPeople(ctx context.Context, includeInactive bool) ([]domain.Person, error) {
	query := `SELECT id,display_name,email,phone,department,source,directory_username,active,created_at,updated_at FROM people`
	if !includeInactive {
		query += ` WHERE active=1`
	}
	query += ` ORDER BY display_name,email`
	rows, err := s.DB.QueryContext(ctx, query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.Person, 0)
	for rows.Next() {
		var value domain.Person
		if err := rows.Scan(&value.ID, &value.DisplayName, &value.Email, &value.Phone, &value.Department, &value.Source, &value.DirectoryUsername, &value.Active, &value.CreatedAt, &value.UpdatedAt); err != nil {
			return nil, err
		}
		out = append(out, value)
	}
	return out, rows.Err()
}

func (s Service) GetPerson(ctx context.Context, id int64) (domain.Person, error) {
	var value domain.Person
	err := s.DB.QueryRowContext(ctx, `SELECT id,display_name,email,phone,department,source,directory_username,active,created_at,updated_at FROM people WHERE id=?`, id).Scan(&value.ID, &value.DisplayName, &value.Email, &value.Phone, &value.Department, &value.Source, &value.DirectoryUsername, &value.Active, &value.CreatedAt, &value.UpdatedAt)
	return value, err
}

func (s Service) CreatePerson(ctx context.Context, userID int64, input PersonInput) (domain.Person, error) {
	if err := normalizePerson(&input); err != nil {
		return domain.Person{}, err
	}
	active := true
	if input.Active != nil {
		active = *input.Active
	}
	result, err := s.DB.ExecContext(ctx, `INSERT INTO people(display_name,email,phone,department,active,created_by,updated_by) VALUES(?,?,?,?,?,?,?)`, input.DisplayName, input.Email, input.Phone, input.Department, active, userID, userID)
	if err != nil {
		return domain.Person{}, err
	}
	id, _ := result.LastInsertId()
	return s.GetPerson(ctx, id)
}

func (s Service) UpdatePerson(ctx context.Context, id, userID int64, input PersonInput) (domain.Person, error) {
	current, err := s.GetPerson(ctx, id)
	if err != nil {
		return domain.Person{}, err
	}
	if strings.TrimSpace(input.DisplayName) == "" {
		input.DisplayName = current.DisplayName
	}
	if input.Active == nil {
		value := current.Active
		input.Active = &value
	}
	if err := normalizePerson(&input); err != nil {
		return domain.Person{}, err
	}
	_, err = s.DB.ExecContext(ctx, `UPDATE people SET display_name=?,email=?,phone=?,department=?,active=?,updated_by=? WHERE id=?`, input.DisplayName, input.Email, input.Phone, input.Department, *input.Active, userID, id)
	if err != nil {
		return domain.Person{}, err
	}
	return s.GetPerson(ctx, id)
}

func (s Service) ImportDirectoryUsers(ctx context.Context, userID int64, users []directory.User) ([]domain.Person, error) {
	if len(users) == 0 {
		return nil, errors.New("at least one directory user is required")
	}
	if len(users) > 100 {
		return nil, errors.New("at most 100 directory users can be imported at once")
	}
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback()
	ids := make([]int64, 0, len(users))
	for _, directoryUser := range users {
		input := PersonInput{
			DisplayName: directoryUser.DisplayName,
			Email:       directoryUser.Email,
			Phone:       directoryUser.Phone,
			Department:  directoryUser.Department,
		}
		if err := normalizePerson(&input); err != nil {
			return nil, err
		}
		dn := strings.TrimSpace(directoryUser.DistinguishedName)
		if dn == "" {
			return nil, errors.New("directory distinguished name is required")
		}
		directoryKey := strings.TrimSpace(directoryUser.StableKey)
		if directoryKey == "" {
			digest := sha256.Sum256([]byte("dn\x00" + strings.ToLower(dn)))
			directoryKey = hex.EncodeToString(digest[:])
		}
		username := strings.TrimSpace(directoryUser.Username)

		var id int64
		err := tx.QueryRowContext(ctx, `SELECT id FROM people WHERE source='ldap' AND directory_key=? LIMIT 1`, directoryKey).Scan(&id)
		if errors.Is(err, sql.ErrNoRows) && username != "" {
			err = tx.QueryRowContext(ctx, `SELECT id FROM people WHERE source='ldap' AND directory_username=? ORDER BY id LIMIT 1`, username).Scan(&id)
		}
		if errors.Is(err, sql.ErrNoRows) && input.Email != "" {
			err = tx.QueryRowContext(ctx, `SELECT id FROM people WHERE email=? ORDER BY id LIMIT 1`, input.Email).Scan(&id)
		}
		switch {
		case err == nil:
			_, err = tx.ExecContext(ctx, `UPDATE people SET display_name=?,email=?,phone=?,department=?,source='ldap',directory_key=?,directory_username=?,directory_dn=?,active=1,updated_by=? WHERE id=?`, input.DisplayName, input.Email, input.Phone, input.Department, directoryKey, username, dn, userID, id)
		case errors.Is(err, sql.ErrNoRows):
			result, insertErr := tx.ExecContext(ctx, `INSERT INTO people(display_name,email,phone,department,source,directory_key,directory_username,directory_dn,active,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?,1,?,?)`, input.DisplayName, input.Email, input.Phone, input.Department, "ldap", directoryKey, username, dn, userID, userID)
			if insertErr != nil {
				return nil, insertErr
			}
			id, err = result.LastInsertId()
		default:
			return nil, err
		}
		if err != nil {
			return nil, err
		}
		ids = append(ids, id)
	}
	if err := tx.Commit(); err != nil {
		return nil, err
	}
	out := make([]domain.Person, 0, len(ids))
	for _, id := range ids {
		person, err := s.GetPerson(ctx, id)
		if err != nil {
			return nil, err
		}
		out = append(out, person)
	}
	return out, nil
}

func normalizeItem(input *ItemInput) error {
	input.CategoryCode = strings.ToLower(strings.TrimSpace(input.CategoryCode))
	input.Name = strings.TrimSpace(input.Name)
	input.ItemCode = strings.ToLower(strings.TrimSpace(input.ItemCode))
	input.Description = strings.TrimSpace(input.Description)
	if !AllowedCategories[input.CategoryCode] {
		return errors.New("invalid nomenclature category")
	}
	if input.Name == "" {
		return errors.New("name is required")
	}
	if len([]rune(input.Name)) > 255 || len([]rune(input.Description)) > 4000 {
		return errors.New("nomenclature value is too long")
	}
	if input.ItemCode != "" && !codePattern.MatchString(input.ItemCode) {
		return errors.New("item_code is invalid")
	}
	if input.SortOrder < -100000 || input.SortOrder > 100000 {
		return errors.New("sort_order must be between -100000 and 100000")
	}
	layerIDs, err := normalizeLayerIDs(input.LayerIDs)
	if err != nil {
		return err
	}
	input.LayerIDs = layerIDs
	return nil
}

func normalizeLayerIDs(values []int64) ([]int64, error) {
	if values == nil {
		return nil, nil
	}
	if len(values) > 500 {
		return nil, errors.New("at most 500 layers are allowed for a technical role")
	}
	seen := make(map[int64]bool, len(values))
	out := make([]int64, 0, len(values))
	for _, value := range values {
		if value <= 0 {
			return nil, errors.New("layer_ids must contain positive identifiers")
		}
		if seen[value] {
			continue
		}
		seen[value] = true
		out = append(out, value)
	}
	sort.Slice(out, func(i, j int) bool { return out[i] < out[j] })
	return out, nil
}

func normalizePerson(input *PersonInput) error {
	input.DisplayName = strings.TrimSpace(input.DisplayName)
	input.Email = strings.ToLower(strings.TrimSpace(input.Email))
	input.Phone = strings.TrimSpace(input.Phone)
	input.Department = strings.TrimSpace(input.Department)
	if input.DisplayName == "" {
		return errors.New("display_name is required")
	}
	if len([]rune(input.DisplayName)) > 255 || len([]rune(input.Email)) > 255 || len([]rune(input.Phone)) > 64 || len([]rune(input.Department)) > 255 {
		return errors.New("person value is too long")
	}
	if input.Email != "" {
		address, err := mail.ParseAddress(input.Email)
		if err != nil || strings.ToLower(address.Address) != input.Email {
			return errors.New("email is invalid")
		}
	}
	return nil
}

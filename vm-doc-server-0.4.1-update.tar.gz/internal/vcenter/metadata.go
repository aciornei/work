package vcenter

import (
	"context"
	"database/sql"
	"errors"
	"net/mail"
	"net/url"
	"strconv"
	"strings"

	"vm-doc-server/internal/domain"
)

var operationalCategories = []struct {
	Code string
	ID   func(*OperationalMetadataInput) *int64
	Name func(*OperationalMetadataInput) string
}{
	{"environment", func(v *OperationalMetadataInput) *int64 { return v.EnvironmentID }, func(v *OperationalMetadataInput) string { return v.Environment }},
	{"operational_status", func(v *OperationalMetadataInput) *int64 { return v.OperationalStatusID }, func(v *OperationalMetadataInput) string { return v.OperationalStatus }},
	{"classification", func(v *OperationalMetadataInput) *int64 { return v.ClassificationID }, func(v *OperationalMetadataInput) string { return v.Classification }},
}

var allowedResponsibilityTypes = map[string]bool{
	"technical_admin":      true,
	"service_owner":        true,
	"business_owner":       true,
	"application_owner":    true,
	"infrastructure_owner": true,
	"security_contact":     true,
	"backup_contact":       true,
	"other":                true,
}

var allowedServiceUsageTypes = map[string]bool{
	"dedicated":  true,
	"shared":     true,
	"dependency": true,
}

type ResponsibilityInput struct {
	PersonID           int64  `json:"person_id"`
	ResponsibilityType string `json:"responsibility_type"`
	Notes              string `json:"notes"`
	SortOrder          int    `json:"sort_order"`
}

type ServiceAssignmentInput struct {
	ArchitecturalDomainID int64  `json:"architectural_domain_id"`
	ITILCategoryID        int64  `json:"itil_category_id"`
	InternalServiceID     int64  `json:"internal_service_id"`
	LayerID               int64  `json:"layer_id"`
	TechnicalRoleID       int64  `json:"technical_role_id"`
	UsageType             string `json:"usage_type"`
	Primary               bool   `json:"is_primary"`
	Notes                 string `json:"notes"`
	SortOrder             int    `json:"sort_order"`
}

type OperationalMetadataInput struct {
	EnvironmentID       *int64 `json:"environment_id"`
	OperationalStatusID *int64 `json:"operational_status_id"`
	ClassificationID    *int64 `json:"classification_id"`

	Purpose          string `json:"purpose"`
	DocumentationURL string `json:"documentation_url"`
	TicketReference  string `json:"ticket_reference"`
	Notes            string `json:"notes"`

	Responsibilities []ResponsibilityInput `json:"responsibilities"`

	// Accepted only so a stale browser tab from releases before 0.3.6 does not
	// fail JSON decoding. These fields are no longer persisted by this endpoint.
	ITILCategoryID        *int64 `json:"itil_category_id,omitempty"`
	InternalServiceID     *int64 `json:"internal_service_id,omitempty"`
	ArchitecturalDomainID *int64 `json:"architectural_domain_id,omitempty"`
	LayerID               *int64 `json:"layer_id,omitempty"`
	TechnicalRoleID       *int64 `json:"technical_role_id,omitempty"`
	ProvisioningProfileID *int64 `json:"provisioning_profile_id,omitempty"`
	ProvisionedAt         string `json:"provisioned_at,omitempty"`
	ServiceID             *int64 `json:"service_id,omitempty"`
	ComponentID           *int64 `json:"component_id,omitempty"`
	ServiceName           string `json:"service_name,omitempty"`
	ComponentName         string `json:"component_name,omitempty"`
	ArchitecturalDomain   string `json:"architectural_domain,omitempty"`
	LayerName             string `json:"layer_name,omitempty"`
	Environment           string `json:"environment,omitempty"`
	OperationalStatus     string `json:"operational_status,omitempty"`
	TechnicalAdmin        string `json:"technical_admin,omitempty"`
	BusinessOwner         string `json:"business_owner,omitempty"`
	OwnerEmail            string `json:"owner_email,omitempty"`
	ProvisioningProfile   string `json:"provisioning_profile,omitempty"`
	BackupPolicy          string `json:"backup_policy,omitempty"`
	RPOMinutes            *int   `json:"rpo_minutes,omitempty"`
	RTOMinutes            *int   `json:"rto_minutes,omitempty"`
	Classification        string `json:"classification,omitempty"`
}

type resolvedNomenclature struct {
	ID   int64
	Name string
}

func (s *Service) GetOperationalMetadata(ctx context.Context, vmID int64) (domain.VMOperationalMetadata, error) {
	value := domain.VMOperationalMetadata{
		VMID:               vmID,
		ServiceAssignments: make([]domain.VMServiceAssignment, 0),
		Responsibilities:   make([]domain.VMResponsibility, 0),
	}
	var updatedBy sql.NullInt64
	err := s.DB.QueryRowContext(ctx, `SELECT vm_id,environment,operational_status,purpose,classification,documentation_url,ticket_reference,notes,updated_by,created_at,updated_at FROM vm_operational_metadata WHERE vm_id=?`, vmID).Scan(
		&value.VMID, &value.Environment, &value.OperationalStatus, &value.Purpose, &value.Classification, &value.DocumentationURL, &value.TicketReference, &value.Notes, &updatedBy, &value.CreatedAt, &value.UpdatedAt,
	)
	if err != nil && !errors.Is(err, sql.ErrNoRows) {
		return value, err
	}
	if updatedBy.Valid {
		n := updatedBy.Int64
		value.UpdatedBy = &n
	}
	if err := s.loadOperationalNomenclatures(ctx, &value); err != nil {
		return value, err
	}
	assignments, err := s.ListVMServiceAssignments(ctx, vmID)
	if err != nil {
		return value, err
	}
	value.ServiceAssignments = assignments
	responsibilities, err := s.listResponsibilities(ctx, vmID)
	if err != nil {
		return value, err
	}
	value.Responsibilities = responsibilities
	return value, nil
}

func (s *Service) loadOperationalNomenclatures(ctx context.Context, value *domain.VMOperationalMetadata) error {
	rows, err := s.DB.QueryContext(ctx, `SELECT m.category_code,n.id,n.name FROM vm_operational_nomenclatures m JOIN nomenclature_items n ON n.id=m.item_id WHERE m.vm_id=?`, value.VMID)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var code, name string
		var id int64
		if err := rows.Scan(&code, &id, &name); err != nil {
			return err
		}
		switch code {
		case "environment":
			value.EnvironmentID, value.Environment = int64Ptr(id), name
		case "operational_status":
			value.OperationalStatusID, value.OperationalStatus = int64Ptr(id), name
		case "classification":
			value.ClassificationID, value.Classification = int64Ptr(id), name
		}
	}
	return rows.Err()
}

func (s *Service) ListVMServiceAssignments(ctx context.Context, vmID int64) ([]domain.VMServiceAssignment, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT assignment.id,assignment.vm_id,service.id,service.name,assignment.itil_category_id,category_item.name,assignment.architectural_domain_id,domain_item.name,assignment.layer_id,COALESCE(layer_item.name,''),assignment.technical_role_id,COALESCE(role_item.name,''),assignment.usage_type,assignment.is_primary,assignment.notes,assignment.sort_order
		FROM vm_internal_service_assignments assignment
		JOIN internal_services service ON service.id=assignment.internal_service_id
		JOIN nomenclature_items category_item ON category_item.id=assignment.itil_category_id AND category_item.category_code='itil_category'
		JOIN nomenclature_items domain_item ON domain_item.id=assignment.architectural_domain_id AND domain_item.category_code='architectural_domain' 
		LEFT JOIN nomenclature_items layer_item ON layer_item.id=assignment.layer_id
		LEFT JOIN nomenclature_items role_item ON role_item.id=assignment.technical_role_id
		WHERE assignment.vm_id=?
		ORDER BY assignment.is_primary DESC,assignment.sort_order,service.name,layer_item.name,role_item.name,assignment.id`, vmID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.VMServiceAssignment, 0)
	for rows.Next() {
		var value domain.VMServiceAssignment
		var domainID, layerID, roleID sql.NullInt64
		if err := rows.Scan(&value.ID, &value.VMID, &value.InternalServiceID, &value.InternalServiceName, &value.ITILCategoryID, &value.ITILCategory, &domainID, &value.ArchitecturalDomain, &layerID, &value.LayerName, &roleID, &value.TechnicalRole, &value.UsageType, &value.Primary, &value.Notes, &value.SortOrder); err != nil {
			return nil, err
		}
		if domainID.Valid {
			id := domainID.Int64
			value.ArchitecturalDomainID = &id
		}
		if layerID.Valid {
			id := layerID.Int64
			value.LayerID = &id
		}
		if roleID.Valid {
			id := roleID.Int64
			value.TechnicalRoleID = &id
		}
		out = append(out, value)
	}
	return out, rows.Err()
}

func (s *Service) ReplaceVMServiceAssignments(ctx context.Context, vmID, userID int64, inputs []ServiceAssignmentInput) ([]domain.VMServiceAssignment, error) {
	var vmExists int
	if err := s.DB.QueryRowContext(ctx, `SELECT 1 FROM virtual_machines WHERE id=?`, vmID).Scan(&vmExists); err != nil {
		return nil, err
	}
	if len(inputs) > 500 {
		return nil, errors.New("at most 500 service assignments are allowed")
	}
	seen := make(map[string]bool)
	primaryCount := 0
	for i := range inputs {
		input := &inputs[i]
		input.UsageType = strings.ToLower(strings.TrimSpace(input.UsageType))
		input.Notes = strings.TrimSpace(input.Notes)
		if input.UsageType == "" {
			input.UsageType = "dedicated"
		}
		if input.ArchitecturalDomainID <= 0 || input.ITILCategoryID <= 0 || input.InternalServiceID <= 0 || input.LayerID <= 0 || input.TechnicalRoleID <= 0 {
			return nil, errors.New("architectural_domain_id, itil_category_id, internal_service_id, layer_id and technical_role_id are required")
		}
		if !allowedServiceUsageTypes[input.UsageType] {
			return nil, errors.New("invalid usage_type")
		}
		if input.SortOrder < -100000 || input.SortOrder > 100000 {
			return nil, errors.New("sort_order must be between -100000 and 100000")
		}
		if len([]rune(input.Notes)) > 1000 {
			return nil, errors.New("service assignment notes are too long")
		}
		key := strconv.FormatInt(input.ArchitecturalDomainID, 10) + ":" + strconv.FormatInt(input.ITILCategoryID, 10) + ":" + strconv.FormatInt(input.InternalServiceID, 10) + ":" + strconv.FormatInt(input.LayerID, 10) + ":" + strconv.FormatInt(input.TechnicalRoleID, 10)
		if seen[key] {
			return nil, errors.New("duplicate service, layer and technical role assignment")
		}
		seen[key] = true
		if input.Primary {
			primaryCount++
		}
		var exists int
		err := s.DB.QueryRowContext(ctx, `SELECT 1
			FROM internal_services service
			JOIN nomenclature_items domain_item ON domain_item.id=? AND domain_item.category_code='architectural_domain'
			JOIN nomenclature_items category_item ON category_item.id=? AND category_item.category_code='itil_category'
			JOIN nomenclature_item_parents category_parent ON category_parent.child_item_id=category_item.id AND category_parent.parent_item_id=domain_item.id
			JOIN layer_technical_role_mappings mapping ON mapping.layer_id=? AND mapping.technical_role_id=?
			JOIN nomenclature_items layer_item ON layer_item.id=mapping.layer_id AND layer_item.category_code='layer'
			JOIN nomenclature_items role_item ON role_item.id=mapping.technical_role_id AND role_item.category_code='technical_role'
			WHERE service.id=?`, input.ArchitecturalDomainID, input.ITILCategoryID, input.LayerID, input.TechnicalRoleID, input.InternalServiceID).Scan(&exists)
		if errors.Is(err, sql.ErrNoRows) {
			return nil, errors.New("invalid domain, service category, service, layer or technical role")
		}
		if err != nil {
			return nil, err
		}
	}
	if primaryCount > 1 {
		return nil, errors.New("only one service assignment can be primary")
	}

	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback()
	if _, err := tx.ExecContext(ctx, `DELETE FROM vm_internal_service_assignments WHERE vm_id=?`, vmID); err != nil {
		return nil, err
	}
	for _, input := range inputs {
		if _, err := tx.ExecContext(ctx, `INSERT INTO vm_internal_service_assignments(vm_id,architectural_domain_id,itil_category_id,internal_service_id,layer_id,technical_role_id,usage_type,is_primary,notes,sort_order,updated_by) VALUES(?,?,?,?,?,?,?,?,?,?,?)`, vmID, input.ArchitecturalDomainID, input.ITILCategoryID, input.InternalServiceID, input.LayerID, input.TechnicalRoleID, input.UsageType, input.Primary, input.Notes, input.SortOrder, userID); err != nil {
			return nil, err
		}
	}
	if err := tx.Commit(); err != nil {
		return nil, err
	}
	return s.ListVMServiceAssignments(ctx, vmID)
}

func (s *Service) listResponsibilities(ctx context.Context, vmID int64) ([]domain.VMResponsibility, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT r.id,r.person_id,p.display_name,p.email,p.phone,p.department,r.responsibility_type,r.notes,r.sort_order FROM vm_responsibilities r JOIN people p ON p.id=r.person_id WHERE r.vm_id=? ORDER BY r.sort_order,r.id`, vmID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.VMResponsibility, 0)
	for rows.Next() {
		var value domain.VMResponsibility
		if err := rows.Scan(&value.ID, &value.PersonID, &value.PersonName, &value.PersonEmail, &value.PersonPhone, &value.PersonDepartment, &value.ResponsibilityType, &value.Notes, &value.SortOrder); err != nil {
			return nil, err
		}
		out = append(out, value)
	}
	return out, rows.Err()
}

func (s *Service) SaveOperationalMetadata(ctx context.Context, vmID, userID int64, input OperationalMetadataInput) (domain.VMOperationalMetadata, error) {
	if err := normalizeOperationalMetadata(&input); err != nil {
		return domain.VMOperationalMetadata{}, err
	}
	var vmExists int
	if err := s.DB.QueryRowContext(ctx, `SELECT 1 FROM virtual_machines WHERE id=?`, vmID).Scan(&vmExists); err != nil {
		return domain.VMOperationalMetadata{}, err
	}
	resolved, err := s.resolveOperationalNomenclatures(ctx, &input)
	if err != nil {
		return domain.VMOperationalMetadata{}, err
	}
	responsibilities, err := s.resolveLegacyResponsibilities(ctx, input)
	if err != nil {
		return domain.VMOperationalMetadata{}, err
	}
	if err := validateResponsibilities(ctx, s.DB, responsibilities); err != nil {
		return domain.VMOperationalMetadata{}, err
	}
	for _, item := range []*int64{input.EnvironmentID, input.OperationalStatusID, input.ClassificationID} {
		if item != nil && *item < 0 {
			return domain.VMOperationalMetadata{}, errors.New("identifier values must be positive")
		}
	}
	labels := func(code string) string {
		if value, ok := resolved[code]; ok {
			return value.Name
		}
		return ""
	}
	legacyAdmin, legacyOwner, legacyEmail := legacyResponsibilityFields(ctx, s.DB, responsibilities)

	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return domain.VMOperationalMetadata{}, err
	}
	defer tx.Rollback()
	_, err = tx.ExecContext(ctx, `INSERT INTO vm_operational_metadata(vm_id,service_name,component_name,architectural_domain,layer_name,environment,operational_status,purpose,technical_admin,business_owner,owner_email,provisioning_profile,provisioned_at,rpo_minutes,rto_minutes,backup_policy,classification,documentation_url,ticket_reference,notes,updated_by)
		VALUES(?,'','','','',?,?,?,?,?,?,'',NULL,NULL,NULL,'',?,?,?,?,?)
		ON DUPLICATE KEY UPDATE service_name='',component_name='',architectural_domain='',layer_name='',environment=VALUES(environment),operational_status=VALUES(operational_status),purpose=VALUES(purpose),technical_admin=VALUES(technical_admin),business_owner=VALUES(business_owner),owner_email=VALUES(owner_email),provisioning_profile='',provisioned_at=NULL,classification=VALUES(classification),documentation_url=VALUES(documentation_url),ticket_reference=VALUES(ticket_reference),notes=VALUES(notes),updated_by=VALUES(updated_by)`,
		vmID, labels("environment"), labels("operational_status"), input.Purpose, legacyAdmin, legacyOwner, legacyEmail, labels("classification"), input.DocumentationURL, input.TicketReference, input.Notes, userID,
	)
	if err != nil {
		return domain.VMOperationalMetadata{}, err
	}
	if _, err := tx.ExecContext(ctx, `DELETE FROM vm_operational_nomenclatures WHERE vm_id=?`, vmID); err != nil {
		return domain.VMOperationalMetadata{}, err
	}
	for code, value := range resolved {
		if _, err := tx.ExecContext(ctx, `INSERT INTO vm_operational_nomenclatures(vm_id,category_code,item_id) VALUES(?,?,?)`, vmID, code, value.ID); err != nil {
			return domain.VMOperationalMetadata{}, err
		}
	}
	if _, err := tx.ExecContext(ctx, `DELETE FROM vm_responsibilities WHERE vm_id=?`, vmID); err != nil {
		return domain.VMOperationalMetadata{}, err
	}
	for _, item := range responsibilities {
		if _, err := tx.ExecContext(ctx, `INSERT INTO vm_responsibilities(vm_id,person_id,responsibility_type,notes,sort_order,created_by) VALUES(?,?,?,?,?,?)`, vmID, item.PersonID, item.ResponsibilityType, item.Notes, item.SortOrder, userID); err != nil {
			return domain.VMOperationalMetadata{}, err
		}
	}
	// A request from a stale browser tab may contain the former manual backup fields.
	if input.BackupPolicy != "" || input.RPOMinutes != nil || input.RTOMinutes != nil {
		_, err = tx.ExecContext(ctx, `INSERT INTO vm_backup_summary(vm_id,provider,protected,policy_name,rpo_minutes,rto_minutes,error_message) VALUES(?,'manual',?,?,?,?,'') ON DUPLICATE KEY UPDATE protected=VALUES(protected),policy_name=VALUES(policy_name),rpo_minutes=VALUES(rpo_minutes),rto_minutes=VALUES(rto_minutes)`, vmID, input.BackupPolicy != "", input.BackupPolicy, nullableInt(input.RPOMinutes), nullableInt(input.RTOMinutes))
		if err != nil {
			return domain.VMOperationalMetadata{}, err
		}
	}
	if err := tx.Commit(); err != nil {
		return domain.VMOperationalMetadata{}, err
	}
	return s.GetOperationalMetadata(ctx, vmID)
}

func (s *Service) resolveOperationalNomenclatures(ctx context.Context, input *OperationalMetadataInput) (map[string]resolvedNomenclature, error) {
	out := make(map[string]resolvedNomenclature)
	for _, field := range operationalCategories {
		id := field.ID(input)
		legacyName := strings.TrimSpace(field.Name(input))
		if id == nil || *id == 0 {
			if legacyName == "" {
				continue
			}
			var value resolvedNomenclature
			err := s.DB.QueryRowContext(ctx, `SELECT id,name FROM nomenclature_items WHERE category_code=? AND name=?`, field.Code, legacyName).Scan(&value.ID, &value.Name)
			if err != nil {
				return nil, errors.New(field.Code + " must be selected from nomenclatures")
			}
			out[field.Code] = value
			continue
		}
		var value resolvedNomenclature
		err := s.DB.QueryRowContext(ctx, `SELECT id,name FROM nomenclature_items WHERE id=? AND category_code=?`, *id, field.Code).Scan(&value.ID, &value.Name)
		if errors.Is(err, sql.ErrNoRows) {
			return nil, errors.New("invalid nomenclature value for " + field.Code)
		}
		if err != nil {
			return nil, err
		}
		out[field.Code] = value
	}
	return out, nil
}

func (s *Service) resolveLegacyResponsibilities(ctx context.Context, input OperationalMetadataInput) ([]ResponsibilityInput, error) {
	if len(input.Responsibilities) > 0 || (input.TechnicalAdmin == "" && input.BusinessOwner == "") {
		return input.Responsibilities, nil
	}
	out := make([]ResponsibilityInput, 0, 2)
	for _, legacy := range []struct {
		name, email, kind string
	}{{input.TechnicalAdmin, "", "technical_admin"}, {input.BusinessOwner, input.OwnerEmail, "service_owner"}} {
		if strings.TrimSpace(legacy.name) == "" {
			continue
		}
		var id int64
		err := s.DB.QueryRowContext(ctx, `SELECT id FROM people WHERE display_name=? AND email=?`, strings.TrimSpace(legacy.name), strings.ToLower(strings.TrimSpace(legacy.email))).Scan(&id)
		if errors.Is(err, sql.ErrNoRows) {
			return nil, errors.New("responsible person must be selected from People")
		}
		if err != nil {
			return nil, err
		}
		out = append(out, ResponsibilityInput{PersonID: id, ResponsibilityType: legacy.kind, SortOrder: len(out)})
	}
	return out, nil
}

func validateResponsibilities(ctx context.Context, db *sql.DB, values []ResponsibilityInput) error {
	seen := make(map[string]bool)
	for i := range values {
		values[i].ResponsibilityType = strings.ToLower(strings.TrimSpace(values[i].ResponsibilityType))
		values[i].Notes = strings.TrimSpace(values[i].Notes)
		if values[i].PersonID <= 0 {
			return errors.New("person_id is required for every responsibility")
		}
		if !allowedResponsibilityTypes[values[i].ResponsibilityType] {
			return errors.New("invalid responsibility_type")
		}
		if len([]rune(values[i].Notes)) > 512 {
			return errors.New("responsibility notes are too long")
		}
		key := strconv.FormatInt(values[i].PersonID, 10) + ":" + values[i].ResponsibilityType
		if seen[key] {
			return errors.New("duplicate VM responsibility")
		}
		seen[key] = true
		var exists int
		if err := db.QueryRowContext(ctx, `SELECT 1 FROM people WHERE id=?`, values[i].PersonID).Scan(&exists); err != nil {
			if errors.Is(err, sql.ErrNoRows) {
				return errors.New("responsible person does not exist")
			}
			return err
		}
	}
	return nil
}

func legacyResponsibilityFields(ctx context.Context, db *sql.DB, values []ResponsibilityInput) (technicalAdmin, owner, ownerEmail string) {
	for _, item := range values {
		var name, email string
		if err := db.QueryRowContext(ctx, `SELECT display_name,email FROM people WHERE id=?`, item.PersonID).Scan(&name, &email); err != nil {
			continue
		}
		if technicalAdmin == "" && item.ResponsibilityType == "technical_admin" {
			technicalAdmin = name
		}
		if owner == "" && (item.ResponsibilityType == "service_owner" || item.ResponsibilityType == "business_owner") {
			owner, ownerEmail = name, email
		}
	}
	return
}

func (s *Service) GetBackupSummary(ctx context.Context, vmID int64) (domain.VMBackupSummary, error) {
	value := domain.VMBackupSummary{VMID: vmID, Provider: "veeam"}
	var lastBackup, nextRun, syncedAt sql.NullTime
	var restorePoints, rpo, rto sql.NullInt64
	var rawJSON []byte
	err := s.DB.QueryRowContext(ctx, `SELECT vm_id,provider,source_name,protected,job_name,policy_name,repository_name,last_result,last_backup_at,next_run_at,restore_points,rpo_minutes,rto_minutes,synced_at,error_message,raw_json,updated_at FROM vm_backup_summary WHERE vm_id=?`, vmID).Scan(
		&value.VMID, &value.Provider, &value.SourceName, &value.Protected, &value.JobName, &value.PolicyName, &value.RepositoryName, &value.LastResult, &lastBackup, &nextRun, &restorePoints, &rpo, &rto, &syncedAt, &value.ErrorMessage, &rawJSON, &value.UpdatedAt,
	)
	if errors.Is(err, sql.ErrNoRows) {
		return value, nil
	}
	if err != nil {
		return value, err
	}
	value.RawJSON = rawJSON
	if lastBackup.Valid {
		value.LastBackupAt = &lastBackup.Time
	}
	if nextRun.Valid {
		value.NextRunAt = &nextRun.Time
	}
	if syncedAt.Valid {
		value.SyncedAt = &syncedAt.Time
	}
	if restorePoints.Valid {
		n := int(restorePoints.Int64)
		value.RestorePoints = &n
	}
	if rpo.Valid {
		n := int(rpo.Int64)
		value.RPOMinutes = &n
	}
	if rto.Valid {
		n := int(rto.Int64)
		value.RTOMinutes = &n
	}
	return value, nil
}

func normalizeOperationalMetadata(input *OperationalMetadataInput) error {
	input.Purpose = strings.TrimSpace(input.Purpose)
	input.DocumentationURL = strings.TrimSpace(input.DocumentationURL)
	input.TicketReference = strings.TrimSpace(input.TicketReference)
	input.Notes = strings.TrimSpace(input.Notes)
	input.Environment = strings.TrimSpace(input.Environment)
	input.OperationalStatus = strings.TrimSpace(input.OperationalStatus)
	input.TechnicalAdmin = strings.TrimSpace(input.TechnicalAdmin)
	input.BusinessOwner = strings.TrimSpace(input.BusinessOwner)
	input.OwnerEmail = strings.ToLower(strings.TrimSpace(input.OwnerEmail))
	input.BackupPolicy = strings.TrimSpace(input.BackupPolicy)
	input.Classification = strings.TrimSpace(input.Classification)

	for _, item := range []*int{input.RPOMinutes, input.RTOMinutes} {
		if item != nil && (*item < 0 || *item > 5256000) {
			return errors.New("RPO/RTO must be between 0 and 5256000 minutes")
		}
	}
	if input.OwnerEmail != "" {
		address, err := mail.ParseAddress(input.OwnerEmail)
		if err != nil || strings.ToLower(address.Address) != input.OwnerEmail {
			return errors.New("owner_email is invalid")
		}
	}
	if input.DocumentationURL != "" {
		parsed, err := url.ParseRequestURI(input.DocumentationURL)
		if err != nil || (parsed.Scheme != "http" && parsed.Scheme != "https") || parsed.Host == "" {
			return errors.New("documentation_url must be an absolute HTTP or HTTPS URL")
		}
	}
	limits := []struct {
		name  string
		value string
		max   int
	}{
		{"documentation_url", input.DocumentationURL, 1024}, {"ticket_reference", input.TicketReference, 255},
		{"backup_policy", input.BackupPolicy, 255}, {"environment", input.Environment, 64},
		{"operational_status", input.OperationalStatus, 64}, {"technical_admin", input.TechnicalAdmin, 255}, {"business_owner", input.BusinessOwner, 255},
		{"owner_email", input.OwnerEmail, 255}, {"classification", input.Classification, 128},
	}
	for _, limit := range limits {
		if len([]rune(limit.value)) > limit.max {
			return errors.New(limit.name + " is too long")
		}
	}
	return nil
}

func nullableInt(value *int) any {
	if value == nil {
		return nil
	}
	return *value
}

func int64Ptr(value int64) *int64 { return &value }

package directory

import (
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"encoding/hex"
	"errors"
	"fmt"
	"net"
	"os"
	"sort"
	"strings"
	"time"

	"github.com/go-ldap/ldap/v3"
	"vm-doc-server/internal/config"
)

type Service struct {
	Config  config.LDAPConfig
	BindDN  string
	BindPwd string
}

type DepartmentResult struct {
	Enabled           bool     `json:"enabled"`
	Departments       []string `json:"departments"`
	DefaultDepartment string   `json:"default_department,omitempty"`
	BaseDN            string   `json:"base_dn,omitempty"`
}

type User struct {
	DistinguishedName string   `json:"distinguished_name"`
	Username          string   `json:"username"`
	DisplayName       string   `json:"display_name"`
	Email             string   `json:"email,omitempty"`
	Phone             string   `json:"phone,omitempty"`
	Department        string   `json:"department,omitempty"`
	OUPath            []string `json:"ou_path"`
	StableKey         string   `json:"-"`
}

func (s Service) Enabled() bool {
	return s.Config.Enabled && s.Config.Directory.Enabled
}

func (s Service) Departments() (DepartmentResult, error) {
	result := DepartmentResult{Enabled: s.Enabled()}
	if !result.Enabled {
		return result, nil
	}
	result.BaseDN = s.Config.Directory.BaseDN
	attrs := []string{s.Config.Directory.DepartmentAttribute}
	filter := andFilter(s.Config.Directory.UserFilter, fmt.Sprintf("(%s=*)", s.Config.Directory.DepartmentAttribute))
	entries, err := s.search(s.Config.Directory.BaseDN, ldap.ScopeWholeSubtree, filter, attrs)
	if err != nil {
		return result, err
	}
	byFolded := make(map[string]string)
	for _, entry := range entries {
		department := strings.TrimSpace(entry.GetAttributeValue(s.Config.Directory.DepartmentAttribute))
		if department == "" {
			continue
		}
		key := strings.ToLower(department)
		if _, exists := byFolded[key]; !exists {
			byFolded[key] = department
		}
	}
	for _, department := range byFolded {
		result.Departments = append(result.Departments, department)
	}
	sort.Slice(result.Departments, func(i, j int) bool {
		return strings.ToLower(result.Departments[i]) < strings.ToLower(result.Departments[j])
	})
	configured := strings.TrimSpace(s.Config.Directory.DefaultDepartment)
	if configured != "" {
		for _, department := range result.Departments {
			if strings.EqualFold(department, configured) {
				result.DefaultDepartment = department
				break
			}
		}
	}
	if result.DefaultDepartment == "" && len(result.Departments) > 0 {
		result.DefaultDepartment = result.Departments[0]
	}
	return result, nil
}

func (s Service) Users(department string) ([]User, error) {
	if !s.Enabled() {
		return nil, errors.New("LDAP directory is disabled")
	}
	department = strings.TrimSpace(department)
	if department == "" {
		return nil, errors.New("department is required")
	}
	filter := andFilter(
		s.Config.Directory.UserFilter,
		fmt.Sprintf("(%s=%s)", s.Config.Directory.DepartmentAttribute, ldap.EscapeFilter(department)),
	)
	entries, err := s.search(s.Config.Directory.BaseDN, ldap.ScopeWholeSubtree, filter, s.userAttributes())
	if err != nil {
		return nil, err
	}
	users := make([]User, 0, len(entries))
	for _, entry := range entries {
		user, err := s.entryToUser(entry)
		if err != nil {
			continue
		}
		if user.Username == "" && user.DisplayName == "" {
			continue
		}
		users = append(users, user)
	}
	sortUsers(users)
	return users, nil
}

func (s Service) UsersByDN(distinguishedNames []string) ([]User, error) {
	if !s.Enabled() {
		return nil, errors.New("LDAP directory is disabled")
	}
	if len(distinguishedNames) == 0 {
		return nil, errors.New("at least one distinguished name is required")
	}
	if len(distinguishedNames) > 100 {
		return nil, errors.New("at most 100 directory users can be imported at once")
	}
	conn, err := s.connect()
	if err != nil {
		return nil, err
	}
	defer conn.Close()

	users := make([]User, 0, len(distinguishedNames))
	seen := make(map[string]bool, len(distinguishedNames))
	for _, rawDN := range distinguishedNames {
		dn := strings.TrimSpace(rawDN)
		if dn == "" || seen[strings.ToLower(dn)] {
			continue
		}
		seen[strings.ToLower(dn)] = true
		if !withinBase(dn, s.Config.Directory.BaseDN) {
			return nil, errors.New("a selected directory user is outside the configured OU")
		}
		request := ldap.NewSearchRequest(dn, ldap.ScopeBaseObject, ldap.NeverDerefAliases, 2, 15, false, s.Config.Directory.UserFilter, s.userAttributes(), nil)
		result, err := conn.Search(request)
		if err != nil {
			return nil, fmt.Errorf("read directory user %q: %w", dn, err)
		}
		if len(result.Entries) != 1 {
			return nil, fmt.Errorf("directory user %q was not found", dn)
		}
		user, err := s.entryToUser(result.Entries[0])
		if err != nil {
			return nil, err
		}
		if user.Username == "" && user.DisplayName == "" {
			return nil, fmt.Errorf("directory user %q has no username or display name", dn)
		}
		users = append(users, user)
	}
	sortUsers(users)
	return users, nil
}

func (s Service) search(baseDN string, scope int, filter string, attrs []string) ([]*ldap.Entry, error) {
	conn, err := s.connect()
	if err != nil {
		return nil, err
	}
	defer conn.Close()
	request := ldap.NewSearchRequest(baseDN, scope, ldap.NeverDerefAliases, 0, 20, false, filter, attrs, nil)
	result, err := conn.SearchWithPaging(request, s.Config.Directory.PageSize)
	if err != nil {
		return nil, err
	}
	return result.Entries, nil
}

func (s Service) connect() (*ldap.Conn, error) {
	var lastErr error
	for _, host := range s.Config.Hosts {
		conn, err := dial(host, s.Config)
		if err != nil {
			lastErr = err
			continue
		}
		conn.SetTimeout(20 * time.Second)
		if s.BindDN != "" {
			if err := conn.Bind(s.BindDN, s.BindPwd); err != nil {
				conn.Close()
				lastErr = err
				continue
			}
		}
		return conn, nil
	}
	if lastErr == nil {
		lastErr = errors.New("no LDAP hosts are configured")
	}
	return nil, lastErr
}

func (s Service) userAttributes() []string {
	attrs := []string{
		s.Config.UsernameAttribute,
		s.Config.DisplayNameAttribute,
		s.Config.EmailAttribute,
		s.Config.Directory.IdentityAttribute,
		s.Config.Directory.PhoneAttribute,
		s.Config.Directory.DepartmentAttribute,
	}
	seen := make(map[string]bool)
	out := make([]string, 0, len(attrs))
	for _, attr := range attrs {
		attr = strings.TrimSpace(attr)
		key := strings.ToLower(attr)
		if attr == "" || seen[key] {
			continue
		}
		seen[key] = true
		out = append(out, attr)
	}
	return out
}

func (s Service) entryToUser(entry *ldap.Entry) (User, error) {
	path, err := relativeOUPath(entry.DN, s.Config.Directory.BaseDN)
	if err != nil {
		return User{}, err
	}
	username := strings.TrimSpace(entry.GetAttributeValue(s.Config.UsernameAttribute))
	displayName := strings.TrimSpace(entry.GetAttributeValue(s.Config.DisplayNameAttribute))
	if displayName == "" {
		displayName = username
	}
	return User{
		DistinguishedName: entry.DN,
		Username:          username,
		DisplayName:       displayName,
		Email:             strings.ToLower(strings.TrimSpace(entry.GetAttributeValue(s.Config.EmailAttribute))),
		Phone:             strings.TrimSpace(entry.GetAttributeValue(s.Config.Directory.PhoneAttribute)),
		Department:        strings.TrimSpace(entry.GetAttributeValue(s.Config.Directory.DepartmentAttribute)),
		OUPath:            path,
		StableKey:         stableDirectoryKey(entry, s.Config.Directory.IdentityAttribute),
	}, nil
}

func stableDirectoryKey(entry *ldap.Entry, identityAttribute string) string {
	identityAttribute = strings.TrimSpace(identityAttribute)
	raw := entry.GetRawAttributeValue(identityAttribute)
	hash := sha256.New()
	if len(raw) > 0 {
		_, _ = hash.Write([]byte(strings.ToLower(identityAttribute)))
		_, _ = hash.Write([]byte{0})
		_, _ = hash.Write(raw)
	} else {
		_, _ = hash.Write([]byte("dn"))
		_, _ = hash.Write([]byte{0})
		_, _ = hash.Write([]byte(strings.ToLower(strings.TrimSpace(entry.DN))))
	}
	return hex.EncodeToString(hash.Sum(nil))
}

func sortUsers(users []User) {
	sort.SliceStable(users, func(i, j int) bool {
		leftPath := strings.ToLower(strings.Join(users[i].OUPath, "\x00"))
		rightPath := strings.ToLower(strings.Join(users[j].OUPath, "\x00"))
		if leftPath != rightPath {
			return leftPath < rightPath
		}
		leftName, rightName := strings.ToLower(users[i].DisplayName), strings.ToLower(users[j].DisplayName)
		if leftName != rightName {
			return leftName < rightName
		}
		return strings.ToLower(users[i].Username) < strings.ToLower(users[j].Username)
	})
}

func andFilter(filters ...string) string {
	clean := make([]string, 0, len(filters))
	for _, filter := range filters {
		filter = strings.TrimSpace(filter)
		if filter != "" {
			clean = append(clean, filter)
		}
	}
	if len(clean) == 1 {
		return clean[0]
	}
	return "(&" + strings.Join(clean, "") + ")"
}

func withinBase(entryDN, baseDN string) bool {
	entry, err := ldap.ParseDN(entryDN)
	if err != nil {
		return false
	}
	base, err := ldap.ParseDN(baseDN)
	if err != nil || len(entry.RDNs) < len(base.RDNs) {
		return false
	}
	offset := len(entry.RDNs) - len(base.RDNs)
	for index := range base.RDNs {
		if !strings.EqualFold(entry.RDNs[offset+index].String(), base.RDNs[index].String()) {
			return false
		}
	}
	return true
}

func relativeOUPath(entryDN, baseDN string) ([]string, error) {
	entry, err := ldap.ParseDN(entryDN)
	if err != nil {
		return nil, fmt.Errorf("parse directory user DN: %w", err)
	}
	base, err := ldap.ParseDN(baseDN)
	if err != nil {
		return nil, fmt.Errorf("parse directory base DN: %w", err)
	}
	if len(entry.RDNs) < len(base.RDNs) {
		return nil, errors.New("directory user is outside the configured OU")
	}
	offset := len(entry.RDNs) - len(base.RDNs)
	for index := range base.RDNs {
		if !strings.EqualFold(entry.RDNs[offset+index].String(), base.RDNs[index].String()) {
			return nil, errors.New("directory user is outside the configured OU")
		}
	}
	path := make([]string, 0)
	for index := offset - 1; index >= 0; index-- {
		for _, attribute := range entry.RDNs[index].Attributes {
			if strings.EqualFold(attribute.Type, "OU") {
				path = append(path, attribute.Value)
			}
		}
	}
	return path, nil
}

func dial(host string, cfg config.LDAPConfig) (*ldap.Conn, error) {
	mode := strings.ToLower(cfg.Mode)
	if mode == "ldaps" {
		tlsCfg, err := tlsConfig(host, cfg)
		if err != nil {
			return nil, err
		}
		return ldap.DialURL("ldaps://"+host, ldap.DialWithTLSConfig(tlsCfg))
	}
	conn, err := ldap.DialURL("ldap://" + host)
	if err != nil {
		return nil, err
	}
	if mode == "starttls" {
		tlsCfg, err := tlsConfig(host, cfg)
		if err != nil {
			conn.Close()
			return nil, err
		}
		if err := conn.StartTLS(tlsCfg); err != nil {
			conn.Close()
			return nil, err
		}
	}
	return conn, nil
}

func tlsConfig(host string, cfg config.LDAPConfig) (*tls.Config, error) {
	serverName := host
	if value, _, err := net.SplitHostPort(host); err == nil {
		serverName = value
	}
	tlsCfg := &tls.Config{MinVersion: tls.VersionTLS12, ServerName: serverName, InsecureSkipVerify: cfg.InsecureSkipVerify} //nolint:gosec
	if cfg.CAFile != "" {
		contents, err := os.ReadFile(cfg.CAFile)
		if err != nil {
			return nil, err
		}
		pool := x509.NewCertPool()
		if !pool.AppendCertsFromPEM(contents) {
			return nil, errors.New("invalid LDAP CA file")
		}
		tlsCfg.RootCAs = pool
	}
	return tlsCfg, nil
}

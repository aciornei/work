-- 0.4.1: terminologia vizibilă devine „Categorie de serviciu”, iar
-- persoanele importate din Active Directory primesc o identitate stabilă.

UPDATE nomenclature_categories
SET label='Categorie de serviciu'
WHERE code='itil_category';

ALTER TABLE people
  ADD COLUMN IF NOT EXISTS source VARCHAR(32) NOT NULL DEFAULT 'manual' AFTER department,
  ADD COLUMN IF NOT EXISTS directory_key CHAR(64) NULL AFTER source,
  ADD COLUMN IF NOT EXISTS directory_username VARCHAR(255) NOT NULL DEFAULT '' AFTER directory_key,
  ADD COLUMN IF NOT EXISTS directory_dn VARCHAR(2048) NOT NULL DEFAULT '' AFTER directory_username,
  ADD UNIQUE INDEX IF NOT EXISTS uq_people_directory_identity (source,directory_key),
  ADD INDEX IF NOT EXISTS idx_people_department_name (department,display_name);

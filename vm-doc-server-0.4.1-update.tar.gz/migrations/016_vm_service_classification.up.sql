-- 0.4.0: domeniul arhitectural și categoria de serviciu devin atribute ale
-- asocierii VM–serviciu. Catalogul serviciilor le agregă automat.

INSERT IGNORE INTO nomenclature_items(category_code,name,item_code,description,sort_order,active)
VALUES ('architectural_domain','Necategorizat','uncategorized','Valoare temporară pentru asocieri VM fără domeniu arhitectural.',9999,1);

INSERT IGNORE INTO nomenclature_items(category_code,name,item_code,description,sort_order,active)
VALUES ('itil_category','Necategorizat','uncategorized','Valoare temporară pentru asocieri VM fără categorie de serviciu.',9999,1);

INSERT IGNORE INTO nomenclature_item_parents(child_item_id,parent_item_id)
SELECT category_item.id,domain_item.id
FROM nomenclature_items category_item
JOIN nomenclature_items domain_item
  ON domain_item.category_code='architectural_domain'
 AND domain_item.name='Necategorizat'
WHERE category_item.category_code='itil_category'
  AND category_item.name='Necategorizat';

ALTER TABLE vm_internal_service_assignments
  ADD COLUMN IF NOT EXISTS architectural_domain_id BIGINT UNSIGNED NULL AFTER internal_service_id,
  ADD COLUMN IF NOT EXISTS itil_category_id BIGINT UNSIGNED NULL AFTER architectural_domain_id;

-- Păstrează încadrarea existentă: categoria serviciului și domeniul părinte
-- devin valorile inițiale ale fiecărei asocieri VM.
UPDATE vm_internal_service_assignments assignment
JOIN internal_services service ON service.id=assignment.internal_service_id
LEFT JOIN nomenclature_items service_category
  ON service_category.id=service.itil_category_id
 AND service_category.category_code='itil_category'
LEFT JOIN nomenclature_item_parents category_parent
  ON category_parent.child_item_id=service_category.id
JOIN nomenclature_items fallback_category
  ON fallback_category.category_code='itil_category'
 AND fallback_category.name='Necategorizat'
JOIN nomenclature_item_parents fallback_parent
  ON fallback_parent.child_item_id=fallback_category.id
SET assignment.itil_category_id=COALESCE(assignment.itil_category_id,service_category.id,fallback_category.id),
    assignment.architectural_domain_id=COALESCE(assignment.architectural_domain_id,category_parent.parent_item_id,fallback_parent.parent_item_id)
WHERE assignment.itil_category_id IS NULL
   OR assignment.architectural_domain_id IS NULL;

ALTER TABLE vm_internal_service_assignments
  MODIFY COLUMN architectural_domain_id BIGINT UNSIGNED NOT NULL AFTER internal_service_id,
  MODIFY COLUMN itil_category_id BIGINT UNSIGNED NOT NULL AFTER architectural_domain_id;

-- Indexul nou trebuie creat înainte de eliminarea indexului vechi. Cheia externă
-- către virtual_machines poate folosi indexul vechi pentru vm_id, iar MariaDB
-- refuză eliminarea lui dacă nu există deja un index înlocuitor.
ALTER TABLE vm_internal_service_assignments
  ADD UNIQUE INDEX IF NOT EXISTS uq_vm_service_context_assignment
    (vm_id,architectural_domain_id,itil_category_id,internal_service_id,layer_id,technical_role_id),
  ADD INDEX IF NOT EXISTS idx_vm_service_assignment_domain_category
    (architectural_domain_id,itil_category_id,internal_service_id);

ALTER TABLE vm_internal_service_assignments
  DROP INDEX IF EXISTS uq_vm_internal_service_assignment;

-- MariaDB nu oferă aceeași sintaxă IF NOT EXISTS pentru toate variantele
-- de ADD CONSTRAINT. Construirea condiționată păstrează migrarea repetabilă.
SET @ddl = IF(
  (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
   WHERE CONSTRAINT_SCHEMA=DATABASE()
     AND TABLE_NAME='vm_internal_service_assignments'
     AND CONSTRAINT_NAME='fk_vm_service_assignment_domain')=0,
  'ALTER TABLE vm_internal_service_assignments ADD CONSTRAINT fk_vm_service_assignment_domain FOREIGN KEY (architectural_domain_id) REFERENCES nomenclature_items(id)',
  'SELECT 1'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @ddl = IF(
  (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
   WHERE CONSTRAINT_SCHEMA=DATABASE()
     AND TABLE_NAME='vm_internal_service_assignments'
     AND CONSTRAINT_NAME='fk_vm_service_assignment_category')=0,
  'ALTER TABLE vm_internal_service_assignments ADD CONSTRAINT fk_vm_service_assignment_category FOREIGN KEY (itil_category_id) REFERENCES nomenclature_items(id)',
  'SELECT 1'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

# Upgrade la vm-doc-server 0.4.0

Versiunea 0.4.0 mută domeniul arhitectural și categoria de serviciu pe asocierea VM–serviciu. Pagina Servicii devine o vedere agregată a datelor introduse în fișele VM.

## Migrare MariaDB

La prima pornire se aplică:

```text
016_vm_service_classification.up.sql
```

Migrarea:

1. adaugă `architectural_domain_id` și `itil_category_id` în `vm_internal_service_assignments`;
2. copiază pentru asocierile existente categoria serviciului și domeniul părinte;
3. păstrează valori `Necategorizat` numai ca rezervă pentru date vechi incomplete;
4. extinde cheia unică la `VM + domeniu + categorie + serviciu + layer + rol`;
5. păstrează coloana veche `internal_services.itil_category_id` numai pentru rollback și compatibilitate; aplicația 0.4.0 nu o mai folosește ca sursă de adevăr.

## Interfață

Fișa VM folosește:

```text
Domeniu → Categorie de serviciu → Serviciu intern → Layer → Rol tehnic
```

În formularul Serviciului intern nu mai există selector de categorie de serviciu. Domeniile și categoriile sunt afișate automat în pagina serviciului, grupate după asocierile VM-urilor.

## Pași de upgrade

1. Aplicați update-ul peste o copie a sursei 0.3.9 care conține directorul `vendor/`.
2. Rulați `GOPROXY=off GOFLAGS=-mod=vendor go test ./...`.
3. Rulați build-ul offline.
4. Faceți backup la binare, configurație și baza MariaDB.
5. Opriți collectorul și serverul.
6. Instalați binarele 0.4.0.
7. Porniți întâi serverul și verificați aplicarea migrării 016.
8. Porniți collectorul.
9. Executați `Ctrl+F5` în browser.

## Verificare

- serviciul poate fi creat sau editat fără domeniu și categorie;
- în fișa VM, domeniul filtrează categoriile de serviciu;
- asocierea salvează domeniul, categoria, serviciul, layer-ul și rolul;
- pagina serviciului afișează automat încadrările observate;
- încadrările existente înainte de upgrade sunt păstrate;
- combinațiile categorie–domeniu sau rol–layer invalide sunt respinse.

## Rollback

Migrarea este structurală. Pentru revenirea completă la 0.3.9, opriți serviciile, restaurați binarele și baza MariaDB din backupul realizat înainte de upgrade.

# Database

Migrațiile sunt aplicate automat și în ordine.

## Tabele principale

- `vcenter_sources`: conexiuni vCenter și programări;
- `virtual_machines`: inventarul de bază vCenter și asocierea agentului;
- `vcenter_sync_runs`: istoricul rulărilor;
- `agents`: configurația și starea agentului;
- `collection_jobs`: coada persistentă;
- `inventory_snapshots`: JSON brut și câmpuri extrase;
- `vm_operational_metadata`: date manuale pentru fișa tehnică, separate de inventarul automat;
- `vm_internal_service_assignments`: sursa curentă pentru asocierile multiple VM–domeniu–categorie de serviciu–serviciu–layer–rol și pentru agregările afișate în pagina serviciului;
- `audit_events`: audit administrativ/operațional.

Coloanele legacy `virtual_machines.retired*` sunt păstrate doar pentru compatibilitatea migrărilor. În modelul curent, ciclul de viață este gestionat prin `operational_status`. `present_in_vcenter` și `missing_since` sunt actualizate la fiecare rulare.

Datele din `vm_operational_metadata` nu sunt suprascrise nici de sincronizarea vCenter, nici de colectările agentului. Rândul este șters automat numai când VM-ul asociat este șters.


## Nomenclatoare, responsabilități și backup — migrarea 012

- `nomenclature_categories`: categoriile active folosite în fișa VM;
- `nomenclature_items`: valorile administrabile din fiecare categorie;
- `layer_technical_role_mappings`: relația globală dintre layer-e și rolurile tehnice permise; ordinea de afișare folosește mai întâi ordinea layer-ului și apoi `nomenclature_items.sort_order` al rolului;
- `vm_operational_nomenclatures`: selecția curentă a fiecărei VM;
- `people`: registrul de persoane;
- `vm_responsibilities`: relație multiplă VM–persoană–tip responsabilitate;
- `vm_backup_summary`: rezumat separat pentru backup, pregătit pentru sincronizarea Veeam API.


## Model 0.4.0

Migrarea `016_vm_service_classification.up.sql` adaugă pe `vm_internal_service_assignments` coloanele `architectural_domain_id` și `itil_category_id`. Categoria veche din `internal_services.itil_category_id` este păstrată numai pentru compatibilitate structurală și rollback; aplicația curentă nu o folosește ca sursă de adevăr.

Tabelul `internal_service_role_mappings`, creat de o versiune anterioară, nu mai este citit sau modificat. Layer-ele și rolurile afișate în serviciu sunt agregate din `vm_internal_service_assignments`, iar validarea perechii se face prin `layer_technical_role_mappings`.

## Identitatea persoanelor din director

Migrarea `017_service_category_ad_directory.up.sql` extinde `people` cu:

- `source`: `manual` sau `ldap`;
- `directory_key`: SHA-256 calculat din DN-ul normalizat și folosit pentru reimport idempotent;
- `directory_username`: contul AD;
- `directory_dn`: DN-ul citit din director.

Indexul `uq_people_directory_identity(source,directory_key)` permite mai multe persoane manuale cu `directory_key=NULL`, dar împiedică duplicarea aceleiași identități LDAP.

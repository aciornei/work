# Configuration

Configurația este YAML și păstrează `version: 1`. Parolele globale nu se introduc în `config.yaml`; parolele surselor vCenter și tokenurile agenților sunt criptate individual în MariaDB.

## vCenter

```yaml
vcenter:
  allow_http: false
  request_timeout: "60s"
  detail_workers: 8
  scheduler_interval: "1m"
```

- `allow_http`: numai pentru laborator; în producție trebuie să fie `false`;
- `request_timeout`: timeout pentru cererile REST vCenter;
- `detail_workers`: numărul de VM-uri citite concurent, între 1 și 64;
- `scheduler_interval`: frecvența cu care serverul verifică programările zilnice.

Ora fiecărei surse se configurează în interfață și este interpretată folosind `app.timezone`.

## Collector

`collector.allowed_networks` trebuie restrâns la rețelele în care se află VM-urile. Conexiunea către agent este directă, fără proxy HTTP și fără redirecturi.

În producție, `collector.allow_http` trebuie să rămână `false`, iar `verify_tls` trebuie activat pentru agenți.

## Autoînregistrarea agenților

```yaml
agent_registration:
  enabled: true
  max_request_body_bytes: 26214400
```

Tokenul se află în fișierul criptat de secrete sub cheia `agent_registration_token`.

## Directorul Active Directory pentru persoane

Importul persoanelor reutilizează aceeași conexiune LDAP și aceleași secrete ca autentificarea. Căutarea este separată printr-un OU rădăcină dedicat:

```yaml
auth:
  ldap:
    enabled: true
    hosts: ["dc01.example.ro:636", "dc02.example.ro:636"]
    mode: "ldaps"
    base_dn: "DC=example,DC=ro"
    user_base_dn: "OU=Users,DC=example,DC=ro"
    user_filter: "(&(objectClass=user)(sAMAccountName={username}))"
    username_attribute: "sAMAccountName"
    display_name_attribute: "displayName"
    email_attribute: "mail"
    groups_attribute: "memberOf"
    directory:
      enabled: true
      base_dn: "OU=Users,DC=example,DC=ro"
      user_filter: "(&(objectCategory=person)(objectClass=user)(!(objectClass=computer))(!(userAccountControl:1.2.840.113556.1.4.803:=2)))"
      identity_attribute: "objectGUID"
      department_attribute: "department"
      phone_attribute: "telephoneNumber"
      page_size: 500
      default_department: ""
```

`directory.base_dn` este parcurs cu scope subtree. `identity_attribute` este implicit `objectGUID`, pentru identificare stabilă chiar dacă utilizatorul este mutat între sub-OU-uri. Interfața afișează sub-OU-urile ca arbore, dar filtrarea principală se face după `department`. Dacă `default_department` este gol sau nu există în AD, se selectează primul departament în ordine alfabetică.

Contul din `ldap_bind_dn` trebuie să aibă drepturi de citire pentru atributele configurate. Parola rămâne numai în fișierul criptat de secrete.

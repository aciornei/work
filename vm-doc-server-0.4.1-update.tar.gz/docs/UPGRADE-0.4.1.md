# Upgrade la vm-doc-server 0.4.1

Versiunea 0.4.1 schimbă terminologia vizibilă în **Categorie de serviciu** și adaugă importul persoanelor din Active Directory pentru responsabilitățile VM.

## Compatibilitate

Cheia tehnică `itil_category`, coloanele `itil_category_id` și câmpurile JSON existente nu sunt redenumite. Astfel, upgrade-ul nu rupe API-ul, datele sau rollback-ul. Migrarea 017 păstrează identificatorii existenți, actualizează eticheta afișată și extinde registrul de persoane cu identitatea de director.

## Corecția migrării 016

Versiunea include o variantă repetabilă a `016_vm_service_classification.up.sql`. Indexul `uq_vm_service_context_assignment` este creat înainte de eliminarea `uq_vm_internal_service_assignment`, astfel încât cheia externă pe `vm_id` are permanent un index suport.

Dacă pornirea 0.4.0 s-a oprit cu `cannot drop index uq_vm_internal_service_assignment`, se poate instala direct sursa 0.4.1 și reporni serverul. Migrarea 016 reia operațiile deja aplicate și finalizează indexurile și constrângerile.

## Configurarea directorului AD

În `auth.ldap` adăugați:

```yaml
directory:
  enabled: true
  base_dn: "OU=Utilizatori,DC=example,DC=ro"
  user_filter: "(&(objectCategory=person)(objectClass=user)(!(objectClass=computer))(!(userAccountControl:1.2.840.113556.1.4.803:=2)))"
  identity_attribute: "objectGUID"
  department_attribute: "department"
  phone_attribute: "telephoneNumber"
  page_size: 500
  default_department: ""
```

- `base_dn` este OU-ul rădăcină; căutarea include recursiv toate sub-OU-urile;
- `identity_attribute` folosește implicit `objectGUID`, astfel încât aceeași persoană rămâne identificată și după mutarea în alt sub-OU;
- `department_attribute` este folosit pentru lista și filtrarea departamentelor;
- `default_department` este opțional; gol înseamnă primul departament în ordine alfabetică;
- sunt reutilizate `hosts`, `mode`, `ca_file`, atributele utilizatorului și secretele `ldap_bind_dn` / `ldap_bind_password` deja folosite de autentificare;
- contul bind are nevoie numai de drept de citire în OU-ul configurat.

## Migrarea 017

`017_service_category_ad_directory.up.sql`:

1. actualizează eticheta categoriei `itil_category` la „Categorie de serviciu”;
2. adaugă în `people` sursa, cheia stabilă derivată din `objectGUID` (cu fallback pe DN), contul de director și DN-ul;
3. adaugă indexul unic folosit pentru reimport idempotent;
4. păstrează toate persoanele existente ca `source=manual`.

## Verificări după pornire

1. `Nomenclatoare → Catalog servicii` afișează **Categorie de serviciu**;
2. `Nomenclatoare → Persoane` afișează butonul **Importă din AD**;
3. primul departament este selectat automat;
4. utilizatorii sunt grupați după calea sub-OU;
5. reimportul aceleiași persoane actualizează înregistrarea existentă, fără duplicare;
6. persoana importată apare în selectorul de responsabilități al VM-ului.

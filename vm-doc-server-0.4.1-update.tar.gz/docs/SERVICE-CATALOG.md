# Catalogul serviciilor interne

## Scop

Serviciul intern reprezintă obiectul documentat, de exemplu `Metabase`, `Platforma Mail` sau `Alfresco`. Încadrarea arhitecturală nu este proprietatea fixă a serviciului, ci a modului în care un VM participă la acel serviciu.

## Model

```text
Nomenclatoare
├── Domeniu arhitectural
│   └── Categorie de serviciu
└── Layer arhitectural
    └── Rol tehnic permis

Fișă VM
└── Asociere serviciu
    ├── Domeniu arhitectural
    ├── Categorie de serviciu
    ├── Serviciu intern
    ├── Layer arhitectural
    ├── Rol tehnic
    ├── Tip utilizare
    └── Principal / observații
```

## Reguli

- fiecare categorie de serviciu are exact un domeniu arhitectural părinte;
- serviciul intern nu are domeniu sau categorie configurate manual;
- domeniul și categoria se salvează pe asocierea VM–serviciu;
- fiecare rol tehnic aparține unuia sau mai multor layer-e;
- un VM poate avea mai multe asocieri;
- același serviciu poate fi folosit în mai multe domenii sau categorii;
- combinația `VM + domeniu + categorie + serviciu + layer + rol` este unică;
- cel mult o asociere a unui VM poate fi marcată drept principală;
- backendul verifică faptul că categoria aparține domeniului și rolul aparține layer-ului.

## Selecția pe fișa VM

```text
Alegi domeniul
  → apar numai categoriile de serviciu ale domeniului
    → alegi serviciul intern
      → alegi layer-ul
        → apar numai rolurile permise în layer
```

Serviciile interne sunt independente de încadrare și pot fi reutilizate. Un serviciu nou poate fi definit în catalog înainte de a avea VM-uri asociate; până la prima asociere apare ca „Neîncadrat încă”.

## Pagina Servicii

La nivelul serviciului se administrează manual doar:

- denumirea și codul intern;
- descrierea și scopul;
- criticitatea;
- starea și linkul documentației;
- starea activ/inactiv.

Din fișele VM sunt calculate automat:

- domeniile arhitecturale observate;
- categoriile de serviciu observate;
- numărul de VM-uri și asocieri pentru fiecare încadrare;
- layer-ele și rolurile tehnice;
- tipul de utilizare și asocierea principală.

## Exemplu

```text
Serviciu intern: Metabase
├── Business Intelligence → Raportare
│   ├── metabase01 → Aplicație → Aplicație BI
│   └── postgres-shared01 → Bază de date → PostgreSQL
└── Platforme comune → Publicare aplicații
    └── nginx01 → Acces și publicare → Reverse proxy
```

Pagina Metabase va afișa automat ambele încadrări, fără ca acestea să fie introduse în formularul serviciului.

## Documentația viitoare

Unitatea de documentare rămâne serviciul intern. Fișele VM și încadrările aferente vor fi incluse sau referite în documentația DOCX/PDF generată.

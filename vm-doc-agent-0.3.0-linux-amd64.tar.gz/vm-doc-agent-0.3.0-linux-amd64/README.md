# vm-doc-agent 0.3.0

Un singur agent Linux pentru Ubuntu, Debian, CentOS/RHEL și SUSE. Agentul detectează automat distribuția și sistemul de inițializare, scrie inventarul local în JSON și expune un API HTTP protejat cu token.

## Ce colectează în această versiune

- hostname și FQDN;
- distribuție, versiune, kernel și arhitectură;
- sistem de inițializare: systemd sau SysV;
- `/etc/machine-id` ori fallback-ul D-Bus;
- UUID DMI/SMBIOS cu fallback prin `dmidecode`;
- variantă alternativă de byte-order pentru corelarea cu vCenter/GLPI;
- vendor, model, serial și tipul de virtualizare;
- ID persistent propriu al agentului.

## Sisteme vizate

- Ubuntu 20.04 și versiuni mai noi;
- Debian 12 și versiuni apropiate;
- CentOS 7, RHEL, Rocky Linux, AlmaLinux și Oracle Linux;
- SUSE Linux Enterprise Server 11, inclusiv fallback `/etc/SuSE-release`.

Pachetul este unic pentru toate sistemele `x86_64/amd64`.

## Instalare

```bash
tar -xzf vm-doc-agent-0.3.0-linux-amd64.tar.gz
cd vm-doc-agent-0.3.0-linux-amd64
sudo ./install.sh
```

Installerul detectează automat:

- systemd: instalează `/etc/systemd/system/vm-doc-agent.service`;
- SysV: instalează `/etc/init.d/vm-doc-agent`.

Configurația este păstrată în `/etc/vm-doc-agent/config.json`. Inventarul și identitatea agentului sunt păstrate în `/var/lib/vm-doc-agent`.

## Configurație

```json
{
  "listen": "0.0.0.0:9078",
  "output_file": "/var/lib/vm-doc-agent/inventory.json",
  "state_dir": "/var/lib/vm-doc-agent",
  "refresh_interval": "15m",
  "auth_token_file": "/etc/vm-doc-agent/token"
}
```

După schimbarea configurației, repornește serviciul.

## API

`GET /health` nu cere autentificare. Toate endpoint-urile `/v1/*` cer token Bearer.

```bash
TOKEN=$(sudo cat /etc/vm-doc-agent/token)
curl http://127.0.0.1:9078/health
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/version
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/identity
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/inventory
curl -X POST -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/inventory/refresh
```

## Fișierul local

```text
/var/lib/vm-doc-agent/inventory.json
```

Scrierea se face atomic, prin fișier temporar și `rename`.

## Corelare cu vCenter și GLPI

Folosește în această ordine:

1. `host.correlation.dmi_product_uuid` ↔ vCenter `config.uuid`;
2. `host.correlation.smbios_legacy_byte_order` ca variantă alternativă;
3. `host.machine_id`;
4. `agent.id`, care rămâne persistent după update.

Nu confunda vCenter `config.uuid` cu `config.instanceUuid`; serverul central trebuie să le păstreze separat.

## Update

Extrage noua versiune și rulează:

```bash
sudo ./update.sh
```

Configurația, tokenul și `agent-id` sunt păstrate. Binarul precedent este salvat în `/usr/local/sbin/vm-doc-agent.previous`.

## Dezinstalare

```bash
sudo ./uninstall.sh
```

Păstrează configurația și starea. Pentru ștergere completă:

```bash
sudo ./uninstall.sh --purge
```

## Build

Go este necesar doar pe o singură mașină de build:

```bash
./scripts/build.sh
./scripts/package.sh
```

Binarul este compilat static cu `CGO_ENABLED=0`, `GOARCH=amd64` și `GOAMD64=v1`.

## Securitate

Portul 9078 trebuie permis în firewall doar din serverul central sau rețeaua de management. Tokenul protejează API-ul, dar traficul este HTTP în această versiune. Pasul următor pentru producție este TLS/mTLS.

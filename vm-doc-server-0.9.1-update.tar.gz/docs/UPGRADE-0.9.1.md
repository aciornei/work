# Upgrade la vm-doc-server 0.9.1

Versiunea 0.9.1 este un hotfix peste 0.9.0 pentru adăugarea dependențelor directe de infrastructură comună pe VM.

## Baza de date

Nu există migrare nouă. Schema introdusă în 0.9.0 prin `024_common_service_dependencies.up.sql` rămâne neschimbată.

## Corecție

În 0.9.0, după inserarea unei relații `VM → Serviciu comun`, backend-ul reconstruia lista dependențelor printr-un singur `UNION ALL` MariaDB. Ramura pentru relații directe devenea activă numai după primul INSERT și putea produce o eroare de citire, rezultând HTTP 500.

0.9.1 citește separat dependențele moștenite, globale și directe și le agregă în Go. Endpoint-ul scrie acum și eroarea reală în log dacă operația eșuează.

## Upgrade

Opriți serviciile, înlocuiți binarele compilate cu 0.9.1 și porniți din nou `vm-doc-server` și `vm-doc-collector`.

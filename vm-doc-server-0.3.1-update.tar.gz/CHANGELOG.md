# Changelog

## 0.3.1

- meniu nou **Nomenclatoare** pentru serviciu, componentă, domeniu arhitectural, layer, mediu, status operațional, profil de provisionare și clasificare;
- câmpurile controlate din fișa VM sunt list-box-uri și nu mai acceptă text liber;
- registru de persoane și mai multe responsabilități pe aceeași VM;
- secțiune separată **Backup și restaurare · Veeam**, cu model de date pregătit pentru sincronizarea prin API;
- migrarea automată a valorilor și responsabililor existenți din 0.3.0;
- endpointuri API, audit și OpenAPI pentru nomenclatoare și persoane;
- migrarea `012_nomenclatures_responsibilities_backup.up.sql`.

## 0.3.0

- pagină VM refăcută ca fișă tehnică structurată pe carduri și secțiuni pliabile;
- vedere sigură a inventarului agentului, cu mascarea câmpurilor sensibile;
- date operaționale separate de snapshoturile agentului și sincronizarea vCenter;
- tabel nou `vm_operational_metadata` prin migrarea 011;
- endpoint `PUT /api/v1/vms/{id}/operational` și audit `vm.operational.update`;
- formular pentru serviciu, componentă, domeniu, layer, mediu, status, scop, responsabili, provisionare, RPO/RTO, backup, clasificare și referințe;
- OpenAPI, documentație și teste actualizate.

## 0.2.2

- autoînregistrare pentru vm-doc-agent 1.1.0;
- heartbeat și stare online/offline fără creare manuală;
- push direct al inventarului;
- asociere automată cu VM după UUID;
- migrarea 010 și documentația de upgrade.


## 0.2.1

- căutare și filtre VM după nume/hostname, power, OS, IP, agent, `Retired` și sursă vCenter;
- paginare server-side și selector 25/50/100/200 înregistrări;
- statistici pentru rezultatele filtrate;
- export Excel `.xlsx` fără dependențe Go suplimentare;
- antet fix corect în tabelul VM, fără suprapunerea primului rând;
- API-ul `GET /api/v1/vms` întoarce un obiect paginat;
- endpoint nou `GET /api/v1/vms/export`;
- listele vCenter goale sunt serializate ca `[]`, nu `null`;
- rutele Swagger sunt înregistrate explicit ca `GET`, evitând panic în Go 1.23.

## 0.2.0

- vCenter devine sursa principală pentru lista de VM-uri;
- CRUD pentru surse vCenter, cu parolă criptată și verificare TLS;
- sincronizare manuală per sursă sau pentru toate sursele;
- scheduler zilnic configurabil per sursă, în fusul orar al aplicației;
- tabele `vcenter_sources`, `virtual_machines` și `vcenter_sync_runs`;
- VM-urile absente sunt marcate `missing_from_vcenter`, fără ștergere automată;
- lifecycle local `Retired`, cu dată, utilizator și notă;
- asociere automată după BIOS/DMI UUID, inclusiv ordinea SMBIOS legacy VMware;
- asociere manuală și dezlegare agent din fișa VM;
- stare agent și colectare manuală direct din fișa VM;
- parser pentru `agent.id`, `agent.version`, `collection.collectors`, FQDN și UUID-uri de corelare;
- listă VM, filtre, pagină de detaliu și istoric sincronizări în frontend;
- permisiuni RBAC noi: `vcenter.read`, `vcenter.manage`, `vms.manage`;
- OpenAPI 3.1 și documentație actualizate.

## 0.1.0

- două binare: `vm-doc-server` și `vm-doc-collector`;
- configurație YAML și secrete criptate AES-256-GCM;
- migrații MariaDB incluse în binar;
- autentificare LDAP și Keycloak/OIDC cu PKCE;
- sesiuni server-side, CSRF și RBAC;
- administrarea agenților și tokenuri criptate individual;
- joburi manuale și periodice cu lease;
- testare agent, colectare, UUID binding și validare schemă 2.x;
- snapshoturi brute, istoric, hash și stare online/offline;
- audit server/collector;
- frontend static fără Node.js;
- OpenAPI 3.1 și Swagger UI embedded;
- unități systemd și reverse proxy Nginx.

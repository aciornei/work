package nomenclature

import (
	"context"
	"database/sql"
	"errors"
	"net/mail"
	"regexp"
	"strings"

	"vm-doc-server/internal/domain"
)

var codePattern = regexp.MustCompile(`^[a-z0-9][a-z0-9._-]{0,127}$`)

var AllowedCategories = map[string]bool{
	"service":              true,
	"component":            true,
	"architectural_domain": true,
	"layer":                true,
	"environment":          true,
	"operational_status":   true,
	"provisioning_profile": true,
	"classification":       true,
}

type Service struct{ DB *sql.DB }

type ItemInput struct {
	CategoryCode string `json:"category_code"`
	Name         string `json:"name"`
	ItemCode     string `json:"item_code"`
	Description  string `json:"description"`
	SortOrder    int    `json:"sort_order"`
	Active       *bool  `json:"active,omitempty"`
}

type PersonInput struct {
	DisplayName string `json:"display_name"`
	Email       string `json:"email"`
	Phone       string `json:"phone"`
	Department  string `json:"department"`
	Active      *bool  `json:"active,omitempty"`
}

func (s Service) ListCategories(ctx context.Context, includeInactive bool) ([]domain.NomenclatureCategory, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT code,label,sort_order,active FROM nomenclature_categories WHERE active=1 ORDER BY sort_order,label`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.NomenclatureCategory, 0)
	byCode := make(map[string]int)
	for rows.Next() {
		var category domain.NomenclatureCategory
		if err := rows.Scan(&category.Code, &category.Label, &category.SortOrder, &category.Active); err != nil {
			return nil, err
		}
		category.Items = make([]domain.NomenclatureValue, 0)
		byCode[category.Code] = len(out)
		out = append(out, category)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	query := `SELECT id,category_code,name,item_code,description,sort_order,active FROM nomenclature_items`
	if !includeInactive {
		query += ` WHERE active=1`
	}
	query += ` ORDER BY category_code,sort_order,name`
	items, err := s.DB.QueryContext(ctx, query)
	if err != nil {
		return nil, err
	}
	defer items.Close()
	for items.Next() {
		var item domain.NomenclatureValue
		if err := items.Scan(&item.ID, &item.CategoryCode, &item.Name, &item.ItemCode, &item.Description, &item.SortOrder, &item.Active); err != nil {
			return nil, err
		}
		if idx, ok := byCode[item.CategoryCode]; ok {
			out[idx].Items = append(out[idx].Items, item)
		}
	}
	return out, items.Err()
}

func (s Service) GetItem(ctx context.Context, id int64) (domain.NomenclatureValue, error) {
	var item domain.NomenclatureValue
	err := s.DB.QueryRowContext(ctx, `SELECT id,category_code,name,item_code,description,sort_order,active FROM nomenclature_items WHERE id=?`, id).Scan(&item.ID, &item.CategoryCode, &item.Name, &item.ItemCode, &item.Description, &item.SortOrder, &item.Active)
	return item, err
}

func (s Service) CreateItem(ctx context.Context, userID int64, input ItemInput) (domain.NomenclatureValue, error) {
	if err := normalizeItem(&input); err != nil {
		return domain.NomenclatureValue{}, err
	}
	active := true
	if input.Active != nil {
		active = *input.Active
	}
	result, err := s.DB.ExecContext(ctx, `INSERT INTO nomenclature_items(category_code,name,item_code,description,sort_order,active,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?)`, input.CategoryCode, input.Name, input.ItemCode, input.Description, input.SortOrder, active, userID, userID)
	if err != nil {
		return domain.NomenclatureValue{}, err
	}
	id, _ := result.LastInsertId()
	return s.GetItem(ctx, id)
}

func (s Service) UpdateItem(ctx context.Context, id, userID int64, input ItemInput) (domain.NomenclatureValue, error) {
	current, err := s.GetItem(ctx, id)
	if err != nil {
		return domain.NomenclatureValue{}, err
	}
	input.CategoryCode = current.CategoryCode
	if strings.TrimSpace(input.Name) == "" {
		input.Name = current.Name
	}
	if input.Active == nil {
		value := current.Active
		input.Active = &value
	}
	if err := normalizeItem(&input); err != nil {
		return domain.NomenclatureValue{}, err
	}
	_, err = s.DB.ExecContext(ctx, `UPDATE nomenclature_items SET name=?,item_code=?,description=?,sort_order=?,active=?,updated_by=? WHERE id=?`, input.Name, input.ItemCode, input.Description, input.SortOrder, *input.Active, userID, id)
	if err != nil {
		return domain.NomenclatureValue{}, err
	}
	return s.GetItem(ctx, id)
}

func (s Service) ListPeople(ctx context.Context, includeInactive bool) ([]domain.Person, error) {
	query := `SELECT id,display_name,email,phone,department,active,created_at,updated_at FROM people`
	if !includeInactive {
		query += ` WHERE active=1`
	}
	query += ` ORDER BY display_name,email`
	rows, err := s.DB.QueryContext(ctx, query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.Person, 0)
	for rows.Next() {
		var value domain.Person
		if err := rows.Scan(&value.ID, &value.DisplayName, &value.Email, &value.Phone, &value.Department, &value.Active, &value.CreatedAt, &value.UpdatedAt); err != nil {
			return nil, err
		}
		out = append(out, value)
	}
	return out, rows.Err()
}

func (s Service) GetPerson(ctx context.Context, id int64) (domain.Person, error) {
	var value domain.Person
	err := s.DB.QueryRowContext(ctx, `SELECT id,display_name,email,phone,department,active,created_at,updated_at FROM people WHERE id=?`, id).Scan(&value.ID, &value.DisplayName, &value.Email, &value.Phone, &value.Department, &value.Active, &value.CreatedAt, &value.UpdatedAt)
	return value, err
}

func (s Service) CreatePerson(ctx context.Context, userID int64, input PersonInput) (domain.Person, error) {
	if err := normalizePerson(&input); err != nil {
		return domain.Person{}, err
	}
	active := true
	if input.Active != nil {
		active = *input.Active
	}
	result, err := s.DB.ExecContext(ctx, `INSERT INTO people(display_name,email,phone,department,active,created_by,updated_by) VALUES(?,?,?,?,?,?,?)`, input.DisplayName, input.Email, input.Phone, input.Department, active, userID, userID)
	if err != nil {
		return domain.Person{}, err
	}
	id, _ := result.LastInsertId()
	return s.GetPerson(ctx, id)
}

func (s Service) UpdatePerson(ctx context.Context, id, userID int64, input PersonInput) (domain.Person, error) {
	current, err := s.GetPerson(ctx, id)
	if err != nil {
		return domain.Person{}, err
	}
	if strings.TrimSpace(input.DisplayName) == "" {
		input.DisplayName = current.DisplayName
	}
	if input.Active == nil {
		value := current.Active
		input.Active = &value
	}
	if err := normalizePerson(&input); err != nil {
		return domain.Person{}, err
	}
	_, err = s.DB.ExecContext(ctx, `UPDATE people SET display_name=?,email=?,phone=?,department=?,active=?,updated_by=? WHERE id=?`, input.DisplayName, input.Email, input.Phone, input.Department, *input.Active, userID, id)
	if err != nil {
		return domain.Person{}, err
	}
	return s.GetPerson(ctx, id)
}

func normalizeItem(input *ItemInput) error {
	input.CategoryCode = strings.ToLower(strings.TrimSpace(input.CategoryCode))
	input.Name = strings.TrimSpace(input.Name)
	input.ItemCode = strings.ToLower(strings.TrimSpace(input.ItemCode))
	input.Description = strings.TrimSpace(input.Description)
	if !AllowedCategories[input.CategoryCode] {
		return errors.New("invalid nomenclature category")
	}
	if input.Name == "" {
		return errors.New("name is required")
	}
	if len([]rune(input.Name)) > 255 || len([]rune(input.Description)) > 4000 {
		return errors.New("nomenclature value is too long")
	}
	if input.ItemCode != "" && !codePattern.MatchString(input.ItemCode) {
		return errors.New("item_code is invalid")
	}
	if input.SortOrder < -100000 || input.SortOrder > 100000 {
		return errors.New("sort_order must be between -100000 and 100000")
	}
	return nil
}

func normalizePerson(input *PersonInput) error {
	input.DisplayName = strings.TrimSpace(input.DisplayName)
	input.Email = strings.ToLower(strings.TrimSpace(input.Email))
	input.Phone = strings.TrimSpace(input.Phone)
	input.Department = strings.TrimSpace(input.Department)
	if input.DisplayName == "" {
		return errors.New("display_name is required")
	}
	if len([]rune(input.DisplayName)) > 255 || len([]rune(input.Email)) > 255 || len([]rune(input.Phone)) > 64 || len([]rune(input.Department)) > 255 {
		return errors.New("person value is too long")
	}
	if input.Email != "" {
		address, err := mail.ParseAddress(input.Email)
		if err != nil || strings.ToLower(address.Address) != input.Email {
			return errors.New("email is invalid")
		}
	}
	return nil
}

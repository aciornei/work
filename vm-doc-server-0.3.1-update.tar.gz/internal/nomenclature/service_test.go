package nomenclature

import "testing"

func TestNormalizeItem(t *testing.T) {
	input := ItemInput{CategoryCode: " Service ", Name: "  Mail  ", ItemCode: " MAIL.PROD ", Description: " test "}
	if err := normalizeItem(&input); err != nil {
		t.Fatal(err)
	}
	if input.CategoryCode != "service" || input.Name != "Mail" || input.ItemCode != "mail.prod" {
		t.Fatalf("unexpected normalized input: %#v", input)
	}
}

func TestNormalizeItemRejectsUnknownCategory(t *testing.T) {
	if err := normalizeItem(&ItemInput{CategoryCode: "unknown", Name: "X"}); err == nil {
		t.Fatal("expected invalid category")
	}
}

func TestNormalizePerson(t *testing.T) {
	input := PersonInput{DisplayName: "  Ion Popescu ", Email: "ION@EXAMPLE.TEST"}
	if err := normalizePerson(&input); err != nil {
		t.Fatal(err)
	}
	if input.DisplayName != "Ion Popescu" || input.Email != "ion@example.test" {
		t.Fatalf("unexpected normalized person: %#v", input)
	}
}

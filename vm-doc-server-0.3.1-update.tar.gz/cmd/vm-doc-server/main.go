package main

import (
	"context"
	"flag"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"vm-doc-server/internal/agents"
	"vm-doc-server/internal/audit"
	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/buildinfo"
	"vm-doc-server/internal/collection"
	"vm-doc-server/internal/config"
	"vm-doc-server/internal/cryptox"
	"vm-doc-server/internal/database"
	"vm-doc-server/internal/inventory"
	"vm-doc-server/internal/nomenclature"
	"vm-doc-server/internal/registration"
	"vm-doc-server/internal/secrets"
	"vm-doc-server/internal/server"
	"vm-doc-server/internal/vcenter"
	"vm-doc-server/migrations"
)

func main() {
	configPath := flag.String("config", "/etc/vm-doc-server/config.yaml", "configuration file")
	flag.Parse()
	cfg, err := config.Load(*configPath)
	if err != nil {
		fatal("load configuration", err)
	}
	logger := newLogger(cfg.Logging)
	master, err := cryptox.LoadMasterKey(cfg.Secrets.MasterKeyFile, cfg.Secrets.MasterKeyEnv)
	if err != nil {
		fatal("load master key", err)
	}
	box, err := cryptox.New(master)
	if err != nil {
		fatal("initialize encryption", err)
	}
	secretValues, err := secrets.Load(cfg.Secrets, box)
	if err != nil {
		fatal("load secrets", err)
	}
	db, err := database.Open(cfg.Database, secretValues.DatabasePassword)
	if err != nil {
		fatal("open database", err)
	}
	defer db.Close()
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	if err := database.Migrate(ctx, db, migrations.Files); err != nil {
		cancel()
		fatal("database migrations", err)
	}
	cancel()
	appCtx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()
	auditSvc := audit.Service{DB: db}
	authSvc, err := auth.New(appCtx, db, cfg, secretValues, auditSvc)
	if err != nil {
		fatal("initialize authentication", err)
	}
	agentSvc := agents.Service{DB: db, Box: box, Config: cfg.Collector}
	invSvc := inventory.Service{DB: db}
	var registrationSvc *registration.Service
	if cfg.AgentRegistration.Enabled {
		registrationSvc = &registration.Service{
			DB: db, Box: box, Inventory: invSvc, Token: secretValues.AgentRegistrationToken,
			AllowHTTPAgents:           cfg.Collector.AllowHTTP,
			DefaultCollectionInterval: cfg.Collector.DefaultCollectionInterval.Value(),
			DefaultRequestTimeout:     cfg.Collector.DefaultRequestTimeout.Value(),
			DefaultOfflineAfter:       cfg.Collector.DefaultOfflineAfter.Value(),
			AcceptedSchemaMajor:       cfg.Inventory.AcceptedSchemaMajor,
		}
		if err := registrationSvc.Validate(); err != nil {
			fatal("initialize agent registration", err)
		}
	}
	collectionSvc := collection.New(db, agentSvc, invSvc, auditSvc, nil, cfg, logger)
	vcenterSvc := vcenter.NewService(appCtx, db, box, cfg, logger)
	nomenclatureSvc := nomenclature.Service{DB: db}
	go vcenterSvc.RunScheduler(appCtx)
	app := &server.App{Config: cfg, DB: db, Auth: authSvc, Agents: agentSvc, Collection: collectionSvc, Inventory: invSvc, VCenter: vcenterSvc, Nomenclatures: nomenclatureSvc, Registration: registrationSvc, Audit: auditSvc, Logger: logger, Version: buildinfo.Version}
	handler, err := app.Handler()
	if err != nil {
		fatal("build HTTP handler", err)
	}
	httpServer := &http.Server{Addr: cfg.Server.Listen, Handler: handler, ReadHeaderTimeout: cfg.Server.ReadHeaderTimeout.Value(), ReadTimeout: cfg.Server.ReadTimeout.Value(), WriteTimeout: cfg.Server.WriteTimeout.Value(), IdleTimeout: cfg.Server.IdleTimeout.Value()}
	go func() {
		logger.Info("vm-doc-server started", "version", buildinfo.Version, "listen", cfg.Server.Listen)
		if err := httpServer.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			fatal("HTTP server", err)
		}
	}()
	<-appCtx.Done()
	shutdownCtx, shutdownCancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer shutdownCancel()
	if err := httpServer.Shutdown(shutdownCtx); err != nil {
		logger.Error("HTTP shutdown", "error", err)
	}
	vcenterSvc.Wait()
	logger.Info("vm-doc-server stopped")
}

func newLogger(cfg config.LoggingConfig) *slog.Logger {
	level := slog.LevelInfo
	switch cfg.Level {
	case "debug":
		level = slog.LevelDebug
	case "warn":
		level = slog.LevelWarn
	case "error":
		level = slog.LevelError
	}
	opts := &slog.HandlerOptions{Level: level}
	if cfg.Format == "text" {
		return slog.New(slog.NewTextHandler(os.Stdout, opts))
	}
	return slog.New(slog.NewJSONHandler(os.Stdout, opts))
}
func fatal(message string, err error) { slog.Error(message, "error", err); os.Exit(1) }

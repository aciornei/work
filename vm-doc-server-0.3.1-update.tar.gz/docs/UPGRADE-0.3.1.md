# Upgrade vm-doc-server 0.3.0 → 0.3.1

1. Păstrați directorul `vendor/` din sursa 0.3.0 folosită la compilarea offline.
2. Aplicați arhiva incrementală 0.3.1 peste o copie a sursei 0.3.0.
3. Rulați testele și build-ul cu `-mod=vendor`.
4. Faceți backup binarelor și bazei de date.
5. Înlocuiți binarele și porniți mai întâi `vm-doc-server`.

La pornire, migrarea `012_nomenclatures_responsibilities_backup.up.sql`:

- creează cele opt nomenclatoare fixe;
- transformă valorile text existente în valori de nomenclator;
- mută administratorul și responsabilul existenți în registrul de persoane;
- mută politica/RPO/RTO existente în secțiunea separată de backup;
- adaugă permisiunile `nomenclatures.read` și `nomenclatures.manage`.

Migrarea nu șterge vechile coloane din `vm_operational_metadata`, pentru compatibilitate și rollback.

# Database

Migrațiile sunt aplicate automat și în ordine.

## Tabele principale

- `vcenter_sources`: conexiuni vCenter și programări;
- `virtual_machines`: inventarul de bază, lifecycle și asocierea agentului;
- `vcenter_sync_runs`: istoricul rulărilor;
- `agents`: configurația și starea agentului;
- `collection_jobs`: coada persistentă;
- `inventory_snapshots`: JSON brut și câmpuri extrase;
- `vm_operational_metadata`: date manuale pentru fișa tehnică, separate de inventarul automat;
- `audit_events`: audit administrativ/operațional.

`virtual_machines.retired` și câmpurile asociate nu sunt modificate de sincronizarea vCenter. `present_in_vcenter` și `missing_since` sunt actualizate la fiecare rulare.

Datele din `vm_operational_metadata` nu sunt suprascrise nici de sincronizarea vCenter, nici de colectările agentului. Rândul este șters automat numai când VM-ul asociat este șters.


## Nomenclatoare, responsabilități și backup — migrarea 012

- `nomenclature_categories`: cele opt categorii fixe folosite în fișa VM;
- `nomenclature_items`: valorile administrabile din fiecare categorie;
- `vm_operational_nomenclatures`: selecția curentă a fiecărei VM;
- `people`: registrul de persoane;
- `vm_responsibilities`: relație multiplă VM–persoană–tip responsabilitate;
- `vm_backup_summary`: rezumat separat pentru backup, pregătit pentru sincronizarea Veeam API.

package server

import (
	"net/http/httptest"
	"testing"

	"vm-doc-server/internal/domain"
)

func TestResolvedClientIPUsesRightmostUntrustedHop(t *testing.T) {
	r := httptest.NewRequest("GET", "https://vm-doc.example.ro/", nil)
	r.RemoteAddr = "127.0.0.1:43210"
	r.Header.Set("X-Forwarded-For", "203.0.113.200, 198.51.100.10")
	got := resolvedClientIP(r, []string{"127.0.0.1/32"})
	if got != "198.51.100.10" {
		t.Fatalf("resolved client IP %q, want 198.51.100.10", got)
	}
}

func TestResolvedClientIPIgnoresForwardedHeaderFromUntrustedPeer(t *testing.T) {
	r := httptest.NewRequest("GET", "https://vm-doc.example.ro/", nil)
	r.RemoteAddr = "192.0.2.44:43210"
	r.Header.Set("X-Forwarded-For", "203.0.113.200")
	got := resolvedClientIP(r, []string{"127.0.0.1/32"})
	if got != "192.0.2.44" {
		t.Fatalf("resolved client IP %q, want direct peer", got)
	}
}

func TestVMFilterFromRequest(t *testing.T) {
	r := httptest.NewRequest("GET", "/api/v1/vms?q=ubuntu&power=POWERED_ON&agent=online&retired=false&source_id=3&page=2&page_size=100", nil)
	filter, err := vmFilterFromRequest(r)
	if err != nil {
		t.Fatal(err)
	}
	if filter.Query != "ubuntu" || filter.Power != "POWERED_ON" || filter.Agent != "online" || filter.Retired != "false" || filter.SourceID != 3 || filter.Page != 2 || filter.PageSize != 100 {
		t.Fatalf("unexpected filter: %+v", filter)
	}
}

func TestVMExportRowsUsesInventoryValues(t *testing.T) {
	rows := vmExportRows([]domain.VirtualMachine{{
		Name: "vm-01", VCenterSourceName: "vc-main", GuestOS: "fallback", InventoryOSName: "Ubuntu", InventoryOSVersion: "24.04",
		GuestHostname: "fallback-host", InventoryHostname: "vm-01.example", PrimaryIP: "192.0.2.1", InventoryPrimaryIP: "192.0.2.10",
	}})
	if len(rows) != 2 || len(rows[0]) != 18 || len(rows[1]) != 18 {
		t.Fatalf("unexpected export dimensions: rows=%d header=%d data=%d", len(rows), len(rows[0]), len(rows[1]))
	}
	if rows[1][5].Text != "Ubuntu" || rows[1][7].Text != "vm-01.example" || rows[1][8].Text != "192.0.2.10" {
		t.Fatalf("inventory values not preferred: %+v", rows[1])
	}
}

func TestPaginationFromRequest(t *testing.T) {
	r := httptest.NewRequest("GET", "/api/v1/audit/events?page=3&page_size=75", nil)
	page, pageSize, err := paginationFromRequest(r, 50, 200)
	if err != nil {
		t.Fatal(err)
	}
	if page != 3 || pageSize != 75 {
		t.Fatalf("unexpected pagination: page=%d pageSize=%d", page, pageSize)
	}
}

func TestPaginationFromRequestCapsPageSize(t *testing.T) {
	r := httptest.NewRequest("GET", "/api/v1/audit/events?page_size=500", nil)
	page, pageSize, err := paginationFromRequest(r, 50, 200)
	if err != nil {
		t.Fatal(err)
	}
	if page != 1 || pageSize != 200 {
		t.Fatalf("unexpected pagination: page=%d pageSize=%d", page, pageSize)
	}
}

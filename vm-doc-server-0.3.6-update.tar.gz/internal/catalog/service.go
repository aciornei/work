package catalog

import (
	"context"
	"database/sql"
	"errors"
	"net/url"
	"regexp"
	"strconv"
	"strings"

	"vm-doc-server/internal/domain"
)

var codePattern = regexp.MustCompile(`^[a-z0-9][a-z0-9._-]{0,127}$`)

var criticalities = map[string]bool{"low": true, "normal": true, "high": true, "critical": true}
var documentationStatuses = map[string]bool{"draft": true, "in_progress": true, "review": true, "approved": true, "obsolete": true}

type Service struct{ DB *sql.DB }

type InternalServiceInput struct {
	ITILCategoryID      int64  `json:"itil_category_id"`
	Name                string `json:"name"`
	ServiceCode         string `json:"service_code"`
	Description         string `json:"description"`
	Purpose             string `json:"purpose"`
	Criticality         string `json:"criticality"`
	DocumentationStatus string `json:"documentation_status"`
	DocumentationURL    string `json:"documentation_url"`
	Active              *bool  `json:"active,omitempty"`
}

type RoleMappingInput struct {
	LayerID         int64 `json:"layer_id"`
	TechnicalRoleID int64 `json:"technical_role_id"`
	SortOrder       int   `json:"sort_order"`
}

func (s Service) List(ctx context.Context, includeInactive bool) ([]domain.InternalService, error) {
	query := serviceSelect()
	if !includeInactive {
		query += ` WHERE service.active=1`
	}
	query += ` ORDER BY COALESCE(domain_item.name,''),category_item.name,service.name`
	rows, err := s.DB.QueryContext(ctx, query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	values := make([]domain.InternalService, 0)
	for rows.Next() {
		value, err := scanService(rows)
		if err != nil {
			return nil, err
		}
		values = append(values, value)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	mappings, err := s.listAllMappings(ctx)
	if err != nil {
		return nil, err
	}
	for i := range values {
		values[i].RoleMappings = mappings[values[i].ID]
	}
	return values, nil
}

func (s Service) Get(ctx context.Context, id int64) (domain.InternalService, error) {
	row := s.DB.QueryRowContext(ctx, serviceSelect()+` WHERE service.id=?`, id)
	value, err := scanService(row)
	if err != nil {
		return domain.InternalService{}, err
	}
	value.RoleMappings, err = s.ListRoleMappings(ctx, id)
	if err != nil {
		return domain.InternalService{}, err
	}
	value.VMs, err = s.ListVMs(ctx, id)
	return value, err
}

func (s Service) Create(ctx context.Context, userID int64, input InternalServiceInput) (domain.InternalService, error) {
	if err := normalizeService(&input); err != nil {
		return domain.InternalService{}, err
	}
	if err := s.validateCategory(ctx, input.ITILCategoryID); err != nil {
		return domain.InternalService{}, err
	}
	active := true
	if input.Active != nil {
		active = *input.Active
	}
	result, err := s.DB.ExecContext(ctx, `INSERT INTO internal_services(itil_category_id,name,service_code,description,purpose,criticality,documentation_status,documentation_url,active,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?,?,?,?)`, input.ITILCategoryID, input.Name, nullableCode(input.ServiceCode), input.Description, input.Purpose, input.Criticality, input.DocumentationStatus, input.DocumentationURL, active, userID, userID)
	if err != nil {
		return domain.InternalService{}, err
	}
	id, _ := result.LastInsertId()
	return s.Get(ctx, id)
}

func (s Service) Update(ctx context.Context, id, userID int64, input InternalServiceInput) (domain.InternalService, error) {
	current, err := s.Get(ctx, id)
	if err != nil {
		return domain.InternalService{}, err
	}
	if input.ITILCategoryID == 0 {
		input.ITILCategoryID = current.ITILCategoryID
	}
	if strings.TrimSpace(input.Name) == "" {
		input.Name = current.Name
	}
	if input.Active == nil {
		active := current.Active
		input.Active = &active
	}
	if err := normalizeService(&input); err != nil {
		return domain.InternalService{}, err
	}
	if err := s.validateCategory(ctx, input.ITILCategoryID); err != nil {
		return domain.InternalService{}, err
	}
	_, err = s.DB.ExecContext(ctx, `UPDATE internal_services SET itil_category_id=?,name=?,service_code=?,description=?,purpose=?,criticality=?,documentation_status=?,documentation_url=?,active=?,updated_by=? WHERE id=?`, input.ITILCategoryID, input.Name, nullableCode(input.ServiceCode), input.Description, input.Purpose, input.Criticality, input.DocumentationStatus, input.DocumentationURL, *input.Active, userID, id)
	if err != nil {
		return domain.InternalService{}, err
	}
	return s.Get(ctx, id)
}

func (s Service) ListRoleMappings(ctx context.Context, serviceID int64) ([]domain.ServiceRoleMapping, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT mapping.id,mapping.layer_id,layer_item.name,mapping.technical_role_id,role_item.name,mapping.sort_order,mapping.active
		FROM internal_service_role_mappings mapping
		JOIN nomenclature_items layer_item ON layer_item.id=mapping.layer_id
		JOIN nomenclature_items role_item ON role_item.id=mapping.technical_role_id
		WHERE mapping.internal_service_id=?
		ORDER BY mapping.sort_order,layer_item.sort_order,layer_item.name,role_item.sort_order,role_item.name`, serviceID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.ServiceRoleMapping, 0)
	for rows.Next() {
		var value domain.ServiceRoleMapping
		if err := rows.Scan(&value.ID, &value.LayerID, &value.LayerName, &value.TechnicalRoleID, &value.TechnicalRole, &value.SortOrder, &value.Active); err != nil {
			return nil, err
		}
		out = append(out, value)
	}
	return out, rows.Err()
}

func (s Service) listAllMappings(ctx context.Context) (map[int64][]domain.ServiceRoleMapping, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT mapping.internal_service_id,mapping.id,mapping.layer_id,layer_item.name,mapping.technical_role_id,role_item.name,mapping.sort_order,mapping.active
		FROM internal_service_role_mappings mapping
		JOIN nomenclature_items layer_item ON layer_item.id=mapping.layer_id
		JOIN nomenclature_items role_item ON role_item.id=mapping.technical_role_id
		ORDER BY mapping.internal_service_id,mapping.sort_order,layer_item.sort_order,layer_item.name,role_item.sort_order,role_item.name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make(map[int64][]domain.ServiceRoleMapping)
	for rows.Next() {
		var serviceID int64
		var value domain.ServiceRoleMapping
		if err := rows.Scan(&serviceID, &value.ID, &value.LayerID, &value.LayerName, &value.TechnicalRoleID, &value.TechnicalRole, &value.SortOrder, &value.Active); err != nil {
			return nil, err
		}
		out[serviceID] = append(out[serviceID], value)
	}
	return out, rows.Err()
}

func (s Service) ReplaceRoleMappings(ctx context.Context, serviceID, userID int64, inputs []RoleMappingInput) ([]domain.ServiceRoleMapping, error) {
	if _, err := s.Get(ctx, serviceID); err != nil {
		return nil, err
	}
	seen := make(map[string]bool)
	for i := range inputs {
		if inputs[i].LayerID <= 0 || inputs[i].TechnicalRoleID <= 0 {
			return nil, errors.New("layer_id and technical_role_id are required")
		}
		if inputs[i].SortOrder < -100000 || inputs[i].SortOrder > 100000 {
			return nil, errors.New("sort_order must be between -100000 and 100000")
		}
		if err := s.validateNomenclatureCategory(ctx, inputs[i].LayerID, "layer", "invalid layer_id"); err != nil {
			return nil, err
		}
		if err := s.validateNomenclatureCategory(ctx, inputs[i].TechnicalRoleID, "technical_role", "invalid technical_role_id"); err != nil {
			return nil, err
		}
		key := mappingKey(inputs[i].LayerID, inputs[i].TechnicalRoleID)
		if seen[key] {
			return nil, errors.New("invalid duplicate layer and technical role mapping")
		}
		seen[key] = true
	}
	rows, err := s.DB.QueryContext(ctx, `SELECT layer_id,technical_role_id FROM vm_internal_service_assignments WHERE internal_service_id=? AND layer_id IS NOT NULL AND technical_role_id IS NOT NULL`, serviceID)
	if err != nil {
		return nil, err
	}
	for rows.Next() {
		var layerID, roleID int64
		if err := rows.Scan(&layerID, &roleID); err != nil {
			rows.Close()
			return nil, err
		}
		if !seen[mappingKey(layerID, roleID)] {
			rows.Close()
			return nil, errors.New("a layer-role mapping must not be removed while it is used by a VM")
		}
	}
	if err := rows.Err(); err != nil {
		rows.Close()
		return nil, err
	}
	if err := rows.Close(); err != nil {
		return nil, err
	}
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback()
	if _, err := tx.ExecContext(ctx, `DELETE FROM internal_service_role_mappings WHERE internal_service_id=?`, serviceID); err != nil {
		return nil, err
	}
	for _, input := range inputs {
		if _, err := tx.ExecContext(ctx, `INSERT INTO internal_service_role_mappings(internal_service_id,layer_id,technical_role_id,sort_order,active,created_by) VALUES(?,?,?,?,1,?)`, serviceID, input.LayerID, input.TechnicalRoleID, input.SortOrder, userID); err != nil {
			return nil, err
		}
	}
	if err := tx.Commit(); err != nil {
		return nil, err
	}
	return s.ListRoleMappings(ctx, serviceID)
}

func (s Service) ListVMs(ctx context.Context, serviceID int64) ([]domain.InternalServiceVM, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT assignment.id,vm.id,vm.name,vm.power_state,COALESCE(NULLIF(inventory.hostname,''),vm.guest_hostname),COALESCE(NULLIF(inventory.primary_ip,''),vm.primary_ip),assignment.layer_id,COALESCE(layer_item.name,''),assignment.technical_role_id,COALESCE(role_item.name,''),assignment.usage_type,assignment.is_primary,assignment.notes
		FROM vm_internal_service_assignments assignment
		JOIN virtual_machines vm ON vm.id=assignment.vm_id
		LEFT JOIN inventory_snapshots inventory ON inventory.id=vm.current_inventory_id
		LEFT JOIN nomenclature_items layer_item ON layer_item.id=assignment.layer_id
		LEFT JOIN nomenclature_items role_item ON role_item.id=assignment.technical_role_id
		WHERE assignment.internal_service_id=?
		ORDER BY vm.name,assignment.is_primary DESC,assignment.sort_order,layer_item.name,role_item.name`, serviceID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.InternalServiceVM, 0)
	for rows.Next() {
		var value domain.InternalServiceVM
		var layerID, roleID sql.NullInt64
		if err := rows.Scan(&value.AssignmentID, &value.ID, &value.Name, &value.PowerState, &value.GuestHostname, &value.PrimaryIP, &layerID, &value.LayerName, &roleID, &value.TechnicalRole, &value.UsageType, &value.Primary, &value.Notes); err != nil {
			return nil, err
		}
		if layerID.Valid {
			id := layerID.Int64
			value.LayerID = &id
		}
		if roleID.Valid {
			id := roleID.Int64
			value.TechnicalRoleID = &id
		}
		out = append(out, value)
	}
	return out, rows.Err()
}

func (s Service) validateCategory(ctx context.Context, id int64) error {
	return s.validateNomenclatureCategory(ctx, id, "itil_category", "invalid ITIL category")
}

func (s Service) validateNomenclatureCategory(ctx context.Context, id int64, expected, message string) error {
	var category string
	if err := s.DB.QueryRowContext(ctx, `SELECT category_code FROM nomenclature_items WHERE id=?`, id).Scan(&category); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return errors.New(message)
		}
		return err
	}
	if category != expected {
		return errors.New(message)
	}
	return nil
}

func serviceSelect() string {
	return `SELECT service.id,service.itil_category_id,category_item.name,parent_relation.parent_item_id,COALESCE(domain_item.name,''),service.name,service.service_code,service.description,service.purpose,service.criticality,service.documentation_status,service.documentation_url,service.active,
		(SELECT COUNT(DISTINCT assignment.vm_id) FROM vm_internal_service_assignments assignment WHERE assignment.internal_service_id=service.id),
		(SELECT COUNT(*) FROM internal_service_role_mappings mapping WHERE mapping.internal_service_id=service.id AND mapping.active=1),
		service.created_at,service.updated_at
		FROM internal_services service
		JOIN nomenclature_items category_item ON category_item.id=service.itil_category_id
		LEFT JOIN nomenclature_item_parents parent_relation ON parent_relation.child_item_id=category_item.id
		LEFT JOIN nomenclature_items domain_item ON domain_item.id=parent_relation.parent_item_id`
}

type rowScanner interface{ Scan(dest ...any) error }

func scanService(row rowScanner) (domain.InternalService, error) {
	var value domain.InternalService
	var domainID sql.NullInt64
	var serviceCode sql.NullString
	err := row.Scan(&value.ID, &value.ITILCategoryID, &value.ITILCategory, &domainID, &value.ArchitecturalDomain, &value.Name, &serviceCode, &value.Description, &value.Purpose, &value.Criticality, &value.DocumentationStatus, &value.DocumentationURL, &value.Active, &value.VMCount, &value.RoleMappingCount, &value.CreatedAt, &value.UpdatedAt)
	if domainID.Valid {
		id := domainID.Int64
		value.ArchitecturalDomainID = &id
	}
	if serviceCode.Valid {
		value.ServiceCode = serviceCode.String
	}
	return value, err
}

func normalizeService(input *InternalServiceInput) error {
	input.Name = strings.TrimSpace(input.Name)
	input.ServiceCode = strings.ToLower(strings.TrimSpace(input.ServiceCode))
	input.Description = strings.TrimSpace(input.Description)
	input.Purpose = strings.TrimSpace(input.Purpose)
	input.Criticality = strings.ToLower(strings.TrimSpace(input.Criticality))
	input.DocumentationStatus = strings.ToLower(strings.TrimSpace(input.DocumentationStatus))
	input.DocumentationURL = strings.TrimSpace(input.DocumentationURL)
	if input.ITILCategoryID <= 0 {
		return errors.New("itil_category_id is required")
	}
	if input.Name == "" {
		return errors.New("name is required")
	}
	if input.Criticality == "" {
		input.Criticality = "normal"
	}
	if input.DocumentationStatus == "" {
		input.DocumentationStatus = "draft"
	}
	if !criticalities[input.Criticality] {
		return errors.New("invalid criticality")
	}
	if !documentationStatuses[input.DocumentationStatus] {
		return errors.New("invalid documentation_status")
	}
	if input.ServiceCode != "" && !codePattern.MatchString(input.ServiceCode) {
		return errors.New("service_code is invalid")
	}
	if len([]rune(input.Name)) > 255 || len([]rune(input.ServiceCode)) > 128 || len([]rune(input.Description)) > 10000 || len([]rune(input.Purpose)) > 10000 || len([]rune(input.DocumentationURL)) > 1024 {
		return errors.New("internal service values must not exceed the allowed length")
	}
	if input.DocumentationURL != "" {
		parsed, err := url.ParseRequestURI(input.DocumentationURL)
		if err != nil || (parsed.Scheme != "http" && parsed.Scheme != "https") || parsed.Host == "" {
			return errors.New("documentation_url must be an absolute HTTP or HTTPS URL")
		}
	}
	return nil
}

func nullableCode(value string) any {
	if value == "" {
		return nil
	}
	return value
}

func mappingKey(layerID, roleID int64) string {
	return strconv.FormatInt(layerID, 10) + ":" + strconv.FormatInt(roleID, 10)
}

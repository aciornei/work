# Implementation status 0.3.6

## Implementat

- surse vCenter cu secrete criptate, sincronizare asincronă și programare zilnică;
- upsert VM și marcaj `missing` când o mașină nu mai este văzută în vCenter;
- corelare automată sau manuală cu agentul;
- listă VM, fișă tehnică structurată, căutare, paginare și export Excel;
- date operaționale independente de inventarul automat;
- catalog ierarhic: domeniu arhitectural, categorie ITIL și serviciu intern;
- combinații layer–rol permise pentru fiecare serviciu intern;
- asocieri multiple VM–serviciu–layer–rol, cu tip de utilizare, prioritate și observații;
- validare server-side a fiecărei combinații față de configurația serviciului;
- nomenclatoare pentru domenii, categorii ITIL, layer-e, roluri tehnice, medii, statusuri și clasificări;
- registru de persoane și responsabilități multiple pe VM;
- structură separată de backup, pregătită pentru Veeam API;
- inventar agent structurat și restrâns implicit, istoric și audit paginate;
- migrații, audit, RBAC și OpenAPI actualizate.

## Schimbări de model în 0.3.6

- serviciul intern nu mai este un câmp unic al VM-ului;
- layer-ul și rolul tehnic nu mai sunt câmpuri unice ale VM-ului;
- profilul/data provisionării au fost eliminate din modelul funcțional;
- vechiul lifecycle `Retired` este migrat la nomenclatorul `Status operațional: Retras` și nu mai este expus în interfața curentă;
- rezumatul redundant al ultimului inventar a fost eliminat.

## Validare necesară în mediul offline final

Arhiva standard nu include `vendor/`. În sursa offline care păstrează dependențele executați:

```bash
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

## Limitări

- datele efective din Veeam API nu sunt încă sincronizate;
- serviciile nu au încă dependențe și responsabilități proprii;
- generarea DOCX/PDF nu este încă implementată;
- custom attributes generale din vCenter nu sunt încă extrase;
- nu există încă worker automat pentru retenția inventarelor și auditului.

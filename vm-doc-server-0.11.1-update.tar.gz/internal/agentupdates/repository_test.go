package agentupdates

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestLatest(t *testing.T) {
	dir := t.TempDir()
	files := filepath.Join(dir, "files")
	if err := os.MkdirAll(files, 0755); err != nil {
		t.Fatal(err)
	}
	agent := []byte("agent")
	upd := []byte("updater")
	if err := os.WriteFile(filepath.Join(files, "agent.bin"), agent, 0644); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(files, "updater.bin"), upd, 0644); err != nil {
		t.Fatal(err)
	}
	ah := sha256.Sum256(agent)
	uh := sha256.Sum256(upd)
	repo := Repository{Releases: []Release{{Version: "1.3.0", Channel: "stable", OS: "linux", Arch: "amd64", AgentFilename: "agent.bin", AgentSHA256: hex.EncodeToString(ah[:]), AgentSizeBytes: int64(len(agent)), UpdaterFilename: "updater.bin", UpdaterSHA256: hex.EncodeToString(uh[:]), UpdaterSizeBytes: int64(len(upd)), PublishedAt: time.Now().UTC()}}}
	raw, _ := json.Marshal(repo)
	if err := os.WriteFile(filepath.Join(dir, "releases.json"), raw, 0644); err != nil {
		t.Fatal(err)
	}
	svc := Service{Directory: dir}
	got, err := svc.Latest("stable", "linux", "amd64", "1.2.0")
	if err != nil {
		t.Fatal(err)
	}
	if !got.Available || got.Version != "1.3.0" {
		t.Fatalf("unexpected latest: %+v", got)
	}
	current, err := svc.Latest("stable", "linux", "amd64", "1.3.0")
	if err != nil {
		t.Fatal(err)
	}
	if current.Available {
		t.Fatalf("expected no update: %+v", current)
	}
}

func TestPublishPromoteDelete(t *testing.T) {
	dir := t.TempDir()
	svc := Service{Directory: dir}
	if err := svc.Validate(); err != nil {
		t.Fatal(err)
	}
	agentPath := filepath.Join(t.TempDir(), "agent")
	updaterPath := filepath.Join(t.TempDir(), "updater")
	if err := os.WriteFile(agentPath, []byte("agent-1.3.2"), 0755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(updaterPath, []byte("updater-1.3.2"), 0755); err != nil {
		t.Fatal(err)
	}
	release, err := svc.Publish(PublishInput{Version: "1.3.2", Channel: "testing", OS: "linux", Arch: "amd64", AgentPath: agentPath, UpdaterPath: updaterPath, Notes: "pilot"})
	if err != nil {
		t.Fatal(err)
	}
	if release.Channel != "testing" || release.Version != "1.3.2" {
		t.Fatalf("unexpected release: %+v", release)
	}
	promoted, err := svc.Promote("1.3.2", "linux", "amd64")
	if err != nil {
		t.Fatal(err)
	}
	if promoted.Channel != "stable" {
		t.Fatalf("unexpected promoted release: %+v", promoted)
	}
	list, err := svc.List()
	if err != nil {
		t.Fatal(err)
	}
	if len(list) != 2 {
		t.Fatalf("expected testing + stable, got %d", len(list))
	}
	if err := svc.Delete("1.3.2", "testing", "linux", "amd64"); err != nil {
		t.Fatal(err)
	}
	list, err = svc.List()
	if err != nil {
		t.Fatal(err)
	}
	if len(list) != 1 || list[0].Channel != "stable" {
		t.Fatalf("unexpected list after delete: %+v", list)
	}
	if err := svc.Delete("1.3.2", "stable", "linux", "amd64"); err != nil {
		t.Fatal(err)
	}
	if fileExists(filepath.Join(dir, "files", release.AgentFilename)) {
		t.Fatal("unreferenced agent artifact should be removed")
	}
}

# Upgrade la vm-doc-server 0.11.1

0.11.1 este un update peste 0.11.0 și nu introduce migrare MariaDB.

## Funcționalități

- pagina **Agenți → Auto-update agent** permite publicarea unui release prin upload;
- release-ul poate fi publicat pe `testing` sau `stable`;
- un release `testing` poate fi promovat în `stable` fără reîncărcarea binarelor;
- release-urile pot fi șterse din UI;
- serverul calculează SHA-256 și scrie atomic `releases.json`.

## Configurație

Configurația rămâne:

```yaml
agent_updates:
  enabled: true
  directory: "/var/lib/vm-doc-server/agent-updates"
```

Nu este necesară nicio modificare de schemă DB.

## Agent 1.3.2

Agentul 1.3.2 păstrează auto-update-ul din 1.3.0+ și îmbunătățește colectarea versiunilor serviciilor: comenzile sunt rezolvate inclusiv din directoarele `sbin`, detecția rulează concurent și se păstrează fallback-ul la versiunea pachetului.

Recomandare: publică 1.3.2 întâi pe `testing`, verifică un VM pilot, apoi folosește **Promovează stable**.

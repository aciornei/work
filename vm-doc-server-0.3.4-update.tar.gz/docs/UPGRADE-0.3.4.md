# Upgrade la vm-doc-server 0.3.4

Actualizarea repară încărcarea fișei VM atunci când o secțiune opțională asociată agentului nu poate fi citită.

Nu există migrare SQL nouă.

După instalare, dacă există o inconsistență, pagina VM se încarcă parțial și jurnalul conține:

```text
VM detail optional data could not be loaded stage=<agent|inventory|inventory_document> vm_id=<id> error=<detaliu>
```

Validare recomandată:

```bash
GOPROXY=off GOFLAGS=-mod=vendor go test ./...
GOPROXY=off GOFLAGS=-mod=vendor make build
```

# vm-doc-server 0.4.2

Platformă centrală pentru documentarea VM-urilor, cu **vCenter drept punctul 0 al inventarului** și `vm-doc-agent` drept sursă pentru detaliile din sistemul de operare.

```text
vCenter API ──> virtual_machines ──┐
                                  ├──> vm-doc-server ──> browser / API
vm-doc-agent ─> collector ─> JSON ┘
```


## Ce aduce versiunea 0.4.2

- corectează încărcarea inventarului curent din fișa VM; interogarea după `current_inventory_id` transmite acum identificatorul către MariaDB;
- elimină eroarea SQL `Error 1064 ... near '?' at line 1` și avertismentul „Fișa a fost încărcată parțial”;
- JSON-ul agentului nu este modificat și nu este necesară recollectarea inventarului;
- actualizarea nu introduce migrare MariaDB.

Vezi `docs/UPGRADE-0.4.2.md`.

## Ce aduce versiunea 0.4.1

- denumirea din interfață este **Categorie de serviciu**; identificatorul intern `itil_category` este păstrat pentru compatibilitate cu baza și API-ul;
- pagina **Nomenclatoare → Persoane** poate interoga Active Directory folosind configurația LDAP existentă;
- utilizatorii sunt citiți recursiv dintr-un OU rădăcină configurabil și sunt afișați arborescent după sub-OU-uri;
- lista este filtrată după atributul AD `department`; implicit este ales primul departament în ordine alfabetică, dacă `default_department` nu este configurat;
- utilizatorii selectați sunt importați sau actualizați în registrul local de persoane și devin disponibili în responsabilitățile VM;
- migrarea `016` include corecția ordinii indexurilor, iar migrarea `017` adaugă identitatea de director pentru persoane.

Vezi `docs/UPGRADE-0.4.1.md` și `docs/CONFIGURATION.md`.

## Ce aduce versiunea 0.4.0

- domeniul arhitectural și categoria de serviciu se selectează pe fiecare asociere din fișa VM;
- serviciul intern nu mai are domeniu sau categorie configurate manual;
- pagina Servicii agregă automat toate combinațiile `Domeniu → Categorie de serviciu` observate pe VM-urile asociate;
- un serviciu poate apărea în mai multe domenii sau categorii, fără duplicarea serviciului în catalog;
- fișa VM folosește cascada `Domeniu → Categorie de serviciu → Serviciu intern → Layer → Rol tehnic`;
- backendul validează relația categorie–domeniu și relația rol–layer;
- migrarea `016_vm_service_classification.up.sql` copiază încadrarea existentă pe asocierile VM, fără pierderea datelor.

Vezi `docs/UPGRADE-0.4.0.md` și `docs/SERVICE-CATALOG.md`.

## Ce aduce versiunea 0.3.9

- pagina **Nomenclatoare** folosește un submeniu lateral și afișează o singură listă la un moment dat;
- opțiunile sunt grupate în **Catalog servicii**, **Arhitectură tehnică**, **Operare VM** și **Responsabilități**;
- fiecare opțiune afișează numărul de valori și are o rută proprie, păstrată la reîncărcarea paginii;
- pe ecrane mici, submeniul se transformă într-o grilă adaptivă;
- nu există modificări de bază de date.

Vezi `docs/UPGRADE-0.3.9.md`.

## Ce aduce versiunea 0.3.8

- selecția funcțională se face exclusiv pe fișa VM în cascada `Domeniu arhitectural → Serviciu intern → Layer → Rol tehnic`;
- domeniul filtrează serviciile, iar layer-ul filtrează rolurile tehnice permise global;
- serviciul intern nu mai configurează combinații layer–rol; pagina serviciului le agregă automat din VM-urile asociate;
- backendul validează numai existența serviciului și relația globală `Layer → Rol tehnic`;
- la adăugarea sau editarea unui rol tehnic, layer-ele se aleg dintr-un selector multiplu cu căutare, complet offline;
- rolurile tehnice sunt afișate după ordinea layer-ului, apoi după ordinea rolului în layer;
- versiunea nu introduce o migrare de schemă; tabelul vechi de configurare pe serviciu rămâne doar pentru compatibilitatea revenirii la 0.3.7 și nu mai este utilizat.

Vezi `docs/UPGRADE-0.3.8.md`.

## Ce aduce versiunea 0.3.7

- fiecare rol tehnic este legat de unul sau mai multe layer-e arhitecturale;
- în Nomenclatoare, rolul tehnic se editează împreună cu layer-ele permise;
- în pagina Serviciului intern, lista de roluri este filtrată după layer;
- backendul respinge orice combinație layer–rol care nu este definită global;
- perechile deja folosite sunt migrate automat și nu pot fi eliminate cât timp sunt utilizate.

Vezi `docs/UPGRADE-0.3.7.md`.

## Ce aduce versiunea 0.3.6

- un VM poate avea mai multe servicii interne asociate;
- același serviciu poate avea pe același VM mai multe combinații `Layer arhitectural → Rol tehnic`;
- fiecare asociere poate fi dedicată, partajată sau dependență și poate fi marcată drept principală;
- serviciul, layer-ul și rolul nu mai sunt câmpuri unice în formularul operațional;
- profilul și data provisionării sunt eliminate din modelul funcțional și din nomenclatoare;
- lifecycle-ul local `Retired` nu mai este expus în interfață/API; valorile existente sunt migrate la `Status operațional: Retras`;
- cardul redundant „Rezumat ultimul inventar” este eliminat; rămân ultimul inventar, datele agentului și istoricul paginat.

Vezi `docs/SERVICE-CATALOG.md` și `docs/UPGRADE-0.3.6.md`.

## Ce aduce versiunea 0.3.5

- corectează încărcarea fișei VM: erorile din datele operaționale sau backup nu mai blochează întreaga pagină;
- jurnalizează explicit toate etapele endpointului `GET /api/v1/vms/{id}` (`vm`, `operational`, `backup`, `agent`, `inventory`, `inventory_document`);
- afișează dinamic versiunea reală raportată de endpointul `/version`, eliminând eticheta hard-codată `0.3.2`.

## Ce aduce versiunea 0.3.4

- fișa VM nu mai cade complet dacă agentul sau inventarul curent au date inconsistente;
- erorile opționale sunt jurnalizate și afișate ca avertismente în interfață.

## Ce aduce versiunea 0.3.3

- datele detaliate colectate de agent sunt restrânse implicit;
- istoricul inventarelor și evenimentele de audit sunt paginate;

- meniu principal **Servicii**, separat de nomenclatoare;
- `Serviciu` ITIL este redenumit **Categorie de serviciu**, iar vechea `Componentă` devine **Serviciu intern**;
- încadrare strictă și selecție în cascadă: `Domeniu arhitectural → Categorie de serviciu → Serviciu intern → Layer → Rol tehnic`;
- fiecare categorie de serviciu este legată de un domeniu arhitectural;
- fiecare serviciu intern definește combinațiile layer–rol permise;
- pagina serviciului centralizează informațiile serviciului, VM-urile asociate și pregătește unitatea viitoare de documentare DOCX/PDF;
- validare identică în browser și în API, astfel încât combinațiile incompatibile nu pot fi salvate;
- migrarea `013_internal_service_catalog.up.sql` păstrează și convertește datele existente.

Vezi `docs/SERVICE-CATALOG.md` și `docs/UPGRADE-0.3.3.md`.

## Ce aduce versiunea 0.3.1

- meniu administrativ **Nomenclatoare** cu liste controlate pentru încadrarea VM-urilor;
- serviciu, componentă, domeniu arhitectural, layer, mediu, status operațional, profil de provisionare și clasificare sunt selectate din list-box-uri;
- registru de persoane și responsabilități multiple pe VM;
- politica de backup este scoasă din formularul operațional și afișată într-o secțiune separată, pregătită pentru datele Veeam API;
- valorile text și responsabilitățile existente sunt migrate automat la prima pornire.

## Ce aduce versiunea 0.3.0

- fișa tehnică a VM-ului este afișată pe carduri și secțiuni, nu doar ca JSON brut;
- inventarul agentului este transformat într-o vedere structurată și ordonată pentru sistem, rețea, stocare, servicii, porturi, firewall, SSSD, integrări, politici și NTP;
- câmpurile care pot conține parole, tokenuri, secrete sau chei private sunt mascate în vederea structurată;
- date operaționale editabile, păstrate separat de snapshoturile agentului: serviciu, componentă, domeniu arhitectural, layer, mediu, status, scop, responsabili, profil/data provisionării, RPO/RTO, backup, clasificare, documentație, tichet și observații;
- migrarea `011_vm_operational_metadata.up.sql` și audit pentru modificarea datelor operaționale;
- endpoint nou `PUT /api/v1/vms/{id}/operational` și OpenAPI actualizat;
- interfață adaptivă, cu secțiuni pliabile și afișare ierarhică a listelor și obiectelor colectate.

## Ce aduce versiunea 0.2.2

- căutare VM în nume, hostname, power state, sistem de operare, IP, agent și sursă vCenter;
- filtre distincte pentru power, stare agent, `Retired` și sursă;
- paginare server-side cu 25, 50, 100 sau 200 de înregistrări pe pagină;
- statistici calculate pentru rezultatul filtrat;
- export Excel real `.xlsx`, cu aceleași filtre, antet fix, auto-filter și lățimi de coloane;
- corectarea antetului tabelului VM, care nu mai acoperă primul rând;
- răspunsuri `[]` pentru listele vCenter goale și corecția conflictului rutelor Swagger din Go 1.23.

## Ce aduce versiunea 0.2.0

- surse vCenter multiple, cu credențiale criptate individual;
- importul tuturor VM-urilor vizibile prin API-ul vCenter;
- buton de sincronizare manuală și sincronizare automată zilnică;
- istoric pentru fiecare rulare vCenter: găsite, adăugate, actualizate, lipsă și agenți asociați;
- câmp local `Retired`, notă și audit, păstrate la sincronizările ulterioare;
- VM-urile care dispar din vCenter sunt marcate `missing`, nu șterse automat;
- asociere automată VM–agent după BIOS/DMI UUID și asociere manuală din interfață;
- stare agent, ultimul contact, ultima colectare și butoane **Testează** / **Sincronizează acum** în fișa VM;
- parser corect pentru schema agentului 2.0: `agent.id`, `agent.version`, `collection.collectors` și câmpurile de corelare VMware;
- API/OpenAPI și interfață actualizate.

## Componente

- `vm-doc-server`: API, frontend, autentificare, RBAC, audit și scheduler vCenter;
- `vm-doc-collector`: coadă persistentă și interogarea agenților;
- MariaDB: surse vCenter, VM-uri, status operațional, asocieri multiple cu servicii, joburi și snapshoturi JSON.

Serverul web contactează vCenter. Numai `vm-doc-collector` contactează agenții.

## Compilare

Necesită Go 1.23 sau mai nou și modulele declarate în `go.mod`.

```bash
make test
make build
```

Binarele sunt generate în `bin/`.

Pentru un server fără internet, pregătiți pe o stație conectată un pachet cu `vendor/`:

```bash
go mod download
go mod vendor
go test -mod=vendor ./...
```

Apoi transferați întregul director al proiectului și compilați cu:

```bash
CGO_ENABLED=0 go build -mod=vendor -trimpath -o bin/vm-doc-server ./cmd/vm-doc-server
CGO_ENABLED=0 go build -mod=vendor -trimpath -o bin/vm-doc-collector ./cmd/vm-doc-collector
```

## Instalare și upgrade

Instalarea inițială rămâne aceeași ca în 0.1.0. La prima pornire, migrațiile sunt aplicate automat. Versiunea 0.4.1 aplică migrarea `017_service_category_ad_directory.up.sql`, păstrează compatibilitatea cu identificatorul `itil_category` și corectează reluarea sigură a migrării `016_vm_service_classification.up.sql`.

Pentru upgrade:

1. faceți backup la baza MariaDB și la configurație;
2. opriți `vm-doc-server` și `vm-doc-collector`;
3. înlocuiți binarele și fișierele web incluse în binar;
4. păstrați `version: 1` în `config.yaml` și adăugați secțiunea opțională `vcenter`;
5. porniți mai întâi serverul, apoi collectorul;
6. adăugați sursa vCenter din pagina **VM-uri** și porniți prima sincronizare.

Pentru actualizarea curentă consultați `docs/UPGRADE-0.4.1.md`. Pentru instalarea vCenter consultați și `docs/UPGRADE-0.2.0.md` și `docs/VCENTER.md`.

## API

- document OpenAPI: `/api/openapi.yaml`;
- Swagger UI: `/docs/`;
- health: `/healthz`;
- readiness: `/readyz`;
- versiune: `/version`.

## Securitate

- parolele vCenter și tokenurile agenților sunt criptate AES-256-GCM înainte de salvarea în MariaDB;
- API-ul nu returnează secretele;
- `verify_tls` trebuie menținut activ în producție;
- contul vCenter trebuie să fie dedicat și limitat la operațiile de inventariere necesare;
- modificările datelor operaționale, asocierilor multiple și sincronizările manuale sunt auditate.

## Limitări cunoscute

- custom attributes generale din vCenter nu sunt încă importate; statusul operațional este administrat local din nomenclator;
- operația REST `GET /api/vcenter/vm` returnează maximum 4.000 de VM-uri per sursă; pentru inventare mai mari este necesară împărțirea sursei sau o sincronizare filtrată într-o versiune ulterioară;
- exportul DOCX/PDF și retenția automată vor fi dezvoltate ulterior; exportul Excel este disponibil din 0.2.2;
- arhiva sursă standard nu conține dependențe vendorizate.

## Autoînregistrarea agenților

Versiunea 0.2.2 lucrează cu `vm-doc-agent 1.1.0` și creează automat agenții, primește heartbeat și inventarul push. Vezi `docs/AGENT-REGISTRATION.md`.

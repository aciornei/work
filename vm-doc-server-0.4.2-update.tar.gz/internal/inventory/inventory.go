package inventory

import (
	"bytes"
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/domain"
)

type Service struct{ DB *sql.DB }

type Summary struct {
	SchemaVersion     string
	AgentUUID         string
	AgentVersion      string
	Hostname          string
	FQDN              string
	ProductUUID       string
	ProductUUIDLegacy string
	MachineID         string
	OSName            string
	OSVersion         string
	PrimaryIP         string
	BootTime          *time.Time
	CollectorTotal    int
	CollectorOK       int
	CollectorError    int
	CollectorTimeout  int
	CollectedAt       *time.Time
}

func Summarize(raw []byte) (Summary, error) {
	dec := json.NewDecoder(bytes.NewReader(raw))
	dec.UseNumber()
	var root any
	if err := dec.Decode(&root); err != nil {
		return Summary{}, fmt.Errorf("invalid inventory JSON: %w", err)
	}
	if err := dec.Decode(&struct{}{}); !errors.Is(err, io.EOF) {
		return Summary{}, errors.New("inventory JSON contains trailing data")
	}
	m, ok := root.(map[string]any)
	if !ok {
		return Summary{}, errors.New("inventory root must be an object")
	}

	s := Summary{
		SchemaVersion: firstStringAt(m,
			[]string{"schema_version"}, []string{"schemaVersion"}, []string{"schema", "version"}, []string{"meta", "schema_version"}),
		AgentUUID: firstStringAt(m,
			[]string{"agent", "id"}, []string{"agent_uuid"}, []string{"machine_uuid"}, []string{"identity", "uuid"}, []string{"host", "uuid"}, []string{"system", "uuid"}, []string{"identity", "machine_id"}),
		AgentVersion: firstStringAt(m,
			[]string{"agent", "version"}, []string{"agent_version"}),
		Hostname: firstStringAt(m,
			[]string{"hostname"}, []string{"identity", "hostname"}, []string{"host", "hostname"}, []string{"system", "hostname"}, []string{"identity", "fqdn"}),
		FQDN: firstStringAt(m,
			[]string{"fqdn"}, []string{"host", "fqdn"}, []string{"identity", "fqdn"}),
		ProductUUID: firstStringAt(m,
			[]string{"host", "product_uuid"}, []string{"host", "correlation_uuid"}, []string{"host", "correlation", "dmi_product_uuid"}),
		ProductUUIDLegacy: firstStringAt(m,
			[]string{"host", "correlation", "smbios_legacy_byte_order"}),
		MachineID: firstStringAt(m,
			[]string{"host", "machine_id"}, []string{"host", "correlation", "machine_id"}, []string{"identity", "machine_id"}),
		OSName: firstStringAt(m,
			[]string{"os_name"}, []string{"os", "pretty_name"}, []string{"os", "name"}, []string{"operating_system", "name"}, []string{"system", "os", "name"}),
		OSVersion: firstStringAt(m,
			[]string{"os_version"}, []string{"os", "version_id"}, []string{"os", "version"}, []string{"operating_system", "version"}, []string{"system", "os", "version"}),
		PrimaryIP: firstInventoryIP(m),
	}

	if v := firstValueAt(m,
		[]string{"boot_time"}, []string{"bootTime"}, []string{"system", "boot_time"}, []string{"system", "boot_timestamp"}); v != nil {
		if t, ok := parseTime(v); ok {
			s.BootTime = &t
		}
	}
	if v := firstValueAt(m,
		[]string{"collected_at"}, []string{"generated_at"}, []string{"timestamp"}, []string{"meta", "collected_at"}, []string{"meta", "generated_at"}); v != nil {
		if t, ok := parseTime(v); ok {
			s.CollectedAt = &t
		}
	}

	if collectors := firstValueAt(m,
		[]string{"collection", "collectors"}, []string{"collectors"}, []string{"collector_status"}, []string{"status", "collectors"}, []string{"meta", "collectors"}); collectors != nil {
		countCollectorStatuses(collectors, &s)
	}
	return s, nil
}

func countCollectorStatuses(v any, s *Summary) {
	switch values := v.(type) {
	case map[string]any:
		for _, item := range values {
			s.CollectorTotal++
			classifyCollectorStatus(statusString(item), s)
		}
	case []any:
		for _, item := range values {
			s.CollectorTotal++
			classifyCollectorStatus(statusString(item), s)
		}
	}
}

func classifyCollectorStatus(status string, s *Summary) {
	status = strings.ToLower(strings.TrimSpace(status))
	switch {
	case strings.Contains(status, "timeout"):
		s.CollectorTimeout++
	case strings.Contains(status, "error"), strings.Contains(status, "fail"):
		s.CollectorError++
	default:
		s.CollectorOK++
	}
}

func (s Service) Save(ctx context.Context, agentID, jobID int64, raw []byte, summary Summary) (domain.Inventory, error) {
	h := sha256.Sum256(raw)
	hash := hex.EncodeToString(h[:])
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return domain.Inventory{}, err
	}
	defer tx.Rollback()

	var existingID int64
	err = tx.QueryRowContext(ctx, `SELECT id FROM inventory_snapshots WHERE collection_job_id=?`, jobID).Scan(&existingID)
	if err == nil {
		now := time.Now().UTC()
		if _, err = tx.ExecContext(ctx, `UPDATE agents SET current_inventory_id=?,last_attempt_at=?,last_contact_at=?,last_success_at=?,last_error='' WHERE id=?`, existingID, now, now, now, agentID); err != nil {
			return domain.Inventory{}, err
		}
		if err := linkInventoryToVM(ctx, tx, agentID, existingID, summary); err != nil {
			return domain.Inventory{}, err
		}
		if err := tx.Commit(); err != nil {
			return domain.Inventory{}, err
		}
		return s.Get(ctx, existingID, true)
	}
	if !errors.Is(err, sql.ErrNoRows) {
		return domain.Inventory{}, err
	}

	var previous string
	err = tx.QueryRowContext(ctx, `SELECT payload_sha256 FROM inventory_snapshots WHERE agent_id=? ORDER BY id DESC LIMIT 1`, agentID).Scan(&previous)
	if err != nil && !errors.Is(err, sql.ErrNoRows) {
		return domain.Inventory{}, err
	}
	changed := errors.Is(err, sql.ErrNoRows) || previous != hash
	now := time.Now().UTC()
	res, err := tx.ExecContext(ctx, `INSERT INTO inventory_snapshots(agent_id,collection_job_id,schema_version,agent_uuid,agent_version,hostname,fqdn,product_uuid,product_uuid_normalized,product_uuid_legacy,product_uuid_legacy_normalized,machine_id,os_name,os_version,primary_ip,boot_time,collector_total,collector_ok,collector_error,collector_timeout,payload_size,payload_sha256,changed_from_previous,raw_json,collected_at,received_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, agentID, jobID, summary.SchemaVersion, summary.AgentUUID, summary.AgentVersion, summary.Hostname, summary.FQDN, summary.ProductUUID, normalizeUUID(summary.ProductUUID), summary.ProductUUIDLegacy, normalizeUUID(summary.ProductUUIDLegacy), summary.MachineID, summary.OSName, summary.OSVersion, summary.PrimaryIP, summary.BootTime, summary.CollectorTotal, summary.CollectorOK, summary.CollectorError, summary.CollectorTimeout, len(raw), hash, changed, raw, summary.CollectedAt, now)
	if err != nil {
		return domain.Inventory{}, err
	}
	id, err := res.LastInsertId()
	if err != nil {
		return domain.Inventory{}, err
	}
	if _, err = tx.ExecContext(ctx, `UPDATE agents SET current_inventory_id=?,last_attempt_at=?,last_contact_at=?,last_success_at=?,last_error='' WHERE id=?`, id, now, now, now, agentID); err != nil {
		return domain.Inventory{}, err
	}
	if err := linkInventoryToVM(ctx, tx, agentID, id, summary); err != nil {
		return domain.Inventory{}, err
	}
	if err := tx.Commit(); err != nil {
		return domain.Inventory{}, err
	}
	return s.Get(ctx, id, true)
}

func (s Service) ListVMs(ctx context.Context) ([]domain.Inventory, error) {
	rows, err := s.DB.QueryContext(ctx, inventorySelect+` JOIN agents a ON a.current_inventory_id=i.id ORDER BY i.hostname,a.name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.Inventory, 0)
	for rows.Next() {
		v, err := scanInventory(rows, false)
		if err != nil {
			return nil, err
		}
		out = append(out, v)
	}
	return out, rows.Err()
}

const (
	defaultHistoryPageSize = 20
	maxHistoryPageSize     = 100
)

type HistoryPage struct {
	Items    []domain.Inventory `json:"items"`
	Page     int                `json:"page"`
	PageSize int                `json:"page_size"`
	Total    int                `json:"total"`
	Pages    int                `json:"pages"`
}

func NormalizeHistoryPagination(page, pageSize int) (int, int) {
	if page < 1 {
		page = 1
	}
	if pageSize <= 0 {
		pageSize = defaultHistoryPageSize
	}
	if pageSize > maxHistoryPageSize {
		pageSize = maxHistoryPageSize
	}
	return page, pageSize
}

func (s Service) History(ctx context.Context, agentID int64, page, pageSize int) (HistoryPage, error) {
	page, pageSize = NormalizeHistoryPagination(page, pageSize)
	result := HistoryPage{Items: make([]domain.Inventory, 0), Page: page, PageSize: pageSize}
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM inventory_snapshots WHERE agent_id=?`, agentID).Scan(&result.Total); err != nil {
		return HistoryPage{}, err
	}
	if result.Total == 0 {
		return result, nil
	}
	result.Pages = (result.Total + result.PageSize - 1) / result.PageSize
	if result.Page > result.Pages {
		result.Page = result.Pages
	}
	offset := (result.Page - 1) * result.PageSize
	rows, err := s.DB.QueryContext(ctx, inventorySelect+` WHERE i.agent_id=? ORDER BY i.id DESC LIMIT ? OFFSET ?`, agentID, result.PageSize, offset)
	if err != nil {
		return HistoryPage{}, err
	}
	defer rows.Close()
	for rows.Next() {
		v, err := scanInventory(rows, false)
		if err != nil {
			return HistoryPage{}, err
		}
		result.Items = append(result.Items, v)
	}
	return result, rows.Err()
}
func (s Service) Get(ctx context.Context, id int64, raw bool) (domain.Inventory, error) {
	query := inventorySelect + ` WHERE i.id=?`
	v, err := scanInventory(s.DB.QueryRowContext(ctx, query, id), raw)
	if err != nil {
		return v, err
	}
	if raw {
		if err := s.DB.QueryRowContext(ctx, `SELECT raw_json FROM inventory_snapshots WHERE id=?`, id).Scan(&v.RawJSON); err != nil {
			return v, err
		}
	}
	return v, nil
}

const inventorySelect = `SELECT i.id,i.agent_id,i.collection_job_id,i.schema_version,i.agent_uuid,i.agent_version,i.hostname,i.fqdn,i.product_uuid,i.product_uuid_legacy,i.machine_id,i.os_name,i.os_version,i.primary_ip,i.boot_time,i.collector_total,i.collector_ok,i.collector_error,i.collector_timeout,i.payload_size,i.payload_sha256,i.changed_from_previous,i.collected_at,i.received_at FROM inventory_snapshots i`

type scanner interface{ Scan(dest ...any) error }

func scanInventory(s scanner, raw bool) (domain.Inventory, error) {
	var v domain.Inventory
	var boot, collected sql.NullTime
	err := s.Scan(&v.ID, &v.AgentID, &v.CollectionJobID, &v.SchemaVersion, &v.AgentUUID, &v.AgentVersion, &v.Hostname, &v.FQDN, &v.ProductUUID, &v.ProductUUIDLegacy, &v.MachineID, &v.OSName, &v.OSVersion, &v.PrimaryIP, &boot, &v.CollectorTotal, &v.CollectorOK, &v.CollectorError, &v.CollectorTimeout, &v.PayloadSize, &v.PayloadSHA256, &v.ChangedFromPrevious, &collected, &v.ReceivedAt)
	if err != nil {
		return v, err
	}
	if boot.Valid {
		t := boot.Time
		v.BootTime = &t
	}
	if collected.Valid {
		t := collected.Time
		v.CollectedAt = &t
	}
	return v, nil
}

func linkInventoryToVM(ctx context.Context, tx *sql.Tx, agentID, inventoryID int64, summary Summary) error {
	result, err := tx.ExecContext(ctx, `UPDATE virtual_machines SET current_inventory_id=?,guest_hostname=CASE WHEN guest_hostname='' THEN ? ELSE guest_hostname END,primary_ip=CASE WHEN primary_ip='' THEN ? ELSE primary_ip END WHERE agent_id=?`, inventoryID, firstNonEmpty(summary.FQDN, summary.Hostname), summary.PrimaryIP, agentID)
	if err != nil {
		return err
	}
	if rows, _ := result.RowsAffected(); rows > 0 {
		return nil
	}
	biosValues := uniqueNonEmpty(normalizeUUID(summary.ProductUUID), normalizeUUID(summary.ProductUUIDLegacy))
	var candidateIDs []int64
	if len(biosValues) > 0 {
		placeholders := strings.TrimRight(strings.Repeat("?,", len(biosValues)), ",")
		args := make([]any, len(biosValues))
		for i := range biosValues {
			args[i] = biosValues[i]
		}
		rows, err := tx.QueryContext(ctx, `SELECT id FROM virtual_machines WHERE bios_uuid_normalized IN (`+placeholders+`)`, args...)
		if err != nil {
			return err
		}
		for rows.Next() {
			var id int64
			if err := rows.Scan(&id); err != nil {
				rows.Close()
				return err
			}
			candidateIDs = append(candidateIDs, id)
		}
		rows.Close()
	}
	if len(candidateIDs) == 0 {
		names := uniqueNonEmpty(strings.ToLower(summary.Hostname), strings.ToLower(summary.FQDN))
		if len(names) > 0 {
			placeholders := strings.TrimRight(strings.Repeat("?,", len(names)), ",")
			args := make([]any, len(names))
			for i := range names {
				args[i] = names[i]
			}
			rows, err := tx.QueryContext(ctx, `SELECT id FROM virtual_machines WHERE LOWER(name) IN (`+placeholders+`) OR LOWER(guest_hostname) IN (`+placeholders+`)`, append(args, args...)...)
			if err != nil {
				return err
			}
			for rows.Next() {
				var id int64
				if err := rows.Scan(&id); err != nil {
					rows.Close()
					return err
				}
				candidateIDs = append(candidateIDs, id)
			}
			rows.Close()
		}
	}
	if len(candidateIDs) != 1 {
		return nil
	}
	vmID := candidateIDs[0]
	if _, err := tx.ExecContext(ctx, `UPDATE virtual_machines SET agent_id=NULL,current_inventory_id=NULL WHERE agent_id=? AND id<>?`, agentID, vmID); err != nil {
		return err
	}
	_, err = tx.ExecContext(ctx, `UPDATE virtual_machines SET agent_id=?,current_inventory_id=?,guest_hostname=CASE WHEN guest_hostname='' THEN ? ELSE guest_hostname END,primary_ip=CASE WHEN primary_ip='' THEN ? ELSE primary_ip END WHERE id=?`, agentID, inventoryID, firstNonEmpty(summary.FQDN, summary.Hostname), summary.PrimaryIP, vmID)
	return err
}

func normalizeUUID(value string) string {
	value = strings.ToLower(strings.TrimSpace(value))
	value = strings.Trim(value, "{}")
	return strings.ReplaceAll(value, " ", "")
}

func uniqueNonEmpty(values ...string) []string {
	seen := map[string]struct{}{}
	out := make([]string, 0, len(values))
	for _, value := range values {
		value = strings.TrimSpace(value)
		if value == "" {
			continue
		}
		if _, exists := seen[value]; exists {
			continue
		}
		seen[value] = struct{}{}
		out = append(out, value)
	}
	return out
}

func firstNonEmpty(values ...string) string {
	for _, value := range values {
		if strings.TrimSpace(value) != "" {
			return strings.TrimSpace(value)
		}
	}
	return ""
}

func firstStringAt(root map[string]any, paths ...[]string) string {
	for _, path := range paths {
		if v := valueAt(root, path...); v != nil {
			switch x := v.(type) {
			case string:
				if value := strings.TrimSpace(x); value != "" {
					return value
				}
			case json.Number:
				return x.String()
			case float64:
				return strconv.FormatFloat(x, 'f', -1, 64)
			}
		}
	}
	return ""
}

func firstValueAt(root map[string]any, paths ...[]string) any {
	for _, path := range paths {
		if v := valueAt(root, path...); v != nil {
			return v
		}
	}
	return nil
}

func valueAt(root map[string]any, path ...string) any {
	var current any = root
	for _, segment := range path {
		m, ok := current.(map[string]any)
		if !ok {
			return nil
		}
		current = mapValueFold(m, segment)
		if current == nil {
			return nil
		}
	}
	return current
}

func mapValueFold(m map[string]any, key string) any {
	if v, ok := m[key]; ok {
		return v
	}
	for candidate, v := range m {
		if strings.EqualFold(candidate, key) {
			return v
		}
	}
	return nil
}

func firstInventoryIP(root map[string]any) string {
	for _, path := range [][]string{
		{"primary_ip"}, {"network", "primary_ip"}, {"network", "default_ip"},
		{"identity", "primary_ip"}, {"host", "primary_ip"},
	} {
		if ip := usableIPString(valueAt(root, path...)); ip != "" {
			return ip
		}
	}
	for _, path := range [][]string{{"network", "interfaces"}, {"interfaces"}, {"network"}} {
		if ip := findUsableIP(valueAt(root, path...)); ip != "" {
			return ip
		}
	}
	return ""
}

func usableIPString(v any) string {
	s, ok := v.(string)
	if !ok {
		return ""
	}
	ip := net.ParseIP(strings.TrimSpace(strings.Split(s, "/")[0]))
	if ip == nil || ip.IsLoopback() || ip.IsLinkLocalUnicast() || ip.IsUnspecified() {
		return ""
	}
	return ip.String()
}

func findUsableIP(v any) string {
	var ipv6 string
	var walk func(any) string
	walk = func(current any) string {
		switch x := current.(type) {
		case string:
			ip := usableIPString(x)
			if ip == "" {
				return ""
			}
			if net.ParseIP(ip).To4() != nil {
				return ip
			}
			if ipv6 == "" {
				ipv6 = ip
			}
		case []any:
			for _, item := range x {
				if ip := walk(item); ip != "" {
					return ip
				}
			}
		case map[string]any:
			for _, preferred := range []string{"primary_ip", "ip", "address", "addresses", "ipv4"} {
				if item := mapValueFold(x, preferred); item != nil {
					if ip := walk(item); ip != "" {
						return ip
					}
				}
			}
			for _, item := range x {
				if ip := walk(item); ip != "" {
					return ip
				}
			}
		}
		return ""
	}
	if ip := walk(v); ip != "" {
		return ip
	}
	return ipv6
}

func parseTime(v any) (time.Time, bool) {
	switch x := v.(type) {
	case string:
		for _, layout := range []string{time.RFC3339Nano, time.RFC3339, "2006-01-02 15:04:05"} {
			if t, err := time.Parse(layout, x); err == nil {
				return t.UTC(), true
			}
		}
	case float64:
		return time.Unix(int64(x), 0).UTC(), true
	case json.Number:
		if n, err := x.Int64(); err == nil {
			return time.Unix(n, 0).UTC(), true
		}
	}
	return time.Time{}, false
}
func statusString(v any) string {
	switch x := v.(type) {
	case string:
		return x
	case map[string]any:
		for _, k := range []string{"status", "state", "result"} {
			if s, ok := x[k].(string); ok {
				return s
			}
		}
	}
	return fmt.Sprint(v)
}

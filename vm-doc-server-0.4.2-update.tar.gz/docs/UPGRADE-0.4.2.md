# Upgrade la vm-doc-server 0.4.2

Versiunea 0.4.2 corectează încărcarea inventarului curent în fișa VM.

## Cauza

Interogarea SQL conținea `WHERE i.id=?`, dar metoda `QueryRowContext` era apelată fără argumentul `id`. În configurațiile în care parametrul nu este interpolat de driver, MariaDB primea caracterul `?` și răspundea cu:

```text
Error 1064: ... right syntax to use near '?' at line 1
```

Fișa VM continua să se încarce degradat, afișând avertismentul că inventarul curent nu a putut fi încărcat.

## Corecție

Interogarea este apelată acum cu identificatorul snapshotului:

```go
s.DB.QueryRowContext(ctx, query, id)
```

Nu se schimbă JSON-ul agentului, schema inventarului sau baza de date. Nu este necesară recollectarea.

## Instalare

1. rulați `go test ./...`;
2. compilați cu `make build`;
3. opriți `vm-doc-collector` și `vm-doc-server`;
4. înlocuiți cele două binare;
5. porniți serverul, apoi collectorul;
6. reîncărcați fișa VM și verificați că inventarul curent este afișat.

## Rollback

Rollback-ul la 0.4.1 necesită doar restaurarea binarelor. Nu există migrare MariaDB în 0.4.2.

# vm-doc-agent 1.3.0

Agent Linux universal pentru colectarea inventarului local necesar fișei VM.
Versiunea 1.3.0 adaugă auto-update controlat de `vm-doc-server`, păstrând
colectarea inventarului o dată la 24 de ore și heartbeat-ul la 5 minute.

## Ce aduce 1.3.0

- auto-update controlat de serverul central, fără acces direct la GitHub;
- canale `stable` și `testing`;
- verificare SHA-256 și dimensiune înainte de instalare;
- verificarea versiunii executabilului descărcat înainte de înlocuire;
- helper separat `vm-doc-updater`, cu backup și rollback automat dacă noul agent nu trece `/health`;
- verificare periodică implicită la `6h`, cu instalare automată activată;
- API local nou: `GET /v1/update` și `POST /v1/update/check`;
- download-urile de update sunt acceptate numai de la aceeași origine ca `central.url`;
- `refresh_interval` rămâne `24h`, heartbeat `5m`;
- schema inventarului rămâne `2.0`.

## Funcții principale

- identitate persistentă `agent.id` și corelare prin UUID VMware/DMI;
- inventar JSON local și API HTTP protejat cu token Bearer;
- autoînregistrare outbound la serverul central;
- heartbeat periodic pentru starea online/offline;
- push automat al inventarului după fiecare colectare reușită;
- auto-update cu helper separat, validare SHA-256 și rollback;
- retry automat dacă serverul central nu este disponibil;
- compatibilitate cu systemd și SysV Init;
- binar static universal `linux/amd64`, `GOAMD64=v1`.

## Instalare nouă

```bash
tar -xzf vm-doc-agent-1.3.0-linux-amd64.tar.gz
cd vm-doc-agent-1.3.0-linux-amd64
sudo ./install.sh
```

Pachetul intern poate conține fișierul `central-registration-token`, iar
installerul îl copiază automat în:

```text
/etc/vm-doc-agent/central-registration-token
```

cu permisiuni `0600`.

Dacă pachetul nu conține tokenul, acesta poate fi furnizat la instalare:

```bash
sudo VM_DOC_CENTRAL_REGISTRATION_TOKEN='TOKEN' ./install.sh
```

## Configurare centrală implicită

```json
"central": {
  "enabled": true,
  "url": "http://172.20.1.20:9080",
  "registration_token_file": "/etc/vm-doc-agent/central-registration-token",
  "heartbeat_interval": "5m",
  "retry_interval": "1m",
  "request_timeout": "60s",
  "advertise_url": "",
  "ca_file": "",
  "tls_server_name": "",
  "insecure_skip_verify": false,
  "allow_http": true
}
```

`advertise_url` poate rămâne gol. Agentul folosește IP-ul interfeței cu ruta
implicită și portul din `listen`.

## Update manual

```bash
tar -xzf vm-doc-agent-1.3.0-linux-amd64.tar.gz
cd vm-doc-agent-1.3.0-linux-amd64
sudo ./update.sh
```

Updaterul păstrează configurația existentă, tokenul API local, `agent-id` și
inventarele existente. Pentru un agent 1.1.0 deja instalat, dacă `central` era
dezactivat, configurația existentă trebuie activată explicit; `update.sh` nu
suprascrie `config.json`.


## Auto-update

Configurația implicită este:

```json
"updates": {
  "enabled": true,
  "channel": "stable",
  "check_interval": "6h",
  "auto_install": true,
  "endpoint": "/api/v1/agent-updates/latest",
  "download_dir": "",
  "health_timeout": "45s",
  "max_download_bytes": 67108864
}
```

Un agent mai vechi de 1.3.0 trebuie actualizat manual **o singură dată** la 1.3.0.
După aceea, versiunile publicate de server pe canalul agentului pot fi instalate automat.

Verificare manuală:

```bash
TOKEN=$(sudo cat /etc/vm-doc-agent/token)
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/update
curl -X POST -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/update/check
```

## Verificare

```bash
/usr/local/sbin/vm-doc-agent -version
/usr/local/sbin/vm-doc-agent -config /etc/vm-doc-agent/config.json -check-config
sudo systemctl restart vm-doc-agent
sudo journalctl -u vm-doc-agent -n 100 --no-pager
```

În log trebuie să apară evenimentele:

```text
event=central_registered
event=central_inventory_pushed
```

## API local

```bash
curl http://127.0.0.1:9078/health
TOKEN=$(sudo cat /etc/vm-doc-agent/token)
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/status
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/inventory
```

## Build

```bash
./scripts/build.sh
CENTRAL_REGISTRATION_TOKEN='TOKEN' ./scripts/package.sh
./scripts/package-source.sh
```

**Important:** un pachet binar creat cu `CENTRAL_REGISTRATION_TOKEN` conține
secretul comun de bootstrap. Nu trebuie publicat într-un repository public.

Documentația detaliată se află în `docs/`.

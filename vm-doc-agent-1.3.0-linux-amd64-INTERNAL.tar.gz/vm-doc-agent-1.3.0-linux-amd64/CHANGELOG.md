# Changelog

## 1.3.0

### Adăugat

- auto-update centralizat prin `vm-doc-server`;
- canale `stable` / `testing`;
- verificare periodică implicită la `6h`;
- validare SHA-256, dimensiune și versiune pentru executabilele descărcate;
- helper separat `vm-doc-updater`;
- backup al binarului anterior și rollback automat dacă noua versiune nu trece health check-ul;
- endpoint-uri locale `GET /v1/update` și `POST /v1/update/check`;
- protecție same-origin pentru download-urile de update.

### Păstrat

- `refresh_interval=24h`;
- heartbeat central `5m`;
- schema inventarului `2.0`;
- central implicit `http://172.20.1.20:9080`, cu `allow_http=true`.

## 1.1.2

### Modificat

- `refresh_interval` implicit pentru instalările noi este `24h` în loc de `15m`;
- heartbeat-ul central rămâne la `5m`;
- refresh-ul manual continuă să declanșeze imediat colectarea și push-ul inventarului;
- configurația centrală implicită rămâne activă către `http://172.20.1.20:9080`, cu `allow_http=true`.

### Compatibilitate

- schema inventarului rămâne `2.0`;
- protocolul central rămâne versiunea `1`;
- `update.sh` păstrează configurația existentă, deci un agent deja instalat cu `15m` nu este schimbat automat la `24h`.

## 1.1.1

### Modificat

- autoînregistrarea este activată implicit pentru instalările noi;
- endpoint central implicit: `http://172.20.1.20:9080`;
- `central.allow_http=true` pentru profilul intern curent;
- installerul acceptă un token comun inclus în pachet sau furnizat prin `VM_DOC_CENTRAL_REGISTRATION_TOKEN`;
- pachetul intern poate instala automat `/etc/vm-doc-agent/central-registration-token` cu permisiuni `0600`.

### Compatibilitate

- schema inventarului rămâne `2.0`;
- protocolul central rămâne versiunea `1`;
- configurațiile existente sunt păstrate la update.

## 1.1.0

### Adăugat

- autoînregistrare la `vm-doc-server 0.2.2`;
- heartbeat periodic;
- push automat al inventarului după colectare;
- retry automat la indisponibilitatea serverului central;
- configurare TLS/CA și `advertise_url`;
- token de înregistrare separat de tokenul API local.

### Compatibilitate

- configurațiile 1.0.0 fără secțiunea `central` rămân valide;
- API-ul local și schema inventarului `2.0` nu se schimbă.


## 1.0.0

Prima versiune stabilă a agentului.

### Adăugat

- status individual pentru fiecare colector: `success`, `partial`, `timeout`, `error`, `disabled`;
- endpoint `GET /v1/status`;
- comenzi `-check-config`, `-collect-once`, `-print-inventory`, `-diagnostics`;
- activare/dezactivare individuală a colectoarelor;
- timeout global pentru colectoare și timeout separat pentru testarea output-urilor Beats;
- DNS, rute, gateway-uri, proxy, timezone, boot time și uptime;
- păstrarea atomică a `inventory.json.previous`;
- limite configurabile și metadata de truncare;
- loguri structurate și logrotate pentru SysV;
- documentație completă în `docs/`.

### Modificat

- schema JSON a trecut la `2.0`;
- installerul și updaterul validează configurația înainte de pornire;
- updaterul actualizează și fișierele de serviciu/logrotate;
- API-ul adaugă `Cache-Control: no-store` și jurnalizare cu status HTTP.

### Compatibilitate

Configurațiile 0.5.x fără câmpurile noi sunt acceptate și primesc valorile implicite din 1.0.0.

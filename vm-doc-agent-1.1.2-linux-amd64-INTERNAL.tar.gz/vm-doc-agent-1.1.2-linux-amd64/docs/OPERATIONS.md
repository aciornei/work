# Operațiuni și diagnostic

## Versiune

```bash
vm-doc-agent -version
```

## Validarea configurației

```bash
vm-doc-agent -config /etc/vm-doc-agent/config.json -check-config
```

## Colectare unică și salvare

```bash
vm-doc-agent -config /etc/vm-doc-agent/config.json -collect-once
```

## Colectare unică și afișare pe stdout

```bash
vm-doc-agent -config /etc/vm-doc-agent/config.json -print-inventory
```

## Diagnostic sigur

```bash
vm-doc-agent -config /etc/vm-doc-agent/config.json -diagnostics
```

Raportul de diagnostic conține configurația fără token, metadata fișierelor, identificarea hostului, statusul colectoarelor și avertismentele.

## Inventar curent și anterior

```text
/var/lib/vm-doc-agent/inventory.json
/var/lib/vm-doc-agent/inventory.json.previous
```

Fișierul anterior este actualizat numai dacă inventarul curent este JSON valid.

## Loguri

Systemd:

```bash
journalctl -u vm-doc-agent --since today
```

SysV:

```bash
tail -f /var/log/vm-doc-agent.log
```

Evenimentele includ `collection_started`, `collection_completed`, `http_request`, `unauthorized_request` și erorile de scriere.

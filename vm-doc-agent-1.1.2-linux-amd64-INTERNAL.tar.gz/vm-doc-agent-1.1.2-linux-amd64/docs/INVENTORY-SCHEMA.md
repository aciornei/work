# Schema inventarului

Versiunea schemei din 1.0.0 este:

```json
"schema_version": "2.0"
```

Versiunea schemei este separată de versiunea agentului.

## Structură principală

```text
schema_version
agent
collected_at
collection
host
os
system
storage
network
proxy
services
listening_ports
firewall
accounts
sssd
integrations
policies
cron
ntp
truncations
collection_warnings
```

## Statusul colectoarelor

```json
{
  "collection": {
    "status": "partial",
    "collectors": {
      "network": {
        "status": "success",
        "duration_ms": 4
      },
      "integrations": {
        "status": "partial",
        "warning_count": 1,
        "warnings": ["filebeat: output validation failed"]
      }
    }
  }
}
```

Valori posibile:

- `success`;
- `partial`;
- `timeout`;
- `error`;
- `disabled`.

## Truncare

Dacă o limită este atinsă:

```json
{
  "truncations": {
    "firewall.rules": {
      "detected": 14832,
      "returned": 10000,
      "limit": 10000,
      "reason": "configured item limit"
    }
  }
}
```

## Corelare

Câmpurile principale pentru vCenter și GLPI sunt:

```text
host.correlation.dmi_product_uuid
host.correlation.smbios_legacy_byte_order
host.correlation.machine_id
host.correlation.agent_id
```

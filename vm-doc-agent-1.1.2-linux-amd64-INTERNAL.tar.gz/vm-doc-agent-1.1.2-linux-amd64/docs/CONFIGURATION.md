# Configurație

Fișier implicit:

```text
/etc/vm-doc-agent/config.json
```

Configurație completă:

```json
{
  "listen": "0.0.0.0:9078",
  "output_file": "/var/lib/vm-doc-agent/inventory.json",
  "state_dir": "/var/lib/vm-doc-agent",
  "refresh_interval": "24h",
  "auth_token_file": "/etc/vm-doc-agent/token",
  "collector_timeout": "20s",
  "output_test_timeout": "12s",
  "collectors": {
    "system": true,
    "storage": true,
    "network": true,
    "proxy": true,
    "services": true,
    "listening_ports": true,
    "firewall": true,
    "accounts": true,
    "sssd": true,
    "integrations": true,
    "policies": true,
    "cron": true,
    "ntp": true
  },
  "limits": {
    "max_partitions": 1000,
    "max_routes": 5000,
    "max_services": 5000,
    "max_ports": 5000,
    "max_firewall_rules": 10000,
    "max_firewall_zones": 1000,
    "max_accounts": 10000,
    "max_cron_entries": 5000,
    "max_cron_scripts": 5000,
    "max_policy_files": 10000,
    "max_inventory_bytes": 20971520
  },
  "policy_paths": []
}
```

## Validare

```bash
/usr/local/sbin/vm-doc-agent \
  -config /etc/vm-doc-agent/config.json \
  -check-config
```

Câmpurile necunoscute produc eroare, pentru a evita greșelile de scriere.

## Dezactivarea unui colector

```json
"collectors": {
  "cron": false,
  "accounts": false
}
```

Un colector dezactivat apare în inventar cu status `disabled`.

## Politici organizaționale

```json
"policy_paths": [
  "/etc/company/policies/*",
  "/opt/company/policy-markers",
  "/etc/company/hardening.conf"
]
```

Agentul salvează metadata și SHA256, nu conținutul complet.

## Timeout-uri

- `collector_timeout`: timpul maxim acordat unui colector;
- `output_test_timeout`: timpul maxim pentru `filebeat test output` și `auditbeat test output`.

Dacă un colector depășește timeout-ul, restul colectării continuă.

## Conectarea la serverul central

```json
"central": {
  "enabled": true,
  "url": "http://172.20.1.20:9080",
  "registration_token_file": "/etc/vm-doc-agent/central-registration-token",
  "heartbeat_interval": "5m",
  "retry_interval": "1m",
  "request_timeout": "60s",
  "advertise_url": "",
  "ca_file": "/etc/vm-doc-agent/ca/central-ca.pem",
  "tls_server_name": "",
  "insecure_skip_verify": false,
  "allow_http": true
}
```

- `url`: adresa publicată de nodul central, fără calea API;
- `registration_token_file`: token comun, cu permisiuni `0600`;
- `heartbeat_interval`: cât de des este actualizată starea online;
- `retry_interval`: intervalul de retry după o eroare;
- `advertise_url`: URL-ul prin care serverul poate apela API-ul local; gol în mod normal;
- `ca_file`: CA PEM pentru PKI intern;
- `insecure_skip_verify`: doar pentru diagnostic temporar;
- `allow_http`: permite HTTP. În profilul intern 1.1.2 este activat pentru `172.20.1.20:9080`; traficul trebuie limitat la rețeaua de management.

## Cadența implicită în 1.1.2

În 1.1.2, valoarea implicită este `24h`: inventarul complet este recollectat o dată pe zi. Heartbeat-ul central (`5m`) este separat și continuă să indice starea online a agentului. Un refresh manual nu așteaptă intervalul de 24 de ore.

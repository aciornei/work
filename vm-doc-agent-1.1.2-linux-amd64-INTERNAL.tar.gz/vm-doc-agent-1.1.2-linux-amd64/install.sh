#!/bin/sh
set -eu

NAME=vm-doc-agent
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if [ -x "$SCRIPT_DIR/vm-doc-agent" ]; then BASE_DIR="$SCRIPT_DIR"; else BASE_DIR=$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd); fi
BINARY="$BASE_DIR/vm-doc-agent"
CONFIG_SOURCE="$BASE_DIR/config.json"
SYSTEMD_SOURCE="$BASE_DIR/packaging/systemd/vm-doc-agent.service"
SYSV_SOURCE="$BASE_DIR/packaging/sysv/vm-doc-agent"
LOGROTATE_SOURCE="$BASE_DIR/packaging/logrotate/vm-doc-agent"
CENTRAL_TOKEN_SOURCE="$BASE_DIR/central-registration-token"

[ "$(id -u)" -eq 0 ] || { echo "Run as root: sudo ./install.sh"; exit 1; }
[ -x "$BINARY" ] || { echo "Missing executable: $BINARY"; exit 1; }

install_file() {
    SRC=$1; DST=$2; MODE=$3
    if command -v install >/dev/null 2>&1; then install -m "$MODE" "$SRC" "$DST"; else cp "$SRC" "$DST"; chmod "$MODE" "$DST"; fi
}

detect_os() {
    if [ -r /etc/os-release ]; then sed -n 's/^ID=["'\'']*\([^"'\'']*\)["'\'']*$/\1/p' /etc/os-release | head -1
    elif [ -r /etc/SuSE-release ]; then echo sles
    elif [ -r /etc/redhat-release ]; then echo redhat
    elif [ -r /etc/debian_version ]; then echo debian
    else echo unknown; fi
}

detect_init() {
    if [ -d /run/systemd/system ] && command -v systemctl >/dev/null 2>&1; then echo systemd
    elif [ -d /etc/init.d ]; then echo sysv
    else echo unknown; fi
}

OS_ID=$(detect_os)
INIT_SYSTEM=$(detect_init)
echo "Detected OS: $OS_ID"
echo "Detected init system: $INIT_SYSTEM"

mkdir -p /usr/local/sbin /etc/$NAME /var/lib/$NAME
if [ -x /usr/local/sbin/$NAME ]; then cp /usr/local/sbin/$NAME /usr/local/sbin/${NAME}.previous; fi
install_file "$BINARY" /usr/local/sbin/$NAME 0755

if [ ! -f /etc/$NAME/config.json ]; then install_file "$CONFIG_SOURCE" /etc/$NAME/config.json 0640
else echo "Keeping existing configuration: /etc/$NAME/config.json"; fi

# Shared bootstrap token for central auto-registration.
# A token bundled in the internal release takes precedence so all newly installed
# agents use the same registration token. For source/public packages the token
# can instead be supplied through VM_DOC_CENTRAL_REGISTRATION_TOKEN.
if [ -r "$CENTRAL_TOKEN_SOURCE" ]; then
    install_file "$CENTRAL_TOKEN_SOURCE" /etc/$NAME/central-registration-token 0600
    echo "Installed central registration token from package."
elif [ -n "${VM_DOC_CENTRAL_REGISTRATION_TOKEN:-}" ]; then
    umask 077
    printf '%s' "$VM_DOC_CENTRAL_REGISTRATION_TOKEN" > /etc/$NAME/central-registration-token
    chmod 0600 /etc/$NAME/central-registration-token
    echo "Installed central registration token from environment."
elif grep -Eq '"enabled"[[:space:]]*:[[:space:]]*true' /etc/$NAME/config.json 2>/dev/null && [ ! -s /etc/$NAME/central-registration-token ]; then
    echo "Central is enabled, but /etc/$NAME/central-registration-token is missing." >&2
    echo "Provide the internal package token or set VM_DOC_CENTRAL_REGISTRATION_TOKEN." >&2
    exit 1
fi

/usr/local/sbin/$NAME -config /etc/$NAME/config.json -check-config >/dev/null

if [ -d /etc/logrotate.d ] && [ -r "$LOGROTATE_SOURCE" ]; then install_file "$LOGROTATE_SOURCE" /etc/logrotate.d/$NAME 0644; fi

case "$INIT_SYSTEM" in
    systemd)
        install_file "$SYSTEMD_SOURCE" /etc/systemd/system/$NAME.service 0644
        systemctl daemon-reload
        systemctl enable $NAME.service
        systemctl restart $NAME.service
        ;;
    sysv)
        install_file "$SYSV_SOURCE" /etc/init.d/$NAME 0755
        REGISTERED=0
        if command -v insserv >/dev/null 2>&1; then insserv $NAME && REGISTERED=1 || echo "Warning: insserv reported errors; verify autostart with chkconfig or rc*.d links."
        elif command -v chkconfig >/dev/null 2>&1; then chkconfig --add $NAME && chkconfig $NAME on && REGISTERED=1 || true
        elif command -v update-rc.d >/dev/null 2>&1; then update-rc.d $NAME defaults && REGISTERED=1 || true
        fi
        /etc/init.d/$NAME restart
        [ "$REGISTERED" -eq 1 ] || echo "Warning: service is running, but automatic startup could not be confirmed."
        ;;
    *)
        echo "Could not detect systemd or SysV init. Files were installed, but the service was not started."
        echo "Manual command: /usr/local/sbin/$NAME -config /etc/$NAME/config.json"
        exit 2
        ;;
esac

sleep 1
[ -r /etc/$NAME/token ] && chmod 0600 /etc/$NAME/token || true
[ -r /etc/$NAME/central-registration-token ] && chmod 0600 /etc/$NAME/central-registration-token || true
echo "Installed $NAME successfully."
echo "Health: curl http://127.0.0.1:9078/health"
echo "Status: curl -H \"Authorization: Bearer \$(cat /etc/$NAME/token)\" http://127.0.0.1:9078/v1/status"

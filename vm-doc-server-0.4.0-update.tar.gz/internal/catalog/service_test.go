package catalog

import "testing"

func TestNormalizeService(t *testing.T) {
	input := InternalServiceInput{Name: "  Metabase ", ServiceCode: " BI.METABASE ", Criticality: " HIGH ", DocumentationStatus: " IN_PROGRESS "}
	if err := normalizeService(&input); err != nil {
		t.Fatal(err)
	}
	if input.Name != "Metabase" || input.ServiceCode != "bi.metabase" || input.Criticality != "high" || input.DocumentationStatus != "in_progress" {
		t.Fatalf("unexpected normalization: %#v", input)
	}
}

func TestNormalizeServiceRejectsInvalidValues(t *testing.T) {
	tests := []InternalServiceInput{
		{},
		{Name: "X", Criticality: "urgent"},
		{Name: "X", DocumentationStatus: "done"},
		{Name: "X", ServiceCode: "BAD CODE"},
		{Name: "X", DocumentationURL: "file:///tmp/x"},
	}
	for i := range tests {
		if err := normalizeService(&tests[i]); err == nil {
			t.Fatalf("test %d: expected error", i)
		}
	}
}

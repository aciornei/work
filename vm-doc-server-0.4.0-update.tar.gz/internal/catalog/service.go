package catalog

import (
	"context"
	"database/sql"
	"errors"
	"net/url"
	"regexp"
	"sort"
	"strings"

	"vm-doc-server/internal/domain"
)

var codePattern = regexp.MustCompile(`^[a-z0-9][a-z0-9._-]{0,127}$`)

var criticalities = map[string]bool{"low": true, "normal": true, "high": true, "critical": true}
var documentationStatuses = map[string]bool{"draft": true, "in_progress": true, "review": true, "approved": true, "obsolete": true}

type Service struct{ DB *sql.DB }

type InternalServiceInput struct {
	// Păstrat numai pentru compatibilitatea cu file de browser mai vechi.
	// Începând cu 0.4.0, categoria se salvează pe asocierea VM–serviciu.
	ITILCategoryID      int64  `json:"itil_category_id,omitempty"`
	Name                string `json:"name"`
	ServiceCode         string `json:"service_code"`
	Description         string `json:"description"`
	Purpose             string `json:"purpose"`
	Criticality         string `json:"criticality"`
	DocumentationStatus string `json:"documentation_status"`
	DocumentationURL    string `json:"documentation_url"`
	Active              *bool  `json:"active,omitempty"`
}

func (s Service) List(ctx context.Context, includeInactive bool) ([]domain.InternalService, error) {
	query := serviceSelect()
	if !includeInactive {
		query += ` WHERE service.active=1`
	}
	query += ` ORDER BY service.name,service.id`
	rows, err := s.DB.QueryContext(ctx, query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	values := make([]domain.InternalService, 0)
	for rows.Next() {
		value, err := scanService(rows)
		if err != nil {
			return nil, err
		}
		values = append(values, value)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}

	classifications, err := s.listAllClassifications(ctx)
	if err != nil {
		return nil, err
	}
	mappings, err := s.listAllMappings(ctx)
	if err != nil {
		return nil, err
	}
	for i := range values {
		values[i].Classifications = classifications[values[i].ID]
		values[i].ClassificationCount = len(values[i].Classifications)
		values[i].RoleMappings = mappings[values[i].ID]
		applyClassificationCompatibility(&values[i])
	}
	sort.SliceStable(values, func(i, j int) bool {
		leftDomain, leftCategory := firstClassificationNames(values[i].Classifications)
		rightDomain, rightCategory := firstClassificationNames(values[j].Classifications)
		if leftDomain != rightDomain {
			if leftDomain == "" {
				return false
			}
			if rightDomain == "" {
				return true
			}
			return leftDomain < rightDomain
		}
		if leftCategory != rightCategory {
			return leftCategory < rightCategory
		}
		if values[i].Name != values[j].Name {
			return values[i].Name < values[j].Name
		}
		return values[i].ID < values[j].ID
	})
	return values, nil
}

func (s Service) Get(ctx context.Context, id int64) (domain.InternalService, error) {
	row := s.DB.QueryRowContext(ctx, serviceSelect()+` WHERE service.id=?`, id)
	value, err := scanService(row)
	if err != nil {
		return domain.InternalService{}, err
	}
	value.Classifications, err = s.ListClassifications(ctx, id)
	if err != nil {
		return domain.InternalService{}, err
	}
	value.ClassificationCount = len(value.Classifications)
	applyClassificationCompatibility(&value)
	value.RoleMappings, err = s.ListRoleMappings(ctx, id)
	if err != nil {
		return domain.InternalService{}, err
	}
	value.VMs, err = s.ListVMs(ctx, id)
	return value, err
}

func (s Service) Create(ctx context.Context, userID int64, input InternalServiceInput) (domain.InternalService, error) {
	if err := normalizeService(&input); err != nil {
		return domain.InternalService{}, err
	}
	legacyCategoryID, err := s.defaultCategoryID(ctx)
	if err != nil {
		return domain.InternalService{}, err
	}
	active := true
	if input.Active != nil {
		active = *input.Active
	}
	result, err := s.DB.ExecContext(ctx, `INSERT INTO internal_services(itil_category_id,name,service_code,description,purpose,criticality,documentation_status,documentation_url,active,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?,?,?,?)`, legacyCategoryID, input.Name, nullableCode(input.ServiceCode), input.Description, input.Purpose, input.Criticality, input.DocumentationStatus, input.DocumentationURL, active, userID, userID)
	if err != nil {
		return domain.InternalService{}, err
	}
	id, _ := result.LastInsertId()
	return s.Get(ctx, id)
}

func (s Service) Update(ctx context.Context, id, userID int64, input InternalServiceInput) (domain.InternalService, error) {
	current, err := s.Get(ctx, id)
	if err != nil {
		return domain.InternalService{}, err
	}
	if strings.TrimSpace(input.Name) == "" {
		input.Name = current.Name
	}
	if input.Active == nil {
		active := current.Active
		input.Active = &active
	}
	if err := normalizeService(&input); err != nil {
		return domain.InternalService{}, err
	}
	_, err = s.DB.ExecContext(ctx, `UPDATE internal_services SET name=?,service_code=?,description=?,purpose=?,criticality=?,documentation_status=?,documentation_url=?,active=?,updated_by=? WHERE id=?`, input.Name, nullableCode(input.ServiceCode), input.Description, input.Purpose, input.Criticality, input.DocumentationStatus, input.DocumentationURL, *input.Active, userID, id)
	if err != nil {
		return domain.InternalService{}, err
	}
	return s.Get(ctx, id)
}

func (s Service) ListClassifications(ctx context.Context, serviceID int64) ([]domain.InternalServiceClassification, error) {
	rows, err := s.DB.QueryContext(ctx, classificationSelect()+` WHERE assignment.internal_service_id=? GROUP BY assignment.architectural_domain_id,domain_item.name,domain_item.sort_order,assignment.itil_category_id,category_item.name,category_item.sort_order ORDER BY domain_item.sort_order,domain_item.name,category_item.sort_order,category_item.name`, serviceID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.InternalServiceClassification, 0)
	for rows.Next() {
		var value domain.InternalServiceClassification
		if err := rows.Scan(&value.ArchitecturalDomainID, &value.ArchitecturalDomain, &value.ITILCategoryID, &value.ITILCategory, &value.VMCount, &value.AssignmentCount); err != nil {
			return nil, err
		}
		out = append(out, value)
	}
	return out, rows.Err()
}

func (s Service) listAllClassifications(ctx context.Context) (map[int64][]domain.InternalServiceClassification, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT assignment.internal_service_id,`+classificationSelectColumns()+`
		FROM vm_internal_service_assignments assignment
		JOIN nomenclature_items domain_item ON domain_item.id=assignment.architectural_domain_id AND domain_item.category_code='architectural_domain'
		JOIN nomenclature_items category_item ON category_item.id=assignment.itil_category_id AND category_item.category_code='itil_category'
		GROUP BY assignment.internal_service_id,assignment.architectural_domain_id,domain_item.name,domain_item.sort_order,assignment.itil_category_id,category_item.name,category_item.sort_order
		ORDER BY assignment.internal_service_id,domain_item.sort_order,domain_item.name,category_item.sort_order,category_item.name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make(map[int64][]domain.InternalServiceClassification)
	for rows.Next() {
		var serviceID int64
		var value domain.InternalServiceClassification
		if err := rows.Scan(&serviceID, &value.ArchitecturalDomainID, &value.ArchitecturalDomain, &value.ITILCategoryID, &value.ITILCategory, &value.VMCount, &value.AssignmentCount); err != nil {
			return nil, err
		}
		out[serviceID] = append(out[serviceID], value)
	}
	return out, rows.Err()
}

func classificationSelect() string {
	return `SELECT ` + classificationSelectColumns() + `
		FROM vm_internal_service_assignments assignment
		JOIN nomenclature_items domain_item ON domain_item.id=assignment.architectural_domain_id AND domain_item.category_code='architectural_domain'
		JOIN nomenclature_items category_item ON category_item.id=assignment.itil_category_id AND category_item.category_code='itil_category'`
}

func classificationSelectColumns() string {
	return `assignment.architectural_domain_id,domain_item.name,assignment.itil_category_id,category_item.name,COUNT(DISTINCT assignment.vm_id),COUNT(*)`
}

func (s Service) ListRoleMappings(ctx context.Context, serviceID int64) ([]domain.ServiceRoleMapping, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT 0,assignment.layer_id,layer_item.name,assignment.technical_role_id,role_item.name,role_item.sort_order,
		CASE WHEN layer_item.active=1 AND role_item.active=1 THEN 1 ELSE 0 END,COUNT(DISTINCT assignment.vm_id)
		FROM vm_internal_service_assignments assignment
		JOIN nomenclature_items layer_item ON layer_item.id=assignment.layer_id AND layer_item.category_code='layer'
		JOIN nomenclature_items role_item ON role_item.id=assignment.technical_role_id AND role_item.category_code='technical_role'
		WHERE assignment.internal_service_id=?
		GROUP BY assignment.layer_id,layer_item.name,layer_item.sort_order,layer_item.active,assignment.technical_role_id,role_item.name,role_item.sort_order,role_item.active
		ORDER BY layer_item.sort_order,layer_item.name,role_item.sort_order,role_item.name`, serviceID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.ServiceRoleMapping, 0)
	for rows.Next() {
		var value domain.ServiceRoleMapping
		if err := rows.Scan(&value.ID, &value.LayerID, &value.LayerName, &value.TechnicalRoleID, &value.TechnicalRole, &value.SortOrder, &value.Active, &value.VMCount); err != nil {
			return nil, err
		}
		out = append(out, value)
	}
	return out, rows.Err()
}

func (s Service) listAllMappings(ctx context.Context) (map[int64][]domain.ServiceRoleMapping, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT assignment.internal_service_id,0,assignment.layer_id,layer_item.name,assignment.technical_role_id,role_item.name,role_item.sort_order,
		CASE WHEN layer_item.active=1 AND role_item.active=1 THEN 1 ELSE 0 END,COUNT(DISTINCT assignment.vm_id)
		FROM vm_internal_service_assignments assignment
		JOIN nomenclature_items layer_item ON layer_item.id=assignment.layer_id AND layer_item.category_code='layer'
		JOIN nomenclature_items role_item ON role_item.id=assignment.technical_role_id AND role_item.category_code='technical_role'
		GROUP BY assignment.internal_service_id,assignment.layer_id,layer_item.name,layer_item.sort_order,layer_item.active,assignment.technical_role_id,role_item.name,role_item.sort_order,role_item.active
		ORDER BY assignment.internal_service_id,layer_item.sort_order,layer_item.name,role_item.sort_order,role_item.name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make(map[int64][]domain.ServiceRoleMapping)
	for rows.Next() {
		var serviceID int64
		var value domain.ServiceRoleMapping
		if err := rows.Scan(&serviceID, &value.ID, &value.LayerID, &value.LayerName, &value.TechnicalRoleID, &value.TechnicalRole, &value.SortOrder, &value.Active, &value.VMCount); err != nil {
			return nil, err
		}
		out[serviceID] = append(out[serviceID], value)
	}
	return out, rows.Err()
}

func (s Service) ListVMs(ctx context.Context, serviceID int64) ([]domain.InternalServiceVM, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT assignment.id,vm.id,vm.name,vm.power_state,COALESCE(NULLIF(inventory.hostname,''),vm.guest_hostname),COALESCE(NULLIF(inventory.primary_ip,''),vm.primary_ip),assignment.architectural_domain_id,domain_item.name,assignment.itil_category_id,category_item.name,assignment.layer_id,COALESCE(layer_item.name,''),assignment.technical_role_id,COALESCE(role_item.name,''),assignment.usage_type,assignment.is_primary,assignment.notes
		FROM vm_internal_service_assignments assignment
		JOIN virtual_machines vm ON vm.id=assignment.vm_id
		LEFT JOIN inventory_snapshots inventory ON inventory.id=vm.current_inventory_id
		JOIN nomenclature_items domain_item ON domain_item.id=assignment.architectural_domain_id AND domain_item.category_code='architectural_domain'
		JOIN nomenclature_items category_item ON category_item.id=assignment.itil_category_id AND category_item.category_code='itil_category'
		LEFT JOIN nomenclature_items layer_item ON layer_item.id=assignment.layer_id
		LEFT JOIN nomenclature_items role_item ON role_item.id=assignment.technical_role_id
		WHERE assignment.internal_service_id=?
		ORDER BY domain_item.sort_order,domain_item.name,category_item.sort_order,category_item.name,vm.name,assignment.is_primary DESC,assignment.sort_order,layer_item.name,role_item.name`, serviceID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]domain.InternalServiceVM, 0)
	for rows.Next() {
		var value domain.InternalServiceVM
		var layerID, roleID sql.NullInt64
		if err := rows.Scan(&value.AssignmentID, &value.ID, &value.Name, &value.PowerState, &value.GuestHostname, &value.PrimaryIP, &value.ArchitecturalDomainID, &value.ArchitecturalDomain, &value.ITILCategoryID, &value.ITILCategory, &layerID, &value.LayerName, &roleID, &value.TechnicalRole, &value.UsageType, &value.Primary, &value.Notes); err != nil {
			return nil, err
		}
		if layerID.Valid {
			id := layerID.Int64
			value.LayerID = &id
		}
		if roleID.Valid {
			id := roleID.Int64
			value.TechnicalRoleID = &id
		}
		out = append(out, value)
	}
	return out, rows.Err()
}

func (s Service) defaultCategoryID(ctx context.Context) (int64, error) {
	var id int64
	err := s.DB.QueryRowContext(ctx, `SELECT id FROM nomenclature_items WHERE category_code='itil_category' AND name='Necategorizat' ORDER BY id LIMIT 1`).Scan(&id)
	if errors.Is(err, sql.ErrNoRows) {
		return 0, errors.New("missing uncategorized ITIL category")
	}
	return id, err
}

func serviceSelect() string {
	return `SELECT service.id,service.itil_category_id,COALESCE(legacy_category.name,''),service.name,service.service_code,service.description,service.purpose,service.criticality,service.documentation_status,service.documentation_url,service.active,
		(SELECT COUNT(DISTINCT assignment.vm_id) FROM vm_internal_service_assignments assignment WHERE assignment.internal_service_id=service.id),
		(SELECT COUNT(DISTINCT assignment.architectural_domain_id,assignment.itil_category_id) FROM vm_internal_service_assignments assignment WHERE assignment.internal_service_id=service.id),
		(SELECT COUNT(DISTINCT assignment.layer_id,assignment.technical_role_id) FROM vm_internal_service_assignments assignment WHERE assignment.internal_service_id=service.id AND assignment.layer_id IS NOT NULL AND assignment.technical_role_id IS NOT NULL),
		service.created_at,service.updated_at
		FROM internal_services service
		LEFT JOIN nomenclature_items legacy_category ON legacy_category.id=service.itil_category_id`
}

type rowScanner interface{ Scan(dest ...any) error }

func scanService(row rowScanner) (domain.InternalService, error) {
	var value domain.InternalService
	var serviceCode sql.NullString
	err := row.Scan(&value.ID, &value.ITILCategoryID, &value.ITILCategory, &value.Name, &serviceCode, &value.Description, &value.Purpose, &value.Criticality, &value.DocumentationStatus, &value.DocumentationURL, &value.Active, &value.VMCount, &value.ClassificationCount, &value.RoleMappingCount, &value.CreatedAt, &value.UpdatedAt)
	if serviceCode.Valid {
		value.ServiceCode = serviceCode.String
	}
	return value, err
}

func applyClassificationCompatibility(value *domain.InternalService) {
	value.ArchitecturalDomainID = nil
	value.ArchitecturalDomain = ""
	value.ITILCategoryID = 0
	value.ITILCategory = ""
	if len(value.Classifications) != 1 {
		return
	}
	classification := value.Classifications[0]
	domainID := classification.ArchitecturalDomainID
	value.ArchitecturalDomainID = &domainID
	value.ArchitecturalDomain = classification.ArchitecturalDomain
	value.ITILCategoryID = classification.ITILCategoryID
	value.ITILCategory = classification.ITILCategory
}

func firstClassificationNames(values []domain.InternalServiceClassification) (string, string) {
	if len(values) == 0 {
		return "", ""
	}
	return strings.ToLower(values[0].ArchitecturalDomain), strings.ToLower(values[0].ITILCategory)
}

func normalizeService(input *InternalServiceInput) error {
	input.Name = strings.TrimSpace(input.Name)
	input.ServiceCode = strings.ToLower(strings.TrimSpace(input.ServiceCode))
	input.Description = strings.TrimSpace(input.Description)
	input.Purpose = strings.TrimSpace(input.Purpose)
	input.Criticality = strings.ToLower(strings.TrimSpace(input.Criticality))
	input.DocumentationStatus = strings.ToLower(strings.TrimSpace(input.DocumentationStatus))
	input.DocumentationURL = strings.TrimSpace(input.DocumentationURL)
	if input.Name == "" {
		return errors.New("name is required")
	}
	if input.Criticality == "" {
		input.Criticality = "normal"
	}
	if input.DocumentationStatus == "" {
		input.DocumentationStatus = "draft"
	}
	if !criticalities[input.Criticality] {
		return errors.New("invalid criticality")
	}
	if !documentationStatuses[input.DocumentationStatus] {
		return errors.New("invalid documentation_status")
	}
	if input.ServiceCode != "" && !codePattern.MatchString(input.ServiceCode) {
		return errors.New("service_code is invalid")
	}
	if len([]rune(input.Name)) > 255 || len([]rune(input.ServiceCode)) > 128 || len([]rune(input.Description)) > 10000 || len([]rune(input.Purpose)) > 10000 || len([]rune(input.DocumentationURL)) > 1024 {
		return errors.New("internal service values must not exceed the allowed length")
	}
	if input.DocumentationURL != "" {
		parsed, err := url.ParseRequestURI(input.DocumentationURL)
		if err != nil || (parsed.Scheme != "http" && parsed.Scheme != "https") || parsed.Host == "" {
			return errors.New("documentation_url must be an absolute HTTP or HTTPS URL")
		}
	}
	return nil
}

func nullableCode(value string) any {
	if value == "" {
		return nil
	}
	return value
}

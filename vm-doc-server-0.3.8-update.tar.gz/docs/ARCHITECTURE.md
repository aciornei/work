# Architecture 0.3.8

## Surse de adevăr

- **vCenter**: existența VM-ului, MoID, UUID, power state și resurse;
- **vm-doc-agent**: sistem de operare, rețea, servicii, politici și integrări;
- **vm-doc-server**: încadrare operațională, catalog de servicii, responsabilități, asocieri și istoric.

## Relația VM–serviciu

Relația este multiplă. Un VM poate deservi mai multe servicii interne, iar pentru același serviciu poate avea mai multe combinații `Layer arhitectural → Rol tehnic`.

```text
VM
 ├─ Serviciu intern A → Layer aplicație → Rol aplicație
 ├─ Serviciu intern A → Layer bază de date → Rol PostgreSQL
 └─ Serviciu intern B → Layer cache → Rol Redis
```

Fiecare asociere poate fi `dedicated`, `shared` sau `dependency`, poate avea observații și cel mult una poate fi marcată principală pentru VM.

## Relația Layer–Rol tehnic

Relația globală `layer_technical_role_mappings` stabilește layer-ele în care poate fi folosit un rol tehnic. Perechea se selectează direct în asocierea VM–serviciu; serviciul intern nu mai are o listă proprie de perechi permise.

```text
Layer → Rol tehnic
          ↑
VM → Serviciu intern
```

În interfața VM, domeniul filtrează serviciile, iar layer-ul filtrează rolurile. Domeniul este dedus din categoria ITIL a serviciului și nu este duplicat în asociere. Un rol poate aparține mai multor layer-e, dar fiecare asociere păstrează perechea exactă layer–rol.

Pagina serviciului intern este o vedere agregată: layer-ele, rolurile și numărul de VM-uri apar automat din `vm_internal_service_assignments`.

## Procese

`vm-doc-server` deservește browserul/API-ul și execută schedulerul vCenter. `vm-doc-collector` este singurul proces care contactează agenții.

## Sincronizare vCenter

Rulările sunt persistate în `vcenter_sync_runs`. Un named lock MariaDB previne procesarea simultană a aceleiași surse. Operația este asincronă față de cererea HTTP.

## Coada agenților

Joburile sunt stocate în `collection_jobs`. Un worker revendică un job prin lease. Un job rămas `running` poate fi revendicat după expirarea lease-ului.

## Inventar și corelare

Fiecare colectare reușită produce un rând în `inventory_snapshots`. JSON-ul original este păstrat, iar câmpurile de identificare sunt extrase pentru corelare. SHA-256 identifică schimbările fără pierderea istoricului.

## Frontend

Frontendul este HTML/CSS/JavaScript fără Node.js și este inclus în binarul Go cu `go:embed`.

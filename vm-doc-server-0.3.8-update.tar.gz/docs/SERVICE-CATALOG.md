# Catalogul serviciilor interne

## Scop

Catalogul separă clasificarea ITIL de serviciul tehnic documentat. Un serviciu intern, de exemplu `Metabase`, este obiectul pentru care va fi generată documentația completă. VM-urile asociate sunt incluse ulterior ca fișe sau referințe în anexele documentului.

## Ierarhie

```text
Domeniu arhitectural
  → Categorie ITIL
    → Serviciu intern

Layer arhitectural
  → Roluri tehnice permise

VM
  → Domeniu (filtru în interfață)
    → Serviciu intern
      → Layer
        → Rol tehnic
```

## Reguli

- fiecare categorie ITIL are exact un domeniu arhitectural părinte;
- fiecare serviciu intern aparține unei categorii ITIL;
- fiecare rol tehnic aparține unuia sau mai multor layer-e;
- un VM poate fi asociat cu mai multe servicii interne;
- același serviciu poate apărea de mai multe ori pe același VM, cu layer și rol diferite;
- combinația `VM + serviciu + layer + rol` este unică;
- cel mult o asociere a VM-ului poate fi marcată principală;
- backendul validează faptul că serviciul există și că rolul este permis global în layer-ul selectat, nu doar interfața browserului.

Această validare împiedică alegerea `Solr` în layer-ul `Bază de date`. Serviciul intern nu restricționează suplimentar perechea: funcția concretă a VM-ului este stabilită în asocierea VM–serviciu.

## Selecția pe fișa VM

```text
Alegi domeniul
  → apar serviciile din domeniu
    → alegi layer-ul
      → apar numai rolurile permise în acel layer
```

Domeniul este utilizat pentru filtrare și este dedus din serviciul intern. În baza de date, asocierea păstrează `service_id`, `layer_id` și `technical_role_id`, evitând duplicarea domeniului.

## Exemple

```text
metabase-allinone-01
  Metabase → Aplicație → Metabase Application [principal, dedicat]
  Metabase → Bază de date → PostgreSQL [dedicat]
  Metabase → Stocare → File storage [dedicat]
```

```text
shared-redis-01
  Nextcloud → Cache și sesiuni → Redis [partajat]
  Roundcube → Cache și sesiuni → Redis Sessions [partajat]
  Airflow → Mesagerie și transport → Redis Broker [partajat]
```

## Meniul Servicii

Pentru fiecare serviciu intern se administrează:

- denumirea și codul intern;
- domeniul și categoria ITIL;
- descrierea și scopul;
- criticitatea și starea documentației;
- linkul către documentația existentă.

Pagina serviciului afișează automat, fără configurare separată:

- toate VM-urile asociate;
- layer-ele și rolurile tehnice observate;
- numărul de VM-uri pentru fiecare pereche layer–rol;
- tipul de utilizare și marcajul principal al fiecărei asocieri.

## Documentația viitoare

Unitatea de documentare va fi serviciul intern. Un VM partajat poate fi referit de mai multe servicii, fără duplicarea sursei sale de adevăr.

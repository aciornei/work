package nomenclature

import (
	"testing"

	"vm-doc-server/internal/domain"
)

func TestNormalizeItem(t *testing.T) {
	parentID := int64(7)
	input := ItemInput{CategoryCode: " ITIL_CATEGORY ", Name: "  Mail  ", ItemCode: " MAIL.PROD ", Description: " test ", ParentID: &parentID}
	if err := normalizeItem(&input); err != nil {
		t.Fatal(err)
	}
	if input.CategoryCode != "itil_category" || input.Name != "Mail" || input.ItemCode != "mail.prod" {
		t.Fatalf("unexpected normalized input: %#v", input)
	}
}

func TestNormalizeItemRejectsLegacyAndUnknownCategories(t *testing.T) {
	for _, category := range []string{"service", "component", "unknown"} {
		if err := normalizeItem(&ItemInput{CategoryCode: category, Name: "X"}); err == nil {
			t.Fatalf("expected invalid category for %q", category)
		}
	}
}

func TestNormalizePerson(t *testing.T) {
	input := PersonInput{DisplayName: "  Ion Popescu ", Email: "ION@EXAMPLE.TEST"}
	if err := normalizePerson(&input); err != nil {
		t.Fatal(err)
	}
	if input.DisplayName != "Ion Popescu" || input.Email != "ion@example.test" {
		t.Fatalf("unexpected normalized person: %#v", input)
	}
}

func TestNormalizeItemTechnicalRoleLayers(t *testing.T) {
	input := ItemInput{CategoryCode: "technical_role", Name: " PostgreSQL ", LayerIDs: []int64{9, 3, 9}}
	if err := normalizeItem(&input); err != nil {
		t.Fatal(err)
	}
	if len(input.LayerIDs) != 2 || input.LayerIDs[0] != 3 || input.LayerIDs[1] != 9 {
		t.Fatalf("unexpected layer ids: %#v", input.LayerIDs)
	}
}

func TestNormalizeLayerIDsRejectsInvalidValue(t *testing.T) {
	if _, err := normalizeLayerIDs([]int64{1, 0}); err == nil {
		t.Fatal("expected invalid layer identifier")
	}
}

func TestSortTechnicalRolesByLayerThenRoleOrder(t *testing.T) {
	categories := []domain.NomenclatureCategory{
		{Code: "layer", Items: []domain.NomenclatureValue{{ID: 10, Name: "Acces", SortOrder: 10}, {ID: 20, Name: "Aplicație", SortOrder: 20}}},
		{Code: "technical_role", Items: []domain.NomenclatureValue{
			{ID: 3, Name: "Server aplicație", SortOrder: 20, LayerIDs: []int64{20}},
			{ID: 2, Name: "Load balancer", SortOrder: 20, LayerIDs: []int64{10}},
			{ID: 1, Name: "Reverse proxy", SortOrder: 10, LayerIDs: []int64{10}},
		}},
	}
	sortTechnicalRoles(categories, 1)
	got := categories[1].Items
	if len(got) != 3 || got[0].ID != 1 || got[1].ID != 2 || got[2].ID != 3 {
		t.Fatalf("unexpected role order: %#v", got)
	}
}

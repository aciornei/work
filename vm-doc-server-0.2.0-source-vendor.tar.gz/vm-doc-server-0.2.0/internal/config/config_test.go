package config

import (
	"strings"
	"testing"
	"time"
)

func validConfigForTest() Config {
	cfg := Config{
		Version:   1,
		App:       AppConfig{Environment: "test", Timezone: "Europe/Bucharest"},
		Database:  DatabaseConfig{Host: "db", Name: "vm_doc", User: "vm_doc"},
		Secrets:   SecretsConfig{EncryptedFile: "/tmp/secrets", MasterKeyEnv: "TEST_KEY"},
		Session:   SessionConfig{IdleTimeout: Duration(time.Minute), AbsoluteTimeout: Duration(time.Hour)},
		Auth:      AuthConfig{Dev: DevConfig{Enabled: true}},
		Collector: CollectorConfig{Workers: 1},
		VCenter:   VCenterConfig{RequestTimeout: Duration(time.Minute), DetailWorkers: 4, SchedulerInterval: Duration(time.Minute)},
		OpenAPI:   OpenAPIConfig{SwaggerPath: "/docs/"},
	}
	return cfg
}

func TestValidateVCenterSchedulerAndTimezone(t *testing.T) {
	cfg := validConfigForTest()
	if err := cfg.Validate(); err != nil {
		t.Fatalf("valid config: %v", err)
	}
	cfg.App.Timezone = "Invalid/Timezone"
	cfg.VCenter.SchedulerInterval = Duration(-time.Second)
	err := cfg.Validate()
	if err == nil || !strings.Contains(err.Error(), "invalid app.timezone") || !strings.Contains(err.Error(), "scheduler_interval") {
		t.Fatalf("unexpected validation error: %v", err)
	}
}

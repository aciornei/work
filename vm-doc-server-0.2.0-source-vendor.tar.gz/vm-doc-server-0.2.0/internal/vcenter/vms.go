package vcenter

import (
	"context"
	"database/sql"
	"errors"
	"strings"
	"time"

	"vm-doc-server/internal/domain"
)

func (s *Service) ListVMs(ctx context.Context) ([]domain.VirtualMachine, error) {
	rows, err := s.DB.QueryContext(ctx, vmSelect+` ORDER BY vm.retired,vm.present_in_vcenter DESC,vm.name`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []domain.VirtualMachine
	for rows.Next() {
		vm, err := scanVM(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, vm)
	}
	return out, rows.Err()
}

func (s *Service) GetVM(ctx context.Context, id int64) (domain.VirtualMachine, error) {
	return scanVM(s.DB.QueryRowContext(ctx, vmSelect+` WHERE vm.id=?`, id))
}

func (s *Service) UpdateVM(ctx context.Context, id int64, in VMUpdate, userID int64) (domain.VirtualMachine, error) {
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return domain.VirtualMachine{}, err
	}
	defer tx.Rollback()
	var exists int
	if err := tx.QueryRowContext(ctx, `SELECT 1 FROM virtual_machines WHERE id=? FOR UPDATE`, id).Scan(&exists); err != nil {
		return domain.VirtualMachine{}, err
	}
	if in.Retired != nil {
		if *in.Retired {
			_, err = tx.ExecContext(ctx, `UPDATE virtual_machines SET retired=1,retired_at=COALESCE(retired_at,?),retired_by=?,retired_note=? WHERE id=?`, time.Now().UTC(), userID, strings.TrimSpace(in.RetiredNote), id)
		} else {
			_, err = tx.ExecContext(ctx, `UPDATE virtual_machines SET retired=0,retired_at=NULL,retired_by=NULL,retired_note=? WHERE id=?`, strings.TrimSpace(in.RetiredNote), id)
		}
		if err != nil {
			return domain.VirtualMachine{}, err
		}
	} else if in.RetiredNote != "" {
		if _, err := tx.ExecContext(ctx, `UPDATE virtual_machines SET retired_note=? WHERE id=?`, strings.TrimSpace(in.RetiredNote), id); err != nil {
			return domain.VirtualMachine{}, err
		}
	}
	if in.ClearAgent {
		if _, err := tx.ExecContext(ctx, `UPDATE virtual_machines SET agent_id=NULL,current_inventory_id=NULL WHERE id=?`, id); err != nil {
			return domain.VirtualMachine{}, err
		}
	}
	if in.AgentID != nil {
		if *in.AgentID <= 0 {
			return domain.VirtualMachine{}, errors.New("invalid agent_id")
		}
		var currentInventory sql.NullInt64
		if err := tx.QueryRowContext(ctx, `SELECT current_inventory_id FROM agents WHERE id=?`, *in.AgentID).Scan(&currentInventory); err != nil {
			return domain.VirtualMachine{}, err
		}
		if _, err := tx.ExecContext(ctx, `UPDATE virtual_machines SET agent_id=NULL,current_inventory_id=NULL WHERE agent_id=? AND id<>?`, *in.AgentID, id); err != nil {
			return domain.VirtualMachine{}, err
		}
		if _, err := tx.ExecContext(ctx, `UPDATE virtual_machines SET agent_id=?,current_inventory_id=? WHERE id=?`, *in.AgentID, nullableInt64(currentInventory), id); err != nil {
			return domain.VirtualMachine{}, err
		}
	}
	if err := tx.Commit(); err != nil {
		return domain.VirtualMachine{}, err
	}
	return s.GetVM(ctx, id)
}

const vmSelect = `SELECT
 vm.id,vm.vcenter_source_id,src.name,vm.vcenter_moid,vm.instance_uuid,vm.bios_uuid,vm.name,vm.power_state,vm.cpu_count,vm.memory_mib,vm.hardware_version,vm.guest_os,vm.guest_hostname,vm.primary_ip,vm.custom_attributes_json,
 vm.retired,vm.retired_at,vm.retired_by,vm.retired_note,vm.present_in_vcenter,vm.first_seen_at,vm.last_seen_at,vm.missing_since,vm.last_vcenter_sync_at,
 vm.agent_id,a.name,a.enabled,a.offline_after_seconds,a.last_contact_at,a.last_success_at,a.last_error,vm.current_inventory_id,
 i.hostname,i.os_name,i.os_version,i.primary_ip,i.received_at,vm.created_at,vm.updated_at
 FROM virtual_machines vm
 JOIN vcenter_sources src ON src.id=vm.vcenter_source_id
 LEFT JOIN agents a ON a.id=vm.agent_id
 LEFT JOIN inventory_snapshots i ON i.id=vm.current_inventory_id`

func scanVM(scanner interface{ Scan(...any) error }) (domain.VirtualMachine, error) {
	var vm domain.VirtualMachine
	var retiredAt, missingSince, lastVCenter, agentContact, agentSuccess, inventoryReceived sql.NullTime
	var retiredBy, agentID, currentInventory sql.NullInt64
	var agentName, agentError, invHostname, invOSName, invOSVersion, invPrimaryIP sql.NullString
	var agentEnabled sql.NullBool
	var offlineAfter sql.NullInt64
	var custom []byte
	err := scanner.Scan(
		&vm.ID, &vm.VCenterSourceID, &vm.VCenterSourceName, &vm.VCenterMoID, &vm.InstanceUUID, &vm.BIOSUUID, &vm.Name, &vm.PowerState, &vm.CPUCount, &vm.MemoryMiB, &vm.HardwareVersion, &vm.GuestOS, &vm.GuestHostname, &vm.PrimaryIP, &custom,
		&vm.Retired, &retiredAt, &retiredBy, &vm.RetiredNote, &vm.PresentInVCenter, &vm.FirstSeenAt, &vm.LastSeenAt, &missingSince, &lastVCenter,
		&agentID, &agentName, &agentEnabled, &offlineAfter, &agentContact, &agentSuccess, &agentError, &currentInventory,
		&invHostname, &invOSName, &invOSVersion, &invPrimaryIP, &inventoryReceived, &vm.CreatedAt, &vm.UpdatedAt,
	)
	if err != nil {
		return vm, err
	}
	vm.CustomAttributesJSON = custom
	if retiredAt.Valid {
		vm.RetiredAt = &retiredAt.Time
	}
	if retiredBy.Valid {
		v := retiredBy.Int64
		vm.RetiredBy = &v
	}
	if missingSince.Valid {
		vm.MissingSince = &missingSince.Time
	}
	if lastVCenter.Valid {
		vm.LastVCenterSyncAt = &lastVCenter.Time
	}
	if agentID.Valid {
		v := agentID.Int64
		vm.AgentID = &v
		vm.AgentName = agentName.String
		vm.AgentLastError = agentError.String
		if agentContact.Valid {
			vm.AgentLastContactAt = &agentContact.Time
		}
		if agentSuccess.Valid {
			vm.AgentLastSuccessAt = &agentSuccess.Time
		}
		vm.AgentStatus = agentStatus(agentEnabled.Bool, agentContact, offlineAfter.Int64)
	} else {
		vm.AgentStatus = "unconfigured"
	}
	if currentInventory.Valid {
		v := currentInventory.Int64
		vm.CurrentInventoryID = &v
	}
	vm.InventoryHostname = invHostname.String
	vm.InventoryOSName = invOSName.String
	vm.InventoryOSVersion = invOSVersion.String
	vm.InventoryPrimaryIP = invPrimaryIP.String
	if inventoryReceived.Valid {
		vm.InventoryReceivedAt = &inventoryReceived.Time
	}
	return vm, nil
}

func agentStatus(enabled bool, lastContact sql.NullTime, offlineAfter int64) string {
	if !enabled {
		return "disabled"
	}
	if !lastContact.Valid {
		return "unknown"
	}
	if offlineAfter <= 0 || time.Since(lastContact.Time.UTC()) > time.Duration(offlineAfter)*time.Second {
		return "offline"
	}
	return "online"
}

func nullableInt64(value sql.NullInt64) any {
	if value.Valid {
		return value.Int64
	}
	return nil
}

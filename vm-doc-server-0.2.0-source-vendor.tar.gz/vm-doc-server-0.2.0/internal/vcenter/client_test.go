package vcenter

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"vm-doc-server/internal/domain"
)

func TestClientInventory(t *testing.T) {
	mux := http.NewServeMux()
	mux.HandleFunc("POST /api/session", func(w http.ResponseWriter, r *http.Request) {
		user, pass, ok := r.BasicAuth()
		if !ok || user != "svc" || pass != "secret" {
			http.Error(w, "unauthorized", http.StatusUnauthorized)
			return
		}
		_ = json.NewEncoder(w).Encode("session-1")
	})
	mux.HandleFunc("GET /api/vcenter/vm", func(w http.ResponseWriter, r *http.Request) {
		checkSession(t, r)
		_ = json.NewEncoder(w).Encode([]map[string]any{{"vm": "vm-42", "name": "APP-01", "power_state": "POWERED_ON", "cpu_count": 4, "memory_size_mib": 8192}})
	})
	mux.HandleFunc("GET /api/vcenter/vm/vm-42", func(w http.ResponseWriter, r *http.Request) {
		checkSession(t, r)
		_ = json.NewEncoder(w).Encode(map[string]any{
			"identity": map[string]any{"name": "APP-01", "bios_uuid": "A89B0542-0022-9E75-E7BB-3CA7D543A975", "instance_uuid": "instance-42"},
			"cpu":      map[string]any{"count": 4}, "memory": map[string]any{"size_mib": 8192}, "power_state": "POWERED_ON",
			"hardware": map[string]any{"version": "VMX_21"}, "guest_os": "UBUNTU_64",
		})
	})
	mux.HandleFunc("GET /api/vcenter/vm/vm-42/guest/identity", func(w http.ResponseWriter, r *http.Request) {
		checkSession(t, r)
		_ = json.NewEncoder(w).Encode(map[string]any{"host_name": "app-01.example", "ip_address": "10.20.30.40", "full_name": map[string]any{"localized": "Ubuntu Linux", "default_message": "Ubuntu Linux"}})
	})
	mux.HandleFunc("DELETE /api/session", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(http.StatusNoContent) })
	server := httptest.NewServer(mux)
	defer server.Close()

	verify := false
	client, err := NewClient(domain.VCenterSource{BaseURL: server.URL, Username: "svc", VerifyTLS: verify}, "secret", 5*time.Second, 2)
	if err != nil {
		t.Fatal(err)
	}
	vms, err := client.Inventory(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if len(vms) != 1 || vms[0].MoID != "vm-42" || vms[0].BIOSUUID == "" || vms[0].GuestHostname != "app-01.example" || vms[0].PrimaryIP != "10.20.30.40" {
		t.Fatalf("unexpected inventory: %+v", vms)
	}
}

func checkSession(t *testing.T, r *http.Request) {
	t.Helper()
	if r.Header.Get("vmware-api-session-id") != "session-1" {
		t.Fatalf("missing vCenter session header")
	}
}

func TestLocalizedText(t *testing.T) {
	for name, input := range map[string]string{
		"plain":     `"Ubuntu Linux"`,
		"localized": `{"localized":"Ubuntu Linux","default_message":"fallback"}`,
		"default":   `{"default_message":"Ubuntu Linux"}`,
	} {
		t.Run(name, func(t *testing.T) {
			if got := localizedText(json.RawMessage(input)); got != "Ubuntu Linux" {
				t.Fatalf("localizedText() = %q", got)
			}
		})
	}
}

func TestSwapVMwareUUID(t *testing.T) {
	got := swapVMwareUUID("a89b0542-0022-9e75-e7bb-3ca7d543a975")
	want := "42059ba8-2200-759e-e7bb-3ca7d543a975"
	if got != want {
		t.Fatalf("swapVMwareUUID() = %q, want %q", got, want)
	}
}

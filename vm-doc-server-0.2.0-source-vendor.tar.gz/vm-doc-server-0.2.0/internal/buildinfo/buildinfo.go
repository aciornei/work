package buildinfo

var (
	Version = "0.2.0-dev"
	Commit  = "unknown"
	Date    = "unknown"
)

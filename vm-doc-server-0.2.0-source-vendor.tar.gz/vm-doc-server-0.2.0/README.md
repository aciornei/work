# vm-doc-server 0.2.0

Platformă centrală pentru documentarea VM-urilor, cu **vCenter drept punctul 0 al inventarului** și `vm-doc-agent` drept sursă pentru detaliile din sistemul de operare.

```text
vCenter API ──> virtual_machines ──┐
                                  ├──> vm-doc-server ──> browser / API
vm-doc-agent ─> collector ─> JSON ┘
```

## Ce aduce versiunea 0.2.0

- surse vCenter multiple, cu credențiale criptate individual;
- importul tuturor VM-urilor vizibile prin API-ul vCenter;
- buton de sincronizare manuală și sincronizare automată zilnică;
- istoric pentru fiecare rulare vCenter: găsite, adăugate, actualizate, lipsă și agenți asociați;
- câmp local `Retired`, notă și audit, păstrate la sincronizările ulterioare;
- VM-urile care dispar din vCenter sunt marcate `missing`, nu șterse automat;
- asociere automată VM–agent după BIOS/DMI UUID și asociere manuală din interfață;
- stare agent, ultimul contact, ultima colectare și butoane **Testează** / **Sincronizează acum** în fișa VM;
- parser corect pentru schema agentului 2.0: `agent.id`, `agent.version`, `collection.collectors` și câmpurile de corelare VMware;
- API/OpenAPI și interfață actualizate.

## Componente

- `vm-doc-server`: API, frontend, autentificare, RBAC, audit și scheduler vCenter;
- `vm-doc-collector`: coadă persistentă și interogarea agenților;
- MariaDB: surse vCenter, VM-uri, lifecycle, joburi și snapshoturi JSON.

Serverul web contactează vCenter. Numai `vm-doc-collector` contactează agenții.

## Compilare

Necesită Go 1.23 sau mai nou și modulele declarate în `go.mod`.

```bash
make test
make build
```

Binarele sunt generate în `bin/`.

Pentru un server fără internet, pregătiți pe o stație conectată un pachet cu `vendor/`:

```bash
go mod download
go mod vendor
go test -mod=vendor ./...
```

Apoi transferați întregul director al proiectului și compilați cu:

```bash
CGO_ENABLED=0 go build -mod=vendor -trimpath -o bin/vm-doc-server ./cmd/vm-doc-server
CGO_ENABLED=0 go build -mod=vendor -trimpath -o bin/vm-doc-collector ./cmd/vm-doc-collector
```

## Instalare și upgrade

Instalarea inițială rămâne aceeași ca în 0.1.0. La prima pornire, migrațiile `008` și `009` creează tabelele vCenter/VM și noile permisiuni RBAC.

Pentru upgrade:

1. faceți backup la baza MariaDB și la configurație;
2. opriți `vm-doc-server` și `vm-doc-collector`;
3. înlocuiți binarele și fișierele web incluse în binar;
4. păstrați `version: 1` în `config.yaml` și adăugați secțiunea opțională `vcenter`;
5. porniți mai întâi serverul, apoi collectorul;
6. adăugați sursa vCenter din pagina **VM-uri** și porniți prima sincronizare.

Consultați `docs/UPGRADE-0.2.0.md` și `docs/VCENTER.md`.

## API

- document OpenAPI: `/api/openapi.yaml`;
- Swagger UI: `/docs/`;
- health: `/healthz`;
- readiness: `/readyz`;
- versiune: `/version`.

## Securitate

- parolele vCenter și tokenurile agenților sunt criptate AES-256-GCM înainte de salvarea în MariaDB;
- API-ul nu returnează secretele;
- `verify_tls` trebuie menținut activ în producție;
- contul vCenter trebuie să fie dedicat și limitat la operațiile de inventariere necesare;
- modificările `Retired`, asocierile și sincronizările manuale sunt auditate.

## Limitări cunoscute

- custom attributes generale din vCenter nu sunt încă importate; câmpul `Retired` este administrat local de aplicație;
- operația REST `GET /api/vcenter/vm` returnează maximum 4.000 de VM-uri per sursă; pentru inventare mai mari este necesară împărțirea sursei sau o sincronizare filtrată într-o versiune ulterioară;
- exportul DOCX/PDF și retenția automată vor fi dezvoltate ulterior;
- arhiva sursă standard nu conține dependențe vendorizate.

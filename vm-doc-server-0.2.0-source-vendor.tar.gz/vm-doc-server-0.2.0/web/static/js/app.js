const state={user:null,csrf:'',agents:[],sources:[],vms:[]};
const content=document.getElementById('content');
const title=document.getElementById('pageTitle');
const subtitle=document.getElementById('pageSubtitle');
const agentDialog=document.getElementById('agentDialog');
const agentForm=document.getElementById('agentForm');
const vcenterDialog=document.getElementById('vcenterDialog');
const vcenterForm=document.getElementById('vcenterForm');

const rolePermissions={
  admin:new Set(['*']),
  operator:new Set(['dashboard.read','agents.read','agents.manage','collections.read','collections.run','inventories.read','inventories.raw.read','vcenter.read','vcenter.manage','vms.manage']),
  viewer:new Set(['dashboard.read','agents.read','collections.read','inventories.read','vcenter.read']),
  auditor:new Set(['dashboard.read','agents.read','collections.read','inventories.read','inventories.raw.read','audit.read','vcenter.read'])
};
function can(permission){return (state.user?.roles||[]).some(role=>rolePermissions[role]?.has('*')||rolePermissions[role]?.has(permission))}

async function api(path,options={}){
  const headers={Accept:'application/json',...(options.headers||{})};
  if(options.body&&!headers['Content-Type'])headers['Content-Type']='application/json';
  if(!['GET','HEAD'].includes((options.method||'GET').toUpperCase())&&state.csrf)headers['X-CSRF-Token']=state.csrf;
  const response=await fetch(path,{...options,headers});
  if(response.status===401){location.href='/login';throw new Error('Sesiunea a expirat.');}
  const type=response.headers.get('content-type')||'';
  const body=response.status===204?null:type.includes('json')?await response.json():await response.text();
  if(!response.ok)throw new Error(body?.message||body?.error||`HTTP ${response.status}`);
  return body;
}
const e=v=>String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const dt=v=>v?new Date(v).toLocaleString('ro-RO'):'—';
const badge=v=>{const text=String(v??'unknown');return `<span class="badge ${e(text.toLowerCase().replaceAll('_','-'))}">${e(text)}</span>`};
const boolText=v=>v?'Da':'Nu';
const memory=v=>v?`${(Number(v)/1024).toFixed(Number(v)>=10240?0:1)} GB`:'—';
function toast(message,error=false){const box=document.getElementById('toast');box.textContent=message;box.className=`toast show${error?' error':''}`;setTimeout(()=>box.className='toast',3200)}
function pageMeta(name,sub){title.textContent=name;subtitle.textContent=sub||''}
function panel(head,body,tools=''){return `<section class="panel"><div class="panel-header"><h2>${head}</h2><div class="toolbar">${tools}</div></div>${body}</section>`}
function empty(text){return `<div class="empty">${e(text)}</div>`}
function detail(label,value,mono=false){return `<div class="detail-item"><span>${e(label)}</span><div class="${mono?'mono':''}">${value??'—'}</div></div>`}
function jsonSections(raw){const entries=raw&&typeof raw==='object'&&!Array.isArray(raw)?Object.entries(raw):[['inventory',raw]];return `<div class="json-sections">${entries.map(([name,value])=>`<details><summary>${e(name)}</summary><pre class="json">${e(JSON.stringify(value,null,2))}</pre></details>`).join('')}</div>`}

async function init(){
  try{
    state.user=await api('/api/v1/auth/me');state.csrf=state.user.csrf_token;
    document.getElementById('currentUser').textContent=state.user.display_name||state.user.username;
    document.querySelector('[data-page="audit"]').hidden=!can('audit.read');
    document.querySelector('[data-page="access"]').hidden=!can('rbac.manage');
    document.body.classList.remove('booting');route();
  }catch{location.href='/login'}
}

async function route(){
  const raw=(location.hash||'#dashboard').slice(1);const [page,id]=raw.split('/');
  document.querySelectorAll('#nav a[data-page]').forEach(a=>a.classList.toggle('active',a.dataset.page===page));
  content.innerHTML='<div class="loading">Se încarcă…</div>';
  try{
    if(page==='dashboard')await dashboard();
    else if(page==='agents')await agentsPage();
    else if(page==='vms'&&id)await vmDetail(Number(id));
    else if(page==='vms')await vmsPage();
    else if(page==='audit')await auditPage();
    else if(page==='access')await accessPage();
    else location.hash='#dashboard';
  }catch(err){content.innerHTML=empty(err.message);toast(err.message,true)}
}

async function dashboard(){
  pageMeta('Dashboard','Starea centralizată a platformei');
  const d=await api('/api/v1/dashboard');
  content.innerHTML=`<div class="cards">
    <div class="card"><div class="label">VM-uri din vCenter</div><div class="value">${d.vms}</div></div>
    <div class="card"><div class="label">Agenți configurați</div><div class="value">${d.agents_total}</div></div>
    <div class="card"><div class="label">Agenți online</div><div class="value">${d.agents_online}</div></div>
    <div class="card"><div class="label">Joburi în așteptare</div><div class="value">${d.jobs_pending}</div></div>
  </div>${panel('Fluxul 0 → inventar',`<div class="detail-grid">${detail('0. vCenter','Lista completă de VM-uri')}${detail('1. Corelare','BIOS UUID / hostname unic')}${detail('2. Agent','Colectare JSON și stare')}${detail('3. Lifecycle','Retired și istoric local')}</div>`)}`;
}

async function agentsPage(){
  pageMeta('Agenți','Administrare, conectivitate și colectare');state.agents=await api('/api/v1/agents');
  const rows=state.agents.map(a=>{const actions=[can('collections.run')?`<button class="small secondary" data-action="test" data-id="${a.id}">Test</button><button class="small" data-action="collect" data-id="${a.id}">Colectează</button>`:'',can('agents.manage')?`<button class="small secondary" data-action="edit" data-id="${a.id}">Editează</button><button class="small danger" data-action="delete" data-id="${a.id}">Șterge</button>`:''].join('');return `<tr><td><strong>${e(a.name)}</strong><div class="muted mono">${e(a.base_url)}</div></td><td>${badge(a.status)}</td><td class="mono">${e(a.agent_uuid||'—')}</td><td>${dt(a.last_contact_at)}</td><td class="muted">${e(a.last_error||'—')}</td><td><div class="actions">${actions||'—'}</div></td></tr>`}).join('');
  content.innerHTML=panel('Lista agenților',state.agents.length?`<div class="table-wrap"><table><thead><tr><th>Agent</th><th>Status</th><th>UUID</th><th>Ultimul contact</th><th>Ultima eroare</th><th>Acțiuni</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există agenți configurați.'),can('agents.manage')?'<button id="newAgent">Adaugă agent</button>':'');
  document.getElementById('newAgent')?.addEventListener('click',()=>openAgent());
  content.querySelectorAll('[data-action]').forEach(b=>b.onclick=()=>agentAction(b.dataset.action,Number(b.dataset.id)));
}

function openAgent(agent=null){
  document.getElementById('agentDialogTitle').textContent=agent?'Editare agent':'Agent nou';
  document.getElementById('agentId').value=agent?.id||'';document.getElementById('agentName').value=agent?.name||'';document.getElementById('agentURL').value=agent?.base_url||'';document.getElementById('agentToken').value='';document.getElementById('agentToken').required=!agent;
  document.getElementById('agentInterval').value=agent?.collection_interval_seconds||900;document.getElementById('agentTimeout').value=agent?.request_timeout_seconds||45;document.getElementById('agentOffline').value=agent?.offline_after_seconds||2700;document.getElementById('agentEnabled').checked=agent?.enabled??true;document.getElementById('agentVerifyTLS').checked=agent?.verify_tls??true;agentDialog.showModal();
}
async function agentAction(action,id){
  const agent=state.agents.find(a=>a.id===id);
  if(action==='edit'){openAgent(agent);return}
  if(action==='delete'){if(!confirm(`Ștergi agentul ${agent.name}? Istoricul lui va fi șters.`))return;await api(`/api/v1/agents/${id}`,{method:'DELETE'});toast('Agent șters.');agentsPage();return}
  const job=await api(`/api/v1/agents/${id}/${action==='test'?'test':'collect'}`,{method:'POST'});toast(`Job ${job.id} introdus în coadă.`);setTimeout(agentsPage,1000);
}
agentForm.addEventListener('submit',async event=>{
  event.preventDefault();const id=Number(document.getElementById('agentId').value||0);
  const body={name:document.getElementById('agentName').value.trim(),base_url:document.getElementById('agentURL').value.trim(),token:document.getElementById('agentToken').value,enabled:document.getElementById('agentEnabled').checked,verify_tls:document.getElementById('agentVerifyTLS').checked,collection_interval_seconds:Number(document.getElementById('agentInterval').value),request_timeout_seconds:Number(document.getElementById('agentTimeout').value),offline_after_seconds:Number(document.getElementById('agentOffline').value)};
  if(id&&!body.token)delete body.token;
  try{await api(id?`/api/v1/agents/${id}`:'/api/v1/agents',{method:id?'PATCH':'POST',body:JSON.stringify(body)});agentDialog.close();toast(id?'Agent actualizat.':'Agent creat.');agentsPage()}catch(err){toast(err.message,true)}
});

async function vmsPage(){
  pageMeta('VM-uri','vCenter este punctul 0 al inventarului');
  const requests=[api('/api/v1/vms'),can('vcenter.read')?api('/api/v1/vcenter/sources'):Promise.resolve([]),can('vcenter.read')?api('/api/v1/vcenter/sync-runs'):Promise.resolve([])];
  const results=await Promise.all(requests);state.vms=results[0];state.sources=results[1];const runs=results[2];
  const total=state.vms.length,present=state.vms.filter(v=>v.present_in_vcenter).length,withAgent=state.vms.filter(v=>v.agent_id).length,retired=state.vms.filter(v=>v.retired).length;
  const tools=`${can('vcenter.manage')?'<button id="syncAll">Sincronizează vCenter</button><button id="newVCenter" class="secondary">Adaugă sursă</button>':''}`;
  const vmRows=state.vms.map(v=>`<tr data-vm-row data-search="${e(`${v.name} ${v.guest_hostname||''} ${v.inventory_hostname||''} ${v.primary_ip||''} ${v.inventory_primary_ip||''}`.toLowerCase())}"><td><a href="#vms/${v.id}"><strong>${e(v.name)}</strong></a><div class="muted mono">${e(v.vcenter_moid)} · ${e(v.vcenter_source_name)}</div></td><td>${badge(v.power_state||'unknown')}</td><td>${v.cpu_count||'—'} / ${memory(v.memory_mib)}</td><td>${e(v.inventory_os_name||v.guest_os||'—')}<div class="muted">${e(v.inventory_os_version||'')}</div></td><td class="mono">${e(v.inventory_primary_ip||v.primary_ip||'—')}</td><td>${badge(v.agent_status)}<div class="muted">${e(v.agent_name||'Fără agent')}</div></td><td>${dt(v.inventory_received_at)}</td><td>${v.retired?badge('retired'):v.present_in_vcenter?badge('active'):badge('missing')}</td></tr>`).join('');
  const sourceRows=state.sources.map(s=>`<tr><td><strong>${e(s.name)}</strong><div class="muted mono">${e(s.base_url)}</div></td><td>${e(s.username)}</td><td>${s.daily_sync_enabled?`Zilnic ${e(s.daily_sync_time)}`:'Manual'}</td><td>${dt(s.last_success_at)}<div class="error-text">${e(s.last_error||'')}</div></td><td><div class="actions">${can('vcenter.manage')?`<button class="small secondary vc-action" data-action="test" data-id="${s.id}">Test</button><button class="small vc-action" data-action="sync" data-id="${s.id}">Sync</button><button class="small secondary vc-action" data-action="edit" data-id="${s.id}">Editează</button><button class="small danger vc-action" data-action="delete" data-id="${s.id}">Șterge</button>`:'—'}</div></td></tr>`).join('');
  const runRows=(runs||[]).slice(0,15).map(r=>`<tr><td>${dt(r.created_at)}</td><td>${e(r.vcenter_source_name)}</td><td>${badge(r.status)}</td><td>${r.found_count}</td><td>+${r.created_count} / ~${r.updated_count} / lipsă ${r.missing_count}</td><td>${r.linked_agent_count}</td><td class="error-text">${e(r.error_message||'—')}</td></tr>`).join('');
  content.innerHTML=`<div class="cards"><div class="card"><div class="label">Total vCenter</div><div class="value">${total}</div></div><div class="card"><div class="label">Prezente</div><div class="value">${present}</div></div><div class="card"><div class="label">Cu agent asociat</div><div class="value">${withAgent}</div></div><div class="card"><div class="label">Retired</div><div class="value">${retired}</div></div></div>
  ${panel('Inventar VM',`<div class="filterbar"><input id="vmSearch" placeholder="Caută nume, hostname sau IP"><label><input id="showRetired" type="checkbox" checked> Arată retired</label><label><input id="showMissing" type="checkbox" checked> Arată lipsă din vCenter</label></div>${state.vms.length?`<div class="table-wrap"><table><thead><tr><th>VM</th><th>Power</th><th>CPU / RAM</th><th>OS</th><th>IP</th><th>Agent</th><th>Ultimul JSON</th><th>Lifecycle</th></tr></thead><tbody>${vmRows}</tbody></table></div>`:empty('Nu există VM-uri. Adăugați o sursă vCenter și porniți sincronizarea.')}`,tools)}
  ${can('vcenter.read')?panel('Surse vCenter',state.sources.length?`<div class="table-wrap"><table><thead><tr><th>Sursă</th><th>Utilizator</th><th>Program</th><th>Ultima sincronizare</th><th>Acțiuni</th></tr></thead><tbody>${sourceRows}</tbody></table></div>`:empty('Nu există surse vCenter configurate.')):''}
  ${can('vcenter.read')?panel('Ultimele sincronizări',runRows?`<div class="table-wrap"><table><thead><tr><th>Creat</th><th>Sursă</th><th>Status</th><th>Găsite</th><th>Modificări</th><th>Agenți legați</th><th>Eroare</th></tr></thead><tbody>${runRows}</tbody></table></div>`:empty('Nu există sincronizări.')):''}`;
  document.getElementById('syncAll')?.addEventListener('click',async()=>{try{const r=await api('/api/v1/vcenter/sync',{method:'POST'});toast(`${r.length} sincronizări introduse în coadă.`);setTimeout(vmsPage,1200)}catch(err){toast(err.message,true)}});
  document.getElementById('newVCenter')?.addEventListener('click',()=>openVCenter());
  content.querySelectorAll('.vc-action').forEach(b=>b.onclick=()=>vcenterAction(b.dataset.action,Number(b.dataset.id)));
  const filter=()=>{const q=(document.getElementById('vmSearch')?.value||'').toLowerCase(),showRetired=document.getElementById('showRetired')?.checked,showMissing=document.getElementById('showMissing')?.checked;content.querySelectorAll('[data-vm-row]').forEach((row,index)=>{const vm=state.vms[index];row.hidden=!row.dataset.search.includes(q)||(!showRetired&&vm.retired)||(!showMissing&&!vm.present_in_vcenter)})};
  ['vmSearch','showRetired','showMissing'].forEach(id=>document.getElementById(id)?.addEventListener('input',filter));
}

function openVCenter(source=null){
  document.getElementById('vcenterDialogTitle').textContent=source?'Editare sursă vCenter':'Sursă vCenter nouă';document.getElementById('vcenterId').value=source?.id||'';document.getElementById('vcenterName').value=source?.name||'';document.getElementById('vcenterURL').value=source?.base_url||'';document.getElementById('vcenterUsername').value=source?.username||'';document.getElementById('vcenterPassword').value='';document.getElementById('vcenterPassword').required=!source;document.getElementById('vcenterSyncTime').value=source?.daily_sync_time||'05:00';document.getElementById('vcenterTLSServerName').value=source?.tls_server_name||'';document.getElementById('vcenterEnabled').checked=source?.enabled??true;document.getElementById('vcenterVerifyTLS').checked=source?.verify_tls??true;document.getElementById('vcenterDailySync').checked=source?.daily_sync_enabled??true;vcenterDialog.showModal();
}
async function vcenterAction(action,id){
  const source=state.sources.find(s=>s.id===id);
  try{
    if(action==='edit'){openVCenter(source);return}
    if(action==='delete'){if(!confirm(`Ștergi sursa ${source.name} și VM-urile sincronizate din ea?`))return;await api(`/api/v1/vcenter/sources/${id}`,{method:'DELETE'});toast('Sursă vCenter ștearsă.');vmsPage();return}
    if(action==='test'){const r=await api(`/api/v1/vcenter/sources/${id}/test`,{method:'POST'});toast(`Conexiune reușită: ${r.vm_count} VM-uri vizibile.`);return}
    if(action==='sync'){const r=await api(`/api/v1/vcenter/sources/${id}/sync`,{method:'POST'});toast(`Sincronizarea ${r.id} a fost pornită.`);setTimeout(vmsPage,1200)}
  }catch(err){toast(err.message,true)}
}
vcenterForm.addEventListener('submit',async event=>{
  event.preventDefault();const id=Number(document.getElementById('vcenterId').value||0);const body={name:document.getElementById('vcenterName').value.trim(),base_url:document.getElementById('vcenterURL').value.trim(),username:document.getElementById('vcenterUsername').value.trim(),password:document.getElementById('vcenterPassword').value,enabled:document.getElementById('vcenterEnabled').checked,verify_tls:document.getElementById('vcenterVerifyTLS').checked,tls_server_name:document.getElementById('vcenterTLSServerName').value.trim(),daily_sync_enabled:document.getElementById('vcenterDailySync').checked,daily_sync_time:document.getElementById('vcenterSyncTime').value};if(id&&!body.password)delete body.password;
  try{await api(id?`/api/v1/vcenter/sources/${id}`:'/api/v1/vcenter/sources',{method:id?'PATCH':'POST',body:JSON.stringify(body)});vcenterDialog.close();toast(id?'Sursă actualizată.':'Sursă creată.');vmsPage()}catch(err){toast(err.message,true)}
});

async function vmDetail(id){
  const [data,history,agents]=await Promise.all([api(`/api/v1/vms/${id}`),api(`/api/v1/vms/${id}/inventories`),can('agents.read')?api('/api/v1/agents'):Promise.resolve([])]);const vm=data.vm,a=data.agent,v=data.inventory||{};pageMeta(vm.name,'Detalii vCenter, agent și inventar JSON');
  const agentOptions=`<option value="">Fără agent</option>${agents.map(x=>`<option value="${x.id}" ${vm.agent_id===x.id?'selected':''}>${e(x.name)} (${e(x.status)})</option>`).join('')}`;
  const historyRows=(history||[]).map(i=>`<tr><td>${dt(i.received_at)}</td><td>${e(i.hostname)}</td><td>${e(i.os_name)} ${e(i.os_version)}</td><td>${i.collector_ok}/${i.collector_total}</td><td>${i.changed_from_previous?badge('changed'):badge('same')}</td><td>${can('inventories.raw.read')?`<button class="small secondary show-raw" data-id="${i.id}">JSON</button>`:''}</td></tr>`).join('');
  content.innerHTML=`<div class="cards"><div class="card"><div class="label">Power state</div><div class="value compact">${badge(vm.power_state||'unknown')}</div></div><div class="card"><div class="label">Agent</div><div class="value compact">${badge(vm.agent_status)}</div><div class="muted">${e(vm.agent_name||'Neasociat')}</div></div><div class="card"><div class="label">Ultima sincronizare agent</div><div class="value compact">${dt(vm.inventory_received_at)}</div></div><div class="card"><div class="label">Lifecycle</div><div class="value compact">${vm.retired?badge('retired'):vm.present_in_vcenter?badge('active'):badge('missing')}</div></div></div>
  ${panel('Date vCenter',`<div class="detail-grid">${detail('Sursă',e(vm.vcenter_source_name))}${detail('MoID',e(vm.vcenter_moid),true)}${detail('BIOS UUID',e(vm.bios_uuid||'—'),true)}${detail('Instance UUID',e(vm.instance_uuid||'—'),true)}${detail('CPU',e(vm.cpu_count))}${detail('RAM',memory(vm.memory_mib))}${detail('Hardware',e(vm.hardware_version||'—'))}${detail('Ultima vedere',dt(vm.last_seen_at))}${detail('Guest hostname',e(vm.guest_hostname||'—'))}${detail('Guest OS',e(vm.guest_os||'—'))}${detail('IP vCenter',e(vm.primary_ip||'—'),true)}${detail('Prezentă în vCenter',boolText(vm.present_in_vcenter))}</div>`)}
  ${panel('Lifecycle și asociere',`<form id="vmManageForm" class="detail-grid"><label><span>Retired</span><select id="vmRetired"><option value="false" ${!vm.retired?'selected':''}>Nu</option><option value="true" ${vm.retired?'selected':''}>Da</option></select></label><label class="span-2"><span>Notă retired</span><input id="vmRetiredNote" value="${e(vm.retired_note||'')}" placeholder="Motiv / tichet / dată"></label><label><span>Agent asociat</span><select id="vmAgent">${agentOptions}</select></label><label class="form-submit"><button type="submit">Salvează</button></label></form>`,can('collections.run')&&vm.agent_id?'<button id="testVMAgent" class="secondary">Testează agentul</button><button id="collectVM">Sincronizează acum</button>':'')}
  ${panel('Ultimul inventar agent',v.id?`<div class="detail-grid">${detail('Hostname',e(v.hostname||'—'))}${detail('FQDN',e(v.fqdn||'—'))}${detail('Agent',`${e(v.agent_version||'—')} · ${e(v.agent_uuid||'—')}`,true)}${detail('Product UUID',e(v.product_uuid||'—'),true)}${detail('OS',`${e(v.os_name||'—')} ${e(v.os_version||'')}`)}${detail('IP',e(v.primary_ip||'—'),true)}${detail('Colectori OK',`${v.collector_ok}/${v.collector_total}`)}${detail('Primit',dt(v.received_at))}</div>`:empty('Agentul nu a furnizat încă un inventar.'),v.id&&can('inventories.raw.read')?'<button id="latestRaw" class="secondary">Toate câmpurile JSON</button>':'')}
  ${panel('Istoric inventare',historyRows?`<div class="table-wrap"><table><thead><tr><th>Primit</th><th>Hostname</th><th>OS</th><th>Colectori</th><th>Schimbare</th><th></th></tr></thead><tbody>${historyRows}</tbody></table></div>`:empty('Nu există snapshoturi pentru această VM.'))}<section id="rawPanel"></section>`;
  document.getElementById('vmManageForm')?.addEventListener('submit',async ev=>{ev.preventDefault();const selected=document.getElementById('vmAgent').value;const body={retired:document.getElementById('vmRetired').value==='true',retired_note:document.getElementById('vmRetiredNote').value.trim()};if(selected)body.agent_id=Number(selected);else if(vm.agent_id)body.clear_agent=true;try{await api(`/api/v1/vms/${id}`,{method:'PATCH',body:JSON.stringify(body)});toast('VM actualizată.');vmDetail(id)}catch(err){toast(err.message,true)}});
  document.getElementById('testVMAgent')?.addEventListener('click',()=>vmJob(id,'test-agent'));
  document.getElementById('collectVM')?.addEventListener('click',()=>vmJob(id,'collect'));
  document.getElementById('latestRaw')?.addEventListener('click',async()=>{try{const raw=await api(`/api/v1/inventories/${v.id}/raw`);document.getElementById('rawPanel').innerHTML=panel(`Toate câmpurile inventarului #${v.id}`,jsonSections(raw));document.getElementById('rawPanel').scrollIntoView({behavior:'smooth'})}catch(err){toast(err.message,true)}});
  content.querySelectorAll('.show-raw').forEach(b=>b.onclick=async()=>{try{const raw=await api(`/api/v1/inventories/${b.dataset.id}/raw`);document.getElementById('rawPanel').innerHTML=panel(`JSON inventar #${b.dataset.id}`,jsonSections(raw));document.getElementById('rawPanel').scrollIntoView({behavior:'smooth'})}catch(err){toast(err.message,true)}});
}
async function vmJob(id,action){try{const job=await api(`/api/v1/vms/${id}/${action}`,{method:'POST'});toast(`Job ${job.id} introdus în coadă.`);setTimeout(()=>vmDetail(id),1200)}catch(err){toast(err.message,true)}}

async function auditPage(){pageMeta('Audit','Acțiuni administrative și operaționale');const rows=await api('/api/v1/audit/events');content.innerHTML=panel('Evenimente recente',rows.length?`<div class="table-wrap"><table><thead><tr><th>Data</th><th>Sursă</th><th>Actor</th><th>Acțiune</th><th>Resursă</th><th>Rezultat</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${dt(r.occurred_at)}</td><td>${e(r.source)}</td><td>${e(r.actor_username||'sistem')}</td><td class="mono">${e(r.action)}</td><td>${e(r.resource_type)} ${e(r.resource_id)}</td><td>${badge(r.outcome)}</td></tr>`).join('')}</tbody></table></div>`:empty('Nu există evenimente de audit.'))}

async function accessPage(){pageMeta('Acces','Mapări grupuri LDAP/OIDC către roluri');const [roles,maps]=await Promise.all([api('/api/v1/rbac/roles'),api('/api/v1/rbac/group-mappings')]);content.innerHTML=`${panel('Adaugă mapare',`<form id="mappingForm" class="detail-grid"><label>Provider<select id="mapProvider"><option value="ldap">LDAP</option><option value="oidc">OIDC</option><option value="any">Oricare</option></select></label><label>Grup<input id="mapGroup" required placeholder="VM-DOC-Operators"></label><label>Rol<select id="mapRole">${roles.map(r=>`<option value="${e(r.name)}">${e(r.name)}</option>`).join('')}</select></label><label class="form-submit"><button type="submit">Adaugă</button></label></form>`)}${panel('Mapări existente',maps.length?`<div class="table-wrap"><table><thead><tr><th>Provider</th><th>Grup</th><th>Rol</th><th></th></tr></thead><tbody>${maps.map(m=>`<tr><td>${e(m.provider)}</td><td class="mono">${e(m.group_name)}</td><td>${badge(m.role)}</td><td><button class="small danger del-map" data-id="${m.id}">Șterge</button></td></tr>`).join('')}</tbody></table></div>`:empty('Nu există mapări.'))}`;
  document.getElementById('mappingForm').onsubmit=async ev=>{ev.preventDefault();await api('/api/v1/rbac/group-mappings',{method:'POST',body:JSON.stringify({provider:document.getElementById('mapProvider').value,group_name:document.getElementById('mapGroup').value.trim(),role:document.getElementById('mapRole').value})});toast('Mapare creată.');accessPage()};content.querySelectorAll('.del-map').forEach(b=>b.onclick=async()=>{await api(`/api/v1/rbac/group-mappings/${b.dataset.id}`,{method:'DELETE'});toast('Mapare ștearsă.');accessPage()})
}

document.getElementById('logoutButton').onclick=async()=>{await api('/api/v1/auth/logout',{method:'POST'});location.href='/login'};
document.getElementById('themeButton').onclick=()=>{const next=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=next;localStorage.setItem('vm-doc-theme',next)};
const savedTheme=localStorage.getItem('vm-doc-theme');if(savedTheme)document.documentElement.dataset.theme=savedTheme;
window.addEventListener('hashchange',route);
document.querySelectorAll('[data-close-dialog]').forEach(button=>button.addEventListener('click',()=>button.closest('dialog').close()));
init();

# Architecture 0.2.0

## Surse de adevăr

- **vCenter**: existența VM-ului, MoID, UUID, power state și resurse;
- **vm-doc-agent**: sistem de operare, rețea, servicii, politici și integrări;
- **vm-doc-server**: lifecycle local `Retired`, asocieri și istoric.

## Procese

`vm-doc-server` deservește browserul/API-ul și execută schedulerul vCenter. `vm-doc-collector` este singurul proces care contactează agenții.

## Sincronizare vCenter

Rulările sunt persistate în `vcenter_sync_runs`. Un named lock MariaDB previne procesarea simultană a aceleiași surse. Operația este asincronă față de cererea HTTP.

## Coada agenților

Joburile sunt stocate în `collection_jobs`. Un worker revendică un job prin lease. Un job rămas `running` poate fi revendicat după expirarea lease-ului.

## Inventar și corelare

Fiecare colectare reușită produce un rând în `inventory_snapshots`. JSON-ul original este păstrat, iar câmpurile de identificare sunt extrase pentru corelare. SHA-256 identifică schimbările fără pierderea istoricului.

## Frontend

Frontendul este HTML/CSS/JavaScript fără Node.js și este inclus în binarul Go cu `go:embed`.

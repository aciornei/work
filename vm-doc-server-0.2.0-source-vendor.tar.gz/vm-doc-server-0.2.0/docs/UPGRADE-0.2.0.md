# Upgrade 0.1.0 → 0.2.0

## Înainte de upgrade

```bash
mysqldump --single-transaction --routines --triggers vm_doc > vm_doc-before-0.2.0.sql
cp -a /etc/vm-doc-server /etc/vm-doc-server.backup-0.1.0
systemctl stop vm-doc-collector vm-doc-server
```

## Instalare

Înlocuiți binarele, păstrând configurația și cheia master. Adăugați în `config.yaml`:

```yaml
vcenter:
  allow_http: false
  request_timeout: "60s"
  detail_workers: 8
  scheduler_interval: "1m"
```

Porniți serverul pentru aplicarea migrațiilor:

```bash
systemctl start vm-doc-server
journalctl -u vm-doc-server -f
```

După ce `/readyz` răspunde cu `ready`, porniți collectorul:

```bash
systemctl start vm-doc-collector
```

## Prima sincronizare

1. autentificați-vă cu rol `admin` sau `operator`;
2. deschideți **VM-uri**;
3. adăugați sursa vCenter;
4. folosiți **Test**;
5. porniți **Sync**;
6. urmăriți secțiunea **Ultimele sincronizări**;
7. verificați asocierea automată pentru primul agent existent.

## Rollback

Codul 0.1.0 nu folosește tabelele noi, dar inventarele create după migrare conțin coloane suplimentare compatibile cu MariaDB. Pentru rollback complet, restaurați backupul bazei și binarele 0.1.0.

# Validation notes for 0.2.0

The 0.2.0 source package was checked with:

- `gofmt` for all Go sources;
- `go test ./...` and `go vet ./...` using temporary local compatibility stubs for external modules, because the packaging environment had no network access and no complete Go module cache;
- `node --check web/static/js/app.js`;
- YAML parsing for the application configuration examples and OpenAPI document;
- `bash -n` for the shell scripts;
- ZIP integrity verification after packaging.

The temporary compatibility stubs are not included in the source package and `go.mod` has no replacement directives.

## Not performed in the packaging environment

- a live synchronization against a real vCenter;
- a migration/runtime test against a real MariaDB database;
- a production build using the downloaded upstream Go modules.

On the online build machine, run:

```bash
go mod download
./scripts/check.sh
./scripts/build.sh
```

Then test a vCenter source with a read-only service account before enabling the daily scheduler.

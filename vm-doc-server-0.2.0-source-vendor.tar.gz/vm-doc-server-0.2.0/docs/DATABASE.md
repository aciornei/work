# Database

Migrațiile sunt aplicate automat și în ordine.

## Tabele principale

- `vcenter_sources`: conexiuni vCenter și programări;
- `virtual_machines`: inventarul de bază, lifecycle și asocierea agentului;
- `vcenter_sync_runs`: istoricul rulărilor;
- `agents`: configurația și starea agentului;
- `collection_jobs`: coada persistentă;
- `inventory_snapshots`: JSON brut și câmpuri extrase;
- `audit_events`: audit administrativ/operațional.

`virtual_machines.retired` și câmpurile asociate nu sunt modificate de sincronizarea vCenter. `present_in_vcenter` și `missing_since` sunt actualizate la fiecare rulare.

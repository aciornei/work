module vm-doc-server

go 1.23.0

require (
	github.com/coreos/go-oidc/v3 v3.14.1
	github.com/go-ldap/ldap/v3 v3.4.8
	github.com/go-sql-driver/mysql v1.8.1
	github.com/swaggest/swgui v1.8.1
	golang.org/x/oauth2 v0.28.0
	gopkg.in/yaml.v3 v3.0.1
)

require (
	filippo.io/edwards25519 v1.1.0 // indirect
	github.com/Azure/go-ntlmssp v0.0.0-20221128193559-754e69321358 // indirect
	github.com/go-asn1-ber/asn1-ber v1.5.5 // indirect
	github.com/go-jose/go-jose/v4 v4.0.5 // indirect
	github.com/google/uuid v1.6.0 // indirect
	github.com/vearutop/statigz v1.4.0 // indirect
	golang.org/x/crypto v0.36.0 // indirect
)

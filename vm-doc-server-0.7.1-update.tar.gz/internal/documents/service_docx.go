package documents

import (
	"archive/zip"
	"bytes"
	"fmt"
	"io"
	"sort"
	"strconv"
	"strings"

	"vm-doc-server/internal/domain"
)

func DefaultServiceTemplate() ([]byte, error) {
	files := map[string]string{
		"[Content_Types].xml":          `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>`,
		"_rels/.rels":                  `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>`,
		"word/_rels/document.xml.rels": `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`,
		"word/styles.xml":              stylesXML,
		"word/document.xml":            `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:pPr><w:pStyle w:val="Title"/></w:pPr><w:r><w:t>Fișă serviciu intern</w:t></w:r></w:p><w:p><w:r><w:t>{{SERVICE_DOCUMENT_BODY}}</w:t></w:r></w:p><w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr></w:body></w:document>`,
		"docProps/core.xml":            `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>Fișă serviciu intern</dc:title><dc:creator>vm-doc-server</dc:creator><cp:lastModifiedBy>vm-doc-server</cp:lastModifiedBy><dcterms:created xsi:type="dcterms:W3CDTF">2026-01-01T00:00:00Z</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">2026-01-01T00:00:00Z</dcterms:modified></cp:coreProperties>`,
		"docProps/app.xml":             `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>vm-doc-server</Application><DocSecurity>0</DocSecurity><ScaleCrop>false</ScaleCrop><Company></Company><LinksUpToDate>false</LinksUpToDate><SharedDoc>false</SharedDoc><HyperlinksChanged>false</HyperlinksChanged><AppVersion>0.7.1</AppVersion></Properties>`,
	}
	var output bytes.Buffer
	writer := zip.NewWriter(&output)
	order := []string{"[Content_Types].xml", "_rels/.rels", "word/document.xml", "word/styles.xml", "word/_rels/document.xml.rels", "docProps/core.xml", "docProps/app.xml"}
	for _, name := range order {
		entry, err := writer.Create(name)
		if err != nil {
			return nil, err
		}
		if _, err := io.WriteString(entry, files[name]); err != nil {
			return nil, err
		}
	}
	if err := writer.Close(); err != nil {
		return nil, err
	}
	return output.Bytes(), nil
}

func BuildServicePreview(template Template, data ServiceGenerationData) ServicePreview {
	preview := ServicePreview{
		InternalServiceID:   data.Service.ID,
		InternalServiceName: data.Service.Name,
		TemplateID:          template.ID,
		TemplateName:        template.Name,
		DocumentNumber:      data.DocumentNumber,
		GeneratedAt:         data.GeneratedAt,
		Warnings:            make([]string, 0),
		Sections:            servicePreviewSections(data),
	}
	if len(data.Service.VMs) == 0 {
		preview.Warnings = append(preview.Warnings, "Serviciul nu are VM-uri asociate.")
	}
	if len(data.Service.Classifications) == 0 {
		preview.Warnings = append(preview.Warnings, "Serviciul nu are încă domenii și categorii observate din VM-uri.")
	}
	if len(data.Service.SolutionTypes) == 0 {
		preview.Warnings = append(preview.Warnings, "Nu este definit încă niciun tip de soluție pe asocierile VM ale serviciului.")
	}
	if strings.TrimSpace(data.Service.Purpose) == "" {
		preview.Warnings = append(preview.Warnings, "Câmpul Scop și domeniu nu este completat.")
	}
	if strings.TrimSpace(data.Service.Objectives) == "" {
		preview.Warnings = append(preview.Warnings, "Câmpul Obiective nu este completat.")
	}
	return preview
}

func servicePreviewSections(data ServiceGenerationData) []PreviewSection {
	service := data.Service
	sections := []PreviewSection{
		{Title: "Document", Rows: []PreviewRow{{Label: "Număr", Value: data.DocumentNumber}, {Label: "Generat la", Value: formatTime(data.GeneratedAt)}, {Label: "Generat de", Value: firstNonEmpty(data.GeneratedBy.DisplayName, data.GeneratedBy.Username)}}},
		{Title: "Identificare serviciu", Rows: serviceIdentityRows(data)},
		{Title: "Scop, domeniu și obiective", Rows: []PreviewRow{{Label: "Scop și domeniu", Value: service.Purpose}, {Label: "Obiective", Value: service.Objectives}}},
	}
	if len(service.Classifications) > 0 {
		rows := make([]PreviewRow, 0, len(service.Classifications))
		for _, item := range service.Classifications {
			rows = append(rows, PreviewRow{Label: item.ArchitecturalDomain + " / " + item.ITILCategory, Value: fmt.Sprintf("%d VM · %d asocieri", item.VMCount, item.AssignmentCount)})
		}
		sections = append(sections, PreviewSection{Title: "Domenii și categorii observate", Rows: rows})
	}
	if len(service.SolutionTypes) > 0 {
		rows := make([]PreviewRow, 0, len(service.SolutionTypes))
		for _, item := range service.SolutionTypes {
			rows = append(rows, PreviewRow{Label: item.SolutionType, Value: fmt.Sprintf("%d VM · %d asocieri", item.VMCount, item.AssignmentCount)})
		}
		sections = append(sections, PreviewSection{Title: "Tipuri de soluție", Rows: rows})
	}
	if len(service.RoleMappings) > 0 {
		rows := make([]PreviewRow, 0, len(service.RoleMappings))
		for _, item := range service.RoleMappings {
			rows = append(rows, PreviewRow{Label: item.LayerName + " → " + item.TechnicalRole, Value: fmt.Sprintf("%d VM", item.VMCount)})
		}
		sections = append(sections, PreviewSection{Title: "Layer-e și roluri tehnice", Rows: rows})
	}
	if len(service.VMs) > 0 {
		rows := make([]PreviewRow, 0, len(service.VMs))
		for _, vm := range service.VMs {
			rows = append(rows, PreviewRow{Label: firstNonEmpty(vm.GuestHostname, vm.Name), Value: strings.Join(nonEmpty(vm.ArchitecturalDomain, vm.ITILCategory, vm.LayerName, vm.TechnicalRole, vm.SolutionType, vm.UsageType), " → ")})
		}
		sections = append(sections, PreviewSection{Title: "VM-uri asociate", Rows: rows})
	}
	return sections
}

func serviceIdentityRows(data ServiceGenerationData) []PreviewRow {
	service := data.Service
	active := "Nu"
	if service.Active {
		active = "Da"
	}
	return []PreviewRow{
		{Label: "Serviciu intern", Value: service.Name},
		{Label: "Cod intern", Value: service.ServiceCode},
		{Label: "Criticitate", Value: service.Criticality},
		{Label: "Status documentație", Value: service.DocumentationStatus},
		{Label: "Activ", Value: active},
		{Label: "Descriere", Value: service.Description},
		{Label: "Documentație existentă", Value: service.DocumentationURL},
		{Label: "VM-uri asociate", Value: strconv.Itoa(service.VMCount)},
	}
}

func RenderServiceDOCX(template []byte, data ServiceGenerationData) ([]byte, error) {
	if err := ValidateTemplateFor(template, "service"); err != nil {
		return nil, err
	}
	reader, err := zip.NewReader(bytes.NewReader(template), int64(len(template)))
	if err != nil {
		return nil, err
	}
	var output bytes.Buffer
	writer := zip.NewWriter(&output)
	tokens := serviceScalarTokens(data)
	body := serviceDocumentBodyXML(data)
	bodyReplaced := false
	for _, source := range reader.File {
		content, err := readZipFile(source, 64<<20)
		if err != nil {
			writer.Close()
			return nil, err
		}
		if strings.HasSuffix(source.Name, ".xml") {
			text := string(content)
			for token, value := range tokens {
				text = strings.ReplaceAll(text, token, xmlText(value))
			}
			if source.Name == "word/document.xml" {
				if replaced, ok := replaceServiceBodyParagraph(text, body); ok {
					text = replaced
					bodyReplaced = true
				}
			}
			if source.Name == "docProps/core.xml" {
				text = updateServiceCoreProperties(text, data)
			}
			content = []byte(text)
		}
		header := source.FileHeader
		header.CRC32 = 0
		header.CompressedSize = 0
		header.CompressedSize64 = 0
		header.UncompressedSize = 0
		header.UncompressedSize64 = 0
		header.SetModTime(data.GeneratedAt)
		destination, err := writer.CreateHeader(&header)
		if err != nil {
			writer.Close()
			return nil, err
		}
		if _, err := destination.Write(content); err != nil {
			writer.Close()
			return nil, err
		}
	}
	if !bodyReplaced {
		writer.Close()
		return nil, fmt.Errorf("template placeholder %s was not found as a complete paragraph", ServiceBodyPlaceholder)
	}
	if err := writer.Close(); err != nil {
		return nil, err
	}
	return output.Bytes(), nil
}

func replaceServiceBodyParagraph(documentXML, body string) (string, bool) {
	placeholder := strings.Index(documentXML, ServiceBodyPlaceholder)
	if placeholder < 0 {
		return documentXML, false
	}
	start := paragraphStart(documentXML[:placeholder])
	if start < 0 {
		return documentXML, false
	}
	endOffset := strings.Index(documentXML[placeholder:], "</w:p>")
	if endOffset < 0 {
		return documentXML, false
	}
	end := placeholder + endOffset + len("</w:p>")
	return documentXML[:start] + body + documentXML[end:], true
}

func serviceScalarTokens(data ServiceGenerationData) map[string]string {
	service := data.Service
	return map[string]string{
		"{{document.number}}":       data.DocumentNumber,
		"{{document.generated_at}}": formatTime(data.GeneratedAt),
		"{{document.generated_by}}": firstNonEmpty(data.GeneratedBy.DisplayName, data.GeneratedBy.Username),
		"{{service.name}}":          service.Name,
		"{{service.code}}":          service.ServiceCode,
		"{{service.criticality}}":   service.Criticality,
		"{{service.status}}":        service.DocumentationStatus,
		"{{service.description}}":   service.Description,
		"{{service.purpose}}":       service.Purpose,
		"{{service.scope_domain}}":  service.Purpose,
		"{{service.objectives}}":    service.Objectives,
		"{{service.documentation}}": service.DocumentationURL,
	}
}

func serviceDocumentBodyXML(data ServiceGenerationData) string {
	service := data.Service
	var out strings.Builder
	out.WriteString(infoParagraph("Număr document", data.DocumentNumber))
	out.WriteString(infoParagraph("Generat la", formatTime(data.GeneratedAt)))
	out.WriteString(infoParagraph("Generat de", firstNonEmpty(data.GeneratedBy.DisplayName, data.GeneratedBy.Username)))
	out.WriteString(heading("1. Identificare serviciu", 1))
	out.WriteString(keyValueTable(serviceIdentityRows(data)))

	out.WriteString(heading("2. Scop, domeniu și obiective", 1))
	out.WriteString(serviceNarrativeBox("Scop și domeniu", service.Purpose))
	out.WriteString(serviceNarrativeBox("Obiective", service.Objectives))

	out.WriteString(heading("3. Schemă logică a serviciului", 1))
	if len(service.VMs) == 0 {
		out.WriteString(paragraph("Schema nu poate fi generată deoarece serviciul nu are VM-uri asociate.", "IntenseQuote"))
	} else {
		out.WriteString(paragraph("Schema este generată automat din asocierile VM. Fiecare VM apare o singură dată; dacă are mai multe asocieri, toate rolurile sunt afișate în același nod.", "IntenseQuote"))
		out.WriteString(serviceDiagramXML(service.VMs))
	}

	out.WriteString(heading("4. Domenii și categorii de serviciu", 1))
	if len(service.Classifications) == 0 {
		out.WriteString(paragraph("Nu există clasificări observate din VM-urile asociate.", "IntenseQuote"))
	} else {
		rows := make([][]string, 0, len(service.Classifications))
		for _, item := range service.Classifications {
			rows = append(rows, []string{item.ArchitecturalDomain, item.ITILCategory, strconv.Itoa(item.VMCount), strconv.Itoa(item.AssignmentCount)})
		}
		out.WriteString(tableWithWidths([]string{"Domeniu", "Categorie de serviciu", "VM-uri", "Asocieri"}, rows, []int{2600, 3600, 1400, 1400}))
	}

	out.WriteString(heading("5. Tipuri de soluție", 1))
	if len(service.SolutionTypes) == 0 {
		out.WriteString(paragraph("Nu există tipuri de soluție definite pe asocierile VM.", "IntenseQuote"))
	} else {
		rows := make([][]string, 0, len(service.SolutionTypes))
		for _, item := range service.SolutionTypes {
			rows = append(rows, []string{item.SolutionType, strconv.Itoa(item.VMCount), strconv.Itoa(item.AssignmentCount)})
		}
		out.WriteString(tableWithWidths([]string{"Tip soluție", "VM-uri", "Asocieri"}, rows, []int{5400, 1800, 1800}))
	}

	out.WriteString(heading("6. Arhitectură tehnică observată", 1))
	if len(service.RoleMappings) == 0 {
		out.WriteString(paragraph("Nu există layer-e și roluri tehnice observate.", "IntenseQuote"))
	} else {
		rows := make([][]string, 0, len(service.RoleMappings))
		for _, item := range service.RoleMappings {
			rows = append(rows, []string{item.LayerName, item.TechnicalRole, strconv.Itoa(item.VMCount)})
		}
		out.WriteString(tableWithWidths([]string{"Layer", "Rol tehnic", "VM-uri"}, rows, []int{3000, 4500, 1500}))
	}

	out.WriteString(heading("7. VM-uri asociate", 1))
	if len(service.VMs) == 0 {
		out.WriteString(paragraph("Nu există VM-uri asociate serviciului.", "IntenseQuote"))
	} else {
		out.WriteString(serviceVMOverviewTable(service.VMs))
	}

	return out.String()
}

type serviceDiagramVM struct {
	ID          int64
	Name        string
	Hostname    string
	PrimaryIP   string
	PowerState  string
	Assignments []domain.InternalServiceVM
}

type serviceDiagramLane struct {
	Name string
	VMs  []serviceDiagramVM
}

func serviceDiagramXML(assignments []domain.InternalServiceVM) string {
	lanes := buildServiceDiagramLanes(assignments)
	var out strings.Builder
	for _, lane := range lanes {
		out.WriteString(serviceDiagramLaneHeader(lane.Name, len(lane.VMs)))
		for _, vm := range lane.VMs {
			out.WriteString(serviceDiagramVMTable(vm))
		}
	}
	return out.String()
}

func buildServiceDiagramLanes(assignments []domain.InternalServiceVM) []serviceDiagramLane {
	byVM := make(map[int64]*serviceDiagramVM)
	order := make([]int64, 0)
	for _, item := range assignments {
		vm := byVM[item.ID]
		if vm == nil {
			vm = &serviceDiagramVM{ID: item.ID, Name: item.Name, Hostname: item.GuestHostname, PrimaryIP: item.PrimaryIP, PowerState: item.PowerState}
			byVM[item.ID] = vm
			order = append(order, item.ID)
		}
		vm.Assignments = append(vm.Assignments, item)
	}

	laneMap := make(map[string]*serviceDiagramLane)
	for _, id := range order {
		vm := byVM[id]
		layerNames := make(map[string]bool)
		for _, item := range vm.Assignments {
			if name := strings.TrimSpace(item.LayerName); name != "" {
				layerNames[name] = true
			}
		}
		laneName := "Fără layer"
		if len(layerNames) == 1 {
			for name := range layerNames {
				laneName = name
			}
		} else if len(layerNames) > 1 {
			laneName = "Multi-layer"
		}
		lane := laneMap[laneName]
		if lane == nil {
			lane = &serviceDiagramLane{Name: laneName}
			laneMap[laneName] = lane
		}
		lane.VMs = append(lane.VMs, *vm)
	}

	lanes := make([]serviceDiagramLane, 0, len(laneMap))
	for _, lane := range laneMap {
		sort.SliceStable(lane.VMs, func(i, j int) bool {
			return strings.ToLower(firstNonEmpty(lane.VMs[i].Hostname, lane.VMs[i].Name)) < strings.ToLower(firstNonEmpty(lane.VMs[j].Hostname, lane.VMs[j].Name))
		})
		lanes = append(lanes, *lane)
	}
	sort.SliceStable(lanes, func(i, j int) bool {
		if lanes[i].Name == "Multi-layer" {
			return false
		}
		if lanes[j].Name == "Multi-layer" {
			return true
		}
		if lanes[i].Name == "Fără layer" {
			return false
		}
		if lanes[j].Name == "Fără layer" {
			return true
		}
		return strings.ToLower(lanes[i].Name) < strings.ToLower(lanes[j].Name)
	})
	return lanes
}

func serviceNarrativeBox(title, value string) string {
	value = strings.TrimSpace(value)
	if value == "" {
		value = "—"
	}
	return `<w:tbl><w:tblPr><w:tblW w:w="9000" w:type="dxa"/><w:tblLayout w:type="fixed"/><w:tblBorders><w:top w:val="single" w:sz="6" w:color="D8DEE8"/><w:left w:val="single" w:sz="6" w:color="D8DEE8"/><w:bottom w:val="single" w:sz="6" w:color="D8DEE8"/><w:right w:val="single" w:sz="6" w:color="D8DEE8"/></w:tblBorders></w:tblPr><w:tblGrid><w:gridCol w:w="9000"/></w:tblGrid>` +
		`<w:tr><w:trPr><w:cantSplit/></w:trPr><w:tc><w:tcPr><w:tcW w:w="9000" w:type="dxa"/><w:shd w:val="clear" w:fill="F7FAFC"/><w:tcMar><w:top w:w="120" w:type="dxa"/><w:left w:w="130" w:type="dxa"/><w:bottom w:w="120" w:type="dxa"/><w:right w:w="130" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:pPr><w:keepNext/><w:spacing w:after="80"/><w:pBdr><w:bottom w:val="single" w:sz="5" w:color="D8DEE8" w:space="4"/></w:pBdr></w:pPr><w:r><w:rPr><w:b/></w:rPr><w:t>` + xmlText(title) + `</w:t></w:r></w:p>` + serviceNarrativeParagraphs(value) + `</w:tc></w:tr></w:tbl><w:p/>`
}

func serviceNarrativeParagraphs(value string) string {
	lines := strings.Split(strings.ReplaceAll(value, "\r\n", "\n"), "\n")
	var out strings.Builder
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if line == "" {
			out.WriteString(`<w:p><w:pPr><w:spacing w:after="60"/></w:pPr></w:p>`)
			continue
		}
		out.WriteString(`<w:p><w:pPr><w:spacing w:after="70"/></w:pPr><w:r><w:t xml:space="preserve">` + xmlText(line) + `</w:t></w:r></w:p>`)
	}
	return out.String()
}

func serviceDiagramLaneHeader(name string, vmCount int) string {
	label := fmt.Sprintf("%s  ·  %d VM", emptyDash(name), vmCount)
	return `<w:tbl><w:tblPr><w:tblW w:w="9000" w:type="dxa"/><w:tblLayout w:type="fixed"/></w:tblPr><w:tblGrid><w:gridCol w:w="9000"/></w:tblGrid><w:tr><w:trPr><w:cantSplit/></w:trPr><w:tc><w:tcPr><w:tcW w:w="9000" w:type="dxa"/><w:shd w:val="clear" w:fill="DCE6F1"/><w:tcMar><w:top w:w="90" w:type="dxa"/><w:left w:w="120" w:type="dxa"/><w:bottom w:w="90" w:type="dxa"/><w:right w:w="120" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:r><w:rPr><w:b/><w:sz w:val="24"/></w:rPr><w:t>` + xmlText(label) + `</w:t></w:r></w:p></w:tc></w:tr></w:tbl>`
}

func serviceDiagramVMTable(vm serviceDiagramVM) string {
	name := firstNonEmpty(vm.Hostname, vm.Name, "VM")
	if vm.Name != "" && vm.Name != name {
		name += " (" + vm.Name + ")"
	}
	meta := strings.Join(nonEmpty(vm.PrimaryIP, vm.PowerState), " · ")
	var associations strings.Builder
	for index, item := range vm.Assignments {
		if index > 0 {
			associations.WriteString(`<w:p><w:pPr><w:spacing w:before="50" w:after="50"/><w:pBdr><w:top w:val="dashed" w:sz="4" w:color="D8DEE8"/></w:pBdr></w:pPr></w:p>`)
		}
		role := firstNonEmpty(item.TechnicalRole, "Rol nespecificat")
		layer := firstNonEmpty(item.LayerName, "Fără layer")
		context := strings.Join(nonEmpty(item.SolutionType, serviceClassificationText(item), serviceUsageLabel(item.UsageType)), " · ")
		if item.Primary {
			context = strings.TrimSpace(context + " · principal")
		}
		associations.WriteString(`<w:p><w:pPr><w:spacing w:after="20"/></w:pPr><w:r><w:rPr><w:b/></w:rPr><w:t>` + xmlText(role) + `</w:t></w:r><w:r><w:t xml:space="preserve">` + xmlText("  |  "+layer) + `</w:t></w:r></w:p>`)
		associations.WriteString(`<w:p><w:pPr><w:spacing w:after="20"/></w:pPr><w:r><w:rPr><w:color w:val="666666"/><w:sz w:val="18"/></w:rPr><w:t xml:space="preserve">` + xmlText(emptyDash(context)) + `</w:t></w:r></w:p>`)
	}
	return `<w:tbl><w:tblPr><w:tblW w:w="9000" w:type="dxa"/><w:tblLayout w:type="fixed"/><w:tblBorders><w:top w:val="single" w:sz="6" w:color="C9D1DC"/><w:left w:val="single" w:sz="6" w:color="C9D1DC"/><w:bottom w:val="single" w:sz="6" w:color="C9D1DC"/><w:right w:val="single" w:sz="6" w:color="C9D1DC"/><w:insideH w:val="single" w:sz="4" w:color="E3E7ED"/><w:insideV w:val="single" w:sz="4" w:color="E3E7ED"/></w:tblBorders></w:tblPr><w:tblGrid><w:gridCol w:w="2700"/><w:gridCol w:w="6300"/></w:tblGrid>` +
		`<w:tr><w:trPr><w:cantSplit/></w:trPr><w:tc><w:tcPr><w:tcW w:w="2700" w:type="dxa"/><w:shd w:val="clear" w:fill="F5F7FA"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="100" w:type="dxa"/><w:left w:w="110" w:type="dxa"/><w:bottom w:w="100" w:type="dxa"/><w:right w:w="110" w:type="dxa"/></w:tcMar></w:tcPr><w:p><w:r><w:rPr><w:b/></w:rPr><w:t>` + xmlText(name) + `</w:t></w:r></w:p><w:p><w:r><w:rPr><w:color w:val="666666"/><w:sz w:val="18"/></w:rPr><w:t>` + xmlText(emptyDash(meta)) + `</w:t></w:r></w:p></w:tc>` +
		`<w:tc><w:tcPr><w:tcW w:w="6300" w:type="dxa"/><w:vAlign w:val="top"/><w:tcMar><w:top w:w="90" w:type="dxa"/><w:left w:w="110" w:type="dxa"/><w:bottom w:w="90" w:type="dxa"/><w:right w:w="110" w:type="dxa"/></w:tcMar></w:tcPr>` + associations.String() + `</w:tc></w:tr></w:tbl><w:p/>`
}

func serviceVMOverviewTable(assignments []domain.InternalServiceVM) string {
	byVM := make(map[int64]*serviceDiagramVM)
	order := make([]int64, 0)
	for _, item := range assignments {
		vm := byVM[item.ID]
		if vm == nil {
			vm = &serviceDiagramVM{ID: item.ID, Name: item.Name, Hostname: item.GuestHostname, PrimaryIP: item.PrimaryIP, PowerState: item.PowerState}
			byVM[item.ID] = vm
			order = append(order, item.ID)
		}
		vm.Assignments = append(vm.Assignments, item)
	}
	sort.SliceStable(order, func(i, j int) bool {
		left := strings.ToLower(firstNonEmpty(byVM[order[i]].Hostname, byVM[order[i]].Name))
		right := strings.ToLower(firstNonEmpty(byVM[order[j]].Hostname, byVM[order[j]].Name))
		return left < right
	})
	rows := make([][]string, 0, len(order))
	for _, id := range order {
		vm := byVM[id]
		name := firstNonEmpty(vm.Hostname, vm.Name)
		identity := name
		if vm.PrimaryIP != "" {
			identity += " · " + vm.PrimaryIP
		}
		associationTexts := make([]string, 0, len(vm.Assignments))
		usageSeen := make(map[string]bool)
		usageTexts := make([]string, 0)
		primary := false
		for _, item := range vm.Assignments {
			associationTexts = append(associationTexts, strings.Join(nonEmpty(firstNonEmpty(item.LayerName, "Fără layer"), firstNonEmpty(item.TechnicalRole, "Rol nespecificat"), item.SolutionType), " / "))
			usage := serviceUsageLabel(item.UsageType)
			if usage != "" && !usageSeen[usage] {
				usageSeen[usage] = true
				usageTexts = append(usageTexts, usage)
			}
			primary = primary || item.Primary
		}
		usage := strings.Join(usageTexts, ", ")
		if primary {
			usage = strings.TrimSpace(usage + " · principal")
		}
		rows = append(rows, []string{identity, strings.Join(associationTexts, "; "), usage})
	}
	return tableWithWidths([]string{"VM / IP", "Asocieri tehnice", "Utilizare"}, rows, []int{2300, 5000, 1700})
}

func serviceClassificationText(item domain.InternalServiceVM) string {
	domainName := strings.TrimSpace(item.ArchitecturalDomain)
	categoryName := strings.TrimSpace(item.ITILCategory)
	if domainName == "" {
		return categoryName
	}
	if categoryName == "" {
		return domainName
	}
	return domainName + " / " + categoryName
}

func serviceUsageLabel(value string) string {
	switch strings.ToLower(strings.TrimSpace(value)) {
	case "dedicated":
		return "Dedicat"
	case "shared":
		return "Partajat"
	case "dependency":
		return "Dependență"
	default:
		return strings.TrimSpace(value)
	}
}

func updateServiceCoreProperties(text string, data ServiceGenerationData) string {
	text = replaceXMLTag(text, "dc:title", "Fișă serviciu intern — "+data.Service.Name)
	text = replaceXMLTag(text, "dc:creator", firstNonEmpty(data.GeneratedBy.DisplayName, data.GeneratedBy.Username, "vm-doc-server"))
	text = replaceXMLTag(text, "cp:lastModifiedBy", firstNonEmpty(data.GeneratedBy.DisplayName, data.GeneratedBy.Username, "vm-doc-server"))
	text = replaceXMLTag(text, "dcterms:modified", data.GeneratedAt.UTC().Format("2006-01-02T15:04:05Z"))
	return text
}

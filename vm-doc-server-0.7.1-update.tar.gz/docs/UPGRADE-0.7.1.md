# Upgrade la vm-doc-server 0.7.1

Versiunea 0.7.1 completează fișa Serviciului intern cu informații narative și include schema logică direct în documentul DOCX generat.

## Migrare MariaDB

La prima pornire, serverul aplică:

```text
021_service_scope_objectives_docx_diagram.up.sql
```

Migrarea adaugă coloana `internal_services.objectives`. Câmpul existent `purpose` nu este mutat și nu este șters; începând cu 0.7.1 acesta este afișat ca **Scop și domeniu**, astfel încât valorile deja introduse sunt păstrate integral.

## După upgrade

1. Deschideți un Serviciu intern și completați **Scop și domeniu** și **Obiective**.
2. Verificați schema serviciului din interfață.
3. Generați o fișă DOCX. Documentul trebuie să conțină secțiunile **Scop, domeniu și obiective** și **Schemă logică a serviciului**.
4. Pentru un VM cu două sau mai multe asocieri, schema DOCX trebuie să afișeze un singur nod VM, cu toate rolurile în același nod.

## Compatibilitate șabloane

Șabloanele existente care conțin `{{SERVICE_DOCUMENT_BODY}}` rămân compatibile. Sunt disponibile și placeholderele scalare:

```text
{{service.scope_domain}}
{{service.objectives}}
```

`{{service.purpose}}` rămâne disponibil ca alias pentru `{{service.scope_domain}}`.

package server

import (
	"testing"

	"vm-doc-server/internal/domain"
)

func TestNomenclatureExportRowsIncludesRelations(t *testing.T) {
	rows := nomenclatureExportRows(domain.NomenclatureCategory{
		Code:  "technical_role",
		Label: "Roluri tehnice",
		Items: []domain.NomenclatureValue{{ID: 7, Name: "PostgreSQL", LayerNames: []string{"Bază de date"}, SortOrder: 10, Active: true}},
	})
	if len(rows) != 2 || len(rows[0]) != 7 {
		t.Fatalf("unexpected export dimensions: %d x %d", len(rows), len(rows[0]))
	}
	if rows[0][2].Text != "Layer-e permise" || rows[1][2].Text != "Bază de date" {
		t.Fatalf("relation column was not exported: %#v", rows)
	}
}

func TestPeopleExportRows(t *testing.T) {
	rows := peopleExportRows([]domain.Person{{ID: 3, DisplayName: "Ion Test", Department: "IT", Source: "ldap", Active: true}})
	if len(rows) != 2 || rows[1][1].Text != "Ion Test" || rows[1][2].Text != "IT" {
		t.Fatalf("unexpected people export: %#v", rows)
	}
}

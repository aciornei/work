Pachet Metabase v4

Păstrați toate fișierele în același director pentru ca linkurile relative din documentul principal să funcționeze.
După identificarea hostname-urilor Nginx și PostgreSQL, redenumiți fișele și actualizați linkurile din documentul principal.

# Generarea fișelor DOCX

În 0.6.0 același motor generează două tipuri de documente: **fișa tehnică VM** și **fișa Serviciului intern**. Șabloanele sunt separate prin `object_type=vm|service`, iar fiecare tip are propriul șablon implicit.

## Flux VM

```text
Fișa VM
└── alegere șablon DOCX
    ├── previzualizare date
    └── generare DOCX
        ├── număr unic
        ├── SHA-256
        ├── snapshot inventar sursă
        ├── autor și dată
        └── istoric și descărcare
```

## Date incluse

- identificare și resurse din vCenter;
- hostname, IP și sistem de operare din inventarul agentului, cu fallback la vCenter;
- mediu, status operațional, clasificare, scop și observații;
- domeniu, categorie de serviciu, serviciu intern, layer, rol tehnic și tip soluție;
- responsabilități și date de contact;
- backup și restaurare;
- inventarul structurat al agentului, cu mascarea valorilor sensibile realizată de `inventory.BuildDocumentView`.

## Șablonul DOCX

Șablonul trebuie să fie un fișier `.docx` valid și să conțină, într-un paragraf separat:

```text
{{VM_DOCUMENT_BODY}}
```

Paragraful este înlocuit cu toate secțiunile generate. Pentru rezultate previzibile, placeholderul nu trebuie formatat pe bucăți diferite în Word.

Placeholdere scalare disponibile:

```text
{{document.number}}
{{document.generated_at}}
{{document.generated_by}}
{{vm.name}}
{{vm.hostname}}
{{vm.ip}}
{{vm.os}}
{{vm.environment}}
{{vm.status}}
{{vm.classification}}
{{vm.purpose}}
```

Placeholderele scalare trebuie și ele păstrate într-un singur segment de text Word.

## Flux Serviciu intern

```text
Pagina Serviciului intern
└── alegere șablon DOCX de tip service
    ├── previzualizare date agregate
    └── generare DOCX
        ├── număr unic FSI-*
        ├── SHA-256
        ├── autor și dată
        └── istoric și descărcare
```

Fișa serviciului include identificarea, domeniile și categoriile observate, tipurile de soluție, combinațiile layer–rol și VM-urile asociate. Datele sunt calculate din asocierile existente ale VM-urilor, nu duplicate manual pe serviciu.

Șablonul de serviciu trebuie să conțină într-un paragraf separat:

```text
{{SERVICE_DOCUMENT_BODY}}
```

Placeholdere scalare suplimentare pentru serviciu:

```text
{{service.name}}
{{service.code}}
{{service.criticality}}
{{service.status}}
{{service.description}}
{{service.purpose}}
```


## Securitate

- șabloanele și documentele sunt stocate în MariaDB;
- fișierele generate păstrează SHA-256 și dimensiunea;
- generarea și descărcarea sunt auditate;
- valorile din inventar cu nume de tip `password`, `secret`, `token`, `credential`, `private_key`, `api_key` sau `access_key` sunt redactate înainte de generare;
- accesul este controlat prin `documents.read` și `documents.manage`.

## Structura compactă a inventarului în 0.5.1

```text
6.1  Schema inventar
6.3  Sistem și hardware
6.4  Sistem de operare
6.5  Stocare
6.6  Rețea
6.8  Servicii active
6.9  Porturi ascultate
6.10 Firewall UFW
6.11 Conturi importante
6.12 Integrare SSSD
6.13 Integrări operaționale
6.14 Politici
6.15 Sarcini programate
6.16 Sincronizare timp
```

Secțiunile 6.2 Agent și 6.7 Proxy nu mai sunt incluse. Datele sunt filtrate și prezentate în tabele cu lățimi fixe. Valorile numerice de capacitate sunt transformate automat în KB, MB, GB sau TB.

## Limitări 0.6.0

- se generează numai DOCX;
- conversia PDF și semnarea digitală vor fi implementate ulterior;
- șablonul personalizat trebuie să păstreze placeholderul principal într-un paragraf separat;
- documentele foarte mari pot crește dimensiunea bazei MariaDB, deoarece conținutul este păstrat pentru audit și redescărcare.

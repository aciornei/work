# Upgrade la vm-doc-server 0.6.0

Versiunea 0.6.0 adaugă tipul soluției pe asocierile VM–serviciu și generarea fișei DOCX pentru Serviciul intern.

## Migrare MariaDB

La prima pornire, serverul aplică:

```text
019_service_documents_solution_type.up.sql
```

Migrarea:

- creează nomenclatorul `solution_type`;
- adaugă `solution_type_id` în `vm_internal_service_assignments`;
- tipizează șabloanele DOCX prin `document_templates.object_type`;
- permite documente care aparțin unui VM sau unui Serviciu intern;
- păstrează toate șabloanele și documentele VM existente ca `object_type=vm`.

Asocierile VM existente rămân nemodificate și au inițial `solution_type_id=NULL`. La prima editare a asocierilor unui VM trebuie ales tipul soluției pentru fiecare rând.

## Înainte de upgrade

```bash
sudo systemctl stop vm-doc-collector vm-doc-server
```

Faceți backup pentru binare, configurație și MariaDB.

## Instalare

Înlocuiți sursa/binarul cu versiunea 0.6.0, compilați în mediul offline și porniți serverul. Migrarea se aplică automat.

```bash
make build
sudo systemctl start vm-doc-server vm-doc-collector
```

## Verificări după upgrade

1. În **Nomenclatoare → Arhitectură tehnică → Tip soluție** trebuie să apară cele trei valori inițiale.
2. În fișa unui VM, secțiunea de servicii trebuie să fie afișată în carduri și să permită alegerea Tipului soluției.
3. În pagina unui Serviciu intern trebuie să apară agregarea tipurilor de soluție.
4. În **Documente** trebuie să existe câte un șablon implicit pentru VM și pentru Serviciu intern.
5. Din pagina Serviciului intern trebuie să funcționeze previzualizarea și generarea unei fișe `FSI-*.docx`.

## Compatibilitate

Fișele VM existente și istoricul lor sunt păstrate. Șablonul VM continuă să folosească `{{VM_DOCUMENT_BODY}}`; șablonul serviciului folosește `{{SERVICE_DOCUMENT_BODY}}`.

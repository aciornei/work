package documents

import (
	"archive/zip"
	"bytes"
	"fmt"
	"io"
	"strconv"
	"strings"
)

func DefaultServiceTemplate() ([]byte, error) {
	files := map[string]string{
		"[Content_Types].xml":          `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>`,
		"_rels/.rels":                  `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>`,
		"word/_rels/document.xml.rels": `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`,
		"word/styles.xml":              stylesXML,
		"word/document.xml":            `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:pPr><w:pStyle w:val="Title"/></w:pPr><w:r><w:t>Fișă serviciu intern</w:t></w:r></w:p><w:p><w:r><w:t>{{SERVICE_DOCUMENT_BODY}}</w:t></w:r></w:p><w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr></w:body></w:document>`,
		"docProps/core.xml":            `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>Fișă serviciu intern</dc:title><dc:creator>vm-doc-server</dc:creator><cp:lastModifiedBy>vm-doc-server</cp:lastModifiedBy><dcterms:created xsi:type="dcterms:W3CDTF">2026-01-01T00:00:00Z</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">2026-01-01T00:00:00Z</dcterms:modified></cp:coreProperties>`,
		"docProps/app.xml":             `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"><Application>vm-doc-server</Application><DocSecurity>0</DocSecurity><ScaleCrop>false</ScaleCrop><Company></Company><LinksUpToDate>false</LinksUpToDate><SharedDoc>false</SharedDoc><HyperlinksChanged>false</HyperlinksChanged><AppVersion>0.6.0</AppVersion></Properties>`,
	}
	var output bytes.Buffer
	writer := zip.NewWriter(&output)
	order := []string{"[Content_Types].xml", "_rels/.rels", "word/document.xml", "word/styles.xml", "word/_rels/document.xml.rels", "docProps/core.xml", "docProps/app.xml"}
	for _, name := range order {
		entry, err := writer.Create(name)
		if err != nil {
			return nil, err
		}
		if _, err := io.WriteString(entry, files[name]); err != nil {
			return nil, err
		}
	}
	if err := writer.Close(); err != nil {
		return nil, err
	}
	return output.Bytes(), nil
}

func BuildServicePreview(template Template, data ServiceGenerationData) ServicePreview {
	preview := ServicePreview{
		InternalServiceID:   data.Service.ID,
		InternalServiceName: data.Service.Name,
		TemplateID:          template.ID,
		TemplateName:        template.Name,
		DocumentNumber:      data.DocumentNumber,
		GeneratedAt:         data.GeneratedAt,
		Warnings:            make([]string, 0),
		Sections:            servicePreviewSections(data),
	}
	if len(data.Service.VMs) == 0 {
		preview.Warnings = append(preview.Warnings, "Serviciul nu are VM-uri asociate.")
	}
	if len(data.Service.Classifications) == 0 {
		preview.Warnings = append(preview.Warnings, "Serviciul nu are încă domenii și categorii observate din VM-uri.")
	}
	if len(data.Service.SolutionTypes) == 0 {
		preview.Warnings = append(preview.Warnings, "Nu este definit încă niciun tip de soluție pe asocierile VM ale serviciului.")
	}
	return preview
}

func servicePreviewSections(data ServiceGenerationData) []PreviewSection {
	service := data.Service
	sections := []PreviewSection{
		{Title: "Document", Rows: []PreviewRow{{Label: "Număr", Value: data.DocumentNumber}, {Label: "Generat la", Value: formatTime(data.GeneratedAt)}, {Label: "Generat de", Value: firstNonEmpty(data.GeneratedBy.DisplayName, data.GeneratedBy.Username)}}},
		{Title: "Identificare serviciu", Rows: serviceIdentityRows(data)},
	}
	if len(service.Classifications) > 0 {
		rows := make([]PreviewRow, 0, len(service.Classifications))
		for _, item := range service.Classifications {
			rows = append(rows, PreviewRow{Label: item.ArchitecturalDomain + " / " + item.ITILCategory, Value: fmt.Sprintf("%d VM · %d asocieri", item.VMCount, item.AssignmentCount)})
		}
		sections = append(sections, PreviewSection{Title: "Domenii și categorii observate", Rows: rows})
	}
	if len(service.SolutionTypes) > 0 {
		rows := make([]PreviewRow, 0, len(service.SolutionTypes))
		for _, item := range service.SolutionTypes {
			rows = append(rows, PreviewRow{Label: item.SolutionType, Value: fmt.Sprintf("%d VM · %d asocieri", item.VMCount, item.AssignmentCount)})
		}
		sections = append(sections, PreviewSection{Title: "Tipuri de soluție", Rows: rows})
	}
	if len(service.RoleMappings) > 0 {
		rows := make([]PreviewRow, 0, len(service.RoleMappings))
		for _, item := range service.RoleMappings {
			rows = append(rows, PreviewRow{Label: item.LayerName + " → " + item.TechnicalRole, Value: fmt.Sprintf("%d VM", item.VMCount)})
		}
		sections = append(sections, PreviewSection{Title: "Layer-e și roluri tehnice", Rows: rows})
	}
	if len(service.VMs) > 0 {
		rows := make([]PreviewRow, 0, len(service.VMs))
		for _, vm := range service.VMs {
			rows = append(rows, PreviewRow{Label: firstNonEmpty(vm.GuestHostname, vm.Name), Value: strings.Join(nonEmpty(vm.ArchitecturalDomain, vm.ITILCategory, vm.LayerName, vm.TechnicalRole, vm.SolutionType, vm.UsageType), " → ")})
		}
		sections = append(sections, PreviewSection{Title: "VM-uri asociate", Rows: rows})
	}
	return sections
}

func serviceIdentityRows(data ServiceGenerationData) []PreviewRow {
	service := data.Service
	active := "Nu"
	if service.Active {
		active = "Da"
	}
	return []PreviewRow{
		{Label: "Serviciu intern", Value: service.Name},
		{Label: "Cod intern", Value: service.ServiceCode},
		{Label: "Criticitate", Value: service.Criticality},
		{Label: "Status documentație", Value: service.DocumentationStatus},
		{Label: "Activ", Value: active},
		{Label: "Descriere", Value: service.Description},
		{Label: "Scop", Value: service.Purpose},
		{Label: "Documentație existentă", Value: service.DocumentationURL},
		{Label: "VM-uri asociate", Value: strconv.Itoa(service.VMCount)},
	}
}

func RenderServiceDOCX(template []byte, data ServiceGenerationData) ([]byte, error) {
	if err := ValidateTemplateFor(template, "service"); err != nil {
		return nil, err
	}
	reader, err := zip.NewReader(bytes.NewReader(template), int64(len(template)))
	if err != nil {
		return nil, err
	}
	var output bytes.Buffer
	writer := zip.NewWriter(&output)
	tokens := serviceScalarTokens(data)
	body := serviceDocumentBodyXML(data)
	bodyReplaced := false
	for _, source := range reader.File {
		content, err := readZipFile(source, 64<<20)
		if err != nil {
			writer.Close()
			return nil, err
		}
		if strings.HasSuffix(source.Name, ".xml") {
			text := string(content)
			for token, value := range tokens {
				text = strings.ReplaceAll(text, token, xmlText(value))
			}
			if source.Name == "word/document.xml" {
				if replaced, ok := replaceServiceBodyParagraph(text, body); ok {
					text = replaced
					bodyReplaced = true
				}
			}
			if source.Name == "docProps/core.xml" {
				text = updateServiceCoreProperties(text, data)
			}
			content = []byte(text)
		}
		header := source.FileHeader
		header.CRC32 = 0
		header.CompressedSize = 0
		header.CompressedSize64 = 0
		header.UncompressedSize = 0
		header.UncompressedSize64 = 0
		header.SetModTime(data.GeneratedAt)
		destination, err := writer.CreateHeader(&header)
		if err != nil {
			writer.Close()
			return nil, err
		}
		if _, err := destination.Write(content); err != nil {
			writer.Close()
			return nil, err
		}
	}
	if !bodyReplaced {
		writer.Close()
		return nil, fmt.Errorf("template placeholder %s was not found as a complete paragraph", ServiceBodyPlaceholder)
	}
	if err := writer.Close(); err != nil {
		return nil, err
	}
	return output.Bytes(), nil
}

func replaceServiceBodyParagraph(documentXML, body string) (string, bool) {
	placeholder := strings.Index(documentXML, ServiceBodyPlaceholder)
	if placeholder < 0 {
		return documentXML, false
	}
	start := paragraphStart(documentXML[:placeholder])
	if start < 0 {
		return documentXML, false
	}
	endOffset := strings.Index(documentXML[placeholder:], "</w:p>")
	if endOffset < 0 {
		return documentXML, false
	}
	end := placeholder + endOffset + len("</w:p>")
	return documentXML[:start] + body + documentXML[end:], true
}

func serviceScalarTokens(data ServiceGenerationData) map[string]string {
	service := data.Service
	return map[string]string{
		"{{document.number}}":       data.DocumentNumber,
		"{{document.generated_at}}": formatTime(data.GeneratedAt),
		"{{document.generated_by}}": firstNonEmpty(data.GeneratedBy.DisplayName, data.GeneratedBy.Username),
		"{{service.name}}":          service.Name,
		"{{service.code}}":          service.ServiceCode,
		"{{service.criticality}}":   service.Criticality,
		"{{service.status}}":        service.DocumentationStatus,
		"{{service.description}}":   service.Description,
		"{{service.purpose}}":       service.Purpose,
		"{{service.documentation}}": service.DocumentationURL,
	}
}

func serviceDocumentBodyXML(data ServiceGenerationData) string {
	service := data.Service
	var out strings.Builder
	out.WriteString(infoParagraph("Număr document", data.DocumentNumber))
	out.WriteString(infoParagraph("Generat la", formatTime(data.GeneratedAt)))
	out.WriteString(infoParagraph("Generat de", firstNonEmpty(data.GeneratedBy.DisplayName, data.GeneratedBy.Username)))
	out.WriteString(heading("1. Identificare serviciu", 1))
	out.WriteString(keyValueTable(serviceIdentityRows(data)))

	out.WriteString(heading("2. Domenii și categorii de serviciu", 1))
	if len(service.Classifications) == 0 {
		out.WriteString(paragraph("Nu există clasificări observate din VM-urile asociate.", "IntenseQuote"))
	} else {
		rows := make([][]string, 0, len(service.Classifications))
		for _, item := range service.Classifications {
			rows = append(rows, []string{item.ArchitecturalDomain, item.ITILCategory, strconv.Itoa(item.VMCount), strconv.Itoa(item.AssignmentCount)})
		}
		out.WriteString(tableWithWidths([]string{"Domeniu", "Categorie de serviciu", "VM-uri", "Asocieri"}, rows, []int{2600, 3600, 1400, 1400}))
	}

	out.WriteString(heading("3. Tipuri de soluție", 1))
	if len(service.SolutionTypes) == 0 {
		out.WriteString(paragraph("Nu există tipuri de soluție definite pe asocierile VM.", "IntenseQuote"))
	} else {
		rows := make([][]string, 0, len(service.SolutionTypes))
		for _, item := range service.SolutionTypes {
			rows = append(rows, []string{item.SolutionType, strconv.Itoa(item.VMCount), strconv.Itoa(item.AssignmentCount)})
		}
		out.WriteString(tableWithWidths([]string{"Tip soluție", "VM-uri", "Asocieri"}, rows, []int{5400, 1800, 1800}))
	}

	out.WriteString(heading("4. Arhitectură tehnică observată", 1))
	if len(service.RoleMappings) == 0 {
		out.WriteString(paragraph("Nu există layer-e și roluri tehnice observate.", "IntenseQuote"))
	} else {
		rows := make([][]string, 0, len(service.RoleMappings))
		for _, item := range service.RoleMappings {
			rows = append(rows, []string{item.LayerName, item.TechnicalRole, strconv.Itoa(item.VMCount)})
		}
		out.WriteString(tableWithWidths([]string{"Layer", "Rol tehnic", "VM-uri"}, rows, []int{3000, 4500, 1500}))
	}

	out.WriteString(heading("5. VM-uri asociate", 1))
	if len(service.VMs) == 0 {
		out.WriteString(paragraph("Nu există VM-uri asociate serviciului.", "IntenseQuote"))
	} else {
		rows := make([][]string, 0, len(service.VMs))
		for _, vm := range service.VMs {
			primary := "Nu"
			if vm.Primary {
				primary = "Da"
			}
			rows = append(rows, []string{firstNonEmpty(vm.GuestHostname, vm.Name), vm.PrimaryIP, vm.LayerName, vm.TechnicalRole, vm.SolutionType, vm.UsageType, primary})
		}
		out.WriteString(tableWithWidths([]string{"VM / hostname", "IP", "Layer", "Rol tehnic", "Tip soluție", "Utilizare", "Principal"}, rows, []int{1900, 1250, 1100, 1600, 1350, 1000, 800}))
	}

	out.WriteString(heading("6. Observații de documentare", 1))
	out.WriteString(paragraph("Domeniile, categoriile, layer-ele, rolurile tehnice și tipurile de soluție sunt agregate automat din asocierile VM ale serviciului. Dependențele, responsabilitățile proprii serviciului și continuitatea extinsă pot fi adăugate în versiunile următoare.", "IntenseQuote"))
	out.WriteString(paragraph("Document generat automat de vm-doc-server. Datele trebuie validate conform procedurilor interne înainte de aprobare.", "IntenseQuote"))
	return out.String()
}

func updateServiceCoreProperties(text string, data ServiceGenerationData) string {
	text = replaceXMLTag(text, "dc:title", "Fișă serviciu intern — "+data.Service.Name)
	text = replaceXMLTag(text, "dc:creator", firstNonEmpty(data.GeneratedBy.DisplayName, data.GeneratedBy.Username, "vm-doc-server"))
	text = replaceXMLTag(text, "cp:lastModifiedBy", firstNonEmpty(data.GeneratedBy.DisplayName, data.GeneratedBy.Username, "vm-doc-server"))
	text = replaceXMLTag(text, "dcterms:modified", data.GeneratedAt.UTC().Format("2006-01-02T15:04:05Z"))
	return text
}

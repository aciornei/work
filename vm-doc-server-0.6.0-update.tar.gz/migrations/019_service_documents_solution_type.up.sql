-- 0.6.0: tipul soluției pe asocierea VM-serviciu și fișe DOCX pentru servicii interne.

INSERT IGNORE INTO nomenclature_categories(code,label,sort_order,active) VALUES
 ('solution_type','Tip soluție',45,1);

INSERT IGNORE INTO nomenclature_items(category_code,name,item_code,description,sort_order,active) VALUES
 ('solution_type','Open source','open_source','Soluție bazată în principal pe software open source.',10,1),
 ('solution_type','Dezvoltată intern','internal_development','Soluție dezvoltată și întreținută intern.',20,1),
 ('solution_type','Comercială','commercial','Soluție comercială/licențiată furnizată de un producător extern.',30,1);

ALTER TABLE vm_internal_service_assignments
  ADD COLUMN IF NOT EXISTS solution_type_id BIGINT UNSIGNED NULL AFTER technical_role_id,
  ADD INDEX IF NOT EXISTS idx_vm_service_assignment_solution_type (solution_type_id);

SET @ddl = IF(
  (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
   WHERE CONSTRAINT_SCHEMA=DATABASE()
     AND TABLE_NAME='vm_internal_service_assignments'
     AND CONSTRAINT_NAME='fk_vm_service_assignment_solution_type')=0,
  'ALTER TABLE vm_internal_service_assignments ADD CONSTRAINT fk_vm_service_assignment_solution_type FOREIGN KEY (solution_type_id) REFERENCES nomenclature_items(id)',
  'SELECT 1'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

ALTER TABLE document_templates
  ADD COLUMN IF NOT EXISTS object_type VARCHAR(32) NOT NULL DEFAULT 'vm' AFTER template_code,
  ADD INDEX IF NOT EXISTS idx_document_templates_object_type (object_type,active,is_default,name);

ALTER TABLE generated_documents
  MODIFY COLUMN vm_id BIGINT UNSIGNED NULL,
  ADD COLUMN IF NOT EXISTS object_type VARCHAR(32) NOT NULL DEFAULT 'vm' AFTER id,
  ADD COLUMN IF NOT EXISTS internal_service_id BIGINT UNSIGNED NULL AFTER vm_id,
  ADD INDEX IF NOT EXISTS idx_generated_documents_service_date (internal_service_id,generated_at,id);

SET @ddl = IF(
  (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
   WHERE CONSTRAINT_SCHEMA=DATABASE()
     AND TABLE_NAME='generated_documents'
     AND CONSTRAINT_NAME='fk_generated_documents_internal_service')=0,
  'ALTER TABLE generated_documents ADD CONSTRAINT fk_generated_documents_internal_service FOREIGN KEY (internal_service_id) REFERENCES internal_services(id) ON DELETE CASCADE',
  'SELECT 1'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

UPDATE document_templates SET object_type='vm' WHERE object_type='' OR object_type IS NULL;
UPDATE generated_documents SET object_type='vm' WHERE object_type='' OR object_type IS NULL;

UPDATE permissions SET description='Vizualizare și descărcare fișe VM și servicii interne generate' WHERE name='documents.read';
UPDATE permissions SET description='Administrare șabloane și generare fișe VM și servicii interne' WHERE name='documents.manage';

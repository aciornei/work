const state={user:null,csrf:'',agents:[],sources:[],vms:[],documentTemplates:[],vmFilters:{q:'',power:'',agent:'',sourceId:'',page:1,pageSize:50},vmHistory:{vmId:0,page:1,pageSize:20},audit:{page:1,pageSize:50},nomenclaturePaging:{},nomenclatureFilters:{}};
const content=document.getElementById('content');
const title=document.getElementById('pageTitle');
const subtitle=document.getElementById('pageSubtitle');
const agentDialog=document.getElementById('agentDialog');
const agentForm=document.getElementById('agentForm');
const vcenterDialog=document.getElementById('vcenterDialog');
const vcenterForm=document.getElementById('vcenterForm');
const nomenclatureDialog=document.getElementById('nomenclatureDialog');
const nomenclatureForm=document.getElementById('nomenclatureForm');
const personDialog=document.getElementById('personDialog');
const personForm=document.getElementById('personForm');
const directoryDialog=document.getElementById('directoryDialog');
const directoryForm=document.getElementById('directoryForm');
const internalServiceDialog=document.getElementById('internalServiceDialog');
const internalServiceForm=document.getElementById('internalServiceForm');
const documentTemplateDialog=document.getElementById('documentTemplateDialog');
const documentTemplateForm=document.getElementById('documentTemplateForm');
const documentPreviewDialog=document.getElementById('documentPreviewDialog');

const rolePermissions={
  admin:new Set(['*']),
  operator:new Set(['dashboard.read','agents.read','agents.manage','collections.read','collections.run','inventories.read','inventories.raw.read','vcenter.read','vcenter.manage','vms.manage','nomenclatures.read','services.read','services.manage','documents.read','documents.manage']),
  viewer:new Set(['dashboard.read','agents.read','collections.read','inventories.read','vcenter.read','nomenclatures.read','services.read','documents.read']),
  auditor:new Set(['dashboard.read','agents.read','collections.read','inventories.read','inventories.raw.read','audit.read','vcenter.read','nomenclatures.read','services.read','documents.read'])
};
function can(permission){return (state.user?.roles||[]).some(role=>rolePermissions[role]?.has('*')||rolePermissions[role]?.has(permission))}

async function api(path,options={}){
  const headers={Accept:'application/json',...(options.headers||{})};
  if(options.body&&!(options.body instanceof FormData)&&!headers['Content-Type'])headers['Content-Type']='application/json';
  if(!['GET','HEAD'].includes((options.method||'GET').toUpperCase())&&state.csrf)headers['X-CSRF-Token']=state.csrf;
  const response=await fetch(path,{...options,headers});
  if(response.status===401){location.href='/login';throw new Error('Sesiunea a expirat.');}
  const type=response.headers.get('content-type')||'';
  const body=response.status===204?null:type.includes('json')?await response.json():await response.text();
  if(!response.ok)throw new Error(body?.message||body?.error||`HTTP ${response.status}`);
  return body;
}
const e=v=>String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const dt=v=>v?new Date(v).toLocaleString('ro-RO'):'—';
const badge=v=>{const text=String(v??'unknown');return `<span class="badge ${e(text.toLowerCase().replaceAll('_','-'))}">${e(text)}</span>`};
const boolText=v=>v?'Da':'Nu';
const memory=v=>v?`${(Number(v)/1024).toFixed(Number(v)>=10240?0:1)} GB`:'—';
function toast(message,error=false){const box=document.getElementById('toast');box.textContent=message;box.className=`toast show${error?' error':''}`;setTimeout(()=>box.className='toast',3200)}
function pageMeta(name,sub){title.textContent=name;subtitle.textContent=sub||''}
function panel(head,body,tools=''){return `<section class="panel"><div class="panel-header"><h2>${head}</h2><div class="toolbar">${tools}</div></div>${body}</section>`}
function empty(text){return `<div class="empty">${e(text)}</div>`}
function detail(label,value,mono=false){return `<div class="detail-item"><span>${e(label)}</span><div class="${mono?'mono':''}">${value??'—'}</div></div>`}
function jsonSections(raw){const entries=raw&&typeof raw==='object'&&!Array.isArray(raw)?Object.entries(raw):[['inventory',raw]];return `<div class="json-sections">${entries.map(([name,value])=>`<details><summary>${e(name)}</summary><pre class="json">${e(JSON.stringify(value,null,2))}</pre></details>`).join('')}</div>`}

async function init(){
  try{
    const versionElement=document.getElementById('appVersion');
    try{const build=await api('/version');if(versionElement)versionElement.textContent=`Server ${build.version||''}`.trim()}catch{if(versionElement)versionElement.textContent='Server'}
    state.user=await api('/api/v1/auth/me');state.csrf=state.user.csrf_token;
    document.getElementById('currentUser').textContent=state.user.display_name||state.user.username;
    document.querySelector('[data-page="audit"]').hidden=!can('audit.read');
    document.querySelector('[data-page="access"]').hidden=!can('rbac.manage');
    document.querySelector('[data-page="nomenclatures"]').hidden=!can('nomenclatures.read');
    document.querySelector('[data-page="services"]').hidden=!can('services.read');
    document.querySelector('[data-page="documents"]').hidden=!can('documents.read');
    document.body.classList.remove('booting');route();
  }catch{location.href='/login'}
}

async function route(){
  const raw=(location.hash||'#dashboard').slice(1);const [page,id]=raw.split('/');
  document.querySelectorAll('#nav a[data-page]').forEach(a=>a.classList.toggle('active',a.dataset.page===page));
  content.innerHTML='<div class="loading">Se încarcă…</div>';
  try{
    if(page==='dashboard')await dashboard();
    else if(page==='agents')await agentsPage();
    else if(page==='vms'&&id)await vmDetail(Number(id));
    else if(page==='vms')await vmsPage();
    else if(page==='services'&&id)await internalServiceDetail(Number(id));
    else if(page==='services')await internalServicesPage();
    else if(page==='nomenclatures')await nomenclaturesPage(id||'');
    else if(page==='documents')await documentsPage();
    else if(page==='audit')await auditPage();
    else if(page==='access')await accessPage();
    else location.hash='#dashboard';
  }catch(err){content.innerHTML=empty(err.message);toast(err.message,true)}
}

async function dashboard(){
  pageMeta('Dashboard','Starea centralizată a platformei');
  const d=await api('/api/v1/dashboard');
  content.innerHTML=`<div class="cards">
    <div class="card"><div class="label">VM-uri din vCenter</div><div class="value">${d.vms}</div></div>
    <div class="card"><div class="label">Agenți configurați</div><div class="value">${d.agents_total}</div></div>
    <div class="card"><div class="label">Agenți online</div><div class="value">${d.agents_online}</div></div>
    <div class="card"><div class="label">Joburi în așteptare</div><div class="value">${d.jobs_pending}</div></div>
  </div>${panel('Fluxul 0 → inventar',`<div class="detail-grid">${detail('0. vCenter','Lista completă de VM-uri')}${detail('1. Corelare','BIOS UUID / hostname unic')}${detail('2. Agent','Colectare JSON și stare')}${detail('3. Operațional','Status, servicii interne și istoric')}</div>`)}`;
}

async function agentsPage(){
  pageMeta('Agenți','Administrare, conectivitate și colectare');state.agents=await api('/api/v1/agents');
  const rows=state.agents.map(a=>{const actions=[can('collections.run')?`<button class="small secondary" data-action="test" data-id="${a.id}">Test</button><button class="small" data-action="collect" data-id="${a.id}">Colectează</button>`:'',can('agents.manage')?`<button class="small secondary" data-action="edit" data-id="${a.id}">Editează</button><button class="small danger" data-action="delete" data-id="${a.id}">Șterge</button>`:''].join('');return `<tr><td><strong>${e(a.name)}</strong><div class="muted mono">${e(a.base_url)}</div></td><td>${badge(a.status)}</td><td class="mono">${e(a.agent_uuid||'—')}</td><td>${dt(a.last_contact_at)}</td><td class="muted">${e(a.last_error||'—')}</td><td><div class="actions">${actions||'—'}</div></td></tr>`}).join('');
  content.innerHTML=panel('Lista agenților',state.agents.length?`<div class="table-wrap"><table><thead><tr><th>Agent</th><th>Status</th><th>UUID</th><th>Ultimul contact</th><th>Ultima eroare</th><th>Acțiuni</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există agenți configurați.'),can('agents.manage')?'<button id="newAgent">Adaugă agent</button>':'');
  document.getElementById('newAgent')?.addEventListener('click',()=>openAgent());
  content.querySelectorAll('[data-action]').forEach(b=>b.onclick=()=>agentAction(b.dataset.action,Number(b.dataset.id)));
}

function openAgent(agent=null){
  document.getElementById('agentDialogTitle').textContent=agent?'Editare agent':'Agent nou';
  document.getElementById('agentId').value=agent?.id||'';document.getElementById('agentName').value=agent?.name||'';document.getElementById('agentURL').value=agent?.base_url||'';document.getElementById('agentToken').value='';document.getElementById('agentToken').required=!agent;
  document.getElementById('agentInterval').value=agent?.collection_interval_seconds||900;document.getElementById('agentTimeout').value=agent?.request_timeout_seconds||45;document.getElementById('agentOffline').value=agent?.offline_after_seconds||2700;document.getElementById('agentEnabled').checked=agent?.enabled??true;document.getElementById('agentVerifyTLS').checked=agent?.verify_tls??true;agentDialog.showModal();
}
async function agentAction(action,id){
  const agent=state.agents.find(a=>a.id===id);
  if(action==='edit'){openAgent(agent);return}
  if(action==='delete'){if(!confirm(`Ștergi agentul ${agent.name}? Istoricul lui va fi șters.`))return;await api(`/api/v1/agents/${id}`,{method:'DELETE'});toast('Agent șters.');agentsPage();return}
  const job=await api(`/api/v1/agents/${id}/${action==='test'?'test':'collect'}`,{method:'POST'});toast(`Job ${job.id} introdus în coadă.`);setTimeout(agentsPage,1000);
}
agentForm.addEventListener('submit',async event=>{
  event.preventDefault();const id=Number(document.getElementById('agentId').value||0);
  const body={name:document.getElementById('agentName').value.trim(),base_url:document.getElementById('agentURL').value.trim(),token:document.getElementById('agentToken').value,enabled:document.getElementById('agentEnabled').checked,verify_tls:document.getElementById('agentVerifyTLS').checked,collection_interval_seconds:Number(document.getElementById('agentInterval').value),request_timeout_seconds:Number(document.getElementById('agentTimeout').value),offline_after_seconds:Number(document.getElementById('agentOffline').value)};
  if(id&&!body.token)delete body.token;
  try{await api(id?`/api/v1/agents/${id}`:'/api/v1/agents',{method:id?'PATCH':'POST',body:JSON.stringify(body)});agentDialog.close();toast(id?'Agent actualizat.':'Agent creat.');agentsPage()}catch(err){toast(err.message,true)}
});

async function vmsPage(){
  pageMeta('VM-uri','Căutare, filtrare, paginare și export din inventarul vCenter');
  const requests=[can('vcenter.read')?api('/api/v1/vcenter/sources'):Promise.resolve([]),can('vcenter.read')?api('/api/v1/vcenter/sync-runs'):Promise.resolve([])];
  const results=await Promise.all(requests);state.sources=Array.isArray(results[0])?results[0]:[];const runs=Array.isArray(results[1])?results[1]:[];
  const filters=state.vmFilters;
  const tools=`<a id="exportVMs" class="button secondary" href="/api/v1/vms/export">Export Excel</a>${can('vcenter.manage')?'<button id="syncAll">Sincronizează vCenter</button><button id="newVCenter" class="secondary">Adaugă sursă</button>':''}`;
  const sourceOptions=state.sources.map(s=>`<option value="${s.id}" ${String(filters.sourceId)===String(s.id)?'selected':''}>${e(s.name)}</option>`).join('');
  const sourceRows=state.sources.map(s=>`<tr><td><strong>${e(s.name)}</strong><div class="muted mono">${e(s.base_url)}</div></td><td>${e(s.username)}</td><td>${s.daily_sync_enabled?`Zilnic ${e(s.daily_sync_time)}`:'Manual'}</td><td>${dt(s.last_success_at)}<div class="error-text">${e(s.last_error||'')}</div></td><td><div class="actions">${can('vcenter.manage')?`<button class="small secondary vc-action" data-action="test" data-id="${s.id}">Test</button><button class="small vc-action" data-action="sync" data-id="${s.id}">Sync</button><button class="small secondary vc-action" data-action="edit" data-id="${s.id}">Editează</button><button class="small danger vc-action" data-action="delete" data-id="${s.id}">Șterge</button>`:'—'}</div></td></tr>`).join('');
  const runRows=runs.slice(0,15).map(r=>`<tr><td>${dt(r.created_at)}</td><td>${e(r.vcenter_source_name)}</td><td>${badge(r.status)}</td><td>${r.found_count}</td><td>+${r.created_count} / ~${r.updated_count} / lipsă ${r.missing_count}</td><td>${r.linked_agent_count}</td><td class="error-text">${e(r.error_message||'—')}</td></tr>`).join('');
  const filterBody=`<div class="filterbar vm-filterbar">
    <label class="vm-search-field"><span>Căutare</span><input id="vmSearch" value="${e(filters.q)}" placeholder="Nume, hostname, OS, IP, agent sau sursă"></label>
    <label><span>Power</span><select id="vmPower"><option value="">Toate</option><option value="POWERED_ON" ${filters.power==='POWERED_ON'?'selected':''}>Pornite</option><option value="POWERED_OFF" ${filters.power==='POWERED_OFF'?'selected':''}>Oprite</option><option value="SUSPENDED" ${filters.power==='SUSPENDED'?'selected':''}>Suspendate</option></select></label>
    <label><span>Agent</span><select id="vmAgentFilter"><option value="">Toți</option><option value="configured" ${filters.agent==='configured'?'selected':''}>Asociat</option><option value="unconfigured" ${filters.agent==='unconfigured'?'selected':''}>Fără agent</option><option value="online" ${filters.agent==='online'?'selected':''}>Online</option><option value="offline" ${filters.agent==='offline'?'selected':''}>Offline</option><option value="unknown" ${filters.agent==='unknown'?'selected':''}>Necunoscut</option><option value="disabled" ${filters.agent==='disabled'?'selected':''}>Dezactivat</option></select></label>
    <label><span>Sursă</span><select id="vmSource"><option value="">Toate sursele</option>${sourceOptions}</select></label>
    <label><span>Pe pagină</span><select id="vmPageSize">${[25,50,100,200].map(n=>`<option value="${n}" ${Number(filters.pageSize)===n?'selected':''}>${n}</option>`).join('')}</select></label>
    <button id="clearVMFilters" class="secondary vm-clear-filter" type="button">Curăță</button>
  </div><div id="vmTableArea" class="loading">Se încarcă VM-urile…</div>`;
  content.innerHTML=`<div class="cards"><div class="card"><div class="label">Rezultate</div><div id="vmTotal" class="value">—</div></div><div class="card"><div class="label">Prezente în vCenter</div><div id="vmPresent" class="value">—</div></div><div class="card"><div class="label">Cu agent asociat</div><div id="vmWithAgent" class="value">—</div></div></div>
  ${panel('Inventar VM',filterBody,tools)}
  ${can('vcenter.read')?panel('Surse vCenter',state.sources.length?`<div class="table-wrap"><table><thead><tr><th>Sursă</th><th>Utilizator</th><th>Program</th><th>Ultima sincronizare</th><th>Acțiuni</th></tr></thead><tbody>${sourceRows}</tbody></table></div>`:empty('Nu există surse vCenter configurate.')):''}
  ${can('vcenter.read')?panel('Ultimele sincronizări',runRows?`<div class="table-wrap"><table><thead><tr><th>Creat</th><th>Sursă</th><th>Status</th><th>Găsite</th><th>Modificări</th><th>Agenți legați</th><th>Eroare</th></tr></thead><tbody>${runRows}</tbody></table></div>`:empty('Nu există sincronizări.')):''}`;
  document.getElementById('syncAll')?.addEventListener('click',async()=>{try{const r=await api('/api/v1/vcenter/sync',{method:'POST'});toast(`${Array.isArray(r)?r.length:0} sincronizări introduse în coadă.`);setTimeout(vmsPage,1200)}catch(err){toast(err.message,true)}});
  document.getElementById('newVCenter')?.addEventListener('click',()=>openVCenter());
  content.querySelectorAll('.vc-action').forEach(b=>b.onclick=()=>vcenterAction(b.dataset.action,Number(b.dataset.id)));
  bindVMFilters();
  await loadVMPage();
}

function vmQuery(includePage=true){
  const f=state.vmFilters,params=new URLSearchParams();
  if(f.q)params.set('q',f.q);if(f.power)params.set('power',f.power);if(f.agent)params.set('agent',f.agent);if(f.sourceId)params.set('source_id',f.sourceId);
  if(includePage){params.set('page',String(f.page));params.set('page_size',String(f.pageSize))}
  return params.toString();
}

function bindVMFilters(){
  let timer;
  document.getElementById('vmSearch')?.addEventListener('input',event=>{clearTimeout(timer);timer=setTimeout(()=>{state.vmFilters.q=event.target.value.trim();state.vmFilters.page=1;loadVMPage()},300)});
  const bindings={vmPower:'power',vmAgentFilter:'agent',vmSource:'sourceId'};
  Object.entries(bindings).forEach(([id,key])=>document.getElementById(id)?.addEventListener('change',event=>{state.vmFilters[key]=event.target.value;state.vmFilters.page=1;loadVMPage()}));
  document.getElementById('vmPageSize')?.addEventListener('change',event=>{state.vmFilters.pageSize=Number(event.target.value);state.vmFilters.page=1;loadVMPage()});
  document.getElementById('clearVMFilters')?.addEventListener('click',()=>{state.vmFilters={q:'',power:'',agent:'',sourceId:'',page:1,pageSize:50};vmsPage()});
}

async function loadVMPage(){
  const area=document.getElementById('vmTableArea');if(!area)return;area.className='loading';area.textContent='Se încarcă VM-urile…';
  try{
    const result=await api(`/api/v1/vms?${vmQuery(true)}`);state.vms=Array.isArray(result?.items)?result.items:[];state.vmFilters.page=Number(result?.page||1);
    document.getElementById('vmTotal').textContent=Number(result?.total||0).toLocaleString('ro-RO');document.getElementById('vmPresent').textContent=Number(result?.present_count||0).toLocaleString('ro-RO');document.getElementById('vmWithAgent').textContent=Number(result?.with_agent_count||0).toLocaleString('ro-RO');
    const exportLink=document.getElementById('exportVMs');if(exportLink)exportLink.href=`/api/v1/vms/export?${vmQuery(false)}`;
    area.className='';area.innerHTML=renderVMPage(result);
    area.querySelectorAll('.vm-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==state.vmFilters.page){state.vmFilters.page=page;loadVMPage();area.scrollIntoView({behavior:'smooth',block:'start'})}}));
  }catch(err){area.className='';area.innerHTML=empty(err.message);toast(err.message,true)}
}

function renderVMPage(result){
  const items=Array.isArray(result?.items)?result.items:[];
  if(!items.length)return empty('Nu există VM-uri pentru filtrele selectate.');
  const rows=items.map(v=>`<tr><td><a href="#vms/${v.id}"><strong>${e(v.name)}</strong></a><div class="muted mono">${e(v.vcenter_moid)} · ${e(v.vcenter_source_name)}</div></td><td>${badge(v.power_state||'unknown')}</td><td>${v.cpu_count||'—'} / ${memory(v.memory_mib)}</td><td>${e(v.inventory_os_name||v.guest_os||'—')}<div class="muted">${e(v.inventory_os_version||'')}</div></td><td class="mono">${e(v.inventory_primary_ip||v.primary_ip||'—')}</td><td>${badge(v.agent_status)}<div class="muted">${e(v.agent_name||'Fără agent')}</div></td><td>${dt(v.inventory_received_at)}</td><td>${v.present_in_vcenter?badge('present'):badge('missing')}</td></tr>`).join('');
  const total=Number(result.total||0),page=Number(result.page||1),pageSize=Number(result.page_size||50),start=(page-1)*pageSize+1,end=Math.min(page*pageSize,total);
  return `<div class="table-wrap vm-table-wrap"><table><thead><tr><th>VM</th><th>Power</th><th>CPU / RAM</th><th>OS</th><th>IP</th><th>Agent</th><th>Ultimul JSON</th><th>vCenter</th></tr></thead><tbody>${rows}</tbody></table></div><div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons">${paginationButtons(page,Number(result.pages||1))}</div></div>`;
}

function paginationButtons(page,pages,buttonClass='vm-page'){
  if(pages<=1)return '';
  const values=new Set([1,pages,page-2,page-1,page,page+1,page+2]);const valid=[...values].filter(n=>n>=1&&n<=pages).sort((a,b)=>a-b);let previous=0,html=`<button class="small secondary ${buttonClass}" data-page="${page-1}" ${page<=1?'disabled':''}>Anterior</button>`;
  valid.forEach(n=>{if(previous&&n>previous+1)html+='<span class="pagination-gap">…</span>';html+=`<button class="small ${n===page?'':'secondary'} ${buttonClass}" data-page="${n}" ${n===page?'disabled':''}>${n}</button>`;previous=n});
  return html+`<button class="small secondary ${buttonClass}" data-page="${page+1}" ${page>=pages?'disabled':''}>Următor</button>`;
}
function pageSizeOptions(selected,values=[10,20,50,100]){return values.map(value=>`<option value="${value}" ${Number(selected)===value?'selected':''}>${value}</option>`).join('')}

function nomenclaturePageInfo(code,total){
  const current=state.nomenclaturePaging[code]||{page:1,pageSize:20};
  current.pageSize=[10,20,50,100].includes(Number(current.pageSize))?Number(current.pageSize):20;
  const pages=Math.max(1,Math.ceil(total/current.pageSize));
  current.page=Math.min(Math.max(1,Number(current.page)||1),pages);
  state.nomenclaturePaging[code]=current;
  const offset=(current.page-1)*current.pageSize;
  return {page:current.page,pageSize:current.pageSize,pages,total,offset,end:Math.min(offset+current.pageSize,total)};
}
function nomenclaturePagination(code,info){
  if(!info.total)return '';
  const start=info.offset+1;
  return `<div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${info.end.toLocaleString('ro-RO')} din ${info.total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="nomenclaturePageSize" data-category="${e(code)}">${pageSizeOptions(info.pageSize)}</select></label>${paginationButtons(info.page,info.pages,'nomenclature-page')}</div></div>`;
}

function openVCenter(source=null){
  document.getElementById('vcenterDialogTitle').textContent=source?'Editare sursă vCenter':'Sursă vCenter nouă';document.getElementById('vcenterId').value=source?.id||'';document.getElementById('vcenterName').value=source?.name||'';document.getElementById('vcenterURL').value=source?.base_url||'';document.getElementById('vcenterUsername').value=source?.username||'';document.getElementById('vcenterPassword').value='';document.getElementById('vcenterPassword').required=!source;document.getElementById('vcenterSyncTime').value=source?.daily_sync_time||'05:00';document.getElementById('vcenterTLSServerName').value=source?.tls_server_name||'';document.getElementById('vcenterEnabled').checked=source?.enabled??true;document.getElementById('vcenterVerifyTLS').checked=source?.verify_tls??true;document.getElementById('vcenterDailySync').checked=source?.daily_sync_enabled??true;vcenterDialog.showModal();
}
async function vcenterAction(action,id){
  const source=state.sources.find(s=>s.id===id);
  try{
    if(action==='edit'){openVCenter(source);return}
    if(action==='delete'){if(!confirm(`Ștergi sursa ${source.name} și VM-urile sincronizate din ea?`))return;await api(`/api/v1/vcenter/sources/${id}`,{method:'DELETE'});toast('Sursă vCenter ștearsă.');vmsPage();return}
    if(action==='test'){const r=await api(`/api/v1/vcenter/sources/${id}/test`,{method:'POST'});toast(`Conexiune reușită: ${r.vm_count} VM-uri vizibile.`);return}
    if(action==='sync'){const r=await api(`/api/v1/vcenter/sources/${id}/sync`,{method:'POST'});toast(`Sincronizarea ${r.id} a fost pornită.`);setTimeout(vmsPage,1200)}
  }catch(err){toast(err.message,true)}
}
vcenterForm.addEventListener('submit',async event=>{
  event.preventDefault();const id=Number(document.getElementById('vcenterId').value||0);const body={name:document.getElementById('vcenterName').value.trim(),base_url:document.getElementById('vcenterURL').value.trim(),username:document.getElementById('vcenterUsername').value.trim(),password:document.getElementById('vcenterPassword').value,enabled:document.getElementById('vcenterEnabled').checked,verify_tls:document.getElementById('vcenterVerifyTLS').checked,tls_server_name:document.getElementById('vcenterTLSServerName').value.trim(),daily_sync_enabled:document.getElementById('vcenterDailySync').checked,daily_sync_time:document.getElementById('vcenterSyncTime').value};if(id&&!body.password)delete body.password;
  try{await api(id?`/api/v1/vcenter/sources/${id}`:'/api/v1/vcenter/sources',{method:id?'PATCH':'POST',body:JSON.stringify(body)});vcenterDialog.close();toast(id?'Sursă actualizată.':'Sursă creată.');vmsPage()}catch(err){toast(err.message,true)}
});

function fieldLabel(key){
  const labels={hostname:'Hostname',fqdn:'FQDN',uuid:'UUID',product_uuid:'Product UUID',machine_id:'Machine ID',pretty_name:'Denumire OS',version_id:'Versiune',primary_ip:'IP principal',boot_time:'Pornire sistem',status:'Stare',name:'Nume',version:'Versiune',enabled:'Activ',active:'Activ',installed:'Instalat',service:'Serviciu',port:'Port',protocol:'Protocol',address:'Adresă'};
  if(labels[key])return labels[key];
  return String(key||'').replaceAll('_',' ').replaceAll('-',' ').replace(/\b\w/g,c=>c.toUpperCase());
}
function structuredValue(value,depth=0){
  if(value===null||value===undefined||value==='')return '<span class="muted">—</span>';
  if(typeof value==='boolean')return value?badge('active'):badge('disabled');
  if(typeof value==='number')return `<span>${e(value)}</span>`;
  if(typeof value==='string'){
    const low=value.toLowerCase();
    if(['ok','active','enabled','running','installed','success','succeeded','online','configured'].includes(low))return badge(low);
    if(['error','failed','disabled','stopped','missing','offline','not_installed','unconfigured','timeout'].includes(low))return badge(low);
    return `<span class="${value.length>70?'pre-wrap':''}">${e(value)}</span>`;
  }
  if(Array.isArray(value)){
    if(!value.length)return '<span class="muted">Listă goală</span>';
    const primitives=value.every(item=>item===null||['string','number','boolean'].includes(typeof item));
    if(primitives)return `<div class="value-list">${value.map(item=>`<span>${structuredValue(item,depth+1)}</span>`).join('')}</div>`;
    return `<div class="structured-list">${value.map((item,index)=>`<details><summary>Element ${index+1}</summary>${structuredValue(item,depth+1)}</details>`).join('')}</div>`;
  }
  const entries=Object.entries(value);
  if(!entries.length)return '<span class="muted">Fără date</span>';
  return `<dl class="inventory-kv ${depth>1?'nested':''}">${entries.map(([key,item])=>`<div><dt>${e(fieldLabel(key))}</dt><dd>${structuredValue(item,depth+1)}</dd></div>`).join('')}</dl>`;
}
function structuredInventory(documentView){
  const sections=Array.isArray(documentView?.sections)?documentView.sections:[];
  if(!sections.length)return empty('Agentul nu a furnizat încă date structurate.');
  return `<div class="inventory-sections">${sections.map(section=>`<details class="inventory-section"><summary><span>${e(section.title||fieldLabel(section.key))}</span>${section.status?badge(section.status):''}</summary><div class="inventory-section-body">${structuredValue(section.data)}</div></details>`).join('')}</div>`;
}
function categoryItems(categories,code){return (categories||[]).find(item=>item.code===code)?.items||[]}
function selectOptions(items,selected,placeholder='— Neselectat —',label=value=>value.name){return `<option value="">${e(placeholder)}</option>${(items||[]).filter(item=>item.active||Number(item.id)===Number(selected)).map(item=>`<option value="${item.id}" ${Number(selected)===Number(item.id)?'selected':''}>${e(label(item))}${item.active?'':' (inactiv)'}</option>`).join('')}`}
function multiSelectOptions(items,selected=[]){const selectedSet=new Set((selected||[]).map(Number));return (items||[]).filter(item=>item.active||selectedSet.has(Number(item.id))).map(item=>`<option value="${item.id}" ${selectedSet.has(Number(item.id))?'selected':''}>${e(item.name)}${item.active?'':' (inactiv)'}</option>`).join('')}
const enhancedMultiSelects=new WeakMap();
function destroyEnhancedMultiSelect(select){
  const current=enhancedMultiSelects.get(select);if(!current)return;
  current.cleanup?.();current.wrapper.remove();select.hidden=false;select.classList.remove('select2-lite-source');enhancedMultiSelects.delete(select);
}
function enhanceMultiSelect(select,{placeholder='Alege valorile'}={}){
  destroyEnhancedMultiSelect(select);if(!select.multiple)return;
  select.hidden=true;select.classList.add('select2-lite-source');
  const wrapper=document.createElement('div');wrapper.className='select2-lite';
  wrapper.innerHTML=`<button type="button" class="select2-lite-control" aria-haspopup="listbox" aria-expanded="false"><span class="select2-lite-values"></span><span class="select2-lite-arrow">▾</span></button><div class="select2-lite-dropdown" hidden><input type="search" class="select2-lite-search" placeholder="Caută layer…" autocomplete="off"><div class="select2-lite-options" role="listbox" aria-multiselectable="true"></div></div>`;
  select.insertAdjacentElement('afterend',wrapper);
  const control=wrapper.querySelector('.select2-lite-control'),values=wrapper.querySelector('.select2-lite-values'),dropdown=wrapper.querySelector('.select2-lite-dropdown'),search=wrapper.querySelector('.select2-lite-search'),optionsArea=wrapper.querySelector('.select2-lite-options');
  function selectedOptions(){return [...select.options].filter(option=>option.selected)}
  function renderValues(){const selected=selectedOptions();values.innerHTML=selected.length?selected.map(option=>`<span class="select2-lite-chip">${e(option.textContent)}</span>`).join(''):`<span class="select2-lite-placeholder">${e(placeholder)}</span>`}
  function renderOptions(){const query=search.value.trim().toLocaleLowerCase('ro');const options=[...select.options].filter(option=>!query||option.textContent.toLocaleLowerCase('ro').includes(query));optionsArea.innerHTML=options.length?options.map(option=>`<label class="select2-lite-option"><input type="checkbox" value="${e(option.value)}" ${option.selected?'checked':''} ${option.disabled?'disabled':''}><span>${e(option.textContent)}</span></label>`).join(''):'<div class="select2-lite-empty">Niciun rezultat</div>'}
  function setOpen(open){dropdown.hidden=!open;control.setAttribute('aria-expanded',String(open));wrapper.classList.toggle('open',open);if(open){renderOptions();setTimeout(()=>search.focus(),0)}}
  control.addEventListener('click',()=>setOpen(dropdown.hidden));
  search.addEventListener('input',renderOptions);
  optionsArea.addEventListener('change',event=>{const checkbox=event.target.closest('input[type="checkbox"]');if(!checkbox)return;const option=[...select.options].find(item=>item.value===checkbox.value);if(option)option.selected=checkbox.checked;renderValues();select.dispatchEvent(new Event('change',{bubbles:true}))});
  const outsideClick=event=>{if(!wrapper.contains(event.target))setOpen(false)};document.addEventListener('click',outsideClick);
  renderValues();enhancedMultiSelects.set(select,{wrapper,cleanup(){document.removeEventListener('click',outsideClick)},refresh(){renderValues();renderOptions()}});
}
function nomenclatureOptions(categories,code,selected){return selectOptions(categoryItems(categories,code),selected)}
const responsibilityTypes={technical_admin:'Administrator tehnic',service_owner:'Responsabil serviciu',business_owner:'Responsabil business',application_owner:'Responsabil aplicație',infrastructure_owner:'Responsabil infrastructură',security_contact:'Contact securitate',backup_contact:'Contact backup',other:'Altă responsabilitate'};
function responsibilityTypeOptions(selected){return Object.entries(responsibilityTypes).map(([value,label])=>`<option value="${value}" ${selected===value?'selected':''}>${e(label)}</option>`).join('')}
function peopleOptions(people,selected){return `<option value="">— Alege persoana —</option>${(people||[]).filter(person=>person.active||Number(person.id)===Number(selected)).map(person=>`<option value="${person.id}" ${Number(selected)===Number(person.id)?'selected':''}>${e(person.display_name)}${person.email?` · ${e(person.email)}`:''}${person.active?'':' (inactiv)'}</option>`).join('')}`}
function responsibilityRow(item,people,index){return `<div class="responsibility-row" data-index="${index}"><label>Persoană<select class="responsibility-person">${peopleOptions(people,item?.person_id)}</select></label><label>Rol<select class="responsibility-type">${responsibilityTypeOptions(item?.responsibility_type||'technical_admin')}</select></label><label class="responsibility-notes">Detalii<input class="responsibility-note" value="${e(item?.notes||'')}" placeholder="Opțional"></label><button type="button" class="small danger remove-responsibility">Elimină</button></div>`}
function responsibilitySummary(values){if(!values?.length)return '—';return `<div class="responsibility-summary">${values.map(item=>`<div><strong>${e(item.person_name)}</strong><span>${e(responsibilityTypes[item.responsibility_type]||item.responsibility_type)}${item.person_email?` · ${e(item.person_email)}`:''}</span></div>`).join('')}</div>`}
function minutesText(value){if(value===null||value===undefined)return '—';if(value<60)return `${value} min`;if(value%1440===0)return `${value/1440} zile`;if(value%60===0)return `${value/60} ore`;return `${value} min`}
function backupSection(backup){
  const hasData=backup&&(backup.synced_at||backup.policy_name||backup.job_name||backup.source_name||backup.error_message||backup.provider==='manual');
  if(!hasData)return empty('Integrarea Veeam nu a populat încă datele de backup pentru această VM. Secțiunea este pregătită pentru sincronizarea prin API.');
  return `<div class="detail-grid">${detail('Furnizor',e(backup.provider||'veeam'))}${detail('Sursă Veeam',e(backup.source_name||'—'))}${detail('Protejată',backup.protected?badge('protected'):badge('unprotected'))}${detail('Ultimul rezultat',backup.last_result?badge(backup.last_result):'—')}${detail('Job',e(backup.job_name||'—'))}${detail('Politică',e(backup.policy_name||'—'))}${detail('Repository',e(backup.repository_name||'—'))}${detail('Restore points',backup.restore_points??'—')}${detail('Ultimul backup',dt(backup.last_backup_at))}${detail('Următoarea rulare',dt(backup.next_run_at))}${detail('RPO',minutesText(backup.rpo_minutes))}${detail('RTO',minutesText(backup.rto_minutes))}${detail('Ultima sincronizare',dt(backup.synced_at))}${detail('Eroare',e(backup.error_message||'—'))}</div>`;
}

function bytesText(value){const size=Number(value||0);if(size<1024)return `${size} B`;if(size<1024*1024)return `${(size/1024).toFixed(1)} KB`;return `${(size/1024/1024).toFixed(1)} MB`}
function documentTemplateOptions(values){return (values||[]).filter(item=>item.active).map(item=>`<option value="${item.id}" ${item.is_default?'selected':''}>${e(item.name)}${item.is_default?' · implicit':''}</option>`).join('')}
function generatedDocumentRows(values){
  if(!values?.length)return empty('Nu a fost generată încă nicio fișă pentru această VM.');
  const rows=values.map(item=>`<tr><td><strong>${e(item.document_number)}</strong><div class="muted">${e(item.file_name)}</div></td><td>${e(item.template_name||'—')}</td><td>${dt(item.generated_at)}</td><td>${e(item.generated_by_name||'sistem')}</td><td>${bytesText(item.size_bytes)}</td><td><a class="button-link small secondary" href="/api/v1/documents/${item.id}/download">Descarcă DOCX</a></td></tr>`).join('');
  return `<div class="table-wrap"><table class="compact-table"><thead><tr><th>Document</th><th>Șablon</th><th>Generat</th><th>Autor</th><th>Mărime</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`;
}
function vmDocumentsPanel(vmID,templates,generated){
  const active=(templates||[]).filter(item=>item.active);
  const generator=can('documents.manage')?(active.length?`<form id="vmDocumentForm" class="document-generation-form"><label>Șablon DOCX<select id="vmDocumentTemplate">${documentTemplateOptions(active)}</select></label><div class="document-generation-actions"><button id="previewVMDocument" type="button" class="secondary">Previzualizează datele</button><button type="submit">Generează DOCX</button></div><p class="muted">Fișa este generată din datele vCenter, datele operaționale, servicii, responsabilități, backup și inventarul curent al agentului.</p></form>`:empty('Nu există niciun șablon DOCX activ. Activează sau încarcă un șablon din meniul Documente.')):'';
  return panel('Fișe tehnice generate',`${generator}<div class="generated-documents-history">${generatedDocumentRows(generated)}</div>`,can('documents.manage')?'<a class="button-link small secondary" href="#documents">Administrează șabloanele</a>':'');
}
function documentPreviewHTML(preview){
  const warnings=(preview.warnings||[]).length?`<div class="notice warning"><strong>Observații înainte de generare</strong><ul>${preview.warnings.map(item=>`<li>${e(item)}</li>`).join('')}</ul></div>`:'';
  const sections=(preview.sections||[]).map(section=>`<section class="document-preview-section"><h3>${e(section.title)}</h3><div class="detail-grid">${(section.rows||[]).map(row=>detail(row.label,e(row.value||'—'))).join('')}</div></section>`).join('');
  return `${warnings}<div class="document-preview-meta">${detail('VM',e(preview.vm_name))}${detail('Șablon',e(preview.template_name))}${detail('Număr propus',e(preview.document_number),true)}${detail('Data generării',dt(preview.generated_at))}</div>${sections}`;
}
function selectedDocumentTemplateID(){return Number(document.getElementById('vmDocumentTemplate')?.value||0)}
function bindVMDocumentActions(vmID){
  document.getElementById('previewVMDocument')?.addEventListener('click',async()=>{const templateID=selectedDocumentTemplateID();if(!templateID){toast('Alege un șablon DOCX.',true);return}try{const preview=await api(`/api/v1/vms/${vmID}/documents/preview`,{method:'POST',body:JSON.stringify({template_id:templateID})});document.getElementById('documentPreviewContent').innerHTML=documentPreviewHTML(preview);documentPreviewDialog.showModal()}catch(err){toast(err.message,true)}});
  document.getElementById('vmDocumentForm')?.addEventListener('submit',async event=>{event.preventDefault();const templateID=selectedDocumentTemplateID();if(!templateID){toast('Alege un șablon DOCX.',true);return}const submit=event.currentTarget.querySelector('button[type="submit"]');submit.disabled=true;submit.textContent='Se generează…';try{const generated=await api(`/api/v1/vms/${vmID}/documents`,{method:'POST',body:JSON.stringify({template_id:templateID})});toast(`Fișa ${generated.document_number} a fost generată.`);const link=document.createElement('a');link.href=`/api/v1/documents/${generated.id}/download`;link.click();setTimeout(()=>vmDetail(vmID),500)}catch(err){toast(err.message,true)}finally{submit.disabled=false;submit.textContent='Generează DOCX'}});
}
function sortNomenclatureValues(values){return [...(values||[])].sort((left,right)=>Number(left.sort_order||0)-Number(right.sort_order||0)||String(left.name||'').localeCompare(String(right.name||''),'ro',{sensitivity:'base'}))}
const serviceUsageLabels={dedicated:'Dedicat',shared:'Partajat',dependency:'Dependență'};
function domainAssignmentOptions(categories,selected){return selectOptions(sortNomenclatureValues(categoryItems(categories,'architectural_domain')),selected,'— Alege domeniul —')}
function categoryAssignmentOptions(categories,domainID,selected){const values=sortNomenclatureValues(categoryItems(categories,'itil_category').filter(item=>Number(item.parent_id)===Number(domainID)));return selectOptions(values,selected,domainID?'— Alege categoria de serviciu —':'— Alege domeniul —')}
function serviceAssignmentOptions(services,selected){const values=[...(services||[])].sort((left,right)=>String(left.name||'').localeCompare(String(right.name||''),'ro',{sensitivity:'base'}));return `<option value="">— Alege serviciul intern —</option>${values.filter(service=>service.active||Number(service.id)===Number(selected)).map(service=>`<option value="${service.id}" ${Number(selected)===Number(service.id)?'selected':''}>${e(service.name)}${service.service_code?` · ${e(service.service_code)}`:''}${service.active?'':' (inactiv)'}</option>`).join('')}`}
function serviceUsageOptions(selected='dedicated'){return Object.entries(serviceUsageLabels).map(([value,label])=>`<option value="${value}" ${selected===value?'selected':''}>${e(label)}</option>`).join('')}
function serviceAssignmentRow(item,services,categories,index){const domainID=item?.architectural_domain_id||'';const categoryID=item?.itil_category_id||'';return `<div class="vm-service-assignment-row" data-index="${index}"><label>Domeniu<select class="assignment-domain" required>${domainAssignmentOptions(categories,domainID)}</select></label><label>Categorie de serviciu<select class="assignment-category" required>${categoryAssignmentOptions(categories,domainID,categoryID)}</select></label><label>Serviciu intern<select class="assignment-service" required>${serviceAssignmentOptions(services,item?.internal_service_id)}</select></label><label>Layer arhitectural<select class="assignment-layer" required></select></label><label>Rol tehnic<select class="assignment-role" required></select></label><label>Utilizare<select class="assignment-usage">${serviceUsageOptions(item?.usage_type||'dedicated')}</select></label><label class="assignment-primary"><span>Principal</span><input class="assignment-primary-input" type="checkbox" ${item?.is_primary?'checked':''}></label><label class="assignment-notes">Observații<input class="assignment-note" maxlength="1000" value="${e(item?.notes||'')}" placeholder="Opțional"></label>${can('vms.manage')?'<button type="button" class="small danger remove-service-assignment">Elimină</button>':''}</div>`}
function wireServiceAssignmentRow(row,services,categories,initial={}){
  const domain=row.querySelector('.assignment-domain'),category=row.querySelector('.assignment-category'),service=row.querySelector('.assignment-service'),layer=row.querySelector('.assignment-layer'),role=row.querySelector('.assignment-role');
  const layers=sortNomenclatureValues(categoryItems(categories,'layer'));
  const roles=categoryItems(categories,'technical_role');
  function fillCategories(selected=''){category.innerHTML=categoryAssignmentOptions(categories,domain.value,selected);category.disabled=!domain.value}
  function fillServices(selected=''){service.innerHTML=serviceAssignmentOptions(services,selected);service.disabled=!category.value}
  function fillLayers(selected=''){let values=layers;if(selected&&!values.some(value=>Number(value.id)===Number(selected))&&initial.layer_name)values=[...values,{id:Number(selected),name:`${initial.layer_name} · inactiv`,active:false}];layer.innerHTML=selectOptions(values,selected,'— Alege layer-ul —')}
  function fillRoles(selected=''){let values=sortNomenclatureValues(roles.filter(item=>(item.layer_ids||[]).some(id=>Number(id)===Number(layer.value))));if(selected&&!values.some(value=>Number(value.id)===Number(selected))&&initial.technical_role)values=[...values,{id:Number(selected),name:`${initial.technical_role} · nemapat`,active:false}];role.innerHTML=selectOptions(values,selected,layer.value?'— Alege rolul tehnic —':'— Alege layer-ul —');role.disabled=!layer.value}
  fillCategories(initial.itil_category_id);fillServices(initial.internal_service_id);fillLayers(initial.layer_id);fillRoles(initial.technical_role_id);
  domain.addEventListener('change',()=>{fillCategories();fillServices()});category.addEventListener('change',()=>fillServices());layer.addEventListener('change',()=>fillRoles());
}
function serviceAssignmentsSummary(values){
  if(!values?.length)return '<span class="muted">Niciun serviciu intern asociat.</span>';
  return `<div class="table-wrap"><table class="compact-table"><thead><tr><th>Serviciu intern</th><th>Domeniu / Categorie de serviciu</th><th>Layer</th><th>Rol tehnic</th><th>Utilizare</th><th></th></tr></thead><tbody>${values.map(item=>`<tr><td><a href="#services/${item.internal_service_id}">${e(item.internal_service_name)}</a></td><td>${e(item.architectural_domain||'—')}<div class="muted">${e(item.itil_category||'—')}</div></td><td>${e(item.layer_name||'—')}</td><td>${e(item.technical_role||'—')}</td><td>${e(serviceUsageLabels[item.usage_type]||item.usage_type||'—')}</td><td>${item.is_primary?badge('principal'):''}</td></tr>`).join('')}</tbody></table></div>`;
}

async function vmDetail(id){
  if(Number(state.vmHistory.vmId)!==Number(id))state.vmHistory={vmId:id,page:1,pageSize:20};
  const [data,agents,categories,people,services,documentTemplates,generatedDocuments]=await Promise.all([api(`/api/v1/vms/${id}`),can('agents.read')?api('/api/v1/agents'):Promise.resolve([]),api('/api/v1/nomenclatures?include_inactive=true'),api('/api/v1/people?include_inactive=true'),api('/api/v1/services?include_inactive=true'),can('documents.read')?api('/api/v1/document-templates'):Promise.resolve([]),can('documents.read')?api(`/api/v1/vms/${id}/documents`):Promise.resolve([])]);
  const vm=data.vm,v=data.inventory||{},op=data.operational||{},backup=data.backup||{},documentView=data.inventory_document||{};
  const warningLabels={agent_data_unavailable:'Datele agentului asociat nu au putut fi încărcate.',inventory_data_unavailable:'Inventarul curent nu a putut fi încărcat.',inventory_document_unavailable:'Inventarul curent există, dar vederea structurată nu a putut fi generată.',operational_data_unavailable:'Datele operaționale nu au putut fi încărcate.',backup_data_unavailable:'Datele de backup nu au putut fi încărcate.'};
  const vmWarnings=(Array.isArray(data.warnings)?data.warnings:[]).map(code=>warningLabels[code]||code);
  const assignments=Array.isArray(op.service_assignments)?op.service_assignments:[];
  pageMeta(vm.name,'Fișă tehnică, inventar agent și date operaționale');
  const agentOptions=`<option value="">Fără agent</option>${agents.map(x=>`<option value="${x.id}" ${vm.agent_id===x.id?'selected':''}>${e(x.name)} (${e(x.status)})</option>`).join('')}`;
  const documentLink=op.documentation_url?`<a href="${e(op.documentation_url)}" target="_blank" rel="noopener">${e(op.documentation_url)}</a>`:'—';
  const initialResponsibilities=Array.isArray(op.responsibilities)?op.responsibilities:[];
  const assignmentRows=assignments.map((item,index)=>serviceAssignmentRow(item,services,categories,index)).join('');
  const vmDocumentPanel=can('documents.read')?vmDocumentsPanel(id,documentTemplates,generatedDocuments):'';
  content.innerHTML=`${vmWarnings.length?`<div class="notice warning"><strong>Fișa a fost încărcată parțial.</strong><ul>${vmWarnings.map(message=>`<li>${e(message)}</li>`).join('')}</ul><span class="muted">Detaliul tehnic este în jurnalul serviciului vm-doc-server.</span></div>`:''}<div class="cards"><div class="card"><div class="label">Power state</div><div class="value compact">${badge(vm.power_state||'unknown')}</div></div><div class="card"><div class="label">Agent</div><div class="value compact">${badge(vm.agent_status)}</div><div class="muted">${e(vm.agent_name||'Neasociat')}</div></div><div class="card"><div class="label">Ultimul inventar</div><div class="value compact">${dt(vm.inventory_received_at)}</div></div><div class="card"><div class="label">Status operațional</div><div class="value compact">${op.operational_status?badge(op.operational_status):'—'}</div></div></div>
  ${panel('Identificare și încadrare',`<div class="detail-grid">${detail('Nume VM',e(vm.name))}${detail('Hostname',e(v.hostname||vm.guest_hostname||'—'),true)}${detail('IP principal',e(v.primary_ip||vm.primary_ip||'—'),true)}${detail('Sistem de operare',`${e(v.os_name||vm.guest_os||'—')} ${e(v.os_version||'')}`)}${detail('Mediu',e(op.environment||'—'))}${detail('Status operațional',op.operational_status?badge(op.operational_status):'—')}${detail('Clasificare',e(op.classification||'—'))}${detail('Responsabilități',responsibilitySummary(op.responsibilities))}${detail('Documentație',documentLink)}${detail('Referință tichet',e(op.ticket_reference||'—'))}</div>`) }
  ${panel('Servicii interne și roluri tehnice',`<form id="serviceAssignmentsForm" class="service-assignments-form"><p class="muted">Alege în ordine domeniul, categoria de serviciu, serviciul intern, layer-ul și rolul tehnic. Domeniul filtrează categoriile de serviciu, iar layer-ul filtrează rolurile permise.</p><div id="vmServiceAssignmentRows" class="vm-service-assignment-rows">${assignmentRows}</div>${can('vms.manage')?'<div class="form-actions"><button type="button" id="addServiceAssignment" class="secondary">Adaugă asociere</button><button type="submit">Salvează asocierile</button></div>':'<div class="muted form-actions">Nu ai permisiunea de modificare.</div>'}</form>`)}
  ${panel('Date operaționale',`<form id="operationalForm" class="operational-form">
    <div class="form-section"><h3>Încadrare operațională</h3><div class="form-grid"><label>Mediu<select id="opEnvironment">${nomenclatureOptions(categories,'environment',op.environment_id)}</select></label><label>Status operațional<select id="opStatus">${nomenclatureOptions(categories,'operational_status',op.operational_status_id)}</select></label><label>Clasificare<select id="opClassification">${nomenclatureOptions(categories,'classification',op.classification_id)}</select></label></div><label>Scopul VM-ului<textarea id="opPurpose" rows="3">${e(op.purpose||'')}</textarea></label></div>
    <div class="form-section"><div class="section-heading"><h3>Responsabilități</h3>${can('vms.manage')?'<button type="button" id="addResponsibility" class="small secondary">Adaugă persoană</button>':''}</div><div id="responsibilityRows" class="responsibility-rows">${initialResponsibilities.map((item,index)=>responsibilityRow(item,people,index)).join('')}</div>${!people.length?'<p class="muted">Adaugă mai întâi persoane din meniul Nomenclatoare.</p>':''}</div>
    <div class="form-section"><h3>Referințe și observații</h3><div class="form-grid"><label class="span-2">URL documentație<input id="opDocumentation" type="url" value="${e(op.documentation_url||'')}" placeholder="https://..."></label><label>Referință tichet<input id="opTicket" value="${e(op.ticket_reference||'')}"></label></div><label>Observații<textarea id="opNotes" rows="4">${e(op.notes||'')}</textarea></label></div>
    ${can('vms.manage')?'<div class="form-actions"><button type="submit">Salvează datele operaționale</button></div>':'<div class="muted form-actions">Nu ai permisiunea de modificare.</div>'}
  </form>`) }
  ${vmDocumentPanel}
  ${panel('Backup și restaurare · Veeam',backupSection(backup),'<span class="muted">Date separate de inventarul agentului</span>')}
  ${panel('Date colectate de agent',structuredInventory(documentView),v.id&&can('inventories.raw.read')?'<button id="latestRaw" class="secondary">Vezi JSON brut</button>':'')}
  ${panel('Date vCenter',`<div class="detail-grid">${detail('Sursă',e(vm.vcenter_source_name))}${detail('MoID',e(vm.vcenter_moid),true)}${detail('BIOS UUID',e(vm.bios_uuid||'—'),true)}${detail('Instance UUID',e(vm.instance_uuid||'—'),true)}${detail('CPU',e(vm.cpu_count))}${detail('RAM',memory(vm.memory_mib))}${detail('Hardware',e(vm.hardware_version||'—'))}${detail('Ultima vedere',dt(vm.last_seen_at))}${detail('Guest hostname',e(vm.guest_hostname||'—'))}${detail('Guest OS',e(vm.guest_os||'—'))}${detail('IP vCenter',e(vm.primary_ip||'—'),true)}${detail('Prezentă în vCenter',boolText(vm.present_in_vcenter))}</div>`) }
  ${panel('Asociere agent',`<form id="vmManageForm" class="detail-grid"><label><span>Agent asociat</span><select id="vmAgent">${agentOptions}</select></label>${can('vms.manage')?'<label class="form-submit"><button type="submit">Salvează</button></label>':''}</form>`,can('collections.run')&&vm.agent_id?'<button id="testVMAgent" class="secondary">Testează agentul</button><button id="collectVM">Colectează acum</button>':'')}
  ${panel('Istoric inventare','<div id="inventoryHistoryArea" class="loading">Se încarcă istoricul…</div>')}<section id="rawPanel"></section>`;

  const assignmentContainer=document.getElementById('vmServiceAssignmentRows');
  assignmentContainer?.querySelectorAll('.vm-service-assignment-row').forEach((row,index)=>wireServiceAssignmentRow(row,services,categories,assignments[index]||{}));
  document.getElementById('addServiceAssignment')?.addEventListener('click',()=>{const wrapper=document.createElement('div');wrapper.innerHTML=serviceAssignmentRow(null,services,categories,assignmentContainer.children.length);const row=wrapper.firstElementChild;assignmentContainer.appendChild(row);wireServiceAssignmentRow(row,services,categories,{})});
  assignmentContainer?.addEventListener('click',event=>{const button=event.target.closest('.remove-service-assignment');if(button)button.closest('.vm-service-assignment-row').remove()});
  assignmentContainer?.addEventListener('change',event=>{if(!event.target.classList.contains('assignment-primary-input')||!event.target.checked)return;assignmentContainer.querySelectorAll('.assignment-primary-input').forEach(input=>{if(input!==event.target)input.checked=false})});
  document.getElementById('serviceAssignmentsForm')?.addEventListener('submit',async ev=>{ev.preventDefault();if(!can('vms.manage'))return;const rows=[...assignmentContainer.querySelectorAll('.vm-service-assignment-row')];const values=rows.map((row,index)=>({architectural_domain_id:Number(row.querySelector('.assignment-domain').value||0),itil_category_id:Number(row.querySelector('.assignment-category').value||0),internal_service_id:Number(row.querySelector('.assignment-service').value||0),layer_id:Number(row.querySelector('.assignment-layer').value||0),technical_role_id:Number(row.querySelector('.assignment-role').value||0),usage_type:row.querySelector('.assignment-usage').value,is_primary:row.querySelector('.assignment-primary-input').checked,notes:row.querySelector('.assignment-note').value.trim(),sort_order:index}));if(values.some(item=>!item.architectural_domain_id||!item.itil_category_id||!item.internal_service_id||!item.layer_id||!item.technical_role_id)){toast('Completează domeniul, categoria de serviciu, serviciul intern, layer-ul și rolul tehnic pentru fiecare asociere.',true);return}try{await api(`/api/v1/vms/${id}/service-assignments`,{method:'PUT',body:JSON.stringify({assignments:values})});toast('Asocierile cu serviciile interne au fost salvate.');vmDetail(id)}catch(err){toast(err.message,true)}});
  const responsibilityRows=document.getElementById('responsibilityRows');
  document.getElementById('addResponsibility')?.addEventListener('click',()=>{const wrapper=document.createElement('div');wrapper.innerHTML=responsibilityRow(null,people,responsibilityRows.children.length);responsibilityRows.appendChild(wrapper.firstElementChild)});
  responsibilityRows?.addEventListener('click',event=>{const button=event.target.closest('.remove-responsibility');if(button)button.closest('.responsibility-row').remove()});
  document.getElementById('operationalForm')?.addEventListener('submit',async ev=>{ev.preventDefault();if(!can('vms.manage'))return;const responsibilities=[...document.querySelectorAll('.responsibility-row')].map((row,index)=>({person_id:Number(row.querySelector('.responsibility-person').value||0),responsibility_type:row.querySelector('.responsibility-type').value,notes:row.querySelector('.responsibility-note').value.trim(),sort_order:index})).filter(item=>item.person_id>0);const selected=elementId=>{const value=document.getElementById(elementId).value;return value?Number(value):null};const body={environment_id:selected('opEnvironment'),operational_status_id:selected('opStatus'),purpose:document.getElementById('opPurpose').value.trim(),responsibilities,classification_id:selected('opClassification'),documentation_url:document.getElementById('opDocumentation').value.trim(),ticket_reference:document.getElementById('opTicket').value.trim(),notes:document.getElementById('opNotes').value.trim()};try{await api(`/api/v1/vms/${id}/operational`,{method:'PUT',body:JSON.stringify(body)});toast('Datele operaționale au fost salvate.');vmDetail(id)}catch(err){toast(err.message,true)}});
  document.getElementById('vmManageForm')?.addEventListener('submit',async ev=>{ev.preventDefault();if(!can('vms.manage'))return;const selected=document.getElementById('vmAgent').value;const body={};if(selected)body.agent_id=Number(selected);else if(vm.agent_id)body.clear_agent=true;try{await api(`/api/v1/vms/${id}`,{method:'PATCH',body:JSON.stringify(body)});toast('Asocierea agentului a fost actualizată.');vmDetail(id)}catch(err){toast(err.message,true)}});
  document.getElementById('testVMAgent')?.addEventListener('click',()=>vmJob(id,'test-agent'));
  document.getElementById('collectVM')?.addEventListener('click',()=>vmJob(id,'collect'));
  bindVMDocumentActions(id);
  document.getElementById('latestRaw')?.addEventListener('click',async()=>{try{const raw=await api(`/api/v1/inventories/${v.id}/raw`);document.getElementById('rawPanel').innerHTML=panel(`JSON inventar #${v.id}`,jsonSections(raw));document.getElementById('rawPanel').scrollIntoView({behavior:'smooth'})}catch(err){toast(err.message,true)}});
  await loadInventoryHistory(id);
}
function bindRawInventoryButtons(scope=document){scope.querySelectorAll('.show-raw').forEach(button=>button.onclick=async()=>{try{const raw=await api(`/api/v1/inventories/${button.dataset.id}/raw`);document.getElementById('rawPanel').innerHTML=panel(`JSON inventar #${button.dataset.id}`,jsonSections(raw));document.getElementById('rawPanel').scrollIntoView({behavior:'smooth'})}catch(err){toast(err.message,true)}})}
function renderInventoryHistoryPage(result){
  const items=Array.isArray(result?.items)?result.items:[];
  if(!items.length)return empty('Nu există snapshoturi pentru această VM.');
  const rows=items.map(item=>`<tr><td>${dt(item.received_at)}</td><td>${e(item.hostname)}</td><td>${e(item.os_name)} ${e(item.os_version)}</td><td>${item.collector_ok}/${item.collector_total}</td><td>${item.changed_from_previous?badge('changed'):badge('same')}</td><td>${can('inventories.raw.read')?`<button class="small secondary show-raw" data-id="${item.id}">JSON</button>`:''}</td></tr>`).join('');
  const total=Number(result.total||0),page=Number(result.page||1),pageSize=Number(result.page_size||20),start=(page-1)*pageSize+1,end=Math.min(page*pageSize,total);
  return `<div class="table-wrap"><table><thead><tr><th>Primit</th><th>Hostname</th><th>OS</th><th>Colectori</th><th>Schimbare</th><th></th></tr></thead><tbody>${rows}</tbody></table></div><div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="inventoryHistoryPageSize">${pageSizeOptions(pageSize,[10,20,50,100])}</select></label>${paginationButtons(page,Number(result.pages||1),'inventory-history-page')}</div></div>`;
}
async function loadInventoryHistory(vmID){
  const area=document.getElementById('inventoryHistoryArea');if(!area)return;area.className='loading';area.textContent='Se încarcă istoricul…';
  try{const result=await api(`/api/v1/vms/${vmID}/inventories?page=${state.vmHistory.page}&page_size=${state.vmHistory.pageSize}`);state.vmHistory.page=Number(result?.page||1);state.vmHistory.pageSize=Number(result?.page_size||20);area.className='';area.innerHTML=renderInventoryHistoryPage(result);bindRawInventoryButtons(area);area.querySelectorAll('.inventory-history-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==state.vmHistory.page){state.vmHistory.page=page;loadInventoryHistory(vmID)}}));document.getElementById('inventoryHistoryPageSize')?.addEventListener('change',event=>{state.vmHistory.pageSize=Number(event.target.value);state.vmHistory.page=1;loadInventoryHistory(vmID)})}catch(err){area.className='';area.innerHTML=empty(err.message);toast(err.message,true)}
}
async function vmJob(id,action){try{const job=await api(`/api/v1/vms/${id}/${action}`,{method:'POST'});toast(`Job ${job.id} introdus în coadă.`);setTimeout(()=>vmDetail(id),1200)}catch(err){toast(err.message,true)}}

let internalServicesCache=[];
const criticalityLabels={low:'Scăzută',normal:'Normală',high:'Ridicată',critical:'Critică'};
const documentationStatusLabels={draft:'Draft',in_progress:'În lucru',review:'În verificare',approved:'Aprobată',obsolete:'Depășită'};
function criticalityBadge(value){return badge(value||'normal')}
function openInternalService(service=null){
  document.getElementById('internalServiceDialogTitle').textContent=service?'Editare serviciu intern':'Serviciu intern nou';
  document.getElementById('internalServiceId').value=service?.id||'';
  document.getElementById('internalServiceName').value=service?.name||'';
  document.getElementById('internalServiceCode').value=service?.service_code||'';
  document.getElementById('internalServiceCriticality').value=service?.criticality||'normal';
  document.getElementById('internalServiceDocStatus').value=service?.documentation_status||'draft';
  document.getElementById('internalServiceDescription').value=service?.description||'';
  document.getElementById('internalServicePurpose').value=service?.purpose||'';
  document.getElementById('internalServiceDocumentationURL').value=service?.documentation_url||'';
  document.getElementById('internalServiceActive').checked=service?.active??true;
  internalServiceDialog.showModal();
}
function serviceClassificationSummary(values){
  if(!values?.length)return '<span class="muted">Neîncadrat încă</span>';
  return `<div class="service-classification-summary">${values.map(item=>`<div><strong>${e(item.architectural_domain)}</strong><span>${e(item.itil_category)} · ${item.vm_count||0} VM</span></div>`).join('')}</div>`;
}
function observedServiceClassifications(values){
  if(!values?.length)return empty('Domeniul și categoria de serviciu vor apărea automat după prima asociere făcută din fișa unui VM.');
  return `<div class="table-wrap"><table class="compact-table"><thead><tr><th>Domeniu arhitectural</th><th>Categorie de serviciu</th><th>VM-uri</th><th>Asocieri</th></tr></thead><tbody>${values.map(item=>`<tr><td>${e(item.architectural_domain)}</td><td>${e(item.itil_category)}</td><td>${item.vm_count||0}</td><td>${item.assignment_count||0}</td></tr>`).join('')}</tbody></table></div>`;
}
function observedServiceRoles(values){
  if(!values?.length)return empty('Nu există încă layer-e și roluri tehnice. Acestea apar automat după asocierea VM-urilor.');
  return `<div class="table-wrap"><table class="compact-table"><thead><tr><th>Layer</th><th>Rol tehnic</th><th>VM-uri</th><th>Stare</th></tr></thead><tbody>${values.map(mapping=>`<tr><td>${e(mapping.layer_name)}</td><td>${e(mapping.technical_role)}</td><td>${mapping.vm_count||0}</td><td>${mapping.active?badge('active'):badge('disabled')}</td></tr>`).join('')}</tbody></table></div>`;
}
function serviceVMRows(values){
  return (values||[]).map(vm=>`<tr><td><a href="#vms/${vm.id}"><strong>${e(vm.name)}</strong></a><div class="muted mono">${e(vm.guest_hostname||'—')}</div></td><td class="mono">${e(vm.primary_ip||'—')}</td><td>${e(vm.architectural_domain||'—')}<div class="muted">${e(vm.itil_category||'—')}</div></td><td>${e(vm.layer_name||'—')}</td><td>${e(vm.technical_role||'—')}</td><td>${e(serviceUsageLabels[vm.usage_type]||vm.usage_type||'—')}</td><td>${vm.is_primary?badge('principal'):''}</td><td>${badge(vm.power_state||'unknown')}</td></tr>`).join('');
}
async function internalServicesPage(){
  pageMeta('Servicii','Catalogul serviciilor interne și legătura lor cu VM-urile');
  internalServicesCache=await api('/api/v1/services?include_inactive=true');
  const active=internalServicesCache.filter(service=>service.active).length;
  const linkedVMs=internalServicesCache.reduce((sum,service)=>sum+Number(service.vm_count||0),0);
  const configured=internalServicesCache.filter(service=>Number(service.role_mapping_count||0)>0).length;
  const rows=internalServicesCache.map(service=>`<tr><td><a href="#services/${service.id}"><strong>${e(service.name)}</strong></a>${service.description?`<div class="muted service-description">${e(service.description)}</div>`:''}</td><td>${serviceClassificationSummary(service.classifications)}</td><td class="mono">${e(service.service_code||'—')}</td><td>${criticalityBadge(service.criticality)}</td><td>${badge(service.documentation_status||'draft')}</td><td>${service.vm_count||0}</td><td>${service.role_mapping_count||0}</td><td>${service.active?badge('active'):badge('disabled')}</td><td><div class="actions"><a class="button-link small secondary" href="#services/${service.id}">Deschide</a>${can('services.manage')?`<button class="small secondary edit-internal-service" data-id="${service.id}">Editează</button>`:''}</div></td></tr>`).join('');
  content.innerHTML=`<div class="cards"><div class="card"><div class="label">Servicii definite</div><div class="value">${internalServicesCache.length}</div></div><div class="card"><div class="label">Servicii active</div><div class="value">${active}</div></div><div class="card"><div class="label">VM-uri asociate</div><div class="value">${linkedVMs}</div></div><div class="card"><div class="label">Cu roluri observate</div><div class="value">${configured}</div></div></div>
  ${panel('Catalog servicii interne',rows?`<div class="table-wrap"><table><thead><tr><th>Serviciu intern</th><th>Domeniu / Categorie de serviciu</th><th>Cod</th><th>Criticitate</th><th>Documentație</th><th>VM-uri</th><th>Layer–rol observate</th><th>Stare</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există servicii interne definite.'),can('services.manage')?'<button id="newInternalService">Adaugă serviciu</button>':'')}
  ${panel('Model de încadrare','<div class="service-flow"><span>Domeniu arhitectural</span><b>→</b><span>Categorie de serviciu</span><b>→</b><span>Serviciu intern</span><b>→</b><span>Layer</span><b>→</b><span>Rol tehnic</span></div><p class="muted service-flow-note">Serviciul intern definește doar identitatea și documentația serviciului. Domeniul, categoria de serviciu, serviciul, layer-ul și rolul tehnic se selectează pe fișa VM; toate încadrările de aici sunt agregate automat.</p>')}`;
  document.getElementById('newInternalService')?.addEventListener('click',()=>openInternalService());
  content.querySelectorAll('.edit-internal-service').forEach(button=>button.onclick=()=>openInternalService(internalServicesCache.find(service=>service.id===Number(button.dataset.id))));
}
async function internalServiceDetail(id){
  const service=await api(`/api/v1/services/${id}`);
  const vmRows=serviceVMRows(service.vms);
  const documentationLink=service.documentation_url?`<a href="${e(service.documentation_url)}" target="_blank" rel="noopener">${e(service.documentation_url)}</a>`:'—';
  pageMeta(service.name,'Serviciu intern, arhitectură logică și VM-uri asociate');
  content.innerHTML=`<div class="service-detail-toolbar"><a href="#services" class="button-link secondary">← Înapoi la servicii</a>${can('services.manage')?'<button id="editInternalService">Editează serviciul</button>':''}</div>
  <div class="cards"><div class="card"><div class="label">Criticitate</div><div class="value compact">${criticalityBadge(service.criticality)}</div></div><div class="card"><div class="label">Documentație</div><div class="value compact">${badge(service.documentation_status||'draft')}</div></div><div class="card"><div class="label">VM-uri asociate</div><div class="value">${service.vm_count||0}</div></div><div class="card"><div class="label">Combinații observate</div><div class="value">${service.role_mapping_count||0}</div></div></div>
  ${panel('Identificare serviciu',`<div class="detail-grid">${detail('Serviciu intern',e(service.name))}${detail('Cod intern',e(service.service_code||'—'),true)}${detail('Criticitate',criticalityLabels[service.criticality]||e(service.criticality))}${detail('Status documentație',documentationStatusLabels[service.documentation_status]||e(service.documentation_status))}${detail('Activ',service.active?badge('active'):badge('disabled'))}${detail('Ultima actualizare',dt(service.updated_at))}${detail('Documentație existentă',documentationLink)}</div><div class="service-text-block"><h3>Descriere</h3><p>${e(service.description||'—')}</p><h3>Scop</h3><p>${e(service.purpose||'—')}</p></div>`) }
  ${panel('Domenii și categorii de serviciu observate automat',`<p class="muted service-observed-note">Încadrarea este calculată exclusiv din fișele VM asociate serviciului.</p>${observedServiceClassifications(service.classifications)}`) }
  ${panel('Layer-e și roluri tehnice observate automat',`<p class="muted service-observed-note">Această vedere este calculată din asocierile VM-urilor. Nu se configurează manual la nivelul serviciului.</p>${observedServiceRoles(service.role_mappings)}`) }
  ${panel('VM-uri asociate',vmRows?`<div class="table-wrap"><table><thead><tr><th>VM</th><th>IP</th><th>Domeniu / Categorie de serviciu</th><th>Layer</th><th>Rol tehnic</th><th>Utilizare</th><th></th><th>Power state</th></tr></thead><tbody>${vmRows}</tbody></table></div>`:empty('Niciun VM nu este asociat încă acestui serviciu. Asocierea se face din fișa VM prin lista de asocieri multiple.'))}
  ${panel('Documentația serviciului',`<div class="documentation-preview"><div><h3>Document principal</h3><p>Prezentarea serviciului, arhitectură, dependențe, autentificare, monitorizare, backup, continuitate și responsabilități.</p></div><div><h3>Anexe VM</h3><p>${service.vm_count?`${service.vm_count} fișe VM vor putea fi atașate documentației serviciului.`:'Fișele VM vor apărea aici după asociere.'}</p></div></div><p class="muted">Motorul DOCX/PDF va folosi acest serviciu drept unitate de documentare și va include sau referi fișele VM asociate.</p>`)}`;
  document.getElementById('editInternalService')?.addEventListener('click',()=>openInternalService(service));
}
internalServiceForm.addEventListener('submit',async event=>{
  event.preventDefault();if(!can('services.manage'))return;
  const id=Number(document.getElementById('internalServiceId').value||0);
  const body={name:document.getElementById('internalServiceName').value.trim(),service_code:document.getElementById('internalServiceCode').value.trim(),criticality:document.getElementById('internalServiceCriticality').value,documentation_status:document.getElementById('internalServiceDocStatus').value,description:document.getElementById('internalServiceDescription').value.trim(),purpose:document.getElementById('internalServicePurpose').value.trim(),documentation_url:document.getElementById('internalServiceDocumentationURL').value.trim(),active:document.getElementById('internalServiceActive').checked};
  try{const saved=await api(id?`/api/v1/services/${id}`:'/api/v1/services',{method:id?'PATCH':'POST',body:JSON.stringify(body)});internalServiceDialog.close();toast(id?'Serviciu actualizat.':'Serviciu creat.');location.hash=`#services/${saved.id}`;if(id===saved.id&&location.hash===`#services/${saved.id}`)internalServiceDetail(saved.id)}catch(err){toast(err.message,true)}
});

let nomenclatureCache=[];
let peopleCache=[];
let directoryDepartmentCache=null;
let directoryUsersCache=[];
function updateNomenclatureParent(selected=[]){
  const category=document.getElementById('nomenclatureCategory').value;
  const parentLabel=document.getElementById('nomenclatureParentLabel');
  const parentText=document.getElementById('nomenclatureParentText');
  const parentHelp=document.getElementById('nomenclatureParentHelp');
  const orderText=document.getElementById('nomenclatureOrderText');
  const orderHelp=document.getElementById('nomenclatureOrderHelp');
  const parent=document.getElementById('nomenclatureParent');
  const isServiceCategory=category==='itil_category';
  const isTechnicalRole=category==='technical_role';
  destroyEnhancedMultiSelect(parent);
  parentLabel.hidden=!(isServiceCategory||isTechnicalRole);
  parent.required=isServiceCategory;
  parent.multiple=isTechnicalRole;
  parent.removeAttribute('size');
  orderText.textContent=isTechnicalRole?'Ordine în layer':'Ordine';
  orderHelp.textContent=isTechnicalRole?'Rolurile sunt afișate după ordinea layer-ului, apoi după această valoare.':'';
  if(isServiceCategory){
    parentText.textContent='Domeniu arhitectural';
    parentHelp.textContent='Categoria de serviciu aparține unui singur domeniu arhitectural.';
    const domains=sortNomenclatureValues(categoryItems(nomenclatureCache,'architectural_domain'));
    parent.innerHTML=selectOptions(domains,Array.isArray(selected)?selected[0]:selected,'— Alege domeniul arhitectural —');
  }else if(isTechnicalRole){
    parentText.textContent='Layer-e permise';
    parentHelp.textContent='Selectează unul sau mai multe layer-e. Rolul va fi disponibil numai în layer-ele alese.';
    const layers=sortNomenclatureValues(categoryItems(nomenclatureCache,'layer'));
    parent.innerHTML=multiSelectOptions(layers,Array.isArray(selected)?selected:[]);
    enhanceMultiSelect(parent,{placeholder:'Alege layer-ele'});
  }else{
    parentText.textContent='Relație';
    parentHelp.textContent='';
    parent.innerHTML='<option value="">— Nu se aplică —</option>';
  }
}
function openNomenclature(item=null,categoryCode='architectural_domain'){
  const selectedCategory=item?.category_code||categoryCode;
  const categoryOptions=nomenclatureCache.map(category=>`<option value="${e(category.code)}" ${selectedCategory===category.code?'selected':''}>${e(category.label)}</option>`).join('');
  document.getElementById('nomenclatureDialogTitle').textContent=item?'Editare valoare':'Valoare nouă';
  document.getElementById('nomenclatureId').value=item?.id||'';
  const category=document.getElementById('nomenclatureCategory');
  category.innerHTML=categoryOptions;
  category.disabled=Boolean(item);
  document.getElementById('nomenclatureName').value=item?.name||'';
  document.getElementById('nomenclatureCode').value=item?.item_code||'';
  document.getElementById('nomenclatureDescription').value=item?.description||'';
  document.getElementById('nomenclatureOrder').value=item?.sort_order??0;
  document.getElementById('nomenclatureActive').checked=item?.active??true;
  updateNomenclatureParent(selectedCategory==='technical_role'?(item?.layer_ids||[]):(item?.parent_id||''));
  nomenclatureDialog.showModal();
}
document.getElementById('nomenclatureCategory').addEventListener('change',()=>updateNomenclatureParent([]));
function openPerson(person=null){
  document.getElementById('personDialogTitle').textContent=person?'Editare persoană':'Persoană nouă';
  document.getElementById('personId').value=person?.id||'';
  document.getElementById('personName').value=person?.display_name||'';
  document.getElementById('personEmail').value=person?.email||'';
  document.getElementById('personPhone').value=person?.phone||'';
  document.getElementById('personDepartment').value=person?.department||'';
  document.getElementById('personActive').checked=person?.active??true;
  personDialog.showModal();
}
const nomenclatureNavigationGroups=[
  {label:'Catalog servicii',codes:['architectural_domain','itil_category']},
  {label:'Arhitectură tehnică',codes:['layer','technical_role']},
  {label:'Operare VM',codes:['environment','operational_status','classification']},
  {label:'Responsabilități',codes:['people']}
];
const nomenclatureDescriptions={
  architectural_domain:'Domeniile arhitecturale grupează categoriile de serviciu și serviciile interne.',
  itil_category:'Categoriile de serviciu aparțin unui domeniu arhitectural și grupează serviciile interne.',
  layer:'Layer-ele descriu zona arhitecturală în care o VM îndeplinește o funcție.',
  technical_role:'Rolurile tehnice sunt legate de layer-ele în care pot fi selectate.',
  environment:'Mediile separă utilizarea VM-urilor, de exemplu producție, test sau dezvoltare.',
  operational_status:'Statusurile operaționale descriu starea curentă a unei VM în exploatare.',
  classification:'Clasificările permit marcarea nivelului sau tipului de informație gestionată.',
  people:'Registrul persoanelor care pot primi responsabilități pe fișele VM.'
};
function nomenclatureFilterState(code){
  if(!state.nomenclatureFilters[code])state.nomenclatureFilters[code]={q:'',status:'all',parent:'',layer:'',department:'',source:''};
  return state.nomenclatureFilters[code];
}
function normalizedFilterText(value){return String(value||'').trim().toLocaleLowerCase('ro-RO')}
function nomenclatureValueMatches(item,categoryCode,filter){
  if(filter.status==='active'&&!item.active)return false;
  if(filter.status==='inactive'&&item.active)return false;
  if(categoryCode==='itil_category'&&filter.parent&&Number(item.parent_id)!==Number(filter.parent))return false;
  if(categoryCode==='technical_role'&&filter.layer&&!(item.layer_ids||[]).some(id=>Number(id)===Number(filter.layer)))return false;
  const query=normalizedFilterText(filter.q);
  if(!query)return true;
  const haystack=[item.name,item.item_code,item.description,item.parent_name,...(item.layer_names||[])].join(' ').toLocaleLowerCase('ro-RO');
  return haystack.includes(query);
}
function nomenclatureFilterForm(category,visibleCount,totalCount){
  const filter=nomenclatureFilterState(category.code);
  const parentField=category.code==='itil_category'?`<label>Domeniu arhitectural<select name="parent"><option value="">Toate domeniile</option>${sortNomenclatureValues(categoryItems(nomenclatureCache,'architectural_domain')).map(item=>`<option value="${item.id}" ${String(filter.parent)===String(item.id)?'selected':''}>${e(item.name)}</option>`).join('')}</select></label>`:'';
  const layerField=category.code==='technical_role'?`<label>Layer<select name="layer"><option value="">Toate layer-ele</option>${sortNomenclatureValues(categoryItems(nomenclatureCache,'layer')).map(item=>`<option value="${item.id}" ${String(filter.layer)===String(item.id)?'selected':''}>${e(item.name)}</option>`).join('')}</select></label>`:'';
  return `<form id="nomenclatureFilters" class="nomenclature-filters">
    <label class="nomenclature-filter-search">Caută<input name="q" type="search" value="${e(filter.q)}" placeholder="Denumire, cod sau descriere"></label>
    ${parentField}${layerField}
    <label>Stare<select name="status"><option value="all" ${filter.status==='all'?'selected':''}>Toate</option><option value="active" ${filter.status==='active'?'selected':''}>Active</option><option value="inactive" ${filter.status==='inactive'?'selected':''}>Inactive</option></select></label>
    <div class="nomenclature-filter-actions"><button type="submit" class="small">Aplică filtre</button><button type="button" id="clearNomenclatureFilters" class="small secondary">Resetează</button></div>
    <span class="nomenclature-filter-summary">${visibleCount.toLocaleString('ro-RO')} rezultate din ${totalCount.toLocaleString('ro-RO')}</span>
  </form>`;
}
function nomenclaturePanel(category){
  const hasParent=category.code==='itil_category';
  const hasLayerLinks=category.code==='technical_role';
  const relationHead=hasParent?'<th>Domeniu arhitectural</th>':hasLayerLinks?'<th>Layer-e permise</th>':'';
  const head=`<tr><th>Denumire</th>${relationHead}<th>Cod</th><th>Ordine</th><th>Stare</th>${can('nomenclatures.manage')?'<th></th>':''}</tr>`;
  const filter=nomenclatureFilterState(category.code);
  const filteredItems=category.items.filter(item=>nomenclatureValueMatches(item,category.code,filter));
  const info=nomenclaturePageInfo(category.code,filteredItems.length);
  const visibleItems=filteredItems.slice(info.offset,info.end);
  const rows=visibleItems.map(item=>{
    const relation=hasParent?`<td>${e(item.parent_name||'—')}</td>`:hasLayerLinks?`<td>${item.layer_names?.length?e(item.layer_names.join(', ')):'<span class="muted">Nemapate</span>'}</td>`:'';
    return `<tr><td><strong>${e(item.name)}</strong>${item.description?`<div class="muted">${e(item.description)}</div>`:''}</td>${relation}<td class="mono">${e(item.item_code||'—')}</td><td>${item.sort_order}</td><td>${item.active?badge('active'):badge('disabled')}</td>${can('nomenclatures.manage')?`<td><button class="small secondary edit-nomenclature" data-id="${item.id}">Editează</button></td>`:''}</tr>`;
  }).join('');
  const result=rows?`<div class="table-wrap"><table><thead>${head}</thead><tbody>${rows}</tbody></table></div>${nomenclaturePagination(category.code,info)}`:empty(category.items.length?'Nu există valori pentru filtrele selectate.':'Nu există valori definite.');
  const body=`${nomenclatureFilterForm(category,filteredItems.length,category.items.length)}${result}`;
  const tools=`<a class="button-link small secondary" href="/api/v1/nomenclatures/export?category=${encodeURIComponent(category.code)}&include_inactive=true">Export Excel</a>${can('nomenclatures.manage')?`<button class="small add-nomenclature" data-category="${e(category.code)}">Adaugă</button>`:''}`;
  return panel(e(category.label),body,tools);
}
async function loadDirectoryDepartments(force=false){
  if(directoryDepartmentCache&&!force)return directoryDepartmentCache;
  try{directoryDepartmentCache=await api('/api/v1/directory/departments')}
  catch(err){directoryDepartmentCache={enabled:false,departments:[],default_department:'',error:err.message}}
  return directoryDepartmentCache;
}
function directoryUserMatches(user,query){
  if(!query)return true;
  const haystack=[user.display_name,user.username,user.email,user.department,...(user.ou_path||[])].join(' ').toLocaleLowerCase('ro-RO');
  return haystack.includes(query.toLocaleLowerCase('ro-RO'));
}
function directoryUserRow(user){
  const imported=peopleCache.some(person=>person.source==='ldap'&&person.directory_username&&String(person.directory_username).toLocaleLowerCase('ro-RO')===String(user.username||'').toLocaleLowerCase('ro-RO'));
  return `<label class="directory-user"><input type="checkbox" class="directory-user-check" value="${e(user.distinguished_name)}"><span><strong>${e(user.display_name||user.username)}</strong><small>${e(user.username||'')}${user.email?` · ${e(user.email)}`:''}</small></span>${imported?'<em>importat</em>':''}</label>`;
}
function directoryTreeHTML(users){
  const root={children:new Map(),users:[]};
  for(const user of users){let node=root;for(const segment of (user.ou_path||[])){if(!node.children.has(segment))node.children.set(segment,{children:new Map(),users:[]});node=node.children.get(segment)}node.users.push(user)}
  const renderNode=(name,node,rootNode=false)=>{
    const childHTML=[...node.children.entries()].sort((a,b)=>a[0].localeCompare(b[0],'ro')).map(([childName,child])=>renderNode(childName,child)).join('');
    const userHTML=node.users.map(directoryUserRow).join('');
    const body=`${userHTML}${childHTML}`||'<div class="directory-empty muted">Fără utilizatori</div>';
    if(rootNode)return body;
    const count=(node.users?.length||0)+[...node.children.values()].reduce((sum,child)=>sum+directoryNodeCount(child),0);
    return `<details class="directory-ou" open><summary><span>${e(name)}</span><b>${count}</b></summary><div>${body}</div></details>`;
  };
  return renderNode('',root,true);
}
function directoryNodeCount(node){return (node.users?.length||0)+[...(node.children?.values?.()||[])].reduce((sum,child)=>sum+directoryNodeCount(child),0)}
function renderDirectoryUsers(){
  const query=document.getElementById('directorySearch').value.trim();
  const visible=directoryUsersCache.filter(user=>directoryUserMatches(user,query));
  document.getElementById('directorySummary').textContent=`${visible.length} utilizatori afișați din ${directoryUsersCache.length}`;
  document.getElementById('directoryUsers').innerHTML=visible.length?directoryTreeHTML(visible):empty('Nu există utilizatori pentru filtrul ales.');
}
async function loadDirectoryUsers(){
  const department=document.getElementById('directoryDepartment').value;
  const target=document.getElementById('directoryUsers');
  directoryUsersCache=[];
  target.innerHTML='<div class="loading">Se încarcă utilizatorii…</div>';
  document.getElementById('directorySummary').textContent='';
  if(!department){target.innerHTML=empty('Nu există departamente disponibile.');return}
  try{directoryUsersCache=await api(`/api/v1/directory/users?department=${encodeURIComponent(department)}`);renderDirectoryUsers()}
  catch(err){target.innerHTML=empty(err.message);toast(err.message,true)}
}
async function openDirectoryImport(){
  const info=await loadDirectoryDepartments();
  if(!info.enabled){toast(info.error||'Importul din Active Directory nu este activat.',true);return}
  const department=document.getElementById('directoryDepartment');
  department.innerHTML=(info.departments||[]).map(value=>`<option value="${e(value)}" ${value===info.default_department?'selected':''}>${e(value)}</option>`).join('');
  document.getElementById('directorySearch').value='';
  directoryDialog.showModal();
  await loadDirectoryUsers();
}
function personMatchesFilters(person,filter){
  if(filter.status==='active'&&!person.active)return false;
  if(filter.status==='inactive'&&person.active)return false;
  if(filter.department&&person.department!==filter.department)return false;
  if(filter.source&&person.source!==filter.source)return false;
  const query=normalizedFilterText(filter.q);
  if(!query)return true;
  return [person.display_name,person.department,person.email,person.phone,person.directory_username].join(' ').toLocaleLowerCase('ro-RO').includes(query);
}
function peopleFilterForm(visibleCount,totalCount){
  const filter=nomenclatureFilterState('people');
  const departments=[...new Set(peopleCache.map(person=>String(person.department||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'ro',{sensitivity:'base'}));
  return `<form id="nomenclatureFilters" class="nomenclature-filters">
    <label class="nomenclature-filter-search">Caută<input name="q" type="search" value="${e(filter.q)}" placeholder="Nume, departament, email sau telefon"></label>
    <label>Departament<select name="department"><option value="">Toate departamentele</option>${departments.map(value=>`<option value="${e(value)}" ${filter.department===value?'selected':''}>${e(value)}</option>`).join('')}</select></label>
    <label>Sursă<select name="source"><option value="" ${!filter.source?'selected':''}>Toate</option><option value="ldap" ${filter.source==='ldap'?'selected':''}>Active Directory</option><option value="manual" ${filter.source==='manual'?'selected':''}>Manual</option></select></label>
    <label>Stare<select name="status"><option value="all" ${filter.status==='all'?'selected':''}>Toate</option><option value="active" ${filter.status==='active'?'selected':''}>Active</option><option value="inactive" ${filter.status==='inactive'?'selected':''}>Inactive</option></select></label>
    <div class="nomenclature-filter-actions"><button type="submit" class="small">Aplică filtre</button><button type="button" id="clearNomenclatureFilters" class="small secondary">Resetează</button></div>
    <span class="nomenclature-filter-summary">${visibleCount.toLocaleString('ro-RO')} rezultate din ${totalCount.toLocaleString('ro-RO')}</span>
  </form>`;
}
function peopleNomenclaturePanel(directoryInfo){
  const filter=nomenclatureFilterState('people');
  const filteredPeople=peopleCache.filter(person=>personMatchesFilters(person,filter));
  const info=nomenclaturePageInfo('people',filteredPeople.length);
  const visiblePeople=filteredPeople.slice(info.offset,info.end);
  const rows=visiblePeople.map(person=>`<tr><td><strong>${e(person.display_name)}</strong><div class="muted">${e(person.department||'')}</div></td><td>${e(person.email||'—')}</td><td>${e(person.phone||'—')}</td><td>${person.source==='ldap'?badge('AD'):badge('manual')}</td><td>${person.active?badge('active'):badge('disabled')}</td>${can('nomenclatures.manage')?`<td><button class="small secondary edit-person" data-id="${person.id}">Editează</button></td>`:''}</tr>`).join('');
  const head=`<tr><th>Persoană</th><th>Email</th><th>Telefon</th><th>Sursă</th><th>Stare</th>${can('nomenclatures.manage')?'<th></th>':''}</tr>`;
  const result=rows?`<div class="table-wrap"><table><thead>${head}</thead><tbody>${rows}</tbody></table></div>${nomenclaturePagination('people',info)}`:empty(peopleCache.length?'Nu există persoane pentru filtrele selectate.':'Nu există persoane definite.');
  let body=`${peopleFilterForm(filteredPeople.length,peopleCache.length)}${result}`;
  if(directoryInfo?.error)body=`<div class="notice warning">Active Directory nu a putut fi interogat: ${e(directoryInfo.error)}</div>${body}`;
  const tools=`<a class="button-link small secondary" href="/api/v1/nomenclatures/export?category=people&include_inactive=true">Export Excel</a>${can('nomenclatures.manage')?`<button id="addPerson" class="small secondary">Adaugă manual</button>${directoryInfo?.enabled?'<button id="importDirectoryPeople" class="small">Importă din AD</button>':''}`:''}`;
  return panel('Persoane',body,tools);
}
function nomenclatureNavigation(selectedCode){
  const categories=new Map(nomenclatureCache.map(category=>[category.code,category]));
  const rendered=new Set();
  const groups=nomenclatureNavigationGroups.map(group=>{
    const links=group.codes.map(code=>{
      if(code==='people'){
        rendered.add(code);
        return `<a href="#nomenclatures/people" class="${selectedCode==='people'?'active':''}"><span>Persoane</span><b>${peopleCache.length}</b></a>`;
      }
      const category=categories.get(code);if(!category)return '';
      rendered.add(code);
      return `<a href="#nomenclatures/${e(code)}" class="${selectedCode===code?'active':''}"><span>${e(category.label)}</span><b>${category.items.length}</b></a>`;
    }).join('');
    return links?`<section><h3>${e(group.label)}</h3>${links}</section>`:'';
  }).join('');
  const other=[...categories.values()].filter(category=>!rendered.has(category.code));
  const otherGroup=other.length?`<section><h3>Altele</h3>${other.map(category=>`<a href="#nomenclatures/${e(category.code)}" class="${selectedCode===category.code?'active':''}"><span>${e(category.label)}</span><b>${category.items.length}</b></a>`).join('')}</section>`:'';
  return `<aside class="nomenclature-submenu"><div class="nomenclature-submenu-title">Nomenclatoare</div>${groups}${otherGroup}</aside>`;
}
function refreshNomenclatureSection(code){
  const target=`#nomenclatures/${code}`;
  if(location.hash===target)nomenclaturesPage(code);else location.hash=target;
}
async function nomenclaturesPage(requestedCode=''){
  [nomenclatureCache,peopleCache]=await Promise.all([api('/api/v1/nomenclatures?include_inactive=true'),api('/api/v1/people?include_inactive=true')]);
  const allowedCodes=new Set([...nomenclatureCache.map(category=>category.code),'people']);
  const selectedCode=allowedCodes.has(requestedCode)?requestedCode:(nomenclatureCache[0]?.code||'people');
  if(requestedCode!==selectedCode)history.replaceState(null,'',`#nomenclatures/${selectedCode}`);
  const category=nomenclatureCache.find(value=>value.code===selectedCode);
  const label=selectedCode==='people'?'Persoane':category?.label||'Nomenclatoare';
  const description=nomenclatureDescriptions[selectedCode]||'Listă controlată folosită în fișele VM.';
  pageMeta('Nomenclatoare',`${label} · ${description}`);
  const directoryInfo=selectedCode==='people'?await loadDirectoryDepartments():null;
  const selectedPanel=selectedCode==='people'?peopleNomenclaturePanel(directoryInfo):nomenclaturePanel(category);
  content.innerHTML=`<div class="nomenclature-layout">
    ${nomenclatureNavigation(selectedCode)}
    <div class="nomenclature-workspace">
      <div class="nomenclature-context"><span>${e(label)}</span><p>${e(description)}</p></div>
      ${selectedPanel}
    </div>
  </div>`;
  content.querySelectorAll('.add-nomenclature').forEach(button=>button.onclick=()=>openNomenclature(null,button.dataset.category));
  content.querySelectorAll('.edit-nomenclature').forEach(button=>button.onclick=()=>{const item=nomenclatureCache.flatMap(value=>value.items).find(value=>value.id===Number(button.dataset.id));openNomenclature(item)});
  document.getElementById('addPerson')?.addEventListener('click',()=>openPerson());
  document.getElementById('importDirectoryPeople')?.addEventListener('click',openDirectoryImport);
  content.querySelectorAll('.edit-person').forEach(button=>button.onclick=()=>openPerson(peopleCache.find(person=>person.id===Number(button.dataset.id))));
  document.getElementById('nomenclatureFilters')?.addEventListener('submit',event=>{
    event.preventDefault();
    const values=Object.fromEntries(new FormData(event.currentTarget).entries());
    state.nomenclatureFilters[selectedCode]={q:String(values.q||'').trim(),status:String(values.status||'all'),parent:String(values.parent||''),layer:String(values.layer||''),department:String(values.department||''),source:String(values.source||'')};
    const paging=state.nomenclaturePaging[selectedCode]||{page:1,pageSize:20};paging.page=1;state.nomenclaturePaging[selectedCode]=paging;
    nomenclaturesPage(selectedCode);
  });
  document.getElementById('clearNomenclatureFilters')?.addEventListener('click',()=>{
    state.nomenclatureFilters[selectedCode]={q:'',status:'all',parent:'',layer:'',department:'',source:''};
    const paging=state.nomenclaturePaging[selectedCode]||{page:1,pageSize:20};paging.page=1;state.nomenclaturePaging[selectedCode]=paging;
    nomenclaturesPage(selectedCode);
  });
  content.querySelectorAll('.nomenclature-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);const paging=state.nomenclaturePaging[selectedCode]||{page:1,pageSize:20};if(page>0&&page!==paging.page){paging.page=page;state.nomenclaturePaging[selectedCode]=paging;nomenclaturesPage(selectedCode)}}));
  document.getElementById('nomenclaturePageSize')?.addEventListener('change',event=>{state.nomenclaturePaging[selectedCode]={page:1,pageSize:Number(event.target.value)};nomenclaturesPage(selectedCode)});
}

nomenclatureForm.addEventListener('submit',async event=>{
  event.preventDefault();if(!can('nomenclatures.manage'))return;
  const id=Number(document.getElementById('nomenclatureId').value||0);
  const categoryCode=document.getElementById('nomenclatureCategory').value;
  const parent=document.getElementById('nomenclatureParent');
  const parentValue=parent.value;
  const layerIDs=categoryCode==='technical_role'?[...parent.selectedOptions].map(option=>Number(option.value)).filter(Boolean):[];
  if(categoryCode==='technical_role'&&!layerIDs.length){toast('Selectează cel puțin un layer pentru rolul tehnic.',true);return}
  const body={category_code:categoryCode,name:document.getElementById('nomenclatureName').value.trim(),item_code:document.getElementById('nomenclatureCode').value.trim(),description:document.getElementById('nomenclatureDescription').value.trim(),sort_order:Number(document.getElementById('nomenclatureOrder').value||0),active:document.getElementById('nomenclatureActive').checked,parent_id:categoryCode==='itil_category'&&parentValue?Number(parentValue):null,layer_ids:layerIDs};
  try{await api(id?`/api/v1/nomenclatures/items/${id}`:'/api/v1/nomenclatures/items',{method:id?'PATCH':'POST',body:JSON.stringify(body)});nomenclatureDialog.close();toast(id?'Valoare actualizată.':'Valoare creată.');refreshNomenclatureSection(categoryCode)}catch(err){toast(err.message,true)}
});
personForm.addEventListener('submit',async event=>{
  event.preventDefault();if(!can('nomenclatures.manage'))return;
  const id=Number(document.getElementById('personId').value||0);const body={display_name:document.getElementById('personName').value.trim(),email:document.getElementById('personEmail').value.trim(),phone:document.getElementById('personPhone').value.trim(),department:document.getElementById('personDepartment').value.trim(),active:document.getElementById('personActive').checked};
  try{await api(id?`/api/v1/people/${id}`:'/api/v1/people',{method:id?'PATCH':'POST',body:JSON.stringify(body)});personDialog.close();toast(id?'Persoană actualizată.':'Persoană creată.');refreshNomenclatureSection('people')}catch(err){toast(err.message,true)}
});

document.getElementById('directoryDepartment').addEventListener('change',loadDirectoryUsers);
document.getElementById('directorySearch').addEventListener('input',renderDirectoryUsers);
document.getElementById('directoryToggleAll').addEventListener('click',()=>{
  const checks=[...document.querySelectorAll('#directoryUsers .directory-user-check')];
  const select=checks.some(check=>!check.checked);checks.forEach(check=>check.checked=select);
});
directoryForm.addEventListener('submit',async event=>{
  event.preventDefault();if(!can('nomenclatures.manage'))return;
  const distinguishedNames=[...document.querySelectorAll('#directoryUsers .directory-user-check:checked')].map(check=>check.value);
  if(!distinguishedNames.length){toast('Selectează cel puțin un utilizator din Active Directory.',true);return}
  try{const imported=await api('/api/v1/people/import-directory',{method:'POST',body:JSON.stringify({distinguished_names:distinguishedNames})});directoryDialog.close();toast(`${imported.length} persoane importate sau actualizate din AD.`);refreshNomenclatureSection('people')}catch(err){toast(err.message,true)}
});


function openDocumentTemplate(template=null){
  document.getElementById('documentTemplateDialogTitle').textContent=template?'Editare șablon DOCX':'Șablon DOCX nou';
  document.getElementById('documentTemplateId').value=template?.id||'';
  document.getElementById('documentTemplateName').value=template?.name||'';
  document.getElementById('documentTemplateCode').value=template?.code||'';
  document.getElementById('documentTemplateDescription').value=template?.description||'';
  document.getElementById('documentTemplateActive').checked=template?.active??true;
  document.getElementById('documentTemplateDefault').checked=template?.is_default??false;
  const file=document.getElementById('documentTemplateFile');file.value='';file.required=!template;
  document.getElementById('documentTemplateFileLabel').hidden=Boolean(template);
  documentTemplateDialog.showModal();
}
function documentTemplateRows(values){
  if(!values?.length)return empty('Nu există șabloane DOCX.');
  const rows=values.map(item=>`<tr><td><strong>${e(item.name)}</strong>${item.description?`<div class="muted">${e(item.description)}</div>`:''}</td><td class="mono">${e(item.code)}</td><td>${e(item.file_name)}</td><td>${bytesText(item.size_bytes)}</td><td>${item.is_default?badge('implicit'):''}</td><td>${item.active?badge('active'):badge('disabled')}</td><td><div class="actions"><a class="button-link small secondary" href="/api/v1/document-templates/${item.id}/download">Descarcă</a>${can('documents.manage')?`<button class="small secondary edit-document-template" data-id="${item.id}">Editează</button>`:''}</div></td></tr>`).join('');
  return `<div class="table-wrap"><table><thead><tr><th>Șablon</th><th>Cod</th><th>Fișier</th><th>Mărime</th><th>Implicit</th><th>Stare</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`;
}
async function documentsPage(){
  pageMeta('Documente','Șabloane DOCX și generarea fișelor tehnice VM');
  state.documentTemplates=await api(`/api/v1/document-templates${can('documents.manage')?'?include_inactive=true':''}`);
  const active=state.documentTemplates.filter(item=>item.active).length;
  const defaultTemplate=state.documentTemplates.find(item=>item.is_default);
  content.innerHTML=`<div class="cards"><div class="card"><div class="label">Șabloane</div><div class="value">${state.documentTemplates.length}</div></div><div class="card"><div class="label">Șabloane active</div><div class="value">${active}</div></div><div class="card"><div class="label">Șablon implicit</div><div class="value compact">${e(defaultTemplate?.name||'—')}</div></div></div>${panel('Șabloane DOCX',documentTemplateRows(state.documentTemplates),can('documents.manage')?'<button id="newDocumentTemplate">Încarcă șablon</button>':'')}${panel('Placeholdere acceptate',`<div class="document-placeholders"><code>{{VM_DOCUMENT_BODY}}</code><span>obligatoriu, într-un paragraf separat</span><code>{{document.number}}</code><span>numărul fișei</span><code>{{document.generated_at}}</code><span>data generării</span><code>{{document.generated_by}}</code><span>utilizatorul care generează</span><code>{{vm.name}}</code><span>numele VM-ului</span><code>{{vm.hostname}}</code><span>hostname</span><code>{{vm.ip}}</code><span>IP principal</span><code>{{vm.os}}</code><span>sistemul de operare</span><code>{{vm.environment}}</code><span>mediul</span><code>{{vm.status}}</code><span>status operațional</span><code>{{vm.classification}}</code><span>clasificarea</span><code>{{vm.purpose}}</code><span>scopul VM-ului</span></div>`)} `;
  document.getElementById('newDocumentTemplate')?.addEventListener('click',()=>openDocumentTemplate());
  content.querySelectorAll('.edit-document-template').forEach(button=>button.addEventListener('click',()=>openDocumentTemplate(state.documentTemplates.find(item=>item.id===Number(button.dataset.id)))));
}

documentTemplateForm.addEventListener('submit',async event=>{
  event.preventDefault();if(!can('documents.manage'))return;
  const id=Number(document.getElementById('documentTemplateId').value||0);
  const name=document.getElementById('documentTemplateName').value.trim();
  const code=document.getElementById('documentTemplateCode').value.trim();
  const description=document.getElementById('documentTemplateDescription').value.trim();
  const active=document.getElementById('documentTemplateActive').checked;
  const isDefault=document.getElementById('documentTemplateDefault').checked;
  try{
    if(id){await api(`/api/v1/document-templates/${id}`,{method:'PATCH',body:JSON.stringify({name,code,description,active,is_default:isDefault})})}
    else{const file=document.getElementById('documentTemplateFile').files[0];if(!file){toast('Alege fișierul DOCX.',true);return}const body=new FormData();body.set('name',name);body.set('code',code);body.set('description',description);body.set('active',String(active));body.set('is_default',String(isDefault));body.set('file',file);await api('/api/v1/document-templates',{method:'POST',body})}
    documentTemplateDialog.close();toast(id?'Șablon actualizat.':'Șablon încărcat.');documentsPage();
  }catch(err){toast(err.message,true)}
});

async function auditPage(){pageMeta('Audit','Acțiuni administrative și operaționale');content.innerHTML=panel('Evenimente de audit','<div id="auditTableArea" class="loading">Se încarcă evenimentele…</div>');await loadAuditPage()}
function renderAuditPage(result){
  const items=Array.isArray(result?.items)?result.items:[];
  if(!items.length)return empty('Nu există evenimente de audit.');
  const rows=items.map(record=>`<tr><td>${dt(record.occurred_at)}</td><td>${e(record.source)}</td><td>${e(record.actor_username||'sistem')}</td><td class="mono">${e(record.action)}</td><td>${e(record.resource_type)} ${e(record.resource_id)}</td><td>${badge(record.outcome)}</td></tr>`).join('');
  const total=Number(result.total||0),page=Number(result.page||1),pageSize=Number(result.page_size||50),start=(page-1)*pageSize+1,end=Math.min(page*pageSize,total);
  return `<div class="table-wrap"><table><thead><tr><th>Data</th><th>Sursă</th><th>Actor</th><th>Acțiune</th><th>Resursă</th><th>Rezultat</th></tr></thead><tbody>${rows}</tbody></table></div><div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="auditPageSize">${pageSizeOptions(pageSize,[25,50,100,200])}</select></label>${paginationButtons(page,Number(result.pages||1),'audit-page')}</div></div>`;
}
async function loadAuditPage(){
  const area=document.getElementById('auditTableArea');if(!area)return;area.className='loading';area.textContent='Se încarcă evenimentele…';
  try{const result=await api(`/api/v1/audit/events?page=${state.audit.page}&page_size=${state.audit.pageSize}`);state.audit.page=Number(result?.page||1);state.audit.pageSize=Number(result?.page_size||50);area.className='';area.innerHTML=renderAuditPage(result);area.querySelectorAll('.audit-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==state.audit.page){state.audit.page=page;loadAuditPage()}}));document.getElementById('auditPageSize')?.addEventListener('change',event=>{state.audit.pageSize=Number(event.target.value);state.audit.page=1;loadAuditPage()})}catch(err){area.className='';area.innerHTML=empty(err.message);toast(err.message,true)}
}

async function accessPage(){pageMeta('Acces','Mapări grupuri LDAP/OIDC către roluri');const [roles,maps]=await Promise.all([api('/api/v1/rbac/roles'),api('/api/v1/rbac/group-mappings')]);content.innerHTML=`${panel('Adaugă mapare',`<form id="mappingForm" class="detail-grid"><label>Provider<select id="mapProvider"><option value="ldap">LDAP</option><option value="oidc">OIDC</option><option value="any">Oricare</option></select></label><label>Grup<input id="mapGroup" required placeholder="VM-DOC-Operators"></label><label>Rol<select id="mapRole">${roles.map(r=>`<option value="${e(r.name)}">${e(r.name)}</option>`).join('')}</select></label><label class="form-submit"><button type="submit">Adaugă</button></label></form>`)}${panel('Mapări existente',maps.length?`<div class="table-wrap"><table><thead><tr><th>Provider</th><th>Grup</th><th>Rol</th><th></th></tr></thead><tbody>${maps.map(m=>`<tr><td>${e(m.provider)}</td><td class="mono">${e(m.group_name)}</td><td>${badge(m.role)}</td><td><button class="small danger del-map" data-id="${m.id}">Șterge</button></td></tr>`).join('')}</tbody></table></div>`:empty('Nu există mapări.'))}`;
  document.getElementById('mappingForm').onsubmit=async ev=>{ev.preventDefault();await api('/api/v1/rbac/group-mappings',{method:'POST',body:JSON.stringify({provider:document.getElementById('mapProvider').value,group_name:document.getElementById('mapGroup').value.trim(),role:document.getElementById('mapRole').value})});toast('Mapare creată.');accessPage()};content.querySelectorAll('.del-map').forEach(b=>b.onclick=async()=>{await api(`/api/v1/rbac/group-mappings/${b.dataset.id}`,{method:'DELETE'});toast('Mapare ștearsă.');accessPage()})
}

document.getElementById('logoutButton').onclick=async()=>{await api('/api/v1/auth/logout',{method:'POST'});location.href='/login'};
document.getElementById('themeButton').onclick=()=>{const next=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=next;localStorage.setItem('vm-doc-theme',next)};
const savedTheme=localStorage.getItem('vm-doc-theme');if(savedTheme)document.documentElement.dataset.theme=savedTheme;
window.addEventListener('hashchange',route);
document.querySelectorAll('[data-close-dialog]').forEach(button=>button.addEventListener('click',()=>button.closest('dialog').close()));
init();

# Generarea fișei tehnice VM

## Flux

```text
Fișa VM
└── alegere șablon DOCX
    ├── previzualizare date
    └── generare DOCX
        ├── număr unic
        ├── SHA-256
        ├── snapshot inventar sursă
        ├── autor și dată
        └── istoric și descărcare
```

## Date incluse

- identificare și resurse din vCenter;
- hostname, IP și sistem de operare din inventarul agentului, cu fallback la vCenter;
- mediu, status operațional, clasificare, scop și observații;
- domeniu, categorie de serviciu, serviciu intern, layer și rol tehnic;
- responsabilități și date de contact;
- backup și restaurare;
- inventarul structurat al agentului, cu mascarea valorilor sensibile realizată de `inventory.BuildDocumentView`.

## Șablonul DOCX

Șablonul trebuie să fie un fișier `.docx` valid și să conțină, într-un paragraf separat:

```text
{{VM_DOCUMENT_BODY}}
```

Paragraful este înlocuit cu toate secțiunile generate. Pentru rezultate previzibile, placeholderul nu trebuie formatat pe bucăți diferite în Word.

Placeholdere scalare disponibile:

```text
{{document.number}}
{{document.generated_at}}
{{document.generated_by}}
{{vm.name}}
{{vm.hostname}}
{{vm.ip}}
{{vm.os}}
{{vm.environment}}
{{vm.status}}
{{vm.classification}}
{{vm.purpose}}
```

Placeholderele scalare trebuie și ele păstrate într-un singur segment de text Word.

## Securitate

- șabloanele și documentele sunt stocate în MariaDB;
- fișierele generate păstrează SHA-256 și dimensiunea;
- generarea și descărcarea sunt auditate;
- valorile din inventar cu nume de tip `password`, `secret`, `token`, `credential`, `private_key`, `api_key` sau `access_key` sunt redactate înainte de generare;
- accesul este controlat prin `documents.read` și `documents.manage`.

## Limitări 0.5.0

- se generează numai DOCX;
- conversia PDF și semnarea digitală vor fi implementate ulterior;
- șablonul personalizat trebuie să păstreze placeholderul principal într-un paragraf separat;
- documentele foarte mari pot crește dimensiunea bazei MariaDB, deoarece conținutul este păstrat pentru audit și redescărcare.

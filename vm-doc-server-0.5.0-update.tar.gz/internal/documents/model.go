package documents

import (
	"encoding/json"
	"time"

	"vm-doc-server/internal/domain"
	"vm-doc-server/internal/inventory"
)

const (
	DOCXContentType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
	BodyPlaceholder = "{{VM_DOCUMENT_BODY}}"
)

type Template struct {
	ID          int64     `json:"id"`
	Name        string    `json:"name"`
	Code        string    `json:"code"`
	Description string    `json:"description,omitempty"`
	FileName    string    `json:"file_name"`
	MIMEType    string    `json:"mime_type"`
	SHA256      string    `json:"sha256"`
	SizeBytes   int64     `json:"size_bytes"`
	Active      bool      `json:"active"`
	Default     bool      `json:"is_default"`
	CreatedBy   *int64    `json:"created_by,omitempty"`
	UpdatedBy   *int64    `json:"updated_by,omitempty"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
	Content     []byte    `json:"-"`
}

type TemplateInput struct {
	Name        string
	Code        string
	Description string
	FileName    string
	MIMEType    string
	Content     []byte
	Active      bool
	Default     bool
}

type TemplateUpdate struct {
	Name        string `json:"name"`
	Code        string `json:"code"`
	Description string `json:"description"`
	Active      bool   `json:"active"`
	Default     bool   `json:"is_default"`
}

type GeneratedDocument struct {
	ID                int64     `json:"id"`
	VMID              int64     `json:"vm_id"`
	VMName            string    `json:"vm_name"`
	TemplateID        *int64    `json:"template_id,omitempty"`
	TemplateName      string    `json:"template_name"`
	DocumentNumber    string    `json:"document_number"`
	FileName          string    `json:"file_name"`
	MIMEType          string    `json:"mime_type"`
	SHA256            string    `json:"sha256"`
	SizeBytes         int64     `json:"size_bytes"`
	SourceInventoryID *int64    `json:"source_inventory_id,omitempty"`
	GeneratedBy       *int64    `json:"generated_by,omitempty"`
	GeneratedByName   string    `json:"generated_by_name,omitempty"`
	GeneratedAt       time.Time `json:"generated_at"`
	Content           []byte    `json:"-"`
}

type GenerationData struct {
	VM                domain.VirtualMachine
	Operational       domain.VMOperationalMetadata
	Backup            domain.VMBackupSummary
	Inventory         *domain.Inventory
	InventoryDocument *inventory.DocumentView
	GeneratedBy       domain.User
	GeneratedAt       time.Time
	DocumentNumber    string
}

type Preview struct {
	VMID              int64            `json:"vm_id"`
	VMName            string           `json:"vm_name"`
	TemplateID        int64            `json:"template_id"`
	TemplateName      string           `json:"template_name"`
	DocumentNumber    string           `json:"document_number"`
	GeneratedAt       time.Time        `json:"generated_at"`
	SourceInventoryID *int64           `json:"source_inventory_id,omitempty"`
	Warnings          []string         `json:"warnings"`
	Sections          []PreviewSection `json:"sections"`
}

type PreviewSection struct {
	Title string       `json:"title"`
	Rows  []PreviewRow `json:"rows"`
}

type PreviewRow struct {
	Label string `json:"label"`
	Value string `json:"value"`
}

func (d GeneratedDocument) AuditSummary() json.RawMessage {
	value, _ := json.Marshal(map[string]any{
		"document_number": d.DocumentNumber,
		"file_name":       d.FileName,
		"sha256":          d.SHA256,
		"size_bytes":      d.SizeBytes,
		"template_id":     d.TemplateID,
	})
	return value
}

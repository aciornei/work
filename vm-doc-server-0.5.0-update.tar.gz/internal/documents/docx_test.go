package documents

import (
	"archive/zip"
	"bytes"
	"io"
	"strings"
	"testing"
	"time"

	"vm-doc-server/internal/domain"
	"vm-doc-server/internal/inventory"
)

func TestDefaultTemplateAndRender(t *testing.T) {
	template, err := DefaultTemplate()
	if err != nil {
		t.Fatal(err)
	}
	if err := ValidateTemplate(template); err != nil {
		t.Fatal(err)
	}
	now := time.Date(2026, 9, 1, 12, 30, 0, 0, time.UTC)
	view := inventory.DocumentView{Sections: []inventory.DocumentSection{{Key: "network", Title: "Rețea", Data: map[string]any{"primary_ip": "10.0.0.10"}}}}
	data := GenerationData{
		VM:                domain.VirtualMachine{ID: 295, Name: "vm-test", CPUCount: 4, MemoryMiB: 8192, PowerState: "poweredOn", GuestHostname: "vm-test", PrimaryIP: "10.0.0.10"},
		Operational:       domain.VMOperationalMetadata{Environment: "Producție", OperationalStatus: "Activ"},
		InventoryDocument: &view,
		GeneratedBy:       domain.User{Username: "tester", DisplayName: "Test User"},
		GeneratedAt:       now,
		DocumentNumber:    "FVM-20260901-000295-ABCD",
	}
	output, err := RenderDOCX(template, data)
	if err != nil {
		t.Fatal(err)
	}
	reader, err := zip.NewReader(bytes.NewReader(output), int64(len(output)))
	if err != nil {
		t.Fatal(err)
	}
	var document string
	for _, file := range reader.File {
		if file.Name != "word/document.xml" {
			continue
		}
		handle, err := file.Open()
		if err != nil {
			t.Fatal(err)
		}
		content, err := io.ReadAll(handle)
		handle.Close()
		if err != nil {
			t.Fatal(err)
		}
		document = string(content)
	}
	if document == "" {
		t.Fatal("word/document.xml missing")
	}
	if strings.Contains(document, BodyPlaceholder) {
		t.Fatal("body placeholder was not replaced")
	}
	for _, expected := range []string{"Fișă tehnică VM", "vm-test", "FVM-20260901-000295-ABCD", "Rețea", "10.0.0.10"} {
		if !strings.Contains(document, expected) {
			t.Fatalf("document does not contain %q", expected)
		}
	}
}

func TestValidateTemplateRequiresBodyPlaceholder(t *testing.T) {
	template, err := DefaultTemplate()
	if err != nil {
		t.Fatal(err)
	}
	reader, err := zip.NewReader(bytes.NewReader(template), int64(len(template)))
	if err != nil {
		t.Fatal(err)
	}
	var output bytes.Buffer
	writer := zip.NewWriter(&output)
	for _, source := range reader.File {
		handle, err := source.Open()
		if err != nil {
			t.Fatal(err)
		}
		content, err := io.ReadAll(handle)
		handle.Close()
		if err != nil {
			t.Fatal(err)
		}
		if source.Name == "word/document.xml" {
			content = bytes.ReplaceAll(content, []byte(BodyPlaceholder), []byte("missing"))
		}
		destination, err := writer.Create(source.Name)
		if err != nil {
			t.Fatal(err)
		}
		if _, err := destination.Write(content); err != nil {
			t.Fatal(err)
		}
	}
	if err := writer.Close(); err != nil {
		t.Fatal(err)
	}
	if err := ValidateTemplate(output.Bytes()); err == nil {
		t.Fatal("expected validation error")
	}
}

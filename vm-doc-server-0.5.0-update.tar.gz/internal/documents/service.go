package documents

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"errors"
	"fmt"
	"path/filepath"
	"regexp"
	"strings"
	"time"
)

var templateCodePattern = regexp.MustCompile(`^[a-z0-9][a-z0-9._-]{1,63}$`)

type Service struct {
	DB *sql.DB
}

func (s Service) EnsureDefault(ctx context.Context) error {
	var count int
	if err := s.DB.QueryRowContext(ctx, `SELECT COUNT(*) FROM document_templates`).Scan(&count); err != nil {
		return err
	}
	if count > 0 {
		return nil
	}
	content, err := DefaultTemplate()
	if err != nil {
		return err
	}
	_, err = s.CreateTemplate(ctx, TemplateInput{
		Name:        "Fișă tehnică VM standard",
		Code:        "vm.standard",
		Description: "Șablonul implicit livrat cu vm-doc-server. Conține placeholderul {{VM_DOCUMENT_BODY}}.",
		FileName:    "fisa-tehnica-vm-standard.docx",
		MIMEType:    DOCXContentType,
		Content:     content,
		Active:      true,
		Default:     true,
	}, 0)
	return err
}

func (s Service) ListTemplates(ctx context.Context, includeInactive bool) ([]Template, error) {
	query := `SELECT id,name,template_code,description,file_name,mime_type,sha256,size_bytes,active,is_default,created_by,updated_by,created_at,updated_at FROM document_templates`
	if !includeInactive {
		query += ` WHERE active=1`
	}
	query += ` ORDER BY is_default DESC,active DESC,name,id`
	rows, err := s.DB.QueryContext(ctx, query)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]Template, 0)
	for rows.Next() {
		value, err := scanTemplate(rows, false)
		if err != nil {
			return nil, err
		}
		out = append(out, value)
	}
	return out, rows.Err()
}

func (s Service) GetTemplate(ctx context.Context, id int64, withContent bool) (Template, error) {
	columns := `id,name,template_code,description,file_name,mime_type,sha256,size_bytes,active,is_default,created_by,updated_by,created_at,updated_at`
	if withContent {
		columns += `,content`
	}
	return scanTemplate(s.DB.QueryRowContext(ctx, `SELECT `+columns+` FROM document_templates WHERE id=?`, id), withContent)
}

func (s Service) DefaultTemplate(ctx context.Context) (Template, error) {
	return scanTemplate(s.DB.QueryRowContext(ctx, `SELECT id,name,template_code,description,file_name,mime_type,sha256,size_bytes,active,is_default,created_by,updated_by,created_at,updated_at,content FROM document_templates WHERE active=1 ORDER BY is_default DESC,name,id LIMIT 1`), true)
}

func (s Service) CreateTemplate(ctx context.Context, input TemplateInput, userID int64) (Template, error) {
	if err := normalizeTemplateInput(&input); err != nil {
		return Template{}, err
	}
	if err := ValidateTemplate(input.Content); err != nil {
		return Template{}, err
	}
	hash := sha256.Sum256(input.Content)
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return Template{}, err
	}
	defer tx.Rollback()
	if input.Default {
		if _, err := tx.ExecContext(ctx, `UPDATE document_templates SET is_default=0 WHERE is_default=1`); err != nil {
			return Template{}, err
		}
	}
	var createdBy any
	if userID > 0 {
		createdBy = userID
	}
	result, err := tx.ExecContext(ctx, `INSERT INTO document_templates(name,template_code,description,file_name,mime_type,content,sha256,size_bytes,active,is_default,created_by,updated_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`,
		input.Name, input.Code, input.Description, input.FileName, input.MIMEType, input.Content, hex.EncodeToString(hash[:]), len(input.Content), input.Active, input.Default, createdBy, createdBy)
	if err != nil {
		return Template{}, err
	}
	id, err := result.LastInsertId()
	if err != nil {
		return Template{}, err
	}
	if err := tx.Commit(); err != nil {
		return Template{}, err
	}
	return s.GetTemplate(ctx, id, false)
}

func (s Service) UpdateTemplate(ctx context.Context, id, userID int64, input TemplateUpdate) (Template, error) {
	input.Name = strings.TrimSpace(input.Name)
	input.Code = strings.ToLower(strings.TrimSpace(input.Code))
	input.Description = strings.TrimSpace(input.Description)
	if input.Name == "" || input.Code == "" {
		return Template{}, errors.New("name and code are required")
	}
	if !templateCodePattern.MatchString(input.Code) {
		return Template{}, errors.New("template code is invalid")
	}
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return Template{}, err
	}
	defer tx.Rollback()
	if input.Default {
		if !input.Active {
			return Template{}, errors.New("default template must be active")
		}
		if _, err := tx.ExecContext(ctx, `UPDATE document_templates SET is_default=0 WHERE is_default=1 AND id<>?`, id); err != nil {
			return Template{}, err
		}
	}
	result, err := tx.ExecContext(ctx, `UPDATE document_templates SET name=?,template_code=?,description=?,active=?,is_default=?,updated_by=? WHERE id=?`, input.Name, input.Code, input.Description, input.Active, input.Default, nullableUserID(userID), id)
	if err != nil {
		return Template{}, err
	}
	if rows, _ := result.RowsAffected(); rows == 0 {
		return Template{}, sql.ErrNoRows
	}
	if err := tx.Commit(); err != nil {
		return Template{}, err
	}
	return s.GetTemplate(ctx, id, false)
}

func (s Service) ListGenerated(ctx context.Context, vmID int64) ([]GeneratedDocument, error) {
	rows, err := s.DB.QueryContext(ctx, `SELECT d.id,d.vm_id,vm.name,d.template_id,COALESCE(t.name,d.template_name),d.document_number,d.file_name,d.mime_type,d.sha256,d.size_bytes,d.source_inventory_id,d.generated_by,COALESCE(u.display_name,u.username,''),d.generated_at
		FROM generated_documents d
		JOIN virtual_machines vm ON vm.id=d.vm_id
		LEFT JOIN document_templates t ON t.id=d.template_id
		LEFT JOIN users u ON u.id=d.generated_by
		WHERE d.vm_id=? ORDER BY d.id DESC`, vmID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := make([]GeneratedDocument, 0)
	for rows.Next() {
		value, err := scanGenerated(rows, false)
		if err != nil {
			return nil, err
		}
		out = append(out, value)
	}
	return out, rows.Err()
}

func (s Service) GetGenerated(ctx context.Context, id int64, withContent bool) (GeneratedDocument, error) {
	columns := `d.id,d.vm_id,vm.name,d.template_id,COALESCE(t.name,d.template_name),d.document_number,d.file_name,d.mime_type,d.sha256,d.size_bytes,d.source_inventory_id,d.generated_by,COALESCE(u.display_name,u.username,''),d.generated_at`
	if withContent {
		columns += `,d.content`
	}
	return scanGenerated(s.DB.QueryRowContext(ctx, `SELECT `+columns+` FROM generated_documents d JOIN virtual_machines vm ON vm.id=d.vm_id LEFT JOIN document_templates t ON t.id=d.template_id LEFT JOIN users u ON u.id=d.generated_by WHERE d.id=?`, id), withContent)
}

func (s Service) Generate(ctx context.Context, template Template, data GenerationData) (GeneratedDocument, error) {
	if !template.Active {
		return GeneratedDocument{}, errors.New("template is inactive")
	}
	if len(template.Content) == 0 {
		var err error
		template, err = s.GetTemplate(ctx, template.ID, true)
		if err != nil {
			return GeneratedDocument{}, err
		}
	}
	if data.GeneratedAt.IsZero() {
		data.GeneratedAt = time.Now().UTC()
	}
	if data.DocumentNumber == "" {
		data.DocumentNumber = NewDocumentNumber(data.VM.ID, data.GeneratedAt)
	}
	content, err := RenderDOCX(template.Content, data)
	if err != nil {
		return GeneratedDocument{}, err
	}
	hash := sha256.Sum256(content)
	filename := safeDocumentFileName(data.VM.Name, data.DocumentNumber)
	var inventoryID any
	if data.Inventory != nil {
		inventoryID = data.Inventory.ID
	}
	var generatedBy any
	if data.GeneratedBy.ID > 0 {
		generatedBy = data.GeneratedBy.ID
	}
	result, err := s.DB.ExecContext(ctx, `INSERT INTO generated_documents(vm_id,template_id,template_name,document_number,file_name,mime_type,content,sha256,size_bytes,source_inventory_id,generated_by,generated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`,
		data.VM.ID, template.ID, template.Name, data.DocumentNumber, filename, DOCXContentType, content, hex.EncodeToString(hash[:]), len(content), inventoryID, generatedBy, data.GeneratedAt)
	if err != nil {
		return GeneratedDocument{}, err
	}
	id, err := result.LastInsertId()
	if err != nil {
		return GeneratedDocument{}, err
	}
	return s.GetGenerated(ctx, id, false)
}

func NewDocumentNumber(vmID int64, now time.Time) string {
	var suffix [4]byte
	if _, err := rand.Read(suffix[:]); err != nil {
		suffix[0], suffix[1], suffix[2], suffix[3] = byte(now.UnixNano()), byte(now.UnixNano()>>8), byte(now.UnixNano()>>16), byte(now.UnixNano()>>24)
	}
	return fmt.Sprintf("FVM-%s-%06d-%s", now.UTC().Format("20060102"), vmID, strings.ToUpper(hex.EncodeToString(suffix[:])))
}

func normalizeTemplateInput(input *TemplateInput) error {
	input.Name = strings.TrimSpace(input.Name)
	input.Code = strings.ToLower(strings.TrimSpace(input.Code))
	input.Description = strings.TrimSpace(input.Description)
	input.FileName = filepath.Base(strings.TrimSpace(input.FileName))
	input.MIMEType = strings.TrimSpace(input.MIMEType)
	if input.Name == "" || input.Code == "" || input.FileName == "" || len(input.Content) == 0 {
		return errors.New("name, code and DOCX file are required")
	}
	if !templateCodePattern.MatchString(input.Code) {
		return errors.New("template code is invalid")
	}
	if !strings.EqualFold(filepath.Ext(input.FileName), ".docx") {
		return errors.New("template file must have .docx extension")
	}
	if input.MIMEType == "" || input.MIMEType == "application/octet-stream" {
		input.MIMEType = DOCXContentType
	}
	if len(input.Content) > 20<<20 {
		return errors.New("template file must be at most 20 MiB")
	}
	if input.Default && !input.Active {
		return errors.New("default template must be active")
	}
	return nil
}

func safeDocumentFileName(vmName, number string) string {
	name := strings.TrimSpace(vmName)
	if name == "" {
		name = "vm"
	}
	var builder strings.Builder
	for _, r := range name {
		switch {
		case r >= 'a' && r <= 'z', r >= 'A' && r <= 'Z', r >= '0' && r <= '9', r == '-', r == '_', r == '.':
			builder.WriteRune(r)
		default:
			builder.WriteByte('-')
		}
	}
	clean := strings.Trim(builder.String(), "-._")
	if clean == "" {
		clean = "vm"
	}
	return clean + "-" + strings.ToLower(number) + ".docx"
}

func nullableUserID(id int64) any {
	if id <= 0 {
		return nil
	}
	return id
}

type rowScanner interface{ Scan(dest ...any) error }

func scanTemplate(scanner rowScanner, withContent bool) (Template, error) {
	var value Template
	var createdBy, updatedBy sql.NullInt64
	args := []any{&value.ID, &value.Name, &value.Code, &value.Description, &value.FileName, &value.MIMEType, &value.SHA256, &value.SizeBytes, &value.Active, &value.Default, &createdBy, &updatedBy, &value.CreatedAt, &value.UpdatedAt}
	if withContent {
		args = append(args, &value.Content)
	}
	if err := scanner.Scan(args...); err != nil {
		return value, err
	}
	if createdBy.Valid {
		id := createdBy.Int64
		value.CreatedBy = &id
	}
	if updatedBy.Valid {
		id := updatedBy.Int64
		value.UpdatedBy = &id
	}
	return value, nil
}

func scanGenerated(scanner rowScanner, withContent bool) (GeneratedDocument, error) {
	var value GeneratedDocument
	var templateID, inventoryID, generatedBy sql.NullInt64
	args := []any{&value.ID, &value.VMID, &value.VMName, &templateID, &value.TemplateName, &value.DocumentNumber, &value.FileName, &value.MIMEType, &value.SHA256, &value.SizeBytes, &inventoryID, &generatedBy, &value.GeneratedByName, &value.GeneratedAt}
	if withContent {
		args = append(args, &value.Content)
	}
	if err := scanner.Scan(args...); err != nil {
		return value, err
	}
	if templateID.Valid {
		id := templateID.Int64
		value.TemplateID = &id
	}
	if inventoryID.Valid {
		id := inventoryID.Int64
		value.SourceInventoryID = &id
	}
	if generatedBy.Valid {
		id := generatedBy.Int64
		value.GeneratedBy = &id
	}
	return value, nil
}

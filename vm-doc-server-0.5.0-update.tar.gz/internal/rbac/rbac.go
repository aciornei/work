package rbac

import (
	"encoding/json"
	"net/http"
	"vm-doc-server/internal/auth"
)

var rolePermissions = map[string]map[string]bool{
	"admin":    {"*": true},
	"operator": {"dashboard.read": true, "agents.read": true, "agents.manage": true, "collections.read": true, "collections.run": true, "inventories.read": true, "inventories.raw.read": true, "vcenter.read": true, "vcenter.manage": true, "vms.manage": true, "nomenclatures.read": true, "services.read": true, "services.manage": true, "documents.read": true, "documents.manage": true},
	"viewer":   {"dashboard.read": true, "agents.read": true, "collections.read": true, "inventories.read": true, "vcenter.read": true, "nomenclatures.read": true, "services.read": true, "documents.read": true},
	"auditor":  {"dashboard.read": true, "agents.read": true, "collections.read": true, "inventories.read": true, "inventories.raw.read": true, "audit.read": true, "vcenter.read": true, "nomenclatures.read": true, "services.read": true, "documents.read": true},
}

func Allowed(roles []string, permission string) bool {
	for _, role := range roles {
		if p := rolePermissions[role]; p != nil && (p["*"] || p[permission]) {
			return true
		}
	}
	return false
}

func Require(permission string, next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		u, ok := auth.UserFromContext(r.Context())
		if !ok {
			writeError(w, http.StatusUnauthorized, "unauthorized")
			return
		}
		if !Allowed(u.Roles, permission) {
			writeError(w, http.StatusForbidden, "forbidden")
			return
		}
		next.ServeHTTP(w, r)
	})
}

func writeError(w http.ResponseWriter, status int, code string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(map[string]string{"error": code})
}

package server

import (
	"database/sql"
	"errors"
	"fmt"
	"io"
	"mime/multipart"
	"net/http"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"vm-doc-server/internal/auth"
	"vm-doc-server/internal/documents"
	"vm-doc-server/internal/inventory"
)

func (a *App) listDocumentTemplates(w http.ResponseWriter, r *http.Request) {
	includeInactive := r.URL.Query().Get("include_inactive") == "true"
	values, err := a.Documents.ListTemplates(r.Context(), includeInactive)
	respond(w, values, err)
}

func (a *App) createDocumentTemplate(w http.ResponseWriter, r *http.Request) {
	input, err := parseTemplateMultipart(w, r, a.Config.Server.MaxRequestBody)
	if err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.Documents.CreateTemplate(r.Context(), input, user.ID)
	if err == nil {
		a.auditRequest(r, "document_template.create", "document_template", strconv.FormatInt(value.ID, 10), "success", map[string]any{"name": value.Name, "code": value.Code, "sha256": value.SHA256, "size_bytes": value.SizeBytes})
	}
	respondStatus(w, value, err, http.StatusCreated)
}

func (a *App) updateDocumentTemplate(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	var input documents.TemplateUpdate
	if err := decodeJSON(r, &input, 1<<20); err != nil {
		badRequest(w, err)
		return
	}
	user, _ := auth.UserFromContext(r.Context())
	value, err := a.Documents.UpdateTemplate(r.Context(), id, user.ID, input)
	if err == nil {
		a.auditRequest(r, "document_template.update", "document_template", strconv.FormatInt(id, 10), "success", map[string]any{"name": value.Name, "code": value.Code, "active": value.Active, "is_default": value.Default})
	}
	respond(w, value, err)
}

func (a *App) downloadDocumentTemplate(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	value, err := a.Documents.GetTemplate(r.Context(), id, true)
	if err != nil {
		respond(w, nil, err)
		return
	}
	writeDownload(w, value.MIMEType, value.FileName, value.Content)
}

func (a *App) listVMDocuments(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	values, err := a.Documents.ListGenerated(r.Context(), vmID)
	respond(w, values, err)
}

func (a *App) previewVMDocument(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	template, data, err := a.documentGenerationData(r, vmID)
	if err != nil {
		respond(w, nil, err)
		return
	}
	preview := documents.BuildPreview(template, data)
	jsonResponse(w, http.StatusOK, preview)
}

func (a *App) generateVMDocument(w http.ResponseWriter, r *http.Request) {
	vmID, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	template, data, err := a.documentGenerationData(r, vmID)
	if err != nil {
		respond(w, nil, err)
		return
	}
	value, err := a.Documents.Generate(r.Context(), template, data)
	if err == nil {
		a.auditRequest(r, "vm_document.generate", "generated_document", strconv.FormatInt(value.ID, 10), "success", map[string]any{"vm_id": vmID, "document_number": value.DocumentNumber, "template_id": value.TemplateID, "sha256": value.SHA256, "size_bytes": value.SizeBytes})
	}
	respondStatus(w, value, err, http.StatusCreated)
}

func (a *App) downloadGeneratedDocument(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		badRequest(w, err)
		return
	}
	value, err := a.Documents.GetGenerated(r.Context(), id, true)
	if err != nil {
		respond(w, nil, err)
		return
	}
	a.auditRequest(r, "vm_document.download", "generated_document", strconv.FormatInt(id, 10), "success", map[string]any{"vm_id": value.VMID, "document_number": value.DocumentNumber})
	writeDownload(w, value.MIMEType, value.FileName, value.Content)
}

func (a *App) documentGenerationData(r *http.Request, vmID int64) (documents.Template, documents.GenerationData, error) {
	var request struct {
		TemplateID int64 `json:"template_id"`
	}
	if err := decodeJSON(r, &request, 1<<20); err != nil {
		return documents.Template{}, documents.GenerationData{}, err
	}
	var template documents.Template
	var err error
	if request.TemplateID > 0 {
		template, err = a.Documents.GetTemplate(r.Context(), request.TemplateID, true)
	} else {
		template, err = a.Documents.DefaultTemplate(r.Context())
	}
	if err != nil {
		return documents.Template{}, documents.GenerationData{}, err
	}
	vm, err := a.VCenter.GetVM(r.Context(), vmID)
	if err != nil {
		return documents.Template{}, documents.GenerationData{}, err
	}
	operational, err := a.VCenter.GetOperationalMetadata(r.Context(), vmID)
	if err != nil {
		return documents.Template{}, documents.GenerationData{}, err
	}
	backup, err := a.VCenter.GetBackupSummary(r.Context(), vmID)
	if err != nil {
		return documents.Template{}, documents.GenerationData{}, err
	}
	user, _ := auth.UserFromContext(r.Context())
	now := time.Now().UTC()
	data := documents.GenerationData{
		VM:             vm,
		Operational:    operational,
		Backup:         backup,
		GeneratedBy:    user,
		GeneratedAt:    now,
		DocumentNumber: documents.NewDocumentNumber(vmID, now),
	}
	if vm.CurrentInventoryID != nil {
		current, inventoryErr := a.Inventory.Get(r.Context(), *vm.CurrentInventoryID, true)
		if inventoryErr != nil && !errors.Is(inventoryErr, sql.ErrNoRows) {
			return documents.Template{}, documents.GenerationData{}, inventoryErr
		}
		if inventoryErr == nil {
			data.Inventory = &current
			view, viewErr := inventory.BuildDocumentView(current.RawJSON)
			if viewErr != nil {
				return documents.Template{}, documents.GenerationData{}, fmt.Errorf("build inventory document: %w", viewErr)
			}
			data.InventoryDocument = &view
		}
	}
	return template, data, nil
}

func parseTemplateMultipart(w http.ResponseWriter, r *http.Request, max int64) (documents.TemplateInput, error) {
	if max <= 0 || max > 24<<20 {
		max = 24 << 20
	}
	r.Body = http.MaxBytesReader(w, r.Body, max)
	if err := r.ParseMultipartForm(max); err != nil {
		return documents.TemplateInput{}, fmt.Errorf("invalid multipart form: %w", err)
	}
	file, header, err := r.FormFile("file")
	if err != nil {
		return documents.TemplateInput{}, errors.New("DOCX file is required")
	}
	defer file.Close()
	content, err := readMultipartFile(file, 20<<20)
	if err != nil {
		return documents.TemplateInput{}, err
	}
	return documents.TemplateInput{
		Name:        r.FormValue("name"),
		Code:        r.FormValue("code"),
		Description: r.FormValue("description"),
		FileName:    filepath.Base(header.Filename),
		MIMEType:    header.Header.Get("Content-Type"),
		Content:     content,
		Active:      parseFormBool(r.FormValue("active"), true),
		Default:     parseFormBool(r.FormValue("is_default"), false),
	}, nil
}

func readMultipartFile(file multipart.File, max int64) ([]byte, error) {
	content, err := io.ReadAll(io.LimitReader(file, max+1))
	if err != nil {
		return nil, err
	}
	if int64(len(content)) > max {
		return nil, fmt.Errorf("DOCX file must be at most %d MiB", max>>20)
	}
	return content, nil
}

func parseFormBool(value string, fallback bool) bool {
	value = strings.ToLower(strings.TrimSpace(value))
	if value == "" {
		return fallback
	}
	return value == "1" || value == "true" || value == "yes" || value == "on"
}

func writeDownload(w http.ResponseWriter, contentType, filename string, content []byte) {
	filename = strings.ReplaceAll(strings.ReplaceAll(filepath.Base(filename), "\r", ""), "\n", "")
	if filename == "" || filename == "." {
		filename = "document.docx"
	}
	if contentType == "" {
		contentType = "application/octet-stream"
	}
	w.Header().Set("Content-Type", contentType)
	w.Header().Set("Content-Disposition", `attachment; filename="`+strings.ReplaceAll(filename, `"`, "")+`"`)
	w.Header().Set("Content-Length", strconv.Itoa(len(content)))
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.Header().Set("Cache-Control", "private, no-store")
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write(content)
}

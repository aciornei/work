-- 0.5.0: șabloane DOCX și fișe tehnice generate pentru VM-uri.

CREATE TABLE IF NOT EXISTS document_templates (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  template_code VARCHAR(64) NOT NULL,
  description TEXT NOT NULL,
  file_name VARCHAR(255) NOT NULL,
  mime_type VARCHAR(190) NOT NULL DEFAULT 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  content LONGBLOB NOT NULL,
  sha256 CHAR(64) NOT NULL,
  size_bytes BIGINT UNSIGNED NOT NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  is_default TINYINT(1) NOT NULL DEFAULT 0,
  created_by BIGINT UNSIGNED NULL,
  updated_by BIGINT UNSIGNED NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_document_templates_code (template_code),
  KEY idx_document_templates_active_default (active,is_default,name),
  CONSTRAINT fk_document_templates_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_document_templates_updated_by FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS generated_documents (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  vm_id BIGINT UNSIGNED NOT NULL,
  template_id BIGINT UNSIGNED NULL,
  template_name VARCHAR(255) NOT NULL,
  document_number VARCHAR(96) NOT NULL,
  file_name VARCHAR(255) NOT NULL,
  mime_type VARCHAR(190) NOT NULL DEFAULT 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  content LONGBLOB NOT NULL,
  sha256 CHAR(64) NOT NULL,
  size_bytes BIGINT UNSIGNED NOT NULL,
  source_inventory_id BIGINT UNSIGNED NULL,
  generated_by BIGINT UNSIGNED NULL,
  generated_at DATETIME(6) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_generated_documents_number (document_number),
  KEY idx_generated_documents_vm_date (vm_id,generated_at,id),
  KEY idx_generated_documents_template (template_id),
  CONSTRAINT fk_generated_documents_vm FOREIGN KEY (vm_id) REFERENCES virtual_machines(id) ON DELETE CASCADE,
  CONSTRAINT fk_generated_documents_template FOREIGN KEY (template_id) REFERENCES document_templates(id) ON DELETE SET NULL,
  CONSTRAINT fk_generated_documents_inventory FOREIGN KEY (source_inventory_id) REFERENCES inventory_snapshots(id) ON DELETE SET NULL,
  CONSTRAINT fk_generated_documents_user FOREIGN KEY (generated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO permissions(name, description) VALUES
 ('documents.read', 'Vizualizare și descărcare fișe VM generate'),
 ('documents.manage', 'Administrare șabloane și generare fișe VM');

INSERT IGNORE INTO role_permissions(role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p WHERE r.name='admin';

INSERT IGNORE INTO role_permissions(role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.name IN ('documents.read','documents.manage') WHERE r.name='operator';

INSERT IGNORE INTO role_permissions(role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.name='documents.read' WHERE r.name IN ('viewer','auditor');

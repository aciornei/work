const state={user:null,csrf:'',agents:[],sources:[],vms:[],vmFilters:{q:'',power:'',agent:'',sourceId:'',page:1,pageSize:50},vmHistory:{vmId:0,page:1,pageSize:20},audit:{page:1,pageSize:50}};
const content=document.getElementById('content');
const title=document.getElementById('pageTitle');
const subtitle=document.getElementById('pageSubtitle');
const agentDialog=document.getElementById('agentDialog');
const agentForm=document.getElementById('agentForm');
const vcenterDialog=document.getElementById('vcenterDialog');
const vcenterForm=document.getElementById('vcenterForm');
const nomenclatureDialog=document.getElementById('nomenclatureDialog');
const nomenclatureForm=document.getElementById('nomenclatureForm');
const personDialog=document.getElementById('personDialog');
const personForm=document.getElementById('personForm');
const internalServiceDialog=document.getElementById('internalServiceDialog');
const internalServiceForm=document.getElementById('internalServiceForm');

const rolePermissions={
  admin:new Set(['*']),
  operator:new Set(['dashboard.read','agents.read','agents.manage','collections.read','collections.run','inventories.read','inventories.raw.read','vcenter.read','vcenter.manage','vms.manage','nomenclatures.read','services.read','services.manage']),
  viewer:new Set(['dashboard.read','agents.read','collections.read','inventories.read','vcenter.read','nomenclatures.read','services.read']),
  auditor:new Set(['dashboard.read','agents.read','collections.read','inventories.read','inventories.raw.read','audit.read','vcenter.read','nomenclatures.read','services.read'])
};
function can(permission){return (state.user?.roles||[]).some(role=>rolePermissions[role]?.has('*')||rolePermissions[role]?.has(permission))}

async function api(path,options={}){
  const headers={Accept:'application/json',...(options.headers||{})};
  if(options.body&&!headers['Content-Type'])headers['Content-Type']='application/json';
  if(!['GET','HEAD'].includes((options.method||'GET').toUpperCase())&&state.csrf)headers['X-CSRF-Token']=state.csrf;
  const response=await fetch(path,{...options,headers});
  if(response.status===401){location.href='/login';throw new Error('Sesiunea a expirat.');}
  const type=response.headers.get('content-type')||'';
  const body=response.status===204?null:type.includes('json')?await response.json():await response.text();
  if(!response.ok)throw new Error(body?.message||body?.error||`HTTP ${response.status}`);
  return body;
}
const e=v=>String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const dt=v=>v?new Date(v).toLocaleString('ro-RO'):'—';
const badge=v=>{const text=String(v??'unknown');return `<span class="badge ${e(text.toLowerCase().replaceAll('_','-'))}">${e(text)}</span>`};
const boolText=v=>v?'Da':'Nu';
const memory=v=>v?`${(Number(v)/1024).toFixed(Number(v)>=10240?0:1)} GB`:'—';
function toast(message,error=false){const box=document.getElementById('toast');box.textContent=message;box.className=`toast show${error?' error':''}`;setTimeout(()=>box.className='toast',3200)}
function pageMeta(name,sub){title.textContent=name;subtitle.textContent=sub||''}
function panel(head,body,tools=''){return `<section class="panel"><div class="panel-header"><h2>${head}</h2><div class="toolbar">${tools}</div></div>${body}</section>`}
function empty(text){return `<div class="empty">${e(text)}</div>`}
function detail(label,value,mono=false){return `<div class="detail-item"><span>${e(label)}</span><div class="${mono?'mono':''}">${value??'—'}</div></div>`}
function jsonSections(raw){const entries=raw&&typeof raw==='object'&&!Array.isArray(raw)?Object.entries(raw):[['inventory',raw]];return `<div class="json-sections">${entries.map(([name,value])=>`<details><summary>${e(name)}</summary><pre class="json">${e(JSON.stringify(value,null,2))}</pre></details>`).join('')}</div>`}

async function init(){
  try{
    const versionElement=document.getElementById('appVersion');
    try{const build=await api('/version');if(versionElement)versionElement.textContent=`Server ${build.version||''}`.trim()}catch{if(versionElement)versionElement.textContent='Server'}
    state.user=await api('/api/v1/auth/me');state.csrf=state.user.csrf_token;
    document.getElementById('currentUser').textContent=state.user.display_name||state.user.username;
    document.querySelector('[data-page="audit"]').hidden=!can('audit.read');
    document.querySelector('[data-page="access"]').hidden=!can('rbac.manage');
    document.querySelector('[data-page="nomenclatures"]').hidden=!can('nomenclatures.read');
    document.querySelector('[data-page="services"]').hidden=!can('services.read');
    document.body.classList.remove('booting');route();
  }catch{location.href='/login'}
}

async function route(){
  const raw=(location.hash||'#dashboard').slice(1);const [page,id]=raw.split('/');
  document.querySelectorAll('#nav a[data-page]').forEach(a=>a.classList.toggle('active',a.dataset.page===page));
  content.innerHTML='<div class="loading">Se încarcă…</div>';
  try{
    if(page==='dashboard')await dashboard();
    else if(page==='agents')await agentsPage();
    else if(page==='vms'&&id)await vmDetail(Number(id));
    else if(page==='vms')await vmsPage();
    else if(page==='services'&&id)await internalServiceDetail(Number(id));
    else if(page==='services')await internalServicesPage();
    else if(page==='nomenclatures')await nomenclaturesPage();
    else if(page==='audit')await auditPage();
    else if(page==='access')await accessPage();
    else location.hash='#dashboard';
  }catch(err){content.innerHTML=empty(err.message);toast(err.message,true)}
}

async function dashboard(){
  pageMeta('Dashboard','Starea centralizată a platformei');
  const d=await api('/api/v1/dashboard');
  content.innerHTML=`<div class="cards">
    <div class="card"><div class="label">VM-uri din vCenter</div><div class="value">${d.vms}</div></div>
    <div class="card"><div class="label">Agenți configurați</div><div class="value">${d.agents_total}</div></div>
    <div class="card"><div class="label">Agenți online</div><div class="value">${d.agents_online}</div></div>
    <div class="card"><div class="label">Joburi în așteptare</div><div class="value">${d.jobs_pending}</div></div>
  </div>${panel('Fluxul 0 → inventar',`<div class="detail-grid">${detail('0. vCenter','Lista completă de VM-uri')}${detail('1. Corelare','BIOS UUID / hostname unic')}${detail('2. Agent','Colectare JSON și stare')}${detail('3. Operațional','Status, servicii interne și istoric')}</div>`)}`;
}

async function agentsPage(){
  pageMeta('Agenți','Administrare, conectivitate și colectare');state.agents=await api('/api/v1/agents');
  const rows=state.agents.map(a=>{const actions=[can('collections.run')?`<button class="small secondary" data-action="test" data-id="${a.id}">Test</button><button class="small" data-action="collect" data-id="${a.id}">Colectează</button>`:'',can('agents.manage')?`<button class="small secondary" data-action="edit" data-id="${a.id}">Editează</button><button class="small danger" data-action="delete" data-id="${a.id}">Șterge</button>`:''].join('');return `<tr><td><strong>${e(a.name)}</strong><div class="muted mono">${e(a.base_url)}</div></td><td>${badge(a.status)}</td><td class="mono">${e(a.agent_uuid||'—')}</td><td>${dt(a.last_contact_at)}</td><td class="muted">${e(a.last_error||'—')}</td><td><div class="actions">${actions||'—'}</div></td></tr>`}).join('');
  content.innerHTML=panel('Lista agenților',state.agents.length?`<div class="table-wrap"><table><thead><tr><th>Agent</th><th>Status</th><th>UUID</th><th>Ultimul contact</th><th>Ultima eroare</th><th>Acțiuni</th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există agenți configurați.'),can('agents.manage')?'<button id="newAgent">Adaugă agent</button>':'');
  document.getElementById('newAgent')?.addEventListener('click',()=>openAgent());
  content.querySelectorAll('[data-action]').forEach(b=>b.onclick=()=>agentAction(b.dataset.action,Number(b.dataset.id)));
}

function openAgent(agent=null){
  document.getElementById('agentDialogTitle').textContent=agent?'Editare agent':'Agent nou';
  document.getElementById('agentId').value=agent?.id||'';document.getElementById('agentName').value=agent?.name||'';document.getElementById('agentURL').value=agent?.base_url||'';document.getElementById('agentToken').value='';document.getElementById('agentToken').required=!agent;
  document.getElementById('agentInterval').value=agent?.collection_interval_seconds||900;document.getElementById('agentTimeout').value=agent?.request_timeout_seconds||45;document.getElementById('agentOffline').value=agent?.offline_after_seconds||2700;document.getElementById('agentEnabled').checked=agent?.enabled??true;document.getElementById('agentVerifyTLS').checked=agent?.verify_tls??true;agentDialog.showModal();
}
async function agentAction(action,id){
  const agent=state.agents.find(a=>a.id===id);
  if(action==='edit'){openAgent(agent);return}
  if(action==='delete'){if(!confirm(`Ștergi agentul ${agent.name}? Istoricul lui va fi șters.`))return;await api(`/api/v1/agents/${id}`,{method:'DELETE'});toast('Agent șters.');agentsPage();return}
  const job=await api(`/api/v1/agents/${id}/${action==='test'?'test':'collect'}`,{method:'POST'});toast(`Job ${job.id} introdus în coadă.`);setTimeout(agentsPage,1000);
}
agentForm.addEventListener('submit',async event=>{
  event.preventDefault();const id=Number(document.getElementById('agentId').value||0);
  const body={name:document.getElementById('agentName').value.trim(),base_url:document.getElementById('agentURL').value.trim(),token:document.getElementById('agentToken').value,enabled:document.getElementById('agentEnabled').checked,verify_tls:document.getElementById('agentVerifyTLS').checked,collection_interval_seconds:Number(document.getElementById('agentInterval').value),request_timeout_seconds:Number(document.getElementById('agentTimeout').value),offline_after_seconds:Number(document.getElementById('agentOffline').value)};
  if(id&&!body.token)delete body.token;
  try{await api(id?`/api/v1/agents/${id}`:'/api/v1/agents',{method:id?'PATCH':'POST',body:JSON.stringify(body)});agentDialog.close();toast(id?'Agent actualizat.':'Agent creat.');agentsPage()}catch(err){toast(err.message,true)}
});

async function vmsPage(){
  pageMeta('VM-uri','Căutare, filtrare, paginare și export din inventarul vCenter');
  const requests=[can('vcenter.read')?api('/api/v1/vcenter/sources'):Promise.resolve([]),can('vcenter.read')?api('/api/v1/vcenter/sync-runs'):Promise.resolve([])];
  const results=await Promise.all(requests);state.sources=Array.isArray(results[0])?results[0]:[];const runs=Array.isArray(results[1])?results[1]:[];
  const filters=state.vmFilters;
  const tools=`<a id="exportVMs" class="button secondary" href="/api/v1/vms/export">Export Excel</a>${can('vcenter.manage')?'<button id="syncAll">Sincronizează vCenter</button><button id="newVCenter" class="secondary">Adaugă sursă</button>':''}`;
  const sourceOptions=state.sources.map(s=>`<option value="${s.id}" ${String(filters.sourceId)===String(s.id)?'selected':''}>${e(s.name)}</option>`).join('');
  const sourceRows=state.sources.map(s=>`<tr><td><strong>${e(s.name)}</strong><div class="muted mono">${e(s.base_url)}</div></td><td>${e(s.username)}</td><td>${s.daily_sync_enabled?`Zilnic ${e(s.daily_sync_time)}`:'Manual'}</td><td>${dt(s.last_success_at)}<div class="error-text">${e(s.last_error||'')}</div></td><td><div class="actions">${can('vcenter.manage')?`<button class="small secondary vc-action" data-action="test" data-id="${s.id}">Test</button><button class="small vc-action" data-action="sync" data-id="${s.id}">Sync</button><button class="small secondary vc-action" data-action="edit" data-id="${s.id}">Editează</button><button class="small danger vc-action" data-action="delete" data-id="${s.id}">Șterge</button>`:'—'}</div></td></tr>`).join('');
  const runRows=runs.slice(0,15).map(r=>`<tr><td>${dt(r.created_at)}</td><td>${e(r.vcenter_source_name)}</td><td>${badge(r.status)}</td><td>${r.found_count}</td><td>+${r.created_count} / ~${r.updated_count} / lipsă ${r.missing_count}</td><td>${r.linked_agent_count}</td><td class="error-text">${e(r.error_message||'—')}</td></tr>`).join('');
  const filterBody=`<div class="filterbar vm-filterbar">
    <label class="vm-search-field"><span>Căutare</span><input id="vmSearch" value="${e(filters.q)}" placeholder="Nume, hostname, OS, IP, agent sau sursă"></label>
    <label><span>Power</span><select id="vmPower"><option value="">Toate</option><option value="POWERED_ON" ${filters.power==='POWERED_ON'?'selected':''}>Pornite</option><option value="POWERED_OFF" ${filters.power==='POWERED_OFF'?'selected':''}>Oprite</option><option value="SUSPENDED" ${filters.power==='SUSPENDED'?'selected':''}>Suspendate</option></select></label>
    <label><span>Agent</span><select id="vmAgentFilter"><option value="">Toți</option><option value="configured" ${filters.agent==='configured'?'selected':''}>Asociat</option><option value="unconfigured" ${filters.agent==='unconfigured'?'selected':''}>Fără agent</option><option value="online" ${filters.agent==='online'?'selected':''}>Online</option><option value="offline" ${filters.agent==='offline'?'selected':''}>Offline</option><option value="unknown" ${filters.agent==='unknown'?'selected':''}>Necunoscut</option><option value="disabled" ${filters.agent==='disabled'?'selected':''}>Dezactivat</option></select></label>
    <label><span>Sursă</span><select id="vmSource"><option value="">Toate sursele</option>${sourceOptions}</select></label>
    <label><span>Pe pagină</span><select id="vmPageSize">${[25,50,100,200].map(n=>`<option value="${n}" ${Number(filters.pageSize)===n?'selected':''}>${n}</option>`).join('')}</select></label>
    <button id="clearVMFilters" class="secondary vm-clear-filter" type="button">Curăță</button>
  </div><div id="vmTableArea" class="loading">Se încarcă VM-urile…</div>`;
  content.innerHTML=`<div class="cards"><div class="card"><div class="label">Rezultate</div><div id="vmTotal" class="value">—</div></div><div class="card"><div class="label">Prezente în vCenter</div><div id="vmPresent" class="value">—</div></div><div class="card"><div class="label">Cu agent asociat</div><div id="vmWithAgent" class="value">—</div></div></div>
  ${panel('Inventar VM',filterBody,tools)}
  ${can('vcenter.read')?panel('Surse vCenter',state.sources.length?`<div class="table-wrap"><table><thead><tr><th>Sursă</th><th>Utilizator</th><th>Program</th><th>Ultima sincronizare</th><th>Acțiuni</th></tr></thead><tbody>${sourceRows}</tbody></table></div>`:empty('Nu există surse vCenter configurate.')):''}
  ${can('vcenter.read')?panel('Ultimele sincronizări',runRows?`<div class="table-wrap"><table><thead><tr><th>Creat</th><th>Sursă</th><th>Status</th><th>Găsite</th><th>Modificări</th><th>Agenți legați</th><th>Eroare</th></tr></thead><tbody>${runRows}</tbody></table></div>`:empty('Nu există sincronizări.')):''}`;
  document.getElementById('syncAll')?.addEventListener('click',async()=>{try{const r=await api('/api/v1/vcenter/sync',{method:'POST'});toast(`${Array.isArray(r)?r.length:0} sincronizări introduse în coadă.`);setTimeout(vmsPage,1200)}catch(err){toast(err.message,true)}});
  document.getElementById('newVCenter')?.addEventListener('click',()=>openVCenter());
  content.querySelectorAll('.vc-action').forEach(b=>b.onclick=()=>vcenterAction(b.dataset.action,Number(b.dataset.id)));
  bindVMFilters();
  await loadVMPage();
}

function vmQuery(includePage=true){
  const f=state.vmFilters,params=new URLSearchParams();
  if(f.q)params.set('q',f.q);if(f.power)params.set('power',f.power);if(f.agent)params.set('agent',f.agent);if(f.sourceId)params.set('source_id',f.sourceId);
  if(includePage){params.set('page',String(f.page));params.set('page_size',String(f.pageSize))}
  return params.toString();
}

function bindVMFilters(){
  let timer;
  document.getElementById('vmSearch')?.addEventListener('input',event=>{clearTimeout(timer);timer=setTimeout(()=>{state.vmFilters.q=event.target.value.trim();state.vmFilters.page=1;loadVMPage()},300)});
  const bindings={vmPower:'power',vmAgentFilter:'agent',vmSource:'sourceId'};
  Object.entries(bindings).forEach(([id,key])=>document.getElementById(id)?.addEventListener('change',event=>{state.vmFilters[key]=event.target.value;state.vmFilters.page=1;loadVMPage()}));
  document.getElementById('vmPageSize')?.addEventListener('change',event=>{state.vmFilters.pageSize=Number(event.target.value);state.vmFilters.page=1;loadVMPage()});
  document.getElementById('clearVMFilters')?.addEventListener('click',()=>{state.vmFilters={q:'',power:'',agent:'',sourceId:'',page:1,pageSize:50};vmsPage()});
}

async function loadVMPage(){
  const area=document.getElementById('vmTableArea');if(!area)return;area.className='loading';area.textContent='Se încarcă VM-urile…';
  try{
    const result=await api(`/api/v1/vms?${vmQuery(true)}`);state.vms=Array.isArray(result?.items)?result.items:[];state.vmFilters.page=Number(result?.page||1);
    document.getElementById('vmTotal').textContent=Number(result?.total||0).toLocaleString('ro-RO');document.getElementById('vmPresent').textContent=Number(result?.present_count||0).toLocaleString('ro-RO');document.getElementById('vmWithAgent').textContent=Number(result?.with_agent_count||0).toLocaleString('ro-RO');
    const exportLink=document.getElementById('exportVMs');if(exportLink)exportLink.href=`/api/v1/vms/export?${vmQuery(false)}`;
    area.className='';area.innerHTML=renderVMPage(result);
    area.querySelectorAll('.vm-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==state.vmFilters.page){state.vmFilters.page=page;loadVMPage();area.scrollIntoView({behavior:'smooth',block:'start'})}}));
  }catch(err){area.className='';area.innerHTML=empty(err.message);toast(err.message,true)}
}

function renderVMPage(result){
  const items=Array.isArray(result?.items)?result.items:[];
  if(!items.length)return empty('Nu există VM-uri pentru filtrele selectate.');
  const rows=items.map(v=>`<tr><td><a href="#vms/${v.id}"><strong>${e(v.name)}</strong></a><div class="muted mono">${e(v.vcenter_moid)} · ${e(v.vcenter_source_name)}</div></td><td>${badge(v.power_state||'unknown')}</td><td>${v.cpu_count||'—'} / ${memory(v.memory_mib)}</td><td>${e(v.inventory_os_name||v.guest_os||'—')}<div class="muted">${e(v.inventory_os_version||'')}</div></td><td class="mono">${e(v.inventory_primary_ip||v.primary_ip||'—')}</td><td>${badge(v.agent_status)}<div class="muted">${e(v.agent_name||'Fără agent')}</div></td><td>${dt(v.inventory_received_at)}</td><td>${v.present_in_vcenter?badge('present'):badge('missing')}</td></tr>`).join('');
  const total=Number(result.total||0),page=Number(result.page||1),pageSize=Number(result.page_size||50),start=(page-1)*pageSize+1,end=Math.min(page*pageSize,total);
  return `<div class="table-wrap vm-table-wrap"><table><thead><tr><th>VM</th><th>Power</th><th>CPU / RAM</th><th>OS</th><th>IP</th><th>Agent</th><th>Ultimul JSON</th><th>vCenter</th></tr></thead><tbody>${rows}</tbody></table></div><div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons">${paginationButtons(page,Number(result.pages||1))}</div></div>`;
}

function paginationButtons(page,pages,buttonClass='vm-page'){
  if(pages<=1)return '';
  const values=new Set([1,pages,page-2,page-1,page,page+1,page+2]);const valid=[...values].filter(n=>n>=1&&n<=pages).sort((a,b)=>a-b);let previous=0,html=`<button class="small secondary ${buttonClass}" data-page="${page-1}" ${page<=1?'disabled':''}>Anterior</button>`;
  valid.forEach(n=>{if(previous&&n>previous+1)html+='<span class="pagination-gap">…</span>';html+=`<button class="small ${n===page?'':'secondary'} ${buttonClass}" data-page="${n}" ${n===page?'disabled':''}>${n}</button>`;previous=n});
  return html+`<button class="small secondary ${buttonClass}" data-page="${page+1}" ${page>=pages?'disabled':''}>Următor</button>`;
}
function pageSizeOptions(selected,values=[10,20,50,100]){return values.map(value=>`<option value="${value}" ${Number(selected)===value?'selected':''}>${value}</option>`).join('')}

function openVCenter(source=null){
  document.getElementById('vcenterDialogTitle').textContent=source?'Editare sursă vCenter':'Sursă vCenter nouă';document.getElementById('vcenterId').value=source?.id||'';document.getElementById('vcenterName').value=source?.name||'';document.getElementById('vcenterURL').value=source?.base_url||'';document.getElementById('vcenterUsername').value=source?.username||'';document.getElementById('vcenterPassword').value='';document.getElementById('vcenterPassword').required=!source;document.getElementById('vcenterSyncTime').value=source?.daily_sync_time||'05:00';document.getElementById('vcenterTLSServerName').value=source?.tls_server_name||'';document.getElementById('vcenterEnabled').checked=source?.enabled??true;document.getElementById('vcenterVerifyTLS').checked=source?.verify_tls??true;document.getElementById('vcenterDailySync').checked=source?.daily_sync_enabled??true;vcenterDialog.showModal();
}
async function vcenterAction(action,id){
  const source=state.sources.find(s=>s.id===id);
  try{
    if(action==='edit'){openVCenter(source);return}
    if(action==='delete'){if(!confirm(`Ștergi sursa ${source.name} și VM-urile sincronizate din ea?`))return;await api(`/api/v1/vcenter/sources/${id}`,{method:'DELETE'});toast('Sursă vCenter ștearsă.');vmsPage();return}
    if(action==='test'){const r=await api(`/api/v1/vcenter/sources/${id}/test`,{method:'POST'});toast(`Conexiune reușită: ${r.vm_count} VM-uri vizibile.`);return}
    if(action==='sync'){const r=await api(`/api/v1/vcenter/sources/${id}/sync`,{method:'POST'});toast(`Sincronizarea ${r.id} a fost pornită.`);setTimeout(vmsPage,1200)}
  }catch(err){toast(err.message,true)}
}
vcenterForm.addEventListener('submit',async event=>{
  event.preventDefault();const id=Number(document.getElementById('vcenterId').value||0);const body={name:document.getElementById('vcenterName').value.trim(),base_url:document.getElementById('vcenterURL').value.trim(),username:document.getElementById('vcenterUsername').value.trim(),password:document.getElementById('vcenterPassword').value,enabled:document.getElementById('vcenterEnabled').checked,verify_tls:document.getElementById('vcenterVerifyTLS').checked,tls_server_name:document.getElementById('vcenterTLSServerName').value.trim(),daily_sync_enabled:document.getElementById('vcenterDailySync').checked,daily_sync_time:document.getElementById('vcenterSyncTime').value};if(id&&!body.password)delete body.password;
  try{await api(id?`/api/v1/vcenter/sources/${id}`:'/api/v1/vcenter/sources',{method:id?'PATCH':'POST',body:JSON.stringify(body)});vcenterDialog.close();toast(id?'Sursă actualizată.':'Sursă creată.');vmsPage()}catch(err){toast(err.message,true)}
});

function fieldLabel(key){
  const labels={hostname:'Hostname',fqdn:'FQDN',uuid:'UUID',product_uuid:'Product UUID',machine_id:'Machine ID',pretty_name:'Denumire OS',version_id:'Versiune',primary_ip:'IP principal',boot_time:'Pornire sistem',status:'Stare',name:'Nume',version:'Versiune',enabled:'Activ',active:'Activ',installed:'Instalat',service:'Serviciu',port:'Port',protocol:'Protocol',address:'Adresă'};
  if(labels[key])return labels[key];
  return String(key||'').replaceAll('_',' ').replaceAll('-',' ').replace(/\b\w/g,c=>c.toUpperCase());
}
function structuredValue(value,depth=0){
  if(value===null||value===undefined||value==='')return '<span class="muted">—</span>';
  if(typeof value==='boolean')return value?badge('active'):badge('disabled');
  if(typeof value==='number')return `<span>${e(value)}</span>`;
  if(typeof value==='string'){
    const low=value.toLowerCase();
    if(['ok','active','enabled','running','installed','success','succeeded','online','configured'].includes(low))return badge(low);
    if(['error','failed','disabled','stopped','missing','offline','not_installed','unconfigured','timeout'].includes(low))return badge(low);
    return `<span class="${value.length>70?'pre-wrap':''}">${e(value)}</span>`;
  }
  if(Array.isArray(value)){
    if(!value.length)return '<span class="muted">Listă goală</span>';
    const primitives=value.every(item=>item===null||['string','number','boolean'].includes(typeof item));
    if(primitives)return `<div class="value-list">${value.map(item=>`<span>${structuredValue(item,depth+1)}</span>`).join('')}</div>`;
    return `<div class="structured-list">${value.map((item,index)=>`<details><summary>Element ${index+1}</summary>${structuredValue(item,depth+1)}</details>`).join('')}</div>`;
  }
  const entries=Object.entries(value);
  if(!entries.length)return '<span class="muted">Fără date</span>';
  return `<dl class="inventory-kv ${depth>1?'nested':''}">${entries.map(([key,item])=>`<div><dt>${e(fieldLabel(key))}</dt><dd>${structuredValue(item,depth+1)}</dd></div>`).join('')}</dl>`;
}
function structuredInventory(documentView){
  const sections=Array.isArray(documentView?.sections)?documentView.sections:[];
  if(!sections.length)return empty('Agentul nu a furnizat încă date structurate.');
  return `<div class="inventory-sections">${sections.map(section=>`<details class="inventory-section"><summary><span>${e(section.title||fieldLabel(section.key))}</span>${section.status?badge(section.status):''}</summary><div class="inventory-section-body">${structuredValue(section.data)}</div></details>`).join('')}</div>`;
}
function categoryItems(categories,code){return (categories||[]).find(item=>item.code===code)?.items||[]}
function selectOptions(items,selected,placeholder='— Neselectat —',label=value=>value.name){return `<option value="">${e(placeholder)}</option>${(items||[]).filter(item=>item.active||Number(item.id)===Number(selected)).map(item=>`<option value="${item.id}" ${Number(selected)===Number(item.id)?'selected':''}>${e(label(item))}${item.active?'':' (inactiv)'}</option>`).join('')}`}
function multiSelectOptions(items,selected=[]){const selectedSet=new Set((selected||[]).map(Number));return (items||[]).filter(item=>item.active||selectedSet.has(Number(item.id))).map(item=>`<option value="${item.id}" ${selectedSet.has(Number(item.id))?'selected':''}>${e(item.name)}${item.active?'':' (inactiv)'}</option>`).join('')}
function nomenclatureOptions(categories,code,selected){return selectOptions(categoryItems(categories,code),selected)}
function serviceOptionLabel(service){return `${service.name}${service.active?'':' (inactiv)'}`}
function serviceOptions(services,categoryID,selected){const values=(services||[]).filter(service=>Number(service.itil_category_id)===Number(categoryID));return `<option value="">— Alege serviciul intern —</option>${values.filter(service=>service.active||Number(service.id)===Number(selected)).map(service=>`<option value="${service.id}" ${Number(selected)===Number(service.id)?'selected':''}>${e(serviceOptionLabel(service))}</option>`).join('')}`}
const responsibilityTypes={technical_admin:'Administrator tehnic',service_owner:'Responsabil serviciu',business_owner:'Responsabil business',application_owner:'Responsabil aplicație',infrastructure_owner:'Responsabil infrastructură',security_contact:'Contact securitate',backup_contact:'Contact backup',other:'Altă responsabilitate'};
function responsibilityTypeOptions(selected){return Object.entries(responsibilityTypes).map(([value,label])=>`<option value="${value}" ${selected===value?'selected':''}>${e(label)}</option>`).join('')}
function peopleOptions(people,selected){return `<option value="">— Alege persoana —</option>${(people||[]).filter(person=>person.active||Number(person.id)===Number(selected)).map(person=>`<option value="${person.id}" ${Number(selected)===Number(person.id)?'selected':''}>${e(person.display_name)}${person.email?` · ${e(person.email)}`:''}${person.active?'':' (inactiv)'}</option>`).join('')}`}
function responsibilityRow(item,people,index){return `<div class="responsibility-row" data-index="${index}"><label>Persoană<select class="responsibility-person">${peopleOptions(people,item?.person_id)}</select></label><label>Rol<select class="responsibility-type">${responsibilityTypeOptions(item?.responsibility_type||'technical_admin')}</select></label><label class="responsibility-notes">Detalii<input class="responsibility-note" value="${e(item?.notes||'')}" placeholder="Opțional"></label><button type="button" class="small danger remove-responsibility">Elimină</button></div>`}
function responsibilitySummary(values){if(!values?.length)return '—';return `<div class="responsibility-summary">${values.map(item=>`<div><strong>${e(item.person_name)}</strong><span>${e(responsibilityTypes[item.responsibility_type]||item.responsibility_type)}${item.person_email?` · ${e(item.person_email)}`:''}</span></div>`).join('')}</div>`}
function minutesText(value){if(value===null||value===undefined)return '—';if(value<60)return `${value} min`;if(value%1440===0)return `${value/1440} zile`;if(value%60===0)return `${value/60} ore`;return `${value} min`}
function backupSection(backup){
  const hasData=backup&&(backup.synced_at||backup.policy_name||backup.job_name||backup.source_name||backup.error_message||backup.provider==='manual');
  if(!hasData)return empty('Integrarea Veeam nu a populat încă datele de backup pentru această VM. Secțiunea este pregătită pentru sincronizarea prin API.');
  return `<div class="detail-grid">${detail('Furnizor',e(backup.provider||'veeam'))}${detail('Sursă Veeam',e(backup.source_name||'—'))}${detail('Protejată',backup.protected?badge('protected'):badge('unprotected'))}${detail('Ultimul rezultat',backup.last_result?badge(backup.last_result):'—')}${detail('Job',e(backup.job_name||'—'))}${detail('Politică',e(backup.policy_name||'—'))}${detail('Repository',e(backup.repository_name||'—'))}${detail('Restore points',backup.restore_points??'—')}${detail('Ultimul backup',dt(backup.last_backup_at))}${detail('Următoarea rulare',dt(backup.next_run_at))}${detail('RPO',minutesText(backup.rpo_minutes))}${detail('RTO',minutesText(backup.rto_minutes))}${detail('Ultima sincronizare',dt(backup.synced_at))}${detail('Eroare',e(backup.error_message||'—'))}</div>`;
}
function uniqueLayers(mappings){const seen=new Set();return (mappings||[]).filter(mapping=>{if(seen.has(mapping.layer_id))return false;seen.add(mapping.layer_id);return true}).map(mapping=>({id:mapping.layer_id,name:mapping.layer_name,active:mapping.active}))}
const serviceUsageLabels={dedicated:'Dedicat',shared:'Partajat',dependency:'Dependență'};
function allServiceOptions(services,selected){return `<option value="">— Alege serviciul intern —</option>${(services||[]).filter(service=>service.active||Number(service.id)===Number(selected)).map(service=>`<option value="${service.id}" ${Number(selected)===Number(service.id)?'selected':''}>${e([service.architectural_domain,service.itil_category,service.name].filter(Boolean).join(' → '))}${service.active?'':' (inactiv)'}</option>`).join('')}`}
function serviceUsageOptions(selected='dedicated'){return Object.entries(serviceUsageLabels).map(([value,label])=>`<option value="${value}" ${selected===value?'selected':''}>${e(label)}</option>`).join('')}
function serviceAssignmentRow(item,services,index){return `<div class="vm-service-assignment-row" data-index="${index}"><label>Serviciu intern<select class="assignment-service" required>${allServiceOptions(services,item?.internal_service_id)}</select></label><label>Layer arhitectural<select class="assignment-layer" required></select></label><label>Rol tehnic<select class="assignment-role" required></select></label><label>Utilizare<select class="assignment-usage">${serviceUsageOptions(item?.usage_type||'dedicated')}</select></label><label class="assignment-primary"><span>Principal</span><input class="assignment-primary-input" type="checkbox" ${item?.is_primary?'checked':''}></label><label class="assignment-notes">Observații<input class="assignment-note" maxlength="1000" value="${e(item?.notes||'')}" placeholder="Opțional"></label>${can('vms.manage')?'<button type="button" class="small danger remove-service-assignment">Elimină</button>':''}</div>`}
function wireServiceAssignmentRow(row,services,initial={}){
  const service=row.querySelector('.assignment-service'),layer=row.querySelector('.assignment-layer'),role=row.querySelector('.assignment-role');
  const currentService=()=>services.find(item=>Number(item.id)===Number(service.value));
  function fillLayers(selected=''){const current=currentService();let values=uniqueLayers(current?.role_mappings);if(selected&&!values.some(value=>Number(value.id)===Number(selected))&&initial.layer_name)values=[...values,{id:Number(selected),name:`${initial.layer_name} · nemapat`,active:false}];layer.innerHTML=selectOptions(values,selected,current?'— Alege layer-ul —':'— Alege serviciul —');layer.disabled=!current}
  function fillRoles(selected=''){const current=currentService();let values=(current?.role_mappings||[]).filter(mapping=>Number(mapping.layer_id)===Number(layer.value)).map(mapping=>({id:mapping.technical_role_id,name:mapping.technical_role,active:mapping.active}));if(selected&&!values.some(value=>Number(value.id)===Number(selected))&&initial.technical_role)values=[...values,{id:Number(selected),name:`${initial.technical_role} · nemapat`,active:false}];role.innerHTML=selectOptions(values,selected,layer.value?'— Alege rolul tehnic —':'— Alege layer-ul —');role.disabled=!layer.value}
  fillLayers(initial.layer_id);fillRoles(initial.technical_role_id);
  service.addEventListener('change',()=>{fillLayers();fillRoles()});layer.addEventListener('change',()=>fillRoles());
}
function serviceAssignmentsSummary(values){
  if(!values?.length)return '<span class="muted">Niciun serviciu intern asociat.</span>';
  return `<div class="table-wrap"><table class="compact-table"><thead><tr><th>Serviciu intern</th><th>Domeniu / Categorie ITIL</th><th>Layer</th><th>Rol tehnic</th><th>Utilizare</th><th></th></tr></thead><tbody>${values.map(item=>`<tr><td><a href="#services/${item.internal_service_id}">${e(item.internal_service_name)}</a></td><td>${e(item.architectural_domain||'—')}<div class="muted">${e(item.itil_category||'—')}</div></td><td>${e(item.layer_name||'—')}</td><td>${e(item.technical_role||'—')}</td><td>${e(serviceUsageLabels[item.usage_type]||item.usage_type||'—')}</td><td>${item.is_primary?badge('principal'):''}</td></tr>`).join('')}</tbody></table></div>`;
}

async function vmDetail(id){
  if(Number(state.vmHistory.vmId)!==Number(id))state.vmHistory={vmId:id,page:1,pageSize:20};
  const [data,agents,categories,people,services]=await Promise.all([api(`/api/v1/vms/${id}`),can('agents.read')?api('/api/v1/agents'):Promise.resolve([]),api('/api/v1/nomenclatures?include_inactive=true'),api('/api/v1/people?include_inactive=true'),api('/api/v1/services?include_inactive=true')]);
  const vm=data.vm,v=data.inventory||{},op=data.operational||{},backup=data.backup||{},documentView=data.inventory_document||{};
  const warningLabels={agent_data_unavailable:'Datele agentului asociat nu au putut fi încărcate.',inventory_data_unavailable:'Inventarul curent nu a putut fi încărcat.',inventory_document_unavailable:'Inventarul curent există, dar vederea structurată nu a putut fi generată.',operational_data_unavailable:'Datele operaționale nu au putut fi încărcate.',backup_data_unavailable:'Datele de backup nu au putut fi încărcate.'};
  const vmWarnings=(Array.isArray(data.warnings)?data.warnings:[]).map(code=>warningLabels[code]||code);
  const assignments=Array.isArray(op.service_assignments)?op.service_assignments:[];
  pageMeta(vm.name,'Fișă tehnică, inventar agent și date operaționale');
  const agentOptions=`<option value="">Fără agent</option>${agents.map(x=>`<option value="${x.id}" ${vm.agent_id===x.id?'selected':''}>${e(x.name)} (${e(x.status)})</option>`).join('')}`;
  const documentLink=op.documentation_url?`<a href="${e(op.documentation_url)}" target="_blank" rel="noopener">${e(op.documentation_url)}</a>`:'—';
  const initialResponsibilities=Array.isArray(op.responsibilities)?op.responsibilities:[];
  const assignmentRows=assignments.map((item,index)=>serviceAssignmentRow(item,services,index)).join('');
  content.innerHTML=`${vmWarnings.length?`<div class="notice warning"><strong>Fișa a fost încărcată parțial.</strong><ul>${vmWarnings.map(message=>`<li>${e(message)}</li>`).join('')}</ul><span class="muted">Detaliul tehnic este în jurnalul serviciului vm-doc-server.</span></div>`:''}<div class="cards"><div class="card"><div class="label">Power state</div><div class="value compact">${badge(vm.power_state||'unknown')}</div></div><div class="card"><div class="label">Agent</div><div class="value compact">${badge(vm.agent_status)}</div><div class="muted">${e(vm.agent_name||'Neasociat')}</div></div><div class="card"><div class="label">Ultimul inventar</div><div class="value compact">${dt(vm.inventory_received_at)}</div></div><div class="card"><div class="label">Status operațional</div><div class="value compact">${op.operational_status?badge(op.operational_status):'—'}</div></div></div>
  ${panel('Identificare și încadrare',`<div class="detail-grid">${detail('Nume VM',e(vm.name))}${detail('Hostname',e(v.hostname||vm.guest_hostname||'—'),true)}${detail('IP principal',e(v.primary_ip||vm.primary_ip||'—'),true)}${detail('Sistem de operare',`${e(v.os_name||vm.guest_os||'—')} ${e(v.os_version||'')}`)}${detail('Mediu',e(op.environment||'—'))}${detail('Status operațional',op.operational_status?badge(op.operational_status):'—')}${detail('Clasificare',e(op.classification||'—'))}${detail('Responsabilități',responsibilitySummary(op.responsibilities))}${detail('Documentație',documentLink)}${detail('Referință tichet',e(op.ticket_reference||'—'))}</div>`) }
  ${panel('Servicii interne și roluri tehnice',`<form id="serviceAssignmentsForm" class="service-assignments-form"><p class="muted">Un VM poate deservi mai multe servicii interne și poate avea mai multe combinații layer–rol pentru același serviciu.</p><div id="vmServiceAssignmentRows" class="vm-service-assignment-rows">${assignmentRows}</div>${can('vms.manage')?'<div class="form-actions"><button type="button" id="addServiceAssignment" class="secondary">Adaugă asociere</button><button type="submit">Salvează asocierile</button></div>':'<div class="muted form-actions">Nu ai permisiunea de modificare.</div>'}</form>`)}
  ${panel('Date operaționale',`<form id="operationalForm" class="operational-form">
    <div class="form-section"><h3>Încadrare operațională</h3><div class="form-grid"><label>Mediu<select id="opEnvironment">${nomenclatureOptions(categories,'environment',op.environment_id)}</select></label><label>Status operațional<select id="opStatus">${nomenclatureOptions(categories,'operational_status',op.operational_status_id)}</select></label><label>Clasificare<select id="opClassification">${nomenclatureOptions(categories,'classification',op.classification_id)}</select></label></div><label>Scopul VM-ului<textarea id="opPurpose" rows="3">${e(op.purpose||'')}</textarea></label></div>
    <div class="form-section"><div class="section-heading"><h3>Responsabilități</h3>${can('vms.manage')?'<button type="button" id="addResponsibility" class="small secondary">Adaugă persoană</button>':''}</div><div id="responsibilityRows" class="responsibility-rows">${initialResponsibilities.map((item,index)=>responsibilityRow(item,people,index)).join('')}</div>${!people.length?'<p class="muted">Adaugă mai întâi persoane din meniul Nomenclatoare.</p>':''}</div>
    <div class="form-section"><h3>Referințe și observații</h3><div class="form-grid"><label class="span-2">URL documentație<input id="opDocumentation" type="url" value="${e(op.documentation_url||'')}" placeholder="https://..."></label><label>Referință tichet<input id="opTicket" value="${e(op.ticket_reference||'')}"></label></div><label>Observații<textarea id="opNotes" rows="4">${e(op.notes||'')}</textarea></label></div>
    ${can('vms.manage')?'<div class="form-actions"><button type="submit">Salvează datele operaționale</button></div>':'<div class="muted form-actions">Nu ai permisiunea de modificare.</div>'}
  </form>`) }
  ${panel('Backup și restaurare · Veeam',backupSection(backup),'<span class="muted">Date separate de inventarul agentului</span>')}
  ${panel('Date colectate de agent',structuredInventory(documentView),v.id&&can('inventories.raw.read')?'<button id="latestRaw" class="secondary">Vezi JSON brut</button>':'')}
  ${panel('Date vCenter',`<div class="detail-grid">${detail('Sursă',e(vm.vcenter_source_name))}${detail('MoID',e(vm.vcenter_moid),true)}${detail('BIOS UUID',e(vm.bios_uuid||'—'),true)}${detail('Instance UUID',e(vm.instance_uuid||'—'),true)}${detail('CPU',e(vm.cpu_count))}${detail('RAM',memory(vm.memory_mib))}${detail('Hardware',e(vm.hardware_version||'—'))}${detail('Ultima vedere',dt(vm.last_seen_at))}${detail('Guest hostname',e(vm.guest_hostname||'—'))}${detail('Guest OS',e(vm.guest_os||'—'))}${detail('IP vCenter',e(vm.primary_ip||'—'),true)}${detail('Prezentă în vCenter',boolText(vm.present_in_vcenter))}</div>`) }
  ${panel('Asociere agent',`<form id="vmManageForm" class="detail-grid"><label><span>Agent asociat</span><select id="vmAgent">${agentOptions}</select></label>${can('vms.manage')?'<label class="form-submit"><button type="submit">Salvează</button></label>':''}</form>`,can('collections.run')&&vm.agent_id?'<button id="testVMAgent" class="secondary">Testează agentul</button><button id="collectVM">Colectează acum</button>':'')}
  ${panel('Istoric inventare','<div id="inventoryHistoryArea" class="loading">Se încarcă istoricul…</div>')}<section id="rawPanel"></section>`;

  const assignmentContainer=document.getElementById('vmServiceAssignmentRows');
  assignmentContainer?.querySelectorAll('.vm-service-assignment-row').forEach((row,index)=>wireServiceAssignmentRow(row,services,assignments[index]||{}));
  document.getElementById('addServiceAssignment')?.addEventListener('click',()=>{const wrapper=document.createElement('div');wrapper.innerHTML=serviceAssignmentRow(null,services,assignmentContainer.children.length);const row=wrapper.firstElementChild;assignmentContainer.appendChild(row);wireServiceAssignmentRow(row,services,{})});
  assignmentContainer?.addEventListener('click',event=>{const button=event.target.closest('.remove-service-assignment');if(button)button.closest('.vm-service-assignment-row').remove()});
  assignmentContainer?.addEventListener('change',event=>{if(!event.target.classList.contains('assignment-primary-input')||!event.target.checked)return;assignmentContainer.querySelectorAll('.assignment-primary-input').forEach(input=>{if(input!==event.target)input.checked=false})});
  document.getElementById('serviceAssignmentsForm')?.addEventListener('submit',async ev=>{ev.preventDefault();if(!can('vms.manage'))return;const values=[...assignmentContainer.querySelectorAll('.vm-service-assignment-row')].map((row,index)=>({internal_service_id:Number(row.querySelector('.assignment-service').value||0),layer_id:Number(row.querySelector('.assignment-layer').value||0),technical_role_id:Number(row.querySelector('.assignment-role').value||0),usage_type:row.querySelector('.assignment-usage').value,is_primary:row.querySelector('.assignment-primary-input').checked,notes:row.querySelector('.assignment-note').value.trim(),sort_order:index}));if(values.some(item=>!item.internal_service_id||!item.layer_id||!item.technical_role_id)){toast('Completează serviciul intern, layer-ul și rolul tehnic pentru fiecare asociere.',true);return}try{await api(`/api/v1/vms/${id}/service-assignments`,{method:'PUT',body:JSON.stringify({assignments:values})});toast('Asocierile cu serviciile interne au fost salvate.');vmDetail(id)}catch(err){toast(err.message,true)}});
  const responsibilityRows=document.getElementById('responsibilityRows');
  document.getElementById('addResponsibility')?.addEventListener('click',()=>{const wrapper=document.createElement('div');wrapper.innerHTML=responsibilityRow(null,people,responsibilityRows.children.length);responsibilityRows.appendChild(wrapper.firstElementChild)});
  responsibilityRows?.addEventListener('click',event=>{const button=event.target.closest('.remove-responsibility');if(button)button.closest('.responsibility-row').remove()});
  document.getElementById('operationalForm')?.addEventListener('submit',async ev=>{ev.preventDefault();if(!can('vms.manage'))return;const responsibilities=[...document.querySelectorAll('.responsibility-row')].map((row,index)=>({person_id:Number(row.querySelector('.responsibility-person').value||0),responsibility_type:row.querySelector('.responsibility-type').value,notes:row.querySelector('.responsibility-note').value.trim(),sort_order:index})).filter(item=>item.person_id>0);const selected=elementId=>{const value=document.getElementById(elementId).value;return value?Number(value):null};const body={environment_id:selected('opEnvironment'),operational_status_id:selected('opStatus'),purpose:document.getElementById('opPurpose').value.trim(),responsibilities,classification_id:selected('opClassification'),documentation_url:document.getElementById('opDocumentation').value.trim(),ticket_reference:document.getElementById('opTicket').value.trim(),notes:document.getElementById('opNotes').value.trim()};try{await api(`/api/v1/vms/${id}/operational`,{method:'PUT',body:JSON.stringify(body)});toast('Datele operaționale au fost salvate.');vmDetail(id)}catch(err){toast(err.message,true)}});
  document.getElementById('vmManageForm')?.addEventListener('submit',async ev=>{ev.preventDefault();if(!can('vms.manage'))return;const selected=document.getElementById('vmAgent').value;const body={};if(selected)body.agent_id=Number(selected);else if(vm.agent_id)body.clear_agent=true;try{await api(`/api/v1/vms/${id}`,{method:'PATCH',body:JSON.stringify(body)});toast('Asocierea agentului a fost actualizată.');vmDetail(id)}catch(err){toast(err.message,true)}});
  document.getElementById('testVMAgent')?.addEventListener('click',()=>vmJob(id,'test-agent'));
  document.getElementById('collectVM')?.addEventListener('click',()=>vmJob(id,'collect'));
  document.getElementById('latestRaw')?.addEventListener('click',async()=>{try{const raw=await api(`/api/v1/inventories/${v.id}/raw`);document.getElementById('rawPanel').innerHTML=panel(`JSON inventar #${v.id}`,jsonSections(raw));document.getElementById('rawPanel').scrollIntoView({behavior:'smooth'})}catch(err){toast(err.message,true)}});
  await loadInventoryHistory(id);
}
function bindRawInventoryButtons(scope=document){scope.querySelectorAll('.show-raw').forEach(button=>button.onclick=async()=>{try{const raw=await api(`/api/v1/inventories/${button.dataset.id}/raw`);document.getElementById('rawPanel').innerHTML=panel(`JSON inventar #${button.dataset.id}`,jsonSections(raw));document.getElementById('rawPanel').scrollIntoView({behavior:'smooth'})}catch(err){toast(err.message,true)}})}
function renderInventoryHistoryPage(result){
  const items=Array.isArray(result?.items)?result.items:[];
  if(!items.length)return empty('Nu există snapshoturi pentru această VM.');
  const rows=items.map(item=>`<tr><td>${dt(item.received_at)}</td><td>${e(item.hostname)}</td><td>${e(item.os_name)} ${e(item.os_version)}</td><td>${item.collector_ok}/${item.collector_total}</td><td>${item.changed_from_previous?badge('changed'):badge('same')}</td><td>${can('inventories.raw.read')?`<button class="small secondary show-raw" data-id="${item.id}">JSON</button>`:''}</td></tr>`).join('');
  const total=Number(result.total||0),page=Number(result.page||1),pageSize=Number(result.page_size||20),start=(page-1)*pageSize+1,end=Math.min(page*pageSize,total);
  return `<div class="table-wrap"><table><thead><tr><th>Primit</th><th>Hostname</th><th>OS</th><th>Colectori</th><th>Schimbare</th><th></th></tr></thead><tbody>${rows}</tbody></table></div><div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="inventoryHistoryPageSize">${pageSizeOptions(pageSize,[10,20,50,100])}</select></label>${paginationButtons(page,Number(result.pages||1),'inventory-history-page')}</div></div>`;
}
async function loadInventoryHistory(vmID){
  const area=document.getElementById('inventoryHistoryArea');if(!area)return;area.className='loading';area.textContent='Se încarcă istoricul…';
  try{const result=await api(`/api/v1/vms/${vmID}/inventories?page=${state.vmHistory.page}&page_size=${state.vmHistory.pageSize}`);state.vmHistory.page=Number(result?.page||1);state.vmHistory.pageSize=Number(result?.page_size||20);area.className='';area.innerHTML=renderInventoryHistoryPage(result);bindRawInventoryButtons(area);area.querySelectorAll('.inventory-history-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==state.vmHistory.page){state.vmHistory.page=page;loadInventoryHistory(vmID)}}));document.getElementById('inventoryHistoryPageSize')?.addEventListener('change',event=>{state.vmHistory.pageSize=Number(event.target.value);state.vmHistory.page=1;loadInventoryHistory(vmID)})}catch(err){area.className='';area.innerHTML=empty(err.message);toast(err.message,true)}
}
async function vmJob(id,action){try{const job=await api(`/api/v1/vms/${id}/${action}`,{method:'POST'});toast(`Job ${job.id} introdus în coadă.`);setTimeout(()=>vmDetail(id),1200)}catch(err){toast(err.message,true)}}

let internalServicesCache=[];
let serviceNomenclatureCache=[];
const criticalityLabels={low:'Scăzută',normal:'Normală',high:'Ridicată',critical:'Critică'};
const documentationStatusLabels={draft:'Draft',in_progress:'În lucru',review:'În verificare',approved:'Aprobată',obsolete:'Depășită'};
function criticalityBadge(value){return badge(value||'normal')}
function serviceCategoryOptions(categories,selected){
  const items=categoryItems(categories,'itil_category');
  return `<option value="">— Alege categoria ITIL —</option>${items.filter(item=>item.active||Number(item.id)===Number(selected)).map(item=>`<option value="${item.id}" ${Number(selected)===Number(item.id)?'selected':''}>${e(item.parent_name?`${item.parent_name} → ${item.name}`:item.name)}${item.active?'':' (inactiv)'}</option>`).join('')}`;
}
function openInternalService(service=null){
  document.getElementById('internalServiceDialogTitle').textContent=service?'Editare serviciu intern':'Serviciu intern nou';
  document.getElementById('internalServiceId').value=service?.id||'';
  document.getElementById('internalServiceCategory').innerHTML=serviceCategoryOptions(serviceNomenclatureCache,service?.itil_category_id);
  document.getElementById('internalServiceName').value=service?.name||'';
  document.getElementById('internalServiceCode').value=service?.service_code||'';
  document.getElementById('internalServiceCriticality').value=service?.criticality||'normal';
  document.getElementById('internalServiceDocStatus').value=service?.documentation_status||'draft';
  document.getElementById('internalServiceDescription').value=service?.description||'';
  document.getElementById('internalServicePurpose').value=service?.purpose||'';
  document.getElementById('internalServiceDocumentationURL').value=service?.documentation_url||'';
  document.getElementById('internalServiceActive').checked=service?.active??true;
  internalServiceDialog.showModal();
}
function mappingRow(mapping,categories,index){
  const layers=categoryItems(categories,'layer');
  return `<div class="service-mapping-row" data-index="${index}"><label>Layer<select class="mapping-layer" required>${selectOptions(layers,mapping?.layer_id,'— Alege layer-ul —')}</select></label><label>Rol tehnic<select class="mapping-role" required></select></label><label>Ordine<input class="mapping-order" type="number" value="${mapping?.sort_order??index}" min="-100000" max="100000"></label>${can('services.manage')?'<button type="button" class="small danger remove-service-mapping">Elimină</button>':''}</div>`;
}
function wireServiceMappingRow(row,categories,initial={}){
  const layer=row.querySelector('.mapping-layer'),role=row.querySelector('.mapping-role');
  const roles=categoryItems(categories,'technical_role');
  function fillRoles(selected=''){
    let values=roles.filter(item=>(item.layer_ids||[]).some(id=>Number(id)===Number(layer.value)));
    if(selected&&!values.some(value=>Number(value.id)===Number(selected))&&initial.technical_role){values=[...values,{id:Number(selected),name:`${initial.technical_role} · nemapat`,active:false}]}
    role.innerHTML=selectOptions(values,selected,layer.value?'— Alege rolul tehnic —':'— Alege layer-ul —');
    role.disabled=!layer.value;
  }
  fillRoles(initial.technical_role_id);
  layer.addEventListener('change',()=>fillRoles());
}
function serviceVMRows(values){
  return (values||[]).map(vm=>`<tr><td><a href="#vms/${vm.id}"><strong>${e(vm.name)}</strong></a><div class="muted mono">${e(vm.guest_hostname||'—')}</div></td><td class="mono">${e(vm.primary_ip||'—')}</td><td>${e(vm.layer_name||'—')}</td><td>${e(vm.technical_role||'—')}</td><td>${e(serviceUsageLabels[vm.usage_type]||vm.usage_type||'—')}</td><td>${vm.is_primary?badge('principal'):''}</td><td>${badge(vm.power_state||'unknown')}</td></tr>`).join('');
}
async function internalServicesPage(){
  pageMeta('Servicii','Catalogul serviciilor interne și legătura lor cu VM-urile');
  [internalServicesCache,serviceNomenclatureCache]=await Promise.all([api('/api/v1/services?include_inactive=true'),api('/api/v1/nomenclatures?include_inactive=true')]);
  const active=internalServicesCache.filter(service=>service.active).length;
  const linkedVMs=internalServicesCache.reduce((sum,service)=>sum+Number(service.vm_count||0),0);
  const configured=internalServicesCache.filter(service=>Number(service.role_mapping_count||0)>0).length;
  const rows=internalServicesCache.map(service=>`<tr><td><a href="#services/${service.id}"><strong>${e(service.name)}</strong></a>${service.description?`<div class="muted service-description">${e(service.description)}</div>`:''}</td><td><div>${e(service.architectural_domain||'—')}</div><div class="muted">${e(service.itil_category||'—')}</div></td><td class="mono">${e(service.service_code||'—')}</td><td>${criticalityBadge(service.criticality)}</td><td>${badge(service.documentation_status||'draft')}</td><td>${service.vm_count||0}</td><td>${service.role_mapping_count||0}</td><td>${service.active?badge('active'):badge('disabled')}</td><td><div class="actions"><a class="button-link small secondary" href="#services/${service.id}">Deschide</a>${can('services.manage')?`<button class="small secondary edit-internal-service" data-id="${service.id}">Editează</button>`:''}</div></td></tr>`).join('');
  content.innerHTML=`<div class="cards"><div class="card"><div class="label">Servicii definite</div><div class="value">${internalServicesCache.length}</div></div><div class="card"><div class="label">Servicii active</div><div class="value">${active}</div></div><div class="card"><div class="label">VM-uri asociate</div><div class="value">${linkedVMs}</div></div><div class="card"><div class="label">Cu roluri configurate</div><div class="value">${configured}</div></div></div>
  ${panel('Catalog servicii interne',rows?`<div class="table-wrap"><table><thead><tr><th>Serviciu intern</th><th>Domeniu / Categorie ITIL</th><th>Cod</th><th>Criticitate</th><th>Documentație</th><th>VM-uri</th><th>Layer–rol</th><th>Stare</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`:empty('Nu există servicii interne definite.'),can('services.manage')?'<button id="newInternalService">Adaugă serviciu</button>':'')}
  ${panel('Model de încadrare','<div class="service-flow"><span>Domeniu arhitectural</span><b>→</b><span>Categorie ITIL</span><b>→</b><span>Serviciu intern</span><b>→</b><span>Layer</span><b>→</b><span>Rol tehnic</span></div><p class="muted service-flow-note">Serviciul intern este obiectul documentat. Rolurile tehnice sunt legate global de layer-e în Nomenclatoare, iar serviciul selectează numai combinațiile de care are nevoie. VM-urile asociate vor fi reunite ulterior într-o singură documentație, cu fișele VM ca anexe.</p>')}`;
  document.getElementById('newInternalService')?.addEventListener('click',()=>openInternalService());
  content.querySelectorAll('.edit-internal-service').forEach(button=>button.onclick=()=>openInternalService(internalServicesCache.find(service=>service.id===Number(button.dataset.id))));
}
async function internalServiceDetail(id){
  const [service,categories]=await Promise.all([api(`/api/v1/services/${id}`),api('/api/v1/nomenclatures?include_inactive=true')]);
  serviceNomenclatureCache=categories;
  const mappingRows=(service.role_mappings||[]).map((mapping,index)=>mappingRow(mapping,categories,index)).join('');
  const vmRows=serviceVMRows(service.vms);
  const documentationLink=service.documentation_url?`<a href="${e(service.documentation_url)}" target="_blank" rel="noopener">${e(service.documentation_url)}</a>`:'—';
  pageMeta(service.name,'Serviciu intern, arhitectură logică și VM-uri asociate');
  content.innerHTML=`<div class="service-detail-toolbar"><a href="#services" class="button-link secondary">← Înapoi la servicii</a>${can('services.manage')?'<button id="editInternalService">Editează serviciul</button>':''}</div>
  <div class="cards"><div class="card"><div class="label">Criticitate</div><div class="value compact">${criticalityBadge(service.criticality)}</div></div><div class="card"><div class="label">Documentație</div><div class="value compact">${badge(service.documentation_status||'draft')}</div></div><div class="card"><div class="label">VM-uri asociate</div><div class="value">${service.vm_count||0}</div></div><div class="card"><div class="label">Combinații layer–rol</div><div class="value">${service.role_mapping_count||0}</div></div></div>
  ${panel('Identificare serviciu',`<div class="detail-grid">${detail('Serviciu intern',e(service.name))}${detail('Cod intern',e(service.service_code||'—'),true)}${detail('Domeniu arhitectural',e(service.architectural_domain||'—'))}${detail('Categorie ITIL',e(service.itil_category||'—'))}${detail('Criticitate',criticalityLabels[service.criticality]||e(service.criticality))}${detail('Status documentație',documentationStatusLabels[service.documentation_status]||e(service.documentation_status))}${detail('Activ',service.active?badge('active'):badge('disabled'))}${detail('Ultima actualizare',dt(service.updated_at))}${detail('Documentație existentă',documentationLink)}</div><div class="service-text-block"><h3>Descriere</h3><p>${e(service.description||'—')}</p><h3>Scop</h3><p>${e(service.purpose||'—')}</p></div>`) }
  ${panel('Layer-e și roluri tehnice permise',`<form id="serviceMappingsForm" class="service-mappings-form"><p class="muted">Lista de roluri este filtrată după layer pe baza relațiilor definite în Nomenclatoare. Numai combinațiile salvate aici pot fi selectate pe VM-urile serviciului.</p><div id="serviceMappingRows" class="service-mapping-rows">${mappingRows}</div>${can('services.manage')?'<div class="service-mapping-actions"><button type="button" id="addServiceMapping" class="secondary">Adaugă combinație</button><button type="submit">Salvează configurația</button></div>':'<div class="muted">Configurația este disponibilă doar pentru citire.</div>'}</form>`) }
  ${panel('VM-uri asociate',vmRows?`<div class="table-wrap"><table><thead><tr><th>VM</th><th>IP</th><th>Layer</th><th>Rol tehnic</th><th>Utilizare</th><th></th><th>Power state</th></tr></thead><tbody>${vmRows}</tbody></table></div>`:empty('Niciun VM nu este asociat încă acestui serviciu. Asocierea se face din fișa VM prin lista de asocieri multiple.'))}
  ${panel('Documentația serviciului',`<div class="documentation-preview"><div><h3>Document principal</h3><p>Prezentarea serviciului, arhitectură, dependențe, autentificare, monitorizare, backup, continuitate și responsabilități.</p></div><div><h3>Anexe VM</h3><p>${service.vm_count?`${service.vm_count} fișe VM vor putea fi atașate documentației serviciului.`:'Fișele VM vor apărea aici după asociere.'}</p></div></div><p class="muted">Motorul DOCX/PDF va folosi acest serviciu drept unitate de documentare și va include sau referi fișele VM asociate.</p>`)}`;
  document.getElementById('editInternalService')?.addEventListener('click',()=>openInternalService(service));
  const mappingContainer=document.getElementById('serviceMappingRows');
  mappingContainer?.querySelectorAll('.service-mapping-row').forEach((row,index)=>wireServiceMappingRow(row,categories,(service.role_mappings||[])[index]||{}));
  document.getElementById('addServiceMapping')?.addEventListener('click',()=>{const wrapper=document.createElement('div');wrapper.innerHTML=mappingRow(null,categories,mappingContainer.children.length);const row=wrapper.firstElementChild;mappingContainer.appendChild(row);wireServiceMappingRow(row,categories,{})});
  mappingContainer?.addEventListener('click',event=>{const button=event.target.closest('.remove-service-mapping');if(button)button.closest('.service-mapping-row').remove()});
  document.getElementById('serviceMappingsForm')?.addEventListener('submit',async event=>{event.preventDefault();if(!can('services.manage'))return;const mappings=[...mappingContainer.querySelectorAll('.service-mapping-row')].map((row,index)=>({layer_id:Number(row.querySelector('.mapping-layer').value||0),technical_role_id:Number(row.querySelector('.mapping-role').value||0),sort_order:Number(row.querySelector('.mapping-order').value||index)}));if(mappings.some(mapping=>!mapping.layer_id||!mapping.technical_role_id)){toast('Completează layer-ul și rolul tehnic pentru fiecare combinație.',true);return}try{await api(`/api/v1/services/${id}/role-mappings`,{method:'PUT',body:JSON.stringify({mappings})});toast('Combinațiile layer–rol au fost salvate.');internalServiceDetail(id)}catch(err){toast(err.message,true)}});
}
internalServiceForm.addEventListener('submit',async event=>{
  event.preventDefault();if(!can('services.manage'))return;
  const id=Number(document.getElementById('internalServiceId').value||0);
  const body={itil_category_id:Number(document.getElementById('internalServiceCategory').value||0),name:document.getElementById('internalServiceName').value.trim(),service_code:document.getElementById('internalServiceCode').value.trim(),criticality:document.getElementById('internalServiceCriticality').value,documentation_status:document.getElementById('internalServiceDocStatus').value,description:document.getElementById('internalServiceDescription').value.trim(),purpose:document.getElementById('internalServicePurpose').value.trim(),documentation_url:document.getElementById('internalServiceDocumentationURL').value.trim(),active:document.getElementById('internalServiceActive').checked};
  try{const saved=await api(id?`/api/v1/services/${id}`:'/api/v1/services',{method:id?'PATCH':'POST',body:JSON.stringify(body)});internalServiceDialog.close();toast(id?'Serviciu actualizat.':'Serviciu creat.');location.hash=`#services/${saved.id}`;if(id===saved.id&&location.hash===`#services/${saved.id}`)internalServiceDetail(saved.id)}catch(err){toast(err.message,true)}
});

let nomenclatureCache=[];
let peopleCache=[];
function updateNomenclatureParent(selected=[]){
  const category=document.getElementById('nomenclatureCategory').value;
  const parentLabel=document.getElementById('nomenclatureParentLabel');
  const parentText=document.getElementById('nomenclatureParentText');
  const parentHelp=document.getElementById('nomenclatureParentHelp');
  const parent=document.getElementById('nomenclatureParent');
  const isITIL=category==='itil_category';
  const isTechnicalRole=category==='technical_role';
  parentLabel.hidden=!(isITIL||isTechnicalRole);
  parent.required=isITIL||isTechnicalRole;
  parent.multiple=isTechnicalRole;
  parent.removeAttribute('size');
  if(isITIL){
    parentText.textContent='Domeniu arhitectural';
    parentHelp.textContent='Categoria ITIL aparține unui singur domeniu arhitectural.';
    const domains=categoryItems(nomenclatureCache,'architectural_domain');
    parent.innerHTML=selectOptions(domains,Array.isArray(selected)?selected[0]:selected,'— Alege domeniul arhitectural —');
  }else if(isTechnicalRole){
    parentText.textContent='Layer-e permise';
    parentHelp.textContent='Poți selecta unul sau mai multe layer-e. Rolul va putea fi folosit numai în aceste layer-e.';
    const layers=categoryItems(nomenclatureCache,'layer');
    parent.size=Math.min(Math.max(layers.length,4),10);
    parent.innerHTML=multiSelectOptions(layers,Array.isArray(selected)?selected:[]);
  }else{
    parentText.textContent='Relație';
    parentHelp.textContent='';
    parent.innerHTML='<option value="">— Nu se aplică —</option>';
  }
}
function openNomenclature(item=null,categoryCode='architectural_domain'){
  const selectedCategory=item?.category_code||categoryCode;
  const categoryOptions=nomenclatureCache.map(category=>`<option value="${e(category.code)}" ${selectedCategory===category.code?'selected':''}>${e(category.label)}</option>`).join('');
  document.getElementById('nomenclatureDialogTitle').textContent=item?'Editare valoare':'Valoare nouă';
  document.getElementById('nomenclatureId').value=item?.id||'';
  const category=document.getElementById('nomenclatureCategory');
  category.innerHTML=categoryOptions;
  category.disabled=Boolean(item);
  document.getElementById('nomenclatureName').value=item?.name||'';
  document.getElementById('nomenclatureCode').value=item?.item_code||'';
  document.getElementById('nomenclatureDescription').value=item?.description||'';
  document.getElementById('nomenclatureOrder').value=item?.sort_order??0;
  document.getElementById('nomenclatureActive').checked=item?.active??true;
  updateNomenclatureParent(selectedCategory==='technical_role'?(item?.layer_ids||[]):(item?.parent_id||''));
  nomenclatureDialog.showModal();
}
document.getElementById('nomenclatureCategory').addEventListener('change',()=>updateNomenclatureParent([]));
function openPerson(person=null){
  document.getElementById('personDialogTitle').textContent=person?'Editare persoană':'Persoană nouă';
  document.getElementById('personId').value=person?.id||'';
  document.getElementById('personName').value=person?.display_name||'';
  document.getElementById('personEmail').value=person?.email||'';
  document.getElementById('personPhone').value=person?.phone||'';
  document.getElementById('personDepartment').value=person?.department||'';
  document.getElementById('personActive').checked=person?.active??true;
  personDialog.showModal();
}
function nomenclaturePanel(category){
  const hasParent=category.code==='itil_category';
  const hasLayerLinks=category.code==='technical_role';
  const relationHead=hasParent?'<th>Domeniu arhitectural</th>':hasLayerLinks?'<th>Layer-e permise</th>':'';
  const head=`<tr><th>Denumire</th>${relationHead}<th>Cod</th><th>Ordine</th><th>Stare</th>${can('nomenclatures.manage')?'<th></th>':''}</tr>`;
  const rows=category.items.map(item=>{
    const relation=hasParent?`<td>${e(item.parent_name||'—')}</td>`:hasLayerLinks?`<td>${item.layer_names?.length?e(item.layer_names.join(', ')):'<span class="muted">Nemapate</span>'}</td>`:'';
    return `<tr><td><strong>${e(item.name)}</strong>${item.description?`<div class="muted">${e(item.description)}</div>`:''}</td>${relation}<td class="mono">${e(item.item_code||'—')}</td><td>${item.sort_order}</td><td>${item.active?badge('active'):badge('disabled')}</td>${can('nomenclatures.manage')?`<td><button class="small secondary edit-nomenclature" data-id="${item.id}">Editează</button></td>`:''}</tr>`;
  }).join('');
  const body=rows?`<div class="table-wrap"><table><thead>${head}</thead><tbody>${rows}</tbody></table></div>`:empty('Nu există valori definite.');
  return panel(e(category.label),body,can('nomenclatures.manage')?`<button class="small add-nomenclature" data-category="${e(category.code)}">Adaugă</button>`:'');
}
async function nomenclaturesPage(){
  pageMeta('Nomenclatoare','Liste controlate. Serviciile interne se administrează separat din meniul Servicii.');
  [nomenclatureCache,peopleCache]=await Promise.all([api('/api/v1/nomenclatures?include_inactive=true'),api('/api/v1/people?include_inactive=true')]);
  const categoryPanels=nomenclatureCache.map(nomenclaturePanel).join('');
  const peopleRows=peopleCache.map(person=>`<tr><td><strong>${e(person.display_name)}</strong><div class="muted">${e(person.department||'')}</div></td><td>${e(person.email||'—')}</td><td>${e(person.phone||'—')}</td><td>${person.active?badge('active'):badge('disabled')}</td>${can('nomenclatures.manage')?`<td><button class="small secondary edit-person" data-id="${person.id}">Editează</button></td>`:''}</tr>`).join('');
  const peopleHead=`<tr><th>Persoană</th><th>Email</th><th>Telefon</th><th>Stare</th>${can('nomenclatures.manage')?'<th></th>':''}</tr>`;
  content.innerHTML=`${panel('Structura catalogului','<div class="service-flow"><span>Domeniu arhitectural</span><b>→</b><span>Categorie ITIL</span><b>→</b><span class="flow-external">Serviciu intern</span><b>→</b><span>Layer</span><b>→</b><span>Rol tehnic</span></div><p class="muted service-flow-note">Categoriile ITIL sunt legate de un domeniu. Fiecare rol tehnic este legat de unul sau mai multe layer-e, iar serviciile interne pot folosi numai combinațiile valide.</p>')}
  <div class="catalog-grid">${categoryPanels}</div>
  ${panel('Persoane',peopleRows?`<div class="table-wrap"><table><thead>${peopleHead}</thead><tbody>${peopleRows}</tbody></table></div>`:empty('Nu există persoane definite.'),can('nomenclatures.manage')?'<button id="addPerson">Adaugă persoană</button>':'')}`;
  content.querySelectorAll('.add-nomenclature').forEach(button=>button.onclick=()=>openNomenclature(null,button.dataset.category));
  content.querySelectorAll('.edit-nomenclature').forEach(button=>button.onclick=()=>{const item=nomenclatureCache.flatMap(category=>category.items).find(value=>value.id===Number(button.dataset.id));openNomenclature(item)});
  document.getElementById('addPerson')?.addEventListener('click',()=>openPerson());
  content.querySelectorAll('.edit-person').forEach(button=>button.onclick=()=>openPerson(peopleCache.find(person=>person.id===Number(button.dataset.id))));
}

nomenclatureForm.addEventListener('submit',async event=>{
  event.preventDefault();if(!can('nomenclatures.manage'))return;
  const id=Number(document.getElementById('nomenclatureId').value||0);
  const categoryCode=document.getElementById('nomenclatureCategory').value;
  const parent=document.getElementById('nomenclatureParent');
  const parentValue=parent.value;
  const layerIDs=categoryCode==='technical_role'?[...parent.selectedOptions].map(option=>Number(option.value)).filter(Boolean):[];
  const body={category_code:categoryCode,name:document.getElementById('nomenclatureName').value.trim(),item_code:document.getElementById('nomenclatureCode').value.trim(),description:document.getElementById('nomenclatureDescription').value.trim(),sort_order:Number(document.getElementById('nomenclatureOrder').value||0),active:document.getElementById('nomenclatureActive').checked,parent_id:categoryCode==='itil_category'&&parentValue?Number(parentValue):null,layer_ids:layerIDs};
  try{await api(id?`/api/v1/nomenclatures/items/${id}`:'/api/v1/nomenclatures/items',{method:id?'PATCH':'POST',body:JSON.stringify(body)});nomenclatureDialog.close();toast(id?'Valoare actualizată.':'Valoare creată.');nomenclaturesPage()}catch(err){toast(err.message,true)}
});
personForm.addEventListener('submit',async event=>{
  event.preventDefault();if(!can('nomenclatures.manage'))return;
  const id=Number(document.getElementById('personId').value||0);const body={display_name:document.getElementById('personName').value.trim(),email:document.getElementById('personEmail').value.trim(),phone:document.getElementById('personPhone').value.trim(),department:document.getElementById('personDepartment').value.trim(),active:document.getElementById('personActive').checked};
  try{await api(id?`/api/v1/people/${id}`:'/api/v1/people',{method:id?'PATCH':'POST',body:JSON.stringify(body)});personDialog.close();toast(id?'Persoană actualizată.':'Persoană creată.');nomenclaturesPage()}catch(err){toast(err.message,true)}
});

async function auditPage(){pageMeta('Audit','Acțiuni administrative și operaționale');content.innerHTML=panel('Evenimente de audit','<div id="auditTableArea" class="loading">Se încarcă evenimentele…</div>');await loadAuditPage()}
function renderAuditPage(result){
  const items=Array.isArray(result?.items)?result.items:[];
  if(!items.length)return empty('Nu există evenimente de audit.');
  const rows=items.map(record=>`<tr><td>${dt(record.occurred_at)}</td><td>${e(record.source)}</td><td>${e(record.actor_username||'sistem')}</td><td class="mono">${e(record.action)}</td><td>${e(record.resource_type)} ${e(record.resource_id)}</td><td>${badge(record.outcome)}</td></tr>`).join('');
  const total=Number(result.total||0),page=Number(result.page||1),pageSize=Number(result.page_size||50),start=(page-1)*pageSize+1,end=Math.min(page*pageSize,total);
  return `<div class="table-wrap"><table><thead><tr><th>Data</th><th>Sursă</th><th>Actor</th><th>Acțiune</th><th>Resursă</th><th>Rezultat</th></tr></thead><tbody>${rows}</tbody></table></div><div class="pagination"><span>Afișate ${start.toLocaleString('ro-RO')}–${end.toLocaleString('ro-RO')} din ${total.toLocaleString('ro-RO')}</span><div class="pagination-buttons"><label class="pagination-size">Pe pagină <select id="auditPageSize">${pageSizeOptions(pageSize,[25,50,100,200])}</select></label>${paginationButtons(page,Number(result.pages||1),'audit-page')}</div></div>`;
}
async function loadAuditPage(){
  const area=document.getElementById('auditTableArea');if(!area)return;area.className='loading';area.textContent='Se încarcă evenimentele…';
  try{const result=await api(`/api/v1/audit/events?page=${state.audit.page}&page_size=${state.audit.pageSize}`);state.audit.page=Number(result?.page||1);state.audit.pageSize=Number(result?.page_size||50);area.className='';area.innerHTML=renderAuditPage(result);area.querySelectorAll('.audit-page').forEach(button=>button.addEventListener('click',()=>{const page=Number(button.dataset.page);if(page>0&&page!==state.audit.page){state.audit.page=page;loadAuditPage()}}));document.getElementById('auditPageSize')?.addEventListener('change',event=>{state.audit.pageSize=Number(event.target.value);state.audit.page=1;loadAuditPage()})}catch(err){area.className='';area.innerHTML=empty(err.message);toast(err.message,true)}
}

async function accessPage(){pageMeta('Acces','Mapări grupuri LDAP/OIDC către roluri');const [roles,maps]=await Promise.all([api('/api/v1/rbac/roles'),api('/api/v1/rbac/group-mappings')]);content.innerHTML=`${panel('Adaugă mapare',`<form id="mappingForm" class="detail-grid"><label>Provider<select id="mapProvider"><option value="ldap">LDAP</option><option value="oidc">OIDC</option><option value="any">Oricare</option></select></label><label>Grup<input id="mapGroup" required placeholder="VM-DOC-Operators"></label><label>Rol<select id="mapRole">${roles.map(r=>`<option value="${e(r.name)}">${e(r.name)}</option>`).join('')}</select></label><label class="form-submit"><button type="submit">Adaugă</button></label></form>`)}${panel('Mapări existente',maps.length?`<div class="table-wrap"><table><thead><tr><th>Provider</th><th>Grup</th><th>Rol</th><th></th></tr></thead><tbody>${maps.map(m=>`<tr><td>${e(m.provider)}</td><td class="mono">${e(m.group_name)}</td><td>${badge(m.role)}</td><td><button class="small danger del-map" data-id="${m.id}">Șterge</button></td></tr>`).join('')}</tbody></table></div>`:empty('Nu există mapări.'))}`;
  document.getElementById('mappingForm').onsubmit=async ev=>{ev.preventDefault();await api('/api/v1/rbac/group-mappings',{method:'POST',body:JSON.stringify({provider:document.getElementById('mapProvider').value,group_name:document.getElementById('mapGroup').value.trim(),role:document.getElementById('mapRole').value})});toast('Mapare creată.');accessPage()};content.querySelectorAll('.del-map').forEach(b=>b.onclick=async()=>{await api(`/api/v1/rbac/group-mappings/${b.dataset.id}`,{method:'DELETE'});toast('Mapare ștearsă.');accessPage()})
}

document.getElementById('logoutButton').onclick=async()=>{await api('/api/v1/auth/logout',{method:'POST'});location.href='/login'};
document.getElementById('themeButton').onclick=()=>{const next=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=next;localStorage.setItem('vm-doc-theme',next)};
const savedTheme=localStorage.getItem('vm-doc-theme');if(savedTheme)document.documentElement.dataset.theme=savedTheme;
window.addEventListener('hashchange',route);
document.querySelectorAll('[data-close-dialog]').forEach(button=>button.addEventListener('click',()=>button.closest('dialog').close()));
init();

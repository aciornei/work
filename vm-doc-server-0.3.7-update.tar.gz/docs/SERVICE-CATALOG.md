# Catalogul serviciilor interne

## Scop

Catalogul separă clasificarea ITIL de serviciul tehnic documentat. Un serviciu intern, de exemplu `Metabase`, este obiectul pentru care va fi generată documentația completă. VM-urile asociate sunt incluse ulterior ca fișe sau referințe în anexele documentului.

## Ierarhie

```text
Domeniu arhitectural
  → Categorie ITIL
    → Serviciu intern

Layer arhitectural
  → Roluri tehnice permise
    → combinații selectate de Serviciul intern
      → asocieri multiple pe VM
```

## Reguli

- fiecare categorie ITIL are exact un domeniu arhitectural părinte;
- fiecare serviciu intern aparține unei categorii ITIL;
- fiecare rol tehnic aparține unuia sau mai multor layer-e;
- fiecare serviciu selectează numai combinații layer–rol valide global;
- un VM poate fi asociat cu mai multe servicii interne;
- același serviciu poate apărea de mai multe ori pe același VM, cu layer și rol diferite;
- combinația `VM + serviciu + layer + rol` este unică;
- cel mult o asociere a VM-ului poate fi marcată principală;
- backendul validează combinațiile, nu doar interfața browserului.

Această validare împiedică atât alegerea `Solr` în layer-ul `Bază de date`, cât și asocierea lui unui serviciu intern de mail dacă perechea nu a fost permisă explicit pentru serviciu.

## Exemple

```text
metabase-allinone-01
  Metabase → Aplicație → Metabase Application [principal, dedicat]
  Metabase → Bază de date → PostgreSQL [dedicat]
  Metabase → Stocare → File storage [dedicat]
```

```text
shared-redis-01
  Nextcloud → Cache și sesiuni → Redis [partajat]
  Roundcube → Cache și sesiuni → Redis Sessions [partajat]
  Airflow → Mesagerie și transport → Redis Broker [partajat]
```

## Meniul Servicii

Pentru fiecare serviciu intern se administrează:

- denumirea și codul intern;
- domeniul și categoria ITIL;
- descrierea și scopul;
- criticitatea și starea documentației;
- linkul către documentația existentă;
- combinațiile layer–rol permise;
- toate asocierile VM, inclusiv tipul de utilizare și marcajul principal.

## Documentația viitoare

Unitatea de documentare va fi serviciul intern. Un VM partajat poate fi referit de mai multe servicii, fără duplicarea sursei sale de adevăr.

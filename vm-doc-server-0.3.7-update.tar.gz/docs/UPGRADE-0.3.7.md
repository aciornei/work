# Upgrade la vm-doc-server 0.3.7

Versiunea 0.3.7 leagă explicit fiecare **Rol tehnic** de unul sau mai multe **Layer-e arhitecturale**.

## Model

```text
Layer arhitectural
  └── Roluri tehnice permise
        └── combinații selectate de Serviciul intern
              └── asocieri pe VM
```

Un rol precum `PostgreSQL` poate fi legat de `Bază de date`, iar `Solr` de `Căutare și indexare`. Pagina Serviciului intern afișează în lista de roluri numai valorile permise pentru layer-ul ales. Aceeași regulă este verificată și în API.

## Migrare

La prima pornire este aplicată:

```text
015_layer_technical_role_mappings.up.sql
```

Migrarea creează relația globală layer–rol și copiază automat toate perechile deja folosite în configurațiile serviciilor interne sau în asocierile VM. Rolurile tehnice existente care nu au fost folosite nicăieri rămân marcate `Nemapate` și trebuie editate din **Nomenclatoare → Rol tehnic**.

## Pași

1. Faceți backup la MariaDB, configurație și binarele active.
2. Compilați sursa 0.3.7 cu directorul `vendor/` existent.
3. Opriți `vm-doc-collector` și `vm-doc-server`.
4. Înlocuiți binarele.
5. Porniți mai întâi `vm-doc-server` și verificați migrarea `015` în jurnal.
6. Porniți `vm-doc-collector`.
7. Faceți `Ctrl+F5` în browser.

## Verificare

- în **Nomenclatoare → Rol tehnic**, fiecare rol afișează layer-ele permise;
- la crearea sau editarea unui rol este obligatoriu cel puțin un layer;
- în pagina unui Serviciu intern, alegerea layer-ului filtrează rolurile;
- API-ul respinge o combinație layer–rol care nu există în relația globală;
- o relație layer–rol utilizată de un serviciu sau VM nu poate fi eliminată până când utilizarea este retrasă.
